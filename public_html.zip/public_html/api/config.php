<?php
// api/config.php - إعدادات API مع دعم .env

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// معالجة طلبات OPTIONS للـ CORS
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    exit(0);
}

// تحميل بيئة .env (إن لم تُحمَّل بعد)
require_once __DIR__ . '/../includes/env.php';

// تحديد البيئة: local | production
$appEnv = env('APP_ENV', 'production');

// إعدادات قاعدة البيانات (من .env)
if ($appEnv === 'production') {
    define('DB_HOST', env('DB_HOST_PROD', 'localhost'));
    define('DB_USER', env('DB_USER_PROD', ''));
    define('DB_PASS', env('DB_PASS_PROD', ''));
    define('DB_NAME', env('DB_NAME_PROD', ''));
} else {
    define('DB_HOST', env('DB_HOST_LOCAL', 'localhost'));
    define('DB_USER', env('DB_USER_LOCAL', 'root'));
    define('DB_PASS', env('DB_PASS_LOCAL', ''));
    define('DB_NAME', env('DB_NAME_LOCAL', 'onlinestore'));
}

define('SITE_URL', env('SITE_URL', 'https://mariastore1.com/'));

// إعدادات PDO
try {
    $conn = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]
    );

    $conn->exec("SET NAMES utf8mb4");

} catch (PDOException $e) {
    echo json_encode([
        'success' => false,
        'error' => 'فشل الاتصال بقاعدة البيانات'
    ]);
    exit;
}

function sendResponse($data, $status = 200) {
    http_response_code($status);
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

function sendError($message, $status = 400) {
    sendResponse(['success' => false, 'error' => $message], $status);
}
?>

<?php
require_once 'config.php';

try {
    // استعلام أبسط مع معالجة أخطاء InfinityFree
    $stmt = $conn->query("
        SELECT id, title, description, image_url, link 
        FROM sliders 
        WHERE is_active = 1 
        ORDER BY sort_order ASC 
        LIMIT 5
    ");
    
    $sliders = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // معالجة URLs للصور
    foreach ($sliders as &$slider) {
        $slider['image_url'] = SITE_URL . 'assets/images/banners/' . $slider['image_url'];
        $slider['mobile_image_url'] = SITE_URL . 'assets/images/banners/mobile/' . $slider['image_url'];
    }
    
    sendResponse([
        'success' => true,
        'data' => $sliders
    ]);
    
} catch (PDOException $e) {
    error_log('API sliders error: ' . $e->getMessage());
    sendError('حدث خطأ داخلي في الخادم', 500);
}
?>
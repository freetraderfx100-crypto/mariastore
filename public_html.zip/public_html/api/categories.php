<?php
require_once 'config.php';

try {
    $stmt = $conn->query("
        SELECT id, name, image as sample_image, parent_id
        FROM categories 
        WHERE parent_id IS NOT NULL
        AND image IS NOT NULL
        AND image != ''
        ORDER BY name 
        LIMIT 15
    ");
    
    $categories = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // معالجة URLs للصور
    foreach ($categories as &$category) {
        if (!empty($category['sample_image'])) {
            // تنظيف المسار
            $clean_image = $category['sample_image'];
            
            // إزالة الـ domain القديم إذا وجد
            $clean_image = str_replace('https://mariastore1.com/', '', $clean_image);
            $clean_image = str_replace('assets/images/', '', $clean_image);
            
            // إذا كان المسار لا يحتوي على uploads/categories، أضفه
            if (strpos($clean_image, 'uploads/categories') === false) {
                $clean_image = 'uploads/categories/' . $clean_image;
            }
            
            $category['sample_image'] = SITE_URL . 'assets/images/' . $clean_image;
        } else {
            // صورة افتراضية
            $category['sample_image'] = SITE_URL . 'assets/images/default-category.jpg';
        }
    }
    
    echo json_encode([
        'success' => true,
        'data' => $categories,
        'count' => count($categories)
    ], JSON_UNESCAPED_UNICODE);
    
} catch (PDOException $e) {
    error_log('API categories error: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'حدث خطأ داخلي في الخادم'
    ], JSON_UNESCAPED_UNICODE);
}
?>
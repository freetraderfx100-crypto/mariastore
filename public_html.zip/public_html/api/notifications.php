<?php
/**
 * api/notifications.php
 * --------------------------------------------------------------------
 * REST API لنظام الإشعارات
 *
 * ✅ إصدار: v2.0
 *    - دعم visitor_session من localStorage عبر X-Visitor-Session header
 *    - CSRF token إلزامي لكل طلبات POST
 *    - تصدير visitor_session الجديد للعميل (للأول مرة)
 *
 * Endpoints (all return JSON):
 *   GET  api/notifications.php?action=list&limit=20&offset=0
 *   GET  api/notifications.php?action=unread_count
 *   GET  api/notifications.php?action=vapid_public_key
 *   POST api/notifications.php?action=mark_read       (id=...)     [CSRF + Visitor]
 *   POST api/notifications.php?action=mark_all_read                [CSRF + Visitor]
 *   POST api/notifications.php?action=subscribe      (subscription) [CSRF + Visitor]
 *   POST api/notifications.php?action=unsubscribe    (endpoint)     [CSRF + Visitor]
 * --------------------------------------------------------------------
 */

require_once __DIR__ . '/../includes/db_connect.php';
require_once __DIR__ . '/../includes/notifications.php';

header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');

// ✅ CORS: نفس النطاق فقط (أمان)
$origin = $_SERVER['HTTP_ORIGIN'] ?? '';
$allowed_origins = [SITE_URL, rtrim(SITE_URL, '/')];
if (in_array($origin, $allowed_origins)) {
    header("Access-Control-Allow-Origin: {$origin}");
    header('Access-Control-Allow-Credentials: true');
    header('Vary: Origin');
    header('Access-Control-Allow-Headers: Content-Type, X-CSRF-Token, X-Visitor-Session');
    header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
}

// رفض الطلبات غير POST/GET
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
if (!in_array($method, ['GET', 'POST', 'OPTIONS'])) {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit;
}

if ($method === 'OPTIONS') {
    http_response_code(204);
    exit;
}

// بدء الجلسة
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ✅ توليد CSRF token إن لم يكن موجوداً (يُولّد مرة واحدة لكل جلسة)
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// ✅ التحقق من CSRF token لكل طلبات POST
if ($method === 'POST') {
    $csrf_token = $_SERVER['HTTP_X_CSRF_TOKEN']
        ?? $_POST['csrf_token']
        ?? '';

    if (empty($csrf_token) || !hash_equals($_SESSION['csrf_token'], $csrf_token)) {
        http_response_code(403);
        echo json_encode([
            'success' => false,
            'error' => 'CSRF token invalid or missing',
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }
}

// التعرف على المستخدم/الزائر
$user_id = $_SESSION['user_id'] ?? null;

// ✅ visitor_session: نقرأه من header أولاً (localStorage) ثم من session كاحتياط
$visitor_session = $_SERVER['HTTP_X_VISITOR_SESSION'] ?? '';

// التحقق من صحة الصيغة (منع حقن SQL / XSS)
if (!empty($visitor_session)) {
    if (!preg_match('/^vs_[a-f0-9]{32}$/', $visitor_session)) {
        $visitor_session = '';
    }
}

// لو لم يُرسل عبر header، نستخدم session كاحتياط (للمتصفحات القديمة)
if (empty($visitor_session)) {
    if (empty($_SESSION['visitor_session_id'])) {
        $_SESSION['visitor_session_id'] = 'vs_' . bin2hex(random_bytes(16));
    }
    $visitor_session = $_SESSION['visitor_session_id'];
}

$action = $_GET['action'] ?? $_POST['action'] ?? '';

try {
    $manager = new NotificationsManager($conn);

    switch ($action) {

        case 'list':
            $limit = min(50, max(1, intval($_GET['limit'] ?? 20)));
            $offset = max(0, intval($_GET['offset'] ?? 0));

            $notifications = $manager->getForUser($user_id, $visitor_session, $limit, $offset);

            echo json_encode([
                'success' => true,
                'data' => $notifications,
                'count' => count($notifications),
                'user_id' => $user_id,
                'visitor_session' => $visitor_session,
                // ✅ إرسال CSRF token للعميل (لطلبات POST اللاحقة)
                'csrf_token' => $_SESSION['csrf_token'],
            ], JSON_UNESCAPED_UNICODE);
            break;

        case 'unread_count':
            $count = $manager->getUnreadCount($user_id, $visitor_session);
            echo json_encode([
                'success' => true,
                'count' => $count,
            ], JSON_UNESCAPED_UNICODE);
            break;

        case 'mark_read':
            if ($method !== 'POST') {
                http_response_code(405);
                echo json_encode(['success' => false, 'error' => 'POST required']);
                exit;
            }
            $notif_id = intval($_POST['id'] ?? 0);
            if ($notif_id <= 0) {
                // محاولة قراءة من JSON body
                $input = json_decode(file_get_contents('php://input'), true);
                $notif_id = intval($input['id'] ?? 0);
            }
            if ($notif_id <= 0) {
                http_response_code(400);
                echo json_encode(['success' => false, 'error' => 'id required']);
                exit;
            }
            $ok = $manager->markAsRead($notif_id, $user_id, $visitor_session);
            echo json_encode(['success' => $ok], JSON_UNESCAPED_UNICODE);
            break;

        case 'mark_all_read':
            if ($method !== 'POST') {
                http_response_code(405);
                echo json_encode(['success' => false, 'error' => 'POST required']);
                exit;
            }
            $ok = $manager->markAllAsRead($user_id, $visitor_session);
            echo json_encode(['success' => $ok], JSON_UNESCAPED_UNICODE);
            break;

        case 'subscribe':
            if ($method !== 'POST') {
                http_response_code(405);
                echo json_encode(['success' => false, 'error' => 'POST required']);
                exit;
            }

            $input = json_decode(file_get_contents('php://input'), true);
            if (!$input) {
                $input = $_POST;
            }

            $subscription = $input['subscription'] ?? null;
            if (!$subscription || empty($subscription['endpoint'])) {
                http_response_code(400);
                echo json_encode(['success' => false, 'error' => 'subscription required']);
                exit;
            }

            $ok = $manager->subscribePush($subscription, $user_id);
            echo json_encode([
                'success' => $ok,
                'message' => $ok ? 'تم الاشتراك بنجاح' : 'فشل الاشتراك',
            ], JSON_UNESCAPED_UNICODE);
            break;

        case 'unsubscribe':
            if ($method !== 'POST') {
                http_response_code(405);
                echo json_encode(['success' => false, 'error' => 'POST required']);
                exit;
            }

            $input = json_decode(file_get_contents('php://input'), true);
            $endpoint = $input['endpoint'] ?? $_POST['endpoint'] ?? '';

            if (empty($endpoint)) {
                http_response_code(400);
                echo json_encode(['success' => false, 'error' => 'endpoint required']);
                exit;
            }

            $ok = $manager->unsubscribePush($endpoint);
            echo json_encode(['success' => $ok], JSON_UNESCAPED_UNICODE);
            break;

        case 'vapid_public_key':
            // إرسال المفتاح العمومي للعميل (للاشتراك في Web Push)
            $key = $manager->getSetting('vapid_public_key', '');
            echo json_encode([
                'success' => true,
                'public_key' => $key,
                'web_push_enabled' => $manager->getSetting('web_push_enabled', '0') === '1',
                // ✅ إرسال CSRF token هنا أيضاً (يُستدعى في بداية تحميل الصفحة)
                'csrf_token' => $_SESSION['csrf_token'],
            ], JSON_UNESCAPED_UNICODE);
            break;

        default:
            http_response_code(400);
            echo json_encode([
                'success' => false,
                'error' => 'unknown action',
                'available_actions' => ['list', 'unread_count', 'mark_read', 'mark_all_read', 'subscribe', 'unsubscribe', 'vapid_public_key'],
            ], JSON_UNESCAPED_UNICODE);
    }

} catch (Exception $e) {
    error_log("API notifications error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'حدث خطأ داخلي',
    ], JSON_UNESCAPED_UNICODE);
}

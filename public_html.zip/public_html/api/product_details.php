<?php
require_once 'config.php';

$product_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if (!$product_id) {
    sendError('معرف المنتج مطلوب');
}

try {
    // استعلام مطابق لاستعلام الموقع الرئيسي
    $stmt = $conn->prepare("
        SELECT 
            p.*,
            p.price * (1 - p.discount_percentage/100) as discounted_price,
            GROUP_CONCAT(DISTINCT pv.image_url ORDER BY pv.id SEPARATOR '|||') as variant_images
        FROM products p
        LEFT JOIN product_variants pv ON p.id = pv.product_id
        WHERE p.id = :id AND p.is_active = 1
        GROUP BY p.id
    ");
    
    $stmt->bindValue(':id', $product_id, PDO::PARAM_INT);
    $stmt->execute();
    
    $product = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$product) {
        sendError('المنتج غير موجود', 404);
    }
    
    // معالجة الصور بنفس طريقة الموقع الرئيسي
    $images = array_filter(explode('|||', $product['variant_images']));
    if (empty($images)) {
        $images[] = 'default-product-image.jpg';
    }
    
    $product['images'] = [];
    foreach ($images as $image) {
        $product['images'][] = SITE_URL . 'assets/images/' . ltrim($image, '/');
    }
    
    unset($product['variant_images']);
    
    // جلب الألوان والمقاسات المتاحة
    $variants_stmt = $conn->prepare("
        SELECT DISTINCT color, size 
        FROM product_variants 
        WHERE product_id = :product_id 
        AND stock_quantity > 0
    ");
    $variants_stmt->bindValue(':product_id', $product_id, PDO::PARAM_INT);
    $variants_stmt->execute();
    
    $product['available_colors'] = $variants_stmt->fetchAll(PDO::FETCH_COLUMN, 0);
    $product['available_sizes'] = $variants_stmt->fetchAll(PDO::FETCH_COLUMN, 1);
    
    sendResponse([
        'success' => true,
        'data' => $product
    ]);
    
} catch (PDOException $e) {
    error_log('API product_details error: ' . $e->getMessage());
    sendError('حدث خطأ داخلي في الخادم', 500);
}
?>
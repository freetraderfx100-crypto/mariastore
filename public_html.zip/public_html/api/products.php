<?php
require_once 'config.php';

error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$limit = isset($_GET['limit']) ? min(20, max(1, (int)$_GET['limit'])) : 12;
$offset = ($page - 1) * $limit;

try {
    // جلب إجمالي عدد المنتجات
    $total_stmt = $conn->query("SELECT COUNT(*) as total FROM products WHERE is_active = 1");
    $total = $total_stmt->fetchColumn();
    
    // استعلام محسن لجلب جميع الصور
    $sql = "
        SELECT 
            p.id,
            p.name,
            p.description,
            p.price,
            p.discount_percentage,
            p.discount_end_date,
            p.created_at,
            p.cost_price,
            p.category_id,
            p.sku,
            CASE 
                WHEN p.discount_percentage > 0 AND (p.discount_end_date IS NULL OR p.discount_end_date >= CURDATE()) 
                THEN 1 
                ELSE 0 
            END as has_discount,
            COALESCE(
                (SELECT GROUP_CONCAT(image_urls SEPARATOR '|') 
                 FROM product_variants 
                 WHERE product_id = p.id AND image_urls IS NOT NULL AND image_urls != '[]'),
                '[]'
            ) as all_image_urls
        FROM products p
        WHERE p.is_active = 1
        GROUP BY p.id
        ORDER BY p.created_at DESC
        LIMIT :limit OFFSET :offset
    ";
    
    $stmt = $conn->prepare($sql);
    $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
    $stmt->execute();
    
    $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // معالجة الصور لجميع الحالات
    foreach ($products as &$product) {
        $images = [];
        
        if (!empty($product['all_image_urls']) && $product['all_image_urls'] != '[]') {
            $all_urls = $product['all_image_urls'];
            
            // تقسيم URLs من جميع المتغيرات
            $variants_urls = explode('|', $all_urls);
            
            foreach ($variants_urls as $variant_urls) {
                if (!empty($variant_urls) && $variant_urls != '[]') {
                    
                    // المحاولة 1: معالجة كـ JSON
                    if (strpos($variant_urls, '[') === 0) {
                        $decoded = json_decode($variant_urls, true);
                        if (json_last_error() === JSON_ERROR_NONE && is_array($decoded)) {
                            foreach ($decoded as $img_path) {
                                $clean_path = cleanImagePath($img_path);
                                if ($clean_path) {
                                    $images[] = SITE_URL . 'assets/images/' . $clean_path;
                                }
                            }
                        }
                    }
                    
                    // المحاولة 2: معالجة كسلسلة نصية
                    else {
                        // إذا كانت تحتوي على فواصل
                        if (strpos($variant_urls, ',') !== false) {
                            $image_array = explode(',', $variant_urls);
                            foreach ($image_array as $img) {
                                $clean_path = cleanImagePath($img);
                                if ($clean_path) {
                                    $images[] = SITE_URL . 'assets/images/' . $clean_path;
                                }
                            }
                        } else {
                            // صورة واحدة
                            $clean_path = cleanImagePath($variant_urls);
                            if ($clean_path) {
                                $images[] = SITE_URL . 'assets/images/' . $clean_path;
                            }
                        }
                    }
                }
            }
        }
        
        // إزالة التكرارات والحفاظ على الترتيب
        $images = array_unique($images);
        $images = array_values($images);
        
        $product['images'] = !empty($images) ? $images : [SITE_URL . 'assets/images/default-product-image.jpg'];
        unset($product['all_image_urls']);
        
        // إضافة الحقول المفقودة
        $product['rating'] = null;
        $product['review_count'] = null;
        $product['is_featured'] = false;
        
        // DEBUG
        error_log("🎯 {$product['name']} - الصور: " . count($product['images']));
    }
    
    http_response_code(200);
    echo json_encode([
        'success' => true,
        'data' => $products,
        'pagination' => [
            'current_page' => $page,
            'per_page' => $limit,
            'total' => (int)$total,
            'total_pages' => ceil($total / $limit)
        ]
    ], JSON_UNESCAPED_UNICODE);
    
} catch (Exception $e) {
    error_log('API products error: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'حدث خطأ داخلي في الخادم'
    ], JSON_UNESCAPED_UNICODE);
}

function cleanImagePath($path) {
    if (empty(trim($path))) return null;
    
    $clean = trim($path);
    $clean = str_replace(['\\', '"', "'", '[', ']', '\n', '\r'], '', $clean);
    $clean = preg_replace('/\s+/', ' ', $clean);
    $clean = trim($clean);
    
    if (strpos($clean, 'http') === 0) {
        $base_url = SITE_URL . 'assets/images/';
        $clean = str_replace($base_url, '', $clean);
    }
    
    $clean = str_replace('assets/images/', '', $clean);
    $clean = ltrim($clean, '/');
    
    if (strpos($clean, 'products/') !== 0 && strpos($clean, 'http') !== 0) {
        $clean = 'products/' . $clean;
    }
    
    return !empty($clean) ? $clean : null;
}
?>
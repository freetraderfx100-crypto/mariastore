/**
 * sw.js - Service Worker لنظام الإشعارات الأصلي (VAPID + Web Push)
 * --------------------------------------------------------------------
 * ✅ إصدار: v6.0 (يدعم صور المنتجات في الإشعارات + تحسين fallback)
 * --------------------------------------------------------------------
 */

const SW_VERSION = 'v7.0';
const CACHE_NAME = 'maria-store-v7';

// ============================================================
// 1. التثبيت
// ============================================================
self.addEventListener('install', (event) => {
    console.log('[SW] Installing...');
    self.skipWaiting();
    event.waitUntil(
        caches.open(CACHE_NAME).then(() => {}).catch(() => {})
    );
});

// ============================================================
// 2. التفعيل
// ============================================================
self.addEventListener('activate', (event) => {
    console.log('[SW v7.0] Activating...');
    event.waitUntil(
        Promise.all([
            self.clients.claim(),
            // ✅ حذف كل الكاش القديم فقط (بدون إعادة تحميل الصفحات)
            caches.keys().then((cacheNames) => {
                return Promise.all(
                    cacheNames.map((name) => caches.delete(name))
                );
            }),
        ])
    );
});

// ============================================================
// 3. استقبال Web Push - حتى والمتصفح مغلق
// ============================================================
self.addEventListener('push', (event) => {
    console.log('[SW] Push received at:', new Date().toISOString());

    let data = {};
    try {
        data = event.data ? event.data.json() : {};
    } catch (e) {
        data = {
            title: 'إشعار جديد',
            body: event.data ? event.data.text() : '',
        };
    }

    const title = data.title || 'إشعار من متجر ماريا';
    
    // ✅ تحديد SITE_URL (من الـ origin)
    const siteOrigin = self.location.origin;
    
    // ✅ v6.0: تحسين عرض صورة المنتج في الإشعار
    // الأولوية: صورة المنتج → أيقونة من البيانات → أيقونة افتراضية
    const productImage = data.image || null;
    const serverIcon = data.icon || null;

    // ✅ نختار الأيقونة النهائية:
    // 1. صورة المنتج (لو موجودة) - أفضل خيار
    // 2. الأيقونة من الخادم (data.icon)
    // 3. أيقونة الموقع الافتراضية
    const finalIcon = productImage || serverIcon || (siteOrigin + '/assets/icons/icon-192.png');

    // ✅ v7.0: تحسين عرض الإشعار حتى لو المتصفح مغلق
    // requireInteraction: false (Chrome يخفيه بعد 5-10 ثوان تلقائياً)
    // لكن نستخدم tag فريد لكل إشعار حتى لا يستبدل الإشعارات السابقة
    const options = {
        body: data.body || '',
        // ✅ استخدم صورة المنتج كأيقونة رئيسية (مدعومة على كل المتصفحات)
        icon: finalIcon,
        // ✅ badge: الأيقونة الصغيرة (شريط الحالة) - نستخدم data.badge أو fallback
        badge: data.badge || (siteOrigin + '/assets/icons/badge-72.png'),
        // ✅ image: صورة كبيرة بجانب النص (Chrome Desktop فقط) - نستخدم صورة المنتج
        image: productImage || undefined,
        dir: 'rtl',
        lang: 'ar',
        // ✅ tag فريد لكل إشعار (لا نستبدل الإشعارات السابقة)
        tag: data.tag || `notif-${data.id || Date.now()}`,
        // ✅ renotify: true يوقظ المستخدم بإشعار صوتي حتى لو tag مكرر
        renotify: true,
        // ✅ requireInteraction: false (الإشعار يختفي تلقائياً بعد فترة)
        // لكن يبقى في مركز الإشعارات (Notification Center)
        requireInteraction: false,
        data: {
            url: data.url || '/',
            notification_id: data.id || null,
            timestamp: Date.now(),
        },
        actions: [
            { action: 'open', title: 'فتح المتجر' },
            { action: 'close', title: 'إغلاق' },
        ],
        vibrate: [300, 100, 300, 100, 300],
        silent: false,
        // ✅ v7.0: timestamp يضمن ترتيب الإشعارات حسب الوقت
        timestamp: data.timestamp || Date.now(),
    };

    event.waitUntil(
        self.registration.showNotification(title, options)
    );
});

// ============================================================
// 4. النقر على الإشعار
// ============================================================
self.addEventListener('notificationclick', (event) => {
    console.log('[SW] Notification click:', event);

    event.notification.close();

    if (event.action === 'close') {
        return;
    }

    const targetUrl = event.notification.data?.url || '/';

    event.waitUntil(
        clients.matchAll({ 
            type: 'window', 
            includeUncontrolled: true 
        }).then((clientList) => {
            for (const client of clientList) {
                if ('focus' in client) {
                    client.navigate(targetUrl);
                    return client.focus();
                }
            }
            if (clients.openWindow) {
                return clients.openWindow(targetUrl);
            }
        })
    );
});

// ============================================================
// 5. إغلاق الإشعار
// ============================================================
self.addEventListener('notificationclose', (event) => {
    console.log('[SW] Notification closed:', event);
});

// ============================================================
// 6. رسائل من الصفحة
// ============================================================
self.addEventListener('message', (event) => {
    console.log('[SW] Message received:', event.data);

    if (event.data && event.data.type === 'SHOW_NOTIFICATION') {
        const data = event.data.payload || {};
        const title = data.title || 'إشعار';
        const options = {
            body: data.body || '',
            icon: data.icon || '/assets/icons/icon-192.png',
            badge: '/assets/icons/badge-72.png',
            dir: 'rtl',
            lang: 'ar',
            tag: data.tag || `local-notif-${Date.now()}`,
            data: { url: data.url || '/' },
            vibrate: [300, 100, 300],
        };

        event.waitUntil(
            self.registration.showNotification(title, options)
        );
    }

    if (event.data && event.data.type === 'SKIP_WAITING') {
        self.skipWaiting();
    }
});

// ============================================================
// 7. pushsubscriptionchange - إعادة الاشتراك عند انتهاء صلاحيته
// ============================================================
self.addEventListener('pushsubscriptionchange', (event) => {
    console.log('[SW] Push subscription changed, resubscribing...');
    
    event.waitUntil(
        self.registration.pushManager.getSubscription()
            .then((subscription) => {
                if (subscription) {
                    return fetch('/api/notifications.php?action=subscribe', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ subscription }),
                        credentials: 'same-origin',
                    });
                }
            })
    );
});

// ============================================================
// 8. fetch - استراتيجية Network First للصفحات
// ============================================================
self.addEventListener('fetch', (event) => {
    if (event.request.method !== 'GET') return;
    
    if (event.request.mode === 'navigate') {
        event.respondWith(
            fetch(event.request).catch(() => caches.match('/'))
        );
    }
});

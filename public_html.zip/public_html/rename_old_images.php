<?php
/**
 * rename_old_images.php - إعادة تسمية الصور القديمة وتحديث قاعدة البيانات
 * 
 * يقوم بـ:
 * 1. البحث عن جميع الصور في assets/images/products/ ذات الأسماء التي تحتوي على مسافات أو أحرف خاصة
 * 2. إعادة تسميتها بأسماء نظيفة
 * 3. تحديث قاعدة البيانات (products, product_variants) بالأسماء الجديدة
 * 
 * افتح: https://yoursite.com/rename_old_images.php
 * احذف الملف بعد الانتهاء
 */

require_once __DIR__ . '/includes/db_connect.php';

header('Content-Type: text/html; charset=utf-8');

echo "<!DOCTYPE html><html lang='ar' dir='rtl'><head><meta charset='UTF-8'>";
echo "<style>
body{font-family:monospace;padding:20px;background:#f5f5f5;direction:rtl;}
.ok{color:green;}.err{color:red;}.warn{color:orange;}.info{color:blue;}
.box{background:white;padding:15px;margin:10px 0;border-right:4px solid #007bff;border-radius:4px;}
.code{background:#f8f9fa;padding:10px;font-family:monospace;direction:ltr;text-align:left;border:1px solid #ddd;}
</style></head><body>";

echo "<h1>🔄 إعادة تسمية الصور القديمة</h1>";

$images_dir = __DIR__ . '/assets/images/products/';
$renamed_count = 0;
$updated_db = 0;
$errors = [];

echo "<div class='box'>";
echo "<h2>1. فحص مجلد الصور</h2>";

if (!is_dir($images_dir)) {
    echo "<p class='err'>✗ مجلد الصور غير موجود: $images_dir</p>";
    exit;
}

$files = scandir($images_dir);
$files = array_diff($files, ['.', '..', 'webp']);

echo "<p>عدد الملفات: " . count($files) . "</p>";
echo "</div>";

// 1. إعادة تسمية الملفات
echo "<div class='box'>";
echo "<h2>2. إعادة تسمية الملفات</h2>";

$rename_map = []; // [old_name => new_name]

foreach ($files as $filename) {
    $old_path = $images_dir . $filename;
    
    // تجاهل المجلدات
    if (is_dir($old_path)) continue;
    
    // فحص إذا كان الاسم يحتوي على أحرف خاصة
    $needs_rename = preg_match('/[\s\(\)]/', $filename) || preg_match('/[^\x20-\x7E]/', $filename);
    
    if (!$needs_rename) continue;
    
    // تنظيف الاسم
    $new_name = preg_replace('/\s+/', '_', $filename);          // مسافات → _
    $new_name = preg_replace('/[^A-Za-z0-9._-]/', '_', $new_name); // أحرف خاصة → _
    $new_name = preg_replace('/_+/', '_', $new_name);              // _ متكررة → _
    $new_name = trim($new_name, '_');
    
    // التأكد من عدم وجود ملف بنفس الاسم الجديد
    $new_path = $images_dir . $new_name;
    $counter = 1;
    while (file_exists($new_path) && $old_path !== $new_path) {
        $path_info = pathinfo($new_name);
        $new_name = $path_info['filename'] . '_' . $counter . '.' . $path_info['extension'];
        $new_path = $images_dir . $new_name;
        $counter++;
    }
    
    // إعادة التسمية
    if (rename($old_path, $new_path)) {
        $rename_map[$filename] = $new_name;
        $renamed_count++;
        echo "<p class='ok'>✓ {$filename} → {$new_name}</p>";
        
        // إعادة تسمية نسخة WebP لو وجدت
        $old_webp = __DIR__ . '/assets/images/products/webp/' . pathinfo($filename, PATHINFO_FILENAME) . '.webp';
        $new_webp = __DIR__ . '/assets/images/products/webp/' . pathinfo($new_name, PATHINFO_FILENAME) . '.webp';
        if (file_exists($old_webp) && !file_exists($new_webp)) {
            rename($old_webp, $new_webp);
        }
    } else {
        $errors[] = "فشل إعادة تسمية: {$filename}";
        echo "<p class='err'>✗ فشل: {$filename}</p>";
    }
}

echo "<p><strong>تم إعادة تسمية:</strong> $renamed_count ملف</p>";
echo "</div>";

// 2. تحديث قاعدة البيانات
echo "<div class='box'>";
echo "<h2>3. تحديث قاعدة البيانات</h2>";

if (empty($rename_map)) {
    echo "<p class='info'>ℹ لا توجد ملفات تحتاج إعادة تسمية</p>";
} else {
    // تحديث جدول product_variants (عمود image_urls - JSON array)
    try {
        $stmt = $conn->query("SELECT id, image_urls FROM product_variants WHERE image_urls IS NOT NULL AND image_urls != ''");
        $variants = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo "<p>فحص {$variants_count = count($variants)} variant...</p>";
        
        $update_stmt = $conn->prepare("UPDATE product_variants SET image_urls = ? WHERE id = ?");
        
        foreach ($variants as $variant) {
            $images = json_decode($variant['image_urls'], true);
            if (!is_array($images)) continue;
            
            $changed = false;
            foreach ($images as &$img) {
                // استخراج اسم الملف من المسار
                $basename = basename($img);
                if (isset($rename_map[$basename])) {
                    $new_basename = $rename_map[$basename];
                    $img = str_replace($basename, $new_basename, $img);
                    $changed = true;
                }
            }
            
            if ($changed) {
                $new_json = json_encode($images, JSON_UNESCAPED_UNICODE);
                $update_stmt->execute([$new_json, $variant['id']]);
                $updated_db++;
            }
        }
        
        echo "<p class='ok'>✓ تم تحديث {$updated_db} variant في product_variants</p>";
    } catch (Exception $e) {
        echo "<p class='err'>✗ خطأ في تحديث product_variants: " . $e->getMessage() . "</p>";
    }
    
    // تحديث جدول notifications (عمود image)
    try {
        $stmt = $conn->query("SELECT id, image FROM notifications WHERE image IS NOT NULL AND image != ''");
        $notifs = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $notif_updated = 0;
        $update_stmt = $conn->prepare("UPDATE notifications SET image = ? WHERE id = ?");
        
        foreach ($notifs as $notif) {
            $basename = basename($notif['image']);
            if (isset($rename_map[$basename])) {
                $new_image = str_replace($basename, $rename_map[$basename], $notif['image']);
                $update_stmt->execute([$new_image, $notif['id']]);
                $notif_updated++;
            }
        }
        
        echo "<p class='ok'>✓ تم تحديث {$notif_updated} إشعار في notifications</p>";
    } catch (Exception $e) {
        echo "<p class='err'>✗ خطأ في تحديث notifications: " . $e->getMessage() . "</p>";
    }
}
echo "</div>";

// 3. ملخص
echo "<div class='box'>";
echo "<h2>4. الملخص</h2>";
echo "<p><strong>الملفات المُعاد تسميتها:</strong> $renamed_count</p>";
echo "<p><strong>السجلات المُحدّثة في DB:</strong> $updated_db</p>";

if (!empty($errors)) {
    echo "<p class='err'><strong>أخطاء:</strong></p>";
    echo "<ul>";
    foreach ($errors as $err) {
        echo "<li class='err'>$err</li>";
    }
    echo "</ul>";
}

if ($renamed_count === 0) {
    echo "<p class='info'>ℹ لا توجد صور تحتاج إعادة تسمية. كل الأسماء نظيفة.</p>";
} else {
    echo "<p class='ok'>✅ تم! الآن جرّب فتح الموقع - يجب أن تظهر كل الصور بدون 404.</p>";
}
echo "</div>";

echo "<hr>";
echo "<p class='warn'>⚠ احذف هذا الملف بعد الانتهاء!</p>";
echo "</body></html>";

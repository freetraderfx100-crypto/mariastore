<?php
require_once __DIR__ . '/../includes/db_connect.php';

if (!isset($_GET['product_id']) || !isset($_GET['color'])) {
    echo json_encode([]);
    exit;
}

$product_id = intval($_GET['product_id']);
$color = trim($_GET['color']);

try {
    $stmt = $conn->prepare("SELECT size FROM product_variants WHERE product_id = ? AND color = ? AND quantity > 0");
    $stmt->execute([$product_id, $color]);
    $sizes = $stmt->fetchAll(PDO::FETCH_COLUMN);

    echo json_encode($sizes);
} catch (PDOException $e) {
    echo json_encode([]);
}
?>

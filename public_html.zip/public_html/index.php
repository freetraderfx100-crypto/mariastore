<?php
// تمكين ضغط Gzip للأداء
if (substr_count($_SERVER['HTTP_ACCEPT_ENCODING'], 'gzip')) {
    ob_start("ob_gzhandler");
} else {
    ob_start();
}
session_start();
session_write_close();
require_once 'includes/db_connect.php';
header('Content-Type: text/html; charset=utf-8');
// إضافة cache headers للصور والموارد الثابتة
header("Cache-Control: public, max-age=86400"); // تخزين لمدة يوم
header("Pragma: cache");
// استعلام محسن للحصول على التصنيفات الفرعية مع صورها (بدون is_active و sort_order)
$subcategories = $conn->query("
    SELECT c.*, image as sample_image
    FROM categories c
    WHERE c.parent_id IS NOT NULL
    ORDER BY c.name
")->fetchAll(PDO::FETCH_ASSOC);
// دالة لعرض المنتج
// دالة لعرض المنتج
function displayProduct($product, $conn)
{
    // جلب جميع الصور من جميع متغيرات المنتج
    $images = [];
    try {
        $stmt = $conn->prepare("
            SELECT image_urls 
            FROM product_variants 
            WHERE product_id = ?
        ");
        $stmt->execute([$product['id']]);
        $variants = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // تجميع جميع الصور من جميع المتغيرات
        foreach ($variants as $variant) {
            if (!empty($variant['image_urls'])) {
                $variant_images = json_decode($variant['image_urls'], true);
                if (is_array($variant_images)) {
                    $images = array_merge($images, $variant_images);
                }
            }
        }

        // إزالة الصور المكررة
        $images = array_unique($images);
        $images = array_filter($images); // إزالة القيم الفارغة
        $images = array_values($images); // إعادة فهرسة المصفوفة
    } catch (PDOException $e) {
        // في حالة حدوث خطأ، استخدم صورة افتراضية
        $images = ['default-product-image.jpg'];
    }

    // إذا لم تكن هناك صور، استخدم صورة افتراضية
    if (empty($images)) {
        $images[] = 'default-product-image.jpg';
    }

    // ✅ فلترة الصور المفقودة على القرص - يحل مشكلة دوران السلايدر بين صور موجودة ومفقودة
    $images_dir = __DIR__ . '/assets/images/';
    $valid_images = [];
    foreach ($images as $img) {
        $clean = str_replace(['\\', '"', "'"], '', $img);
        $clean = str_replace('assets/images/', '', $clean);
        $clean = ltrim($clean, '/');
        $full_path = $images_dir . $clean;
        if (file_exists($full_path)) {
            $valid_images[] = $img;
        }
    }
    // لو كل الصور مفقودة، استخدم placeholder واحد (بدلاً من دوران بين صور فارغة)
    if (empty($valid_images)) {
        $valid_images = ['__PLACEHOLDER__'];
    }
    $images = $valid_images;

    // تحديد ما إذا كان المنتج يحتوي على أكثر من صورة واحدة
    $hasMultipleImages = count($images) > 1;

    echo '<div class="product-card" role="article" aria-labelledby="product-name-' . $product['id'] . '">';
    // ✅ شارة "جديد"
    if (!empty($product['is_new'])) {
        echo '<span class="new-badge" title="منتج جديد">';
        echo '<i class="fas fa-bolt" aria-hidden="true"></i> جديد';
        echo '</span>';
    }
    // شارة الخصم
    if ($product['discount_percentage'] > 0) {
        echo '<span class="discount-badge" title="خصم ' . $product['discount_percentage'] . '%">';
        echo '<i class="fas fa-tag" aria-hidden="true"></i> -' . $product['discount_percentage'] . '%';
        echo '</span>';
    }

    // سلايدر الصور
    echo '<div class="product-slider-container ' . ($hasMultipleImages ? 'has-multiple-images' : '') . '">';
    echo '<div class="product-slider" data-product-id="' . $product['id'] . '" data-interval="3000">';
    echo '<div class="product-slides">';
    // placeholder SVG مضمون (لا يعتمد على ملف خارجي)
    $placeholder = 'data:image/svg+xml;base64,' . base64_encode(
        '<svg xmlns="http://www.w3.org/2000/svg" width="400" height="400" viewBox="0 0 400 400">' .
        '<rect width="400" height="400" fill="#f8f9fa"/>' .
        '<text x="200" y="180" font-size="60" text-anchor="middle" fill="#cccccc" font-family="sans-serif">👕</text>' .
        '<text x="200" y="240" font-size="18" text-anchor="middle" fill="#999999" font-family="sans-serif">صورة غير متوفرة</text>' .
        '</svg>'
    );
    foreach ($images as $index => $image) {
        $activeClass = ($index === 0) ? 'active' : '';
        echo '<div class="product-slide ' . $activeClass . '" data-index="' . $index . '">';
        echo '<a href="pages/details_product.php?id=' . $product['id'] . '" aria-label="عرض تفاصيل المنتج: ' . htmlspecialchars($product['name']) . '">';
        // لو الصورة placeholder، استخدم SVG مباشرة
        if ($image === '__PLACEHOLDER__') {
            echo '<img src="' . $placeholder . '"
                     alt="' . htmlspecialchars($product['name']) . '">';
        } else {
            // استخدام SITE_URL للمسار الكامل
            $image_path = SITE_URL . 'assets/images/' . ltrim($image, '/');
            echo '<img src="' . htmlspecialchars($image_path) . '"
                     alt="' . htmlspecialchars($product['name']) . '"
                     loading="lazy"
                     onerror="this.src=\'' . $placeholder . '\'; this.onerror=null;">';
        }
        echo '</a>';
        echo '</div>';
    }
    echo '</div>';

    // إضافة أزرار التنقل إذا كان هناك أكثر من صورة
    if ($hasMultipleImages) {
        echo '<button class="slider-prev" aria-label="الصورة السابقة"><i class="fas fa-chevron-right"></i></button>';
        echo '<button class="slider-next" aria-label="الصورة التالية"><i class="fas fa-chevron-left"></i></button>';

        // إضافة مؤشرات الصور
        echo '<div class="slider-indicators">';
        foreach ($images as $index => $image) {
            $activeClass = ($index === 0) ? 'active' : '';
            echo '<button class="indicator ' . $activeClass . '" data-index="' . $index . '" aria-label="الصورة ' . ($index + 1) . '"></button>';
        }
        echo '</div>';
    }

    echo '</div>';
    echo '</div>';

    // تفاصيل المنتج
    echo '<div class="product-details">';
    echo '<h3 class="product-name" id="product-name-' . $product['id'] . '">' . htmlspecialchars($product['name']) . '</h3>';
    // عرض السعر
    echo '<div class="product-price">';
    if ($product['discount_percentage'] > 0) {
        echo '<div class="price-container">';
        echo '<span class="discounted-price">' . number_format($product['discounted_price'], 2) . ' ر.ي</span>';
        echo '<span class="original-price">' . number_format($product['price'], 2) . ' ر.ي</span>';
        echo '<span class="save-amount">(وفر ' . number_format($product['price'] - $product['discounted_price'], 2) . ' ر.ي)</span>';
        echo '</div>';
    } else {
        echo '<span class="price" id="price_in_index">' . number_format($product['price'], 2) . ' ر.ي</span>';
    }
    echo '</div>';
    echo '</div>';
    echo '</div>';
}

// إذا كان الطلب AJAX لجلب المزيد من المنتجات
// إذا كان الطلب AJAX لجلب المزيد من المنتجات
if (isset($_GET['ajax']) && $_GET['ajax'] == 'load_more_products') {
    $page = isset($_GET['page']) && is_numeric($_GET['page']) ? (int) $_GET['page'] : 1;
    $products_per_page = 12;
    $offset = ($page - 1) * $products_per_page;

    // ✅ توليد seed ثابت للجلسة - يضمن ترتيب عشوائي ثابت طوال جلسة المستخدم
    // (يجدد الترتيب عند كل تحديث للصفحة، لكن لا يكرر المنتجات بين طلبات AJAX)
    if (!isset($_SESSION['random_seed'])) {
        $_SESSION['random_seed'] = rand(1, 999999);
    }
    $random_seed = (int)$_SESSION['random_seed'];

    try {
        // استعلام مبسط لجلب المنتجات فقط
        $sql = "
            SELECT 
                p.id,
                p.name,
                p.price,
                p.discount_percentage,
                p.is_new,
                p.price * (1 - p.discount_percentage/100) as discounted_price
            FROM products p
            WHERE p.is_active = 1
            ORDER BY p.is_new DESC, RAND($random_seed)
            LIMIT :limit OFFSET :offset
        ";
        $stmt = $conn->prepare($sql);
        // استخدام مصفوفة للربط بدلاً من bindValue
        $params = [
            ':limit' => $products_per_page,
            ':offset' => $offset
        ];
        foreach ($params as $key => $value) {
            $stmt->bindValue($key, $value, PDO::PARAM_INT);
        }
        $stmt->execute();
        $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
        if (count($products) > 0) {
            foreach ($products as $product) {
                displayProduct($product, $conn);
            }
        } else {
            echo '<div class="no-more-products">لا يوجد المزيد من المنتجات</div>';
        }
        exit;
    } catch (PDOException $e) {
        echo "<p class='error-message'>خطأ في تحميل المنتجات: " . $e->getMessage() . "</p>";
        exit;
    }
}
// بيانات Structured Data لتحسين SEO
$products_json_ld = [];
// في قسم SEO

// في قسم SEO
try {
    $sql = "
        SELECT 
            p.id,
            p.name,
            p.description,
            p.price,
            p.discount_percentage
        FROM products p 
        WHERE p.is_active = 1 
        ORDER BY p.created_at DESC 
        LIMIT 6
    ";
    $seo_stmt = $conn->prepare($sql);
    $seo_stmt->execute();
    $seo_products = $seo_stmt->fetchAll(PDO::FETCH_ASSOC);
    foreach ($seo_products as $product) {
        // جلب الصور للمنتج
        $images = [];
        try {
            $stmt = $conn->prepare("
                SELECT image_urls 
                FROM product_variants 
                WHERE product_id = ?
                LIMIT 1
            ");
            $stmt->execute([$product['id']]);
            $variant = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!empty($variant['image_urls'])) {
                $variant_images = json_decode($variant['image_urls'], true);
                if (is_array($variant_images) && !empty($variant_images)) {
                    $images = $variant_images;
                }
            }
        } catch (PDOException $e) {
            // تجاهل الخطأ
        }

        // استخدام الصورة الأولى أو صورة افتراضية
        $image_url = !empty($images) ? $images[0] : 'default-product-image.jpg';
        $products_json_ld[] = [
            "@type" => "Product",
            "name" => $product['name'],
            "description" => strip_tags($product['description']),
            "image" => SITE_URL . 'assets/images/' . ltrim($image_url, '/'),
            "offers" => [
                "@type" => "Offer",
                "price" => $product['price'] * (1 - $product['discount_percentage'] / 100),
                "priceCurrency" => "YER"
            ]
        ];
    }
} catch (PDOException $e) {
    // تجاهل الخطأ لعدم تأثيرها على تجربة المستخدم
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo SITE_NAME; ?></title>
    <!-- تحسين تحميل CSS -->
    <link rel="preload" href="assets/css/hero-slider.css?v=2" as="style">
    <link rel="preload" href="assets/css/categories-section.css" as="style">
    <link rel="preload" href="assets/css/product-slider.css" as="style">
    <link rel="preload" href="assets/css/discount_style.css?v=5" as="style">
    <!-- ✅ إضافة ?v=2 لكسر الكاش -->
    <link rel="stylesheet" href="assets/css/hero-slider.css?v=2">
    <link rel="stylesheet" href="assets/css/categories-section.css">
    <link rel="stylesheet" href="assets/css/product-slider.css">
    <link rel="stylesheet" href="assets/css/discount_style.css?v=5">
    <link rel="stylesheet" href="assets/css/responsive.css">
    <link rel="stylesheet" href="assets/css/index.css">
    <!-- تحميل Font Awesome بشكل غير متزامن -->
    <link rel="preconnect" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" media="print" onload="this.media='all'">
    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="<?php echo SITE_URL; ?>assets/images/favicon.ico">
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo SITE_URL; ?>assets/images/favicon.ico">
    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo SITE_URL; ?>assets/images/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo SITE_URL; ?>assets/images/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo SITE_URL; ?>assets/images/favicon-16x16.png">
    <!-- تحسينات SEO -->
    <meta property="og:title" content="<?php echo SITE_NAME; ?>">
    <meta property="og:image" content="<?php echo SITE_URL; ?>assets/images/og-image.jpg">
    <meta property="og:url" content="<?php echo SITE_URL; ?>">

</head>

<body>
    <?php include 'includes/header.php'; ?>
    <main>
        <?php
        $sliders = $conn->query("SELECT * FROM sliders WHERE is_active = 1 ORDER BY sort_order ASC")->fetchAll(PDO::FETCH_ASSOC);
        ?>
        <section class="hero-slider">
            <div class="slider">
                <div class="slides" id="sliderTrack">
                    <?php foreach ($sliders as $index => $slide):
                        // ✅ البحث عن صورة السلايدر في عدة مسارات محتملة
                        $image_filename = $slide['image_url'];
                        $possible_paths = [
                            'assets/images/banners/' . $image_filename,    // المسار المتوقع
                            'assets/images/banners' . $image_filename,     // المسار الفعلي للمultipartFile
                            'assets/images/' . $image_filename,            // في الجذر
                        ];
                        $actual_image_url = null;
                        foreach ($possible_paths as $path) {
                            $full_check = __DIR__ . '/' . $path;
                            if (file_exists($full_check)) {
                                $actual_image_url = SITE_URL . $path;
                                break;
                            }
                        }
                        // ✅ placeholder SVG لو لم تُوجد الصورة
                        if (!$actual_image_url) {
                            $actual_image_url = 'data:image/svg+xml;base64,' . base64_encode(
                                '<svg xmlns="http://www.w3.org/2000/svg" width="1920" height="600" viewBox="0 0 1920 600">' .
                                '<rect width="1920" height="600" fill="#f8f9fa"/>' .
                                '<text x="960" y="280" font-size="80" text-anchor="middle" fill="#cccccc" font-family="sans-serif">🖼️</text>' .
                                '<text x="960" y="360" font-size="28" text-anchor="middle" fill="#999999" font-family="sans-serif">صورة السلايدر غير متوفرة</text>' .
                                '</svg>'
                            );
                        }

                        // ✅ فحص وجود رابط للسلايد
                        $has_link = !empty($slide['link']);
                        // لو الرابط startsWith http://localhost - نستبدله بالـ SITE_URL
                        $slide_link = $slide['link'] ?? '';
                        if (strpos($slide_link, 'http://localhost') === 0) {
                            // نأخذ المسار فقط بعد localhost/online_store/
                            $path_part = strstr($slide_link, '/pages/');
                            if ($path_part === false) {
                                $path_part = strstr($slide_link, '/admin/');
                            }
                            if ($path_part === false) {
                                $path_part = strstr($slide_link, '/assets/');
                            }
                            $slide_link = $path_part !== false ? SITE_URL . ltrim($path_part, '/') : $slide_link;
                        }
                    ?>
                        <div class="slide <?= $index === 0 ? 'active' : '' ?>">
                            <?php if ($has_link): ?>
                                <!-- ✅ الصورة هي الزر - تُلف في <a> -->
                                <a href="<?= htmlspecialchars($slide_link) ?>" style="display:block; width:100%; height:100%;" title="<?= htmlspecialchars($slide['title'] ?? '') ?>">
                                    <img
                                        src="<?= htmlspecialchars($actual_image_url) ?>"
                                        alt="<?= htmlspecialchars($slide['title'] ?? 'بانر') ?>"
                                        style="cursor: pointer;"
                                        onerror="this.onerror=null; this.src='data:image/svg+xml;base64,<?= base64_encode(
                                            '<svg xmlns="http://www.w3.org/2000/svg" width="1920" height="600" viewBox="0 0 1920 600">' .
                                            '<rect width="1920" height="600" fill="#f8f9fa"/>' .
                                            '<text x="960" y="280" font-size="80" text-anchor="middle" fill="#cccccc" font-family="sans-serif">🖼️</text>' .
                                            '<text x="960" y="360" font-size="28" text-anchor="middle" fill="#999999" font-family="sans-serif">صورة السلايدر غير متوفرة</text>' .
                                            '</svg>'
                                        ) ?>';">
                                </a>
                            <?php else: ?>
                                <!-- سلايد بدون رابط -->
                                <img
                                    src="<?= htmlspecialchars($actual_image_url) ?>"
                                    alt="<?= htmlspecialchars($slide['title'] ?? 'بانر') ?>"
                                    onerror="this.onerror=null; this.src='data:image/svg+xml;base64,<?= base64_encode(
                                        '<svg xmlns="http://www.w3.org/2000/svg" width="1920" height="600" viewBox="0 0 1920 600">' .
                                        '<rect width="1920" height="600" fill="#f8f9fa"/>' .
                                        '<text x="960" y="280" font-size="80" text-anchor="middle" fill="#cccccc" font-family="sans-serif">🖼️</text>' .
                                        '<text x="960" y="360" font-size="28" text-anchor="middle" fill="#999999" font-family="sans-serif">صورة السلايدر غير متوفرة</text>' .
                                        '</svg>'
                                    ) ?>';">
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
                <button class="prev" aria-label="السابق">&#10095;</button>
                <button class="next" aria-label="التالي">&#10094;</button>

            </div>
        </section>

        <?php
        // [معطل] بانر تثبيت تطبيق ماريا - لإرجاعه أزل // من السطر التالي
        // require_once 'includes/pwa_install_banner.php';
        ?>

        <?php
        require_once 'includes/categories-section.php';
        ?>
        <section id="products" class="products-section">
            <div class="featured-products">
                <h2>منتجاتنا المميزة</h2>
            </div>
            <div class="products-grid" id="productsContainer">
                <?php
                // في قسم عرض المنتجات في الصفحة الرئيسية
                // في قسم عرض المنتجات في الصفحة الرئيسية
                // في قسم عرض المنتجات في الصفحة الرئيسية
                try {
                    // جلب الدفعة الأولى من المنتجات
                    $products_per_page = 12;

                    // ✅ توليد seed جديد عند فتح الصفحة (refresh) - يجدد الترتيب العشوائي
                    $_SESSION['random_seed'] = rand(1, 999999);
                    $random_seed = (int)$_SESSION['random_seed'];

                    $sql = "
        SELECT 
            p.id,
            p.name,
            p.price,
            p.discount_percentage,
            p.is_new,
            p.price * (1 - p.discount_percentage/100) as discounted_price
        FROM products p
        WHERE p.is_active = 1
        ORDER BY p.is_new DESC, RAND($random_seed)
        LIMIT :limit
    ";
                    $stmt = $conn->prepare($sql);
                    $stmt->bindValue(':limit', $products_per_page, PDO::PARAM_INT);
                    $stmt->execute();
                    while ($product = $stmt->fetch(PDO::FETCH_ASSOC)) {
                        displayProduct($product, $conn);
                    }
                } catch (PDOException $e) {
                    echo "<p class='error-message'>خطأ في تحميل المنتجات: " . $e->getMessage() . "</p>";
                }
                ?>
            </div>
            <div class="loading-indicator" id="loadingIndicator">
                <i class="fas fa-spinner fa-spin"></i> جاري تحميل المزيد من المنتجات...
            </div>
        </section>
    </main>
    <?php include 'includes/footer.php'; ?>
    <script src="<?php echo SITE_URL; ?>assets/js/banner.js"></script>
    <script src="<?php echo SITE_URL; ?>assets/js/main.js"></script>
    <script src="<?php echo SITE_URL; ?>assets/js/product-slider.js"></script>
    <script src="<?php echo SITE_URL; ?>assets/js/categories-section.js"></script>
    <script>
        // دعم لللمس على الأجهزة المحمولة
        let touchStartX = 0;
        let touchEndX = 0;
        const sliderTrack = document.getElementById('sliderTrack');
        if (sliderTrack) {
            sliderTrack.addEventListener('touchstart', e => {
                touchStartX = e.changedTouches[0].screenX;
            }, false);
            sliderTrack.addEventListener('touchend', e => {
                touchEndX = e.changedTouches[0].screenX;
                handleSwipe();
            }, false);
        }

        function handleSwipe() {
            const swipeThreshold = 50;
            if (touchEndX < touchStartX - swipeThreshold) {
                document.querySelector('.next').click();
            }
            if (touchEndX > touchStartX + swipeThreshold) {
                document.querySelector('.prev').click();
            }
        }
        // تحميل لانهائي للمنتجات
        let currentPage = 1;
        let isLoading = false;
        let hasMoreProducts = true;

        function checkScroll() {
            if (isLoading || !hasMoreProducts) return;
            const loadingIndicator = document.getElementById('loadingIndicator');
            const productsContainer = document.getElementById('productsContainer');
            // تحقق إذا كان المؤشر في منطقة الرؤية
            const rect = loadingIndicator.getBoundingClientRect();
            const isInViewport = rect.top <= window.innerHeight && rect.bottom >= 0;
            if (isInViewport) {
                loadMoreProducts();
            }
        }

        function loadMoreProducts() {
            if (isLoading || !hasMoreProducts) return;
            isLoading = true;
            currentPage++;
            const loadingIndicator = document.getElementById('loadingIndicator');
            loadingIndicator.classList.add('active');
            fetch(`?ajax=load_more_products&page=${currentPage}`)
                .then(response => response.text())
                .then(data => {
                    if (data.includes('no-more-products')) {
                        hasMoreProducts = false;
                        loadingIndicator.innerHTML = 'لا يوجد المزيد من المنتجات';
                    } else {
                        const productsContainer = document.getElementById('productsContainer');
                        productsContainer.innerHTML += data;
                        // إعادة تهيئة السلايدرات التلقائية للمنتجات الجديدة فقط
                        setTimeout(initProductSliders, 100);
                    }
                })
                .catch(error => {
                    console.error('Error loading more products:', error);
                    hasMoreProducts = false;
                    loadingIndicator.innerHTML = 'حدث خطأ أثناء تحميل المنتجات';
                })
                .finally(() => {
                    isLoading = false;
                    if (!hasMoreProducts) {
                        loadingIndicator.classList.remove('active');
                    }
                });
        }
        // تهيئة السلايدرات التلقائية للمنتجات
        function initProductSliders() {
            const productSliders = document.querySelectorAll('.product-slider[data-product-id]');

            productSliders.forEach(slider => {
                // ✅ منع إعادة التهيئة المزدوجة (idempotent) - يحل مشكلة "تظهر ثم تختفي"
                if (slider.dataset.initialized === 'true') return;
                slider.dataset.initialized = 'true';

                const productId = slider.dataset.productId;
                const interval = parseInt(slider.dataset.interval) || 3000;
                const slides = slider.querySelectorAll('.product-slide');
                const indicators = slider.querySelectorAll('.indicator');
                const prevBtn = slider.parentElement.querySelector('.slider-prev');
                const nextBtn = slider.parentElement.querySelector('.slider-next');

                // إذا كان هناك صورة واحدة فقط، لا تهيئ السلايدر
                if (slides.length <= 1) return;

                let currentIndex = 0;
                let slideInterval;

                // وظيفة لعرض شريحة معينة
                function showSlide(index) {
                    // التحقق من أن الفهرس ضمن النطاق الصحيح
                    if (index < 0) index = slides.length - 1;
                    if (index >= slides.length) index = 0;

                    // إخفاء جميع الشرائح وإظهار الشريحة المطلوبة
                    slides.forEach((slide, i) => {
                        slide.classList.toggle('active', i === index);
                    });

                    // تحديث المؤشرات
                    indicators.forEach((indicator, i) => {
                        indicator.classList.toggle('active', i === index);
                    });

                    currentIndex = index;
                }

                // وظيفة للشريحة التالية
                function nextSlide() {
                    showSlide(currentIndex + 1);
                }

                // وظيفة للشريحة السابقة
                function prevSlide() {
                    showSlide(currentIndex - 1);
                }

                // بدء السلايدر التلقائي
                function startAutoSlide() {
                    slideInterval = setInterval(nextSlide, interval);
                }

                // إيقاف السلايدر التلقائي
                function stopAutoSlide() {
                    clearInterval(slideInterval);
                }

                // إضافة مستمعي الأحداث للأزرار
                if (prevBtn) prevBtn.addEventListener('click', () => {
                    prevSlide();
                    stopAutoSlide();
                    startAutoSlide();
                });

                if (nextBtn) nextBtn.addEventListener('click', () => {
                    nextSlide();
                    stopAutoSlide();
                    startAutoSlide();
                });

                // إضافة مستمعي الأحداث للمؤشرات
                indicators.forEach((indicator, i) => {
                    indicator.addEventListener('click', () => {
                        showSlide(i);
                        stopAutoSlide();
                        startAutoSlide();
                    });
                });

                // إضافة مستمعي الأحداث لللمس على الهواتف
                let touchStartX = 0;
                let touchEndX = 0;

                slider.addEventListener('touchstart', (e) => {
                    touchStartX = e.changedTouches[0].screenX;
                    stopAutoSlide();
                }, false);

                slider.addEventListener('touchend', (e) => {
                    touchEndX = e.changedTouches[0].screenX;
                    handleSwipe();
                    startAutoSlide();
                }, false);

                function handleSwipe() {
                    const swipeThreshold = 50;
                    if (touchEndX < touchStartX - swipeThreshold) {
                        nextSlide();
                    }
                    if (touchEndX > touchStartX + swipeThreshold) {
                        prevSlide();
                    }
                }

                // إيقاف السلايدر عند تمرير الماوس فوقه
                slider.addEventListener('mouseenter', stopAutoSlide);
                slider.addEventListener('mouseleave', startAutoSlide);

                // بدء السلايدر التلقائي
                startAutoSlide();

                // تخزين وظائف التحكم في السلايدر لاستخدامها لاحقاً
                slider.dataset.slideFunctions = JSON.stringify({
                    showSlide,
                    nextSlide,
                    prevSlide,
                    startAutoSlide,
                    stopAutoSlide
                });
            });
        }
        // تهيئة عند تحميل الصفحة
        document.addEventListener("DOMContentLoaded", function() {
            initProductSliders();
            // مراقبة التمرير لتحميل المزيد من المنتجات
            window.addEventListener('scroll', checkScroll);
            window.addEventListener('resize', checkScroll);
            // تحقق مرة أولية
            setTimeout(checkScroll, 1000);
            // تحسين تجربة اللمس على الهواتف
            const interactiveElements = document.querySelectorAll('button, a, .product-card');
            interactiveElements.forEach(el => {
                el.addEventListener('touchstart', function() {
                    this.style.transform = 'scale(0.98)';
                });
                el.addEventListener('touchend', function() {
                    this.style.transform = '';
                });
            });
        });
        // كود للتحكم في المسافات بين الصورة واسم المنتج
        function adjustProductSpacing() {
            const isMobile = window.innerWidth <= 768;
            const productCards = document.querySelectorAll('.product-card');
            productCards.forEach(card => {
                const imageContainer = card.querySelector('.product-slider-container');
                const productName = card.querySelector('.product-name');
                if (isMobile && imageContainer && productName) {
                    imageContainer.style.marginBottom = '0px';
                    productName.style.marginTop = '2px';
                    productName.style.marginBottom = '2px';
                    productName.style.fontSize = '12px';
                    productName.style.lineHeight = '1.2';
                }
            });
        }
        window.addEventListener('load', adjustProductSpacing);
        window.addEventListener('resize', adjustProductSpacing);
    </script>
    <!-- بيانات Structured Data لتحسين SEO -->
    <script type="application/ld+json">
        {
            "@context": "https://schema.org",
            "@type": "WebSite",
            "name": "<?php echo SITE_NAME; ?>",
            "url": "<?php echo SITE_URL; ?>",
            "potentialAction": {
                "@type": "SearchAction",
                "target": "<?php echo SITE_URL; ?>search?q={search_term_string}",
                "query-input": "required name=search_term_string"
            }
        }
    </script>
    <?php if (!empty($products_json_ld)): ?>
        <script type="application/ld+json">
            {
                "@context": "https://schema.org",
                "@type": "ItemList",
                "itemListElement": [
                    <?php foreach ($products_json_ld as $index => $product): ?> {
                            "@type": "ListItem",
                            "position": <?php echo $index + 1; ?>,
                            "item": <?php echo json_encode($product); ?>
                        }
                        <?php if ($index < count($products_json_ld) - 1) echo ','; ?>
                    <?php endforeach; ?>
                ]
            }
        </script>
    <?php endif; ?>
</body>

</html>
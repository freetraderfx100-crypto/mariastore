<!-- CSS -->
<link rel="stylesheet" href="<?php echo SITE_URL; ?>assets/css/style.css">

<!-- JS -->
<script src="<?php echo SITE_URL; ?>assets/js/app.js"></script>

<!-- صورة -->
<img src="<?php echo SITE_URL; ?>assets/images/logoNew.png" alt="ماريا">

<!-- رابط صفحة -->
<a href="<?php echo SITE_URL; ?>pages/contact.php">اتصل بنا</a>

<!-- --------------------------------------- -->
<!-- اذا كان عدي ملف جافا سكربت منفصل  -->
<!-- اكتب هاذا في ملف PHP -1 -->
<script>
    const SITE_URL = "<?php echo SITE_URL; ?>";
</script>
<!-- نظمن مف الجافا داخل ملف PHP -2 -->
<script src="assets/js/main.js"></script>
<!-- نكتبه تاخل ملف الجافا سكربت بهاذي الطريقه -->
window.location.href = SITE_URL + "includes/logout.php";
<!-- -------------------------------------------------- -->


<!--  -->
header("Location: /online_store/");
header("Location: " . SITE_URL);
header("Location: " . SITE_URL . "pages/login.php");

<!-- لتغيير زمن الجلسه -->
$timeout = 300; // 5 دقائق

const logoutTime = 300000; //// 5 دقائق = 5 * 60 * 1000

const warningTime = 30000; // 30 ثانية


CREATE TABLE visitors (
id INT AUTO_INCREMENT PRIMARY KEY,
session_id VARCHAR(255) NOT NULL,
ip_address VARCHAR(45) NOT NULL,
user_agent TEXT,
referrer VARCHAR(255),
landing_page VARCHAR(255) NOT NULL,
exit_page VARCHAR(255),
country VARCHAR(100),
city VARCHAR(100),
device_type VARCHAR(50),
browser VARCHAR(100),
operating_system VARCHAR(100),
user_id INT NULL,
created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

CREATE INDEX idx_session_id ON visitors(session_id);
CREATE INDEX idx_created_at ON visitors(created_at);
CREATE INDEX idx_user_id ON visitors(user_id);



<?php
// config.php

// ضبط المنطقة الزمنية
date_default_timezone_set('Asia/Aden'); // +03:00

// تحميل بيئة .env (إن لم تُحمَّل بعد)
require_once __DIR__ . '/includes/env.php';

// تحديد البيئة: local | production
$appEnv = env('APP_ENV', 'local');

// إعدادات الموقع + قاعدة البيانات (من ملف .env أو متغيرات البيئة)
if ($appEnv === 'production') {
    define('DB_HOST', env('DB_HOST_PROD', 'localhost'));
    define('DB_USER', env('DB_USER_PROD', ''));
    define('DB_PASS', env('DB_PASS_PROD', ''));
    define('DB_NAME', env('DB_NAME_PROD', ''));

    // بروتوكول ديناميكي
    $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off'
        || ($_SERVER['SERVER_PORT'] ?? '') == 443) ? "https://" : "http://";
    define('SITE_URL', env('SITE_URL', $protocol . ($_SERVER['HTTP_HOST'] ?? 'localhost') . '/'));
} else {
    // محلي (XAMPP)
    define('DB_HOST', env('DB_HOST_LOCAL', 'localhost'));
    define('DB_USER', env('DB_USER_LOCAL', 'root'));
    define('DB_PASS', env('DB_PASS_LOCAL', ''));
    define('DB_NAME', env('DB_NAME_LOCAL', 'onlinestore'));

    define('SITE_URL', env('SITE_URL', 'http://localhost/online_store/'));
}

define('BASE_PATH', __DIR__ . '/'); // مسار فعلي للملفات
define('SITE_NAME', env('SITE_NAME', 'ماريا'));

// إعدادات الجلسة - يجب أن تكون قبل session_start()
if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.gc_probability', 1);
    ini_set('session.gc_divisor', 100);
    ini_set('session.gc_maxlifetime', 3600);

    // بدء الجلسة
    session_start([
        'cookie_lifetime' => 3600,
        'cookie_secure'   => false,
        'cookie_httponly' => true,
        'cookie_samesite' => 'Lax'
    ]);
}

<?php
/**
 * cron/cron_runner.php
 * --------------------------------------------------------------------
 * بديل لـ cron job عبر HTTP - يعمل على أي استضافة
 *
 * ✅ يمكن تشغيله عبر:
 *   1. متصفح: https://mariastore1.com/cron/cron_runner.php?key=YOUR_SECRET
 *   2. external cron service (cron-job.org, setcronjob.com)
 *   3. Hostinger cron job (wget/curl)
 *
 * الفائدة: لو Hostinger لا يدعم cron CLI، يمكن استخدام HTTP cron
 * --------------------------------------------------------------------
 */

// ✅ ضبط المنطقة الزمنية
date_default_timezone_set('Asia/Aden');

// ✅ تفعيل تسجيل الأخطاء
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

// ✅ التحقق من المفتاح السري (أمان)
$secret_key = $_GET['key'] ?? '';

// اقرأ المفتاح من .env أو استخدم قيمة افتراضية
require_once __DIR__ . '/../includes/env.php';
$valid_key = env('CRON_SECRET_KEY', 'CHANGE_ME_TO_RANDOM_STRING');

if (empty($secret_key) || $secret_key !== $valid_key) {
    http_response_code(403);
    header('Content-Type: application/json');
    echo json_encode([
        'success' => false,
        'error' => 'Forbidden - invalid or missing key',
        'hint' => 'Add ?key=YOUR_SECRET to the URL. Set CRON_SECRET_KEY in .env file.',
    ]);
    exit;
}

// ✅ إعداد headers
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-cache, no-store, must-revalidate');
header('X-Robots-Tag: noindex, nofollow');

// ✅ منع timeout (لو كان لدينا الكثير من الإشعارات)
set_time_limit(300); // 5 دقائق كحد أقصى
ini_set('memory_limit', '256M');

// ✅ تسجيل بدء التشغيل
$start_time = microtime(true);
$log_file = __DIR__ . '/push_notifications.log';

function logLine($msg) {
    global $log_file;
    $line = "[" . date('Y-m-d H:i:s') . "] [HTTP] " . $msg;
    @file_put_contents($log_file, $line . "\n", FILE_APPEND | LOCK_EX);
}

logLine("=== HTTP cron runner started ===");
logLine("IP: " . ($_SERVER['REMOTE_ADDR'] ?? 'unknown'));
logLine("User-Agent: " . ($_SERVER['HTTP_USER_AGENT'] ?? 'unknown'));

try {
    // ✅ تحميل الملفات المطلوبة
    require_once __DIR__ . '/../includes/db_connect.php';
    require_once __DIR__ . '/../includes/notifications.php';
    require_once __DIR__ . '/../includes/push_web.php';

    $manager = new NotificationsManager($conn);

    // ✅ فحص إذا كان Web Push مفعّل
    $web_push_enabled = $manager->getSetting('web_push_enabled', '0');
    if ($web_push_enabled !== '1') {
        logLine("Web Push disabled. Exiting.");
        echo json_encode([
            'success' => true,
            'message' => 'Web Push disabled - nothing to do',
            'duration' => round(microtime(true) - $start_time, 2),
        ]);
        exit;
    }

    // ✅ جلب الإشعارات المعلّقة (آخر 24 ساعة فقط)
    $stmt = $conn->prepare("
        SELECT id, type, title, body, url, image, icon, created_at
        FROM notifications
        WHERE is_sent = 0
        AND (scheduled_at IS NULL OR scheduled_at <= NOW())
        AND (expires_at IS NULL OR expires_at > NOW())
        AND created_at > DATE_SUB(NOW(), INTERVAL 24 HOUR)
        ORDER BY created_at ASC
        LIMIT 50
    ");
    $stmt->execute();
    $pending = $stmt->fetchAll(PDO::FETCH_ASSOC);

    logLine("Pending notifications: " . count($pending));

    if (empty($pending)) {
        echo json_encode([
            'success' => true,
            'message' => 'No pending notifications',
            'pending_count' => 0,
            'duration' => round(microtime(true) - $start_time, 2),
        ]);
        logLine("=== Done (no pending) ===");
        exit;
    }

    // ✅ جلب الاشتراكات النشطة
    $subscriptions = $manager->getActiveSubscriptions();
    logLine("Active subscriptions: " . count($subscriptions));

    if (empty($subscriptions)) {
        echo json_encode([
            'success' => true,
            'message' => 'No active subscriptions - will retry later',
            'pending_count' => count($pending),
            'duration' => round(microtime(true) - $start_time, 2),
        ]);
        logLine("=== Done (no subscribers, will retry) ===");
        exit;
    }

    // ✅ إرسال الإشعارات
    $sent_count = 0;
    $failed_count = 0;
    $skipped_count = 0;
    $results = [];

    foreach ($pending as $notif) {
        logLine("Processing notification #{$notif['id']}: {$notif['title']}");

        $success_count = 0;
        $failure_count = 0;
        $errors = [];

        foreach ($subscriptions as $sub) {
            try {
                $result = sendWebPushNotification($sub, $notif['id'], $conn);
                if ($result === true) {
                    $success_count++;
                } else {
                    $failure_count++;
                    // ✅ v2.3: تسجيل تفاصيل الخطأ
                    $err_msg = is_string($result) ? $result : 'Unknown error';
                    $errors[] = "sub#{$sub['id']}: {$err_msg}";
                    logLine("  ❌ sub#{$sub['id']} (user=" . ($sub['user_id'] ?? 'NULL') . "): {$err_msg}");
                }
            } catch (Exception $e) {
                logLine("  ERROR sending to subscription {$sub['id']}: " . $e->getMessage());
                $failure_count++;
                $errors[] = "sub#{$sub['id']}: " . $e->getMessage();
            }
        }

        logLine("  → Sent to {$success_count}/" . count($subscriptions) . " subscribers");

        // ✅ فقط حدّث is_sent=1 لو نجح إرسال واحد على الأقل
        if ($success_count > 0) {
            $stmt = $conn->prepare("UPDATE notifications SET is_sent = 1 WHERE id = ?");
            $stmt->execute([$notif['id']]);
            $sent_count++;
            $results[] = [
                'notif_id' => $notif['id'],
                'status' => 'sent',
                'sent_to' => $success_count,
                'failed' => $failure_count,
            ];
        } else {
            $failed_count++;
            $results[] = [
                'notif_id' => $notif['id'],
                'status' => 'failed',
                'sent_to' => 0,
                'failed' => $failure_count,
                'errors' => array_slice($errors, 0, 3), // أول 3 أخطاء فقط
            ];

            // ✅ لو الإشعار قديم (>6 ساعات)، نسلّم به
            $notif_age_hours = (time() - strtotime($notif['created_at'])) / 3600;
            if ($notif_age_hours > 6) {
                $stmt = $conn->prepare("UPDATE notifications SET is_sent = 1 WHERE id = ?");
                $stmt->execute([$notif['id']]);
                $skipped_count++;
                logLine("  ⚠ Notification older than 6h - marking as sent to stop retrying");
            }
        }

        usleep(100000); // 100ms بين كل إشعار
    }

    $duration = round(microtime(true) - $start_time, 2);
    logLine("=== Done in {$duration}s ===");
    logLine("Sent: $sent_count, Failed (will retry): $failed_count, Skipped (>6h): $skipped_count");

    // ✅ إرجاع تقرير JSON مفصّل
    echo json_encode([
        'success' => true,
        'summary' => [
            'pending_count' => count($pending),
            'subscriptions_count' => count($subscriptions),
            'sent' => $sent_count,
            'failed' => $failed_count,
            'skipped' => $skipped_count,
        ],
        'results' => $results,
        'duration_seconds' => $duration,
        'next_run_hint' => 'Run again in 5 minutes',
    ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);

} catch (Exception $e) {
    logLine("EXCEPTION: " . $e->getMessage());
    logLine("Trace: " . $e->getTraceAsString());
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage(),
        'file' => $e->getFile(),
        'line' => $e->getLine(),
    ]);
}

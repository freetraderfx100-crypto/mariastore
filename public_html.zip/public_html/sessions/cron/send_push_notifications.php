<?php
/**
 * cron/send_push_notifications.php
 * --------------------------------------------------------------------
 * سكريبت مجدول لإرسال إشعارات Web Push المعلقة
 * 
 * التشغيل (كل 5 دقائق):
 *   */5 * * * * php /path/to/public_html/cron/send_push_notifications.php
 * 
 * أو من المتصفح:
 *   https://yoursite.com/cron/send_push_notifications.php?key=CHANGE_ME_TO_RANDOM_STRING
 * --------------------------------------------------------------------
 */

// ✅ تفعيل عرض جميع الأخطاء للتشخيص
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('log_errors', 1);

// ✅ ضبط المنطقة الزمنية
date_default_timezone_set('Asia/Aden');

// ✅ تسجيل دالة لالتقاط الأخطاء الفادحة (fatal errors)
register_shutdown_function(function() {
    $error = error_get_last();
    if ($error && in_array($error['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR])) {
        $msg = "[" . date('Y-m-d H:i:s') . "] FATAL ERROR: " . $error['message'] . " in " . $error['file'] . ":" . $error['line'];
        @file_put_contents(__DIR__ . '/push_notifications.log', $msg . "\n", FILE_APPEND | LOCK_EX);
        @file_put_contents(__DIR__ . '/cron_errors.log', $msg . "\n", FILE_APPEND | LOCK_EX);
    }
});

// ✅ دالة تسجيل مبكرة (قبل تحميل أي ملفات)
function earlyLog($msg) {
    $line = "[" . date('Y-m-d H:i:s') . "] " . $msg;
    @file_put_contents(__DIR__ . '/push_notifications.log', $line . "\n", FILE_APPEND | LOCK_EX);
}

earlyLog("=== Starting push notifications cron ===");
earlyLog("PHP version: " . PHP_VERSION);
earlyLog("SAPI: " . php_sapi_name());
earlyLog("__DIR__: " . __DIR__);

// منع التشغيل المباشر بدون مفتاح (لو لم يكن CLI)
$isCli = php_sapi_name() === 'cli';
if (!$isCli) {
    $secret_key = $_GET['key'] ?? '';
    if ($secret_key !== 'CHANGE_ME_TO_RANDOM_STRING') {
        earlyLog("ACCESS DENIED: invalid or missing key");
        http_response_code(403);
        die('Forbidden - key required');
    }
    earlyLog("Access granted via web with valid key");
}

// ✅ تحميل الملفات مع تسجيل أي أخطاء
earlyLog("Loading db_connect.php...");
$db_file = __DIR__ . '/../includes/db_connect.php';
if (!file_exists($db_file)) {
    earlyLog("ERROR: db_connect.php not found at: " . $db_file);
    die("ERROR: db_connect.php not found");
}
require_once $db_file;
earlyLog("db_connect.php loaded successfully");

earlyLog("Loading notifications.php...");
$notif_file = __DIR__ . '/../includes/notifications.php';
if (!file_exists($notif_file)) {
    earlyLog("ERROR: notifications.php not found at: " . $notif_file);
    die("ERROR: notifications.php not found");
}
require_once $notif_file;
earlyLog("notifications.php loaded successfully");

earlyLog("Loading push_web.php...");
$push_file = __DIR__ . '/../includes/push_web.php';
if (!file_exists($push_file)) {
    earlyLog("ERROR: push_web.php not found at: " . $push_file);
    die("ERROR: push_web.php not found");
}
require_once $push_file;
earlyLog("push_web.php loaded successfully");

$startTime = microtime(true);

try {
    earlyLog("Creating NotificationsManager...");
    $manager = new NotificationsManager($conn);
    earlyLog("NotificationsManager created");
    
    $web_push_enabled = $manager->getSetting('web_push_enabled', '0');
    earlyLog("Web Push enabled setting: " . $web_push_enabled);
    
    if ($web_push_enabled !== '1') {
        earlyLog("Web Push is disabled. Exiting.");
        earlyLog("=== Done (web push disabled) ===");
        exit(0);
    }

    // ✅ v2.2: تحسين الاستعلام - نتخطى الإشعارات القديمة (>24 ساعة) بعد محاولات كثيرة
    earlyLog("Fetching pending notifications...");
    $stmt = $conn->prepare("
        SELECT id, type, title, body, url, image, icon, created_at
        FROM notifications
        WHERE is_sent = 0
        AND (scheduled_at IS NULL OR scheduled_at <= NOW())
        AND (expires_at IS NULL OR expires_at > NOW())
        AND created_at > DATE_SUB(NOW(), INTERVAL 24 HOUR)
        ORDER BY created_at ASC
        LIMIT 50
    ");
    $stmt->execute();
    $pending = $stmt->fetchAll(PDO::FETCH_ASSOC);

    earlyLog("Pending notifications (last 24h): " . count($pending));

    if (empty($pending)) {
        earlyLog("No pending notifications. Exiting.");
        earlyLog("=== Done (no pending) ===");
        exit(0);
    }

    earlyLog("Fetching active subscriptions...");
    $subscriptions = $manager->getActiveSubscriptions();
    earlyLog("Active subscriptions: " . count($subscriptions));

    if (empty($subscriptions)) {
        earlyLog("No active subscribers. Will retry next cron run.");
        // ✅ v2.2: لا نحدّث is_sent=1 - ربما اشتراكات جديدة لاحقاً
        earlyLog("=== Done (no subscribers, will retry) ===");
        exit(0);
    }

    $sent_count = 0;
    $failed_count = 0;
    $skipped_count = 0;

    foreach ($pending as $notif) {
        earlyLog("Processing notification #{$notif['id']}: {$notif['title']}");

        $success_count = 0;
        $failure_count = 0;

        foreach ($subscriptions as $sub) {
            try {
                $result = sendWebPushNotification($sub, $notif['id'], $conn);
                if ($result === true) {
                    $success_count++;
                } else {
                    $failure_count++;
                    // ✅ v2.3: تسجيل تفاصيل الخطأ
                    $err_msg = is_string($result) ? $result : 'Unknown error';
                    earlyLog("  ❌ sub#{$sub['id']} (user=" . ($sub['user_id'] ?? 'NULL') . "): {$err_msg}");
                }
            } catch (Exception $e) {
                earlyLog("  ERROR sending to subscription {$sub['id']}: " . $e->getMessage());
                $failure_count++;
            }
        }

        earlyLog("  → Sent to {$success_count}/" . count($subscriptions) . " subscribers");

        // ✅ v2.2: فقط حدّث is_sent=1 لو نجح إرسال واحد على الأقل
        if ($success_count > 0) {
            $stmt = $conn->prepare("UPDATE notifications SET is_sent = 1 WHERE id = ?");
            $stmt->execute([$notif['id']]);
            $sent_count++;
            earlyLog("  ✓ Marked as sent (is_sent=1)");
        } else {
            $failed_count++;
            earlyLog("  ✗ All attempts failed - keeping is_sent=0 for retry next cron");
            // ✅ مع ذلك، لو الإشعار قديم (>6 ساعات)، نسلّم به ونعلّمه كمرسل
            // لتفادي إعادة المحاولة للأبد
            $notif_age_hours = (time() - strtotime($notif['created_at'])) / 3600;
            if ($notif_age_hours > 6) {
                $stmt = $conn->prepare("UPDATE notifications SET is_sent = 1 WHERE id = ?");
                $stmt->execute([$notif['id']]);
                $skipped_count++;
                earlyLog("  ⚠ Notification older than 6h - marking as sent to stop retrying");
            }
        }

        usleep(100000);
    }

    $duration = round(microtime(true) - $startTime, 2);
    earlyLog("=== Done in {$duration}s ===");
    earlyLog("Sent: $sent_count, Failed (will retry): $failed_count, Skipped (>6h): $skipped_count");

} catch (Exception $e) {
    earlyLog("EXCEPTION: " . $e->getMessage());
    earlyLog("Trace: " . $e->getTraceAsString());
    earlyLog("=== Done with error ===");
    exit(1);
}

/**
 * تسجيل رسالة
 */
function logMessage($msg)
{
    earlyLog($msg);
}

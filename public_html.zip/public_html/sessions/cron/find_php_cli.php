<?php
/**
 * cron/find_php_cli.php - النسخة المحسّنة
 * --------------------------------------------------------------------
 * ✅ تستخدم shell_exec بدلاً من file_exists (يتجاوز open_basedir)
 * --------------------------------------------------------------------
 */

require_once __DIR__ . '/../includes/env.php';
$valid_key = env('CRON_SECRET_KEY', 'CHANGE_ME_TO_RANDOM_STRING');

$secret_key = $_GET['key'] ?? '';
if (empty($secret_key) || $secret_key !== $valid_key) {
    http_response_code(403);
    die('Forbidden');
}

header('Content-Type: text/html; charset=utf-8');
date_default_timezone_set('Asia/Aden');
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<!DOCTYPE html><html lang='ar' dir='rtl'><head><meta charset='UTF-8'>";
echo "<title>بحث عن PHP CLI - v2</title>";
echo "<style>
body{font-family:monospace;padding:20px;background:#f5f5f5;line-height:1.6;}
.ok{color:green;font-weight:bold;}.err{color:red;font-weight:bold;}
.warn{color:orange;font-weight:bold;}.info{color:blue;}
.box{background:white;padding:15px;margin:10px 0;border-right:4px solid #007bff;border-radius:4px;}
pre{background:#1e1e1e;color:#d4d4d4;padding:15px;direction:ltr;text-align:left;border-radius:4px;overflow:auto;}
table{border-collapse:collapse;width:100%;background:white;}
td,th{border:1px solid #ddd;padding:8px;text-align:right;}
.copy-btn{background:#007bff;color:white;border:none;padding:5px 10px;border-radius:4px;cursor:pointer;font-size:12px;}
</style></head><body>";

echo "<h1>🔍 بحث عن PHP CLI - النسخة المحسّنة v2</h1>";

// ✅ v3: فحص توفر shell_exec قبل استخدامه
$shell_exec_available = function_exists('shell_exec')
    && !in_array('shell_exec', array_map('trim', explode(',', ini_get('disable_functions') ?: '')));

if (!$shell_exec_available) {
    echo "<div class='box' style='border-right-color: #dc3545;'>";
    echo "<h2 style='color: #dc3545;'>⚠️ shell_exec معطّل على Hostinger</h2>";
    echo "<p>Hostinger يعطّل دوال shell للأمان. لا يمكن كشف مسار PHP CLI من PHP.</p>";
    echo "<p><strong>الحل:</strong> استخدم HTTP cron عبر cron-job.org بدلاً من CLI cron.</p>";
    echo "<h3>📋 الخطوات:</h3>";
    echo "<ol>";
    echo "<li>سجّل في <a href='https://cron-job.org' target='_blank'>cron-job.org</a> (مجاني)</li>";
    echo "<li>أضف cron job:</li>";
    echo "<ul>";
    echo "<li><strong>URL:</strong></li>";
    echo "<pre style='background:#e3f2fd;padding:10px;direction:ltr;text-align:left;'>https://mariastore1.com/cron/cron_runner.php?key=" . htmlspecialchars($valid_key) . "</pre>";
    echo "<li><strong>Schedule:</strong> <code>*/5 * * * *</code> (كل 5 دقائق)</li>";
    echo "</ul>";
    echo "<li>احفظ. سيقوم الموقع بإرسال الإشعارات تلقائياً.</li>";
    echo "</ol>";
    echo "<p>📖 دليل مفصل: راجع ملف <code>HTTP_CRON_SETUP_GUIDE.md</code></p>";
    echo "</div>";

    echo "<div class='box'>";
    echo "<h2>📋 معلومات للتوثيق</h2>";
    echo "<table>";
    echo "<tr><td>PHP Version</td><td>" . PHP_VERSION . "</td></tr>";
    echo "<tr><td>SAPI</td><td>" . php_sapi_name() . "</td></tr>";
    echo "<tr><td>PHP_BINARY</td><td><code>" . PHP_BINARY . "</code></td></tr>";
    echo "<tr><td>PHP_BINDIR</td><td><code>" . PHP_BINDIR . "</code></td></tr>";
    echo "<tr><td>open_basedir</td><td><code>" . (ini_get('open_basedir') ?: '(مفتوح)') . "</code></td></tr>";
    echo "<tr><td>disable_functions</td><td><code style='font-size:10px;'>" . htmlspecialchars(ini_get('disable_functions') ?: '(لا شيء)') . "</code></td></tr>";
    echo "</table>";

    echo "<h3>💡 لو تريد تجربة CLI cron يدوياً على Hostinger:</h3>";
    echo "<p>جرّب هذه المسارات الشائعة في hPanel → Cron Jobs:</p>";
    echo "<ul>";
    echo "<li><code>/usr/bin/php /home/u905256684/domains/mariastore1.com/public_html/cron/send_push_notifications.php</code></li>";
    echo "<li><code>/usr/local/bin/php /home/u905256684/domains/mariastore1.com/public_html/cron/send_push_notifications.php</code></li>";
    echo "<li><code>/opt/alt/php83/usr/bin/php /home/u905256684/domains/mariastore1.com/public_html/cron/send_push_notifications.php</code></li>";
    echo "</ul>";
    echo "<p>لكن <strong>الحل المضمون 100%</strong> هو HTTP cron عبر cron-job.org.</p>";
    echo "</div>";

    echo "</body></html>";
    exit;
}

// ============================================================
// 1. فحص الدوال المتاحة
// ============================================================
echo "<div class='box'>";
echo "<h2>1. فحص الدوال المتاحة</h2>";
echo "<table>";
echo "<tr><td>shell_exec</td><td>" . (function_exists('shell_exec') && !in_array('shell_exec', explode(',', ini_get('disable_functions'))) ? '<span class="ok">✅ متاح</span>' : '<span class="err">❌ معطّل</span>') . "</td></tr>";
echo "<tr><td>exec</td><td>" . (function_exists('exec') && !in_array('exec', explode(',', ini_get('disable_functions'))) ? '<span class="ok">✅ متاح</span>' : '<span class="err">❌ معطّل</span>') . "</td></tr>";
echo "<tr><td>system</td><td>" . (function_exists('system') && !in_array('system', explode(',', ini_get('disable_functions'))) ? '<span class="ok">✅ متاح</span>' : '<span class="err">❌ معطّل</span>') . "</td></tr>";
echo "<tr><td>passthru</td><td>" . (function_exists('passthru') && !in_array('passthru', explode(',', ini_get('disable_functions'))) ? '<span class="ok">✅ متاح</span>' : '<span class="err">❌ معطّل</span>') . "</td></tr>";
echo "<tr><td>open_basedir</td><td><code>" . (ini_get('open_basedir') ?: '(غير مضبوط - مفتوح)') . "</code></td></tr>";
echo "<tr><td>disable_functions</td><td><code>" . (ini_get('disable_functions') ?: '(لا شيء)') . "</code></td></tr>";
echo "</table>";
echo "</div>";

// ============================================================
// 2. استخدام which للعثور على PHP
// ============================================================
echo "<div class='box'>";
echo "<h2>2. البحث باستخدام <code>which</code></h2>";

$which_php = @shell_exec('which php 2>&1');
echo "<p><code>which php</code> → <code>" . htmlspecialchars(trim($which_php ?: 'فشل')) . "</code></p>";

$which_php83 = @shell_exec('which php8.3 2>&1');
echo "<p><code>which php8.3</code> → <code>" . htmlspecialchars(trim($which_php83 ?: 'فشل')) . "</code></p>";

$which_php82 = @shell_exec('which php8.2 2>&1');
echo "<p><code>which php8.2</code> → <code>" . htmlspecialchars(trim($which_php82 ?: 'فشل')) . "</code></p>";

echo "</div>";

// ============================================================
// 3. فحص المسارات الشائعة باستخدام shell_exec
// ============================================================
echo "<div class='box'>";
echo "<h2>3. فحص المسارات الشائعة (باستخدام shell_exec)</h2>";

$php_paths = [
    '/usr/bin/php',
    '/usr/bin/php8.3',
    '/usr/bin/php8.2',
    '/usr/bin/php8.1',
    '/usr/local/bin/php',
    '/usr/local/bin/php8.3',
    '/usr/local/bin/php8.2',
    '/usr/local/bin/php8.1',
    '/opt/alt/php83/usr/bin/php',
    '/opt/alt/php82/usr/bin/php',
    '/opt/alt/php81/usr/bin/php',
    '/usr/local/lsws/lsphp83/bin/php',
    '/usr/local/lsws/lsphp82/bin/php',
    '/usr/local/lsws/lsphp81/bin/php',
    '/opt/cpanel/ea-php83/root/usr/bin/php',
    '/opt/cpanel/ea-php82/root/usr/bin/php',
];

echo "<table>";
echo "<tr><th>المسار</th><th>موجود؟</th><th>الإصدار</th></tr>";

$found_paths = [];
foreach ($php_paths as $path) {
    // استخدام shell_exec للتحقق من وجود الملف
    $check = @shell_exec('test -f ' . escapeshellarg($path) . ' && echo "YES" || echo "NO" 2>&1');
    $exists = trim($check ?: '') === 'YES';

    $version = '';
    if ($exists) {
        // محاولة الحصول على الإصدار
        $ver_output = @shell_exec(escapeshellarg($path) . ' -v 2>&1');
        if ($ver_output && preg_match('/PHP (\d+\.\d+\.\d+)/', $ver_output, $matches)) {
            $version = $matches[1];
        }
        $found_paths[] = ['path' => $path, 'version' => $version];
    }

    echo "<tr>";
    echo "<td><code>{$path}</code></td>";
    echo "<td>" . ($exists ? "<span class='ok'>✅</span>" : "<span class='err'>❌</span>") . "</td>";
    echo "<td>" . ($version ?: '-') . "</td>";
    echo "</tr>";
}
echo "</table>";
echo "</div>";

// ============================================================
// 4. أفضل مسار + أمر cron
// ============================================================
echo "<div class='box'>";
echo "<h2>4. ✅ المسار الموصى به لـ cron job</h2>";

if (!empty($found_paths)) {
    // ترتيب حسب الإصدار (الأحدث أولاً)
    usort($found_paths, function($a, $b) {
        return version_compare($b['version'] ?: '0.0.0', $a['version'] ?: '0.0.0');
    });

    $best = $found_paths[0];
    echo "<p class='ok'>✅ أفضل مسار: <code>{$best['path']}</code> (PHP {$best['version']})</p>";

    $cron_command = "{$best['path']} /home/u905256684/domains/mariastore1.com/public_html/cron/send_push_notifications.php";

    echo "<h3>📋 أمر cron الكامل (انسخه في hPanel):</h3>";
    echo "<pre style='background:#e3f2fd;padding:15px;border-right:4px solid #007bff;'>{$cron_command}</pre>";

    echo "<p><strong>Schedule:</strong> <code>*/5 * * * *</code> (كل 5 دقائق)</p>";

    echo "<h3>📋 كل المسارات الموجودة:</h3>";
    echo "<ul>";
    foreach ($found_paths as $p) {
        echo "<li><code>{$p['path']}</code> (PHP {$p['version']})</li>";
    }
    echo "</ul>";
} else {
    echo "<p class='err'>❌ لم يتم العثور على PHP CLI في أي مسار!</p>";
    echo "<p class='warn'>جرّب استخدام <code>php</code> فقط (بدون مسار كامل):</p>";
    $fallback_cmd = "php /home/u905256684/domains/mariastore1.com/public_html/cron/send_push_notifications.php";
    echo "<pre>{$fallback_cmd}</pre>";
}
echo "</div>";

// ============================================================
// 5. اختبار فعلي - تشغيل cron من PHP CLI
// ============================================================
echo "<div class='box'>";
echo "<h2>5. 🧪 اختبار فعلي - تشغيل cron من PHP CLI</h2>";

if (!empty($found_paths)) {
    $best_path = $found_paths[0]['path'];
    $cron_script = '/home/u905256684/domains/mariastore1.com/public_html/cron/send_push_notifications.php';

    echo "<p>تشغيل: <code>$best_path $cron_script</code></p>";
    echo "<p>جاري التشغيل... (قد يستغرق عدة ثوان)</p>";

    $cmd = escapeshellarg($best_path) . ' ' . escapeshellarg($cron_script) . ' 2>&1';
    $output = @shell_exec($cmd);

    echo "<h3>المخرجات:</h3>";
    echo "<pre>" . htmlspecialchars($output ?: '(لا توجد مخرجات)') . "</pre>";

    // فحص الـ log بعد التشغيل
    $log_file = __DIR__ . '/push_notifications.log';
    if (file_exists($log_file)) {
        $log_size_after = filesize($log_file);
        $log_modified = date('Y-m-d H:i:s', filemtime($log_file));
        $current_time = date('Y-m-d H:i:s');
        echo "<p class='ok'>✅ آخر تحديث للـ log: $log_modified (الوقت الحالي: $current_time)</p>";

        // عرض آخر 10 أسطر
        $lines = file($log_file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        $last_lines = array_slice($lines, -10);
        echo "<h3>آخر 10 أسطر من الـ log:</h3>";
        echo "<pre>" . htmlspecialchars(implode("\n", $last_lines)) . "</pre>";
    }
} else {
    echo "<p class='err'>لا يمكن الاختبار - PHP CLI غير موجود</p>";
}
echo "</div>";

// ============================================================
// 6. معلومات إضافية
// ============================================================
echo "<div class='box'>";
echo "<h2>6. معلومات إضافية</h2>";
echo "<table>";
echo "<tr><td>PHP_BINARY</td><td><code>" . PHP_BINARY . "</code></td></tr>";
echo "<tr><td>PHP_BINDIR</td><td><code>" . PHP_BINDIR . "</code></td></tr>";
echo "<tr><td>PHP_SAPI</td><td><code>" . php_sapi_name() . "</code></td></tr>";

// محاولة العثور على PHP عبر PATH
$path_env = getenv('PATH');
echo "<tr><td>PATH</td><td><code style='font-size:10px;'>" . htmlspecialchars($path_env ?: '(فارغ)') . "</code></td></tr>";

// ls لمجلدات شائعة
echo "<tr><td>ls /usr/bin/php*</td><td><code>" . htmlspecialchars(@shell_exec('ls /usr/bin/php* 2>&1') ?: 'فشل') . "</code></td></tr>";
echo "<tr><td>ls /usr/local/bin/php*</td><td><code>" . htmlspecialchars(@shell_exec('ls /usr/local/bin/php* 2>&1') ?: 'فشل') . "</code></td></tr>";
echo "<tr><td>ls /opt/alt/</td><td><code>" . htmlspecialchars(@shell_exec('ls /opt/alt/ 2>&1') ?: 'فشل') . "</code></td></tr>";

echo "</table>";
echo "</div>";

// ============================================================
// 7. توصيات نهائية
// ============================================================
echo "<div class='box'>";
echo "<h2>7. 📋 الخطوات التالية</h2>";

if (!empty($found_paths)) {
    $best_path = $found_paths[0]['path'];
    $cron_command = "{$best_path} /home/u905256684/domains/mariastore1.com/public_html/cron/send_push_notifications.php";

    echo "<ol>";
    echo "<li>سجّل دخول لـ <a href='https://hpanel.hostinger.com' target='_blank'>hPanel Hostinger</a></li>";
    echo "<li>اذهب إلى: <strong>Hosting → الإدارة → متقدم → Cron Jobs</strong></li>";
    echo "<li>احذف cron job الحالي (لو موجود)</li>";
    echo "<li>أنشئ cron job جديد:</li>";
    echo "<ul>";
    echo "<li><strong>Schedule:</strong> <code>*/5 * * * *</code></li>";
    echo "<li><strong>Command:</strong> <code>{$cron_command}</code></li>";
    echo "</ul>";
    echo "<li>احفظ</li>";
    echo "<li>بعد 5-10 دقائق، ارجع لـ <a href='../admin/diagnose_push.php'>diagnose_push.php</a> وتأكد أن الـ log محدّث</li>";
    echo "</ol>";
} else {
    echo "<p class='warn'>⚠️ لم يتم العثور على PHP CLI في المسارات الشائعة.</p>";
    echo "<p><strong>الحل البديل:</strong> استخدم HTTP cron عبر cron-job.org:</p>";
    echo "<ol>";
    echo "<li>سجّل في <a href='https://cron-job.org' target='_blank'>cron-job.org</a> (مجاني)</li>";
    echo "<li>أضف cron job:</li>";
    echo "<ul>";
    echo "<li><strong>URL:</strong> <code>https://mariastore1.com/cron/cron_runner.php?key=" . htmlspecialchars($valid_key) . "</code></li>";
    echo "<li><strong>Schedule:</strong> Every 5 minutes</li>";
    echo "</ul>";
    echo "</ol>";
}
echo "</div>";

echo "</body></html>";

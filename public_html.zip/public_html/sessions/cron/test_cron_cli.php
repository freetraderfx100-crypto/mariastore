<?php
/**
 * cron/test_cron_cli.php
 * --------------------------------------------------------------------
 * ✅ سكريبت اختبار: يحاكي تشغيل cron من CLI ويكتشف الأخطاء
 *
 * افتح في المتصفح:
 *   https://mariastore1.com/cron/test_cron_cli.php?key=YOUR_KEY
 *
 * سيعرض:
 *   1. هل PHP CLI يعمل؟
 *   2. هل المسار صحيح؟
 *   3. هل الملفات قابلة للقراءة؟
 *   4. هل يوجد أخطاء في تحميل الملفات؟
 *   5. تشغيل فعلي لـ send_push_notifications.php مع عرض كل المخرجات
 * --------------------------------------------------------------------
 */

require_once __DIR__ . '/../includes/env.php';
$valid_key = env('CRON_SECRET_KEY', 'CHANGE_ME_TO_RANDOM_STRING');

$secret_key = $_GET['key'] ?? '';
if (empty($secret_key) || $secret_key !== $valid_key) {
    http_response_code(403);
    die('Forbidden');
}

header('Content-Type: text/html; charset=utf-8');
header('X-Robots-Tag: noindex, nofollow');

date_default_timezone_set('Asia/Aden');
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<!DOCTYPE html><html lang='ar' dir='rtl'><head><meta charset='UTF-8'>";
echo "<title>اختبار cron CLI</title>";
echo "<style>
body{font-family:monospace;padding:20px;background:#f5f5f5;direction:rtl;line-height:1.6;}
.ok{color:green;font-weight:bold;}.err{color:red;font-weight:bold;}
.warn{color:orange;font-weight:bold;}.info{color:blue;}
.box{background:white;padding:15px;margin:10px 0;border-right:4px solid #007bff;border-radius:4px;}
pre{background:#1e1e1e;color:#d4d4d4;padding:15px;overflow:auto;direction:ltr;text-align:left;border-radius:4px;}
table{border-collapse:collapse;width:100%;background:white;}
td,th{border:1px solid #ddd;padding:8px;text-align:right;}
</style></head><body>";

echo "<h1>🔧 اختبار cron CLI — تشخيص شامل</h1>";

// ============================================================
// 1. معلومات البيئة
// ============================================================
echo "<div class='box'>";
echo "<h2>1. معلومات البيئة</h2>";
echo "<table>";
echo "<tr><td>PHP Version</td><td>" . PHP_VERSION . "</td></tr>";
echo "<tr><td>SAPI (Server API)</td><td>" . php_sapi_name() . "</td></tr>";
echo "<tr><td>هل CLI؟</td><td>" . (php_sapi_name() === 'cli' ? '✅ نعم' : '⚠️ لا (HTTP)') . "</td></tr>";
echo "<tr><td>Current User</td><td>" . get_current_user() . "</td></tr>";
echo "<tr><td>Script Path</td><td>" . __FILE__ . "</td></tr>";
echo "<tr><td>Document Root</td><td>" . ($_SERVER['DOCUMENT_ROOT'] ?? 'N/A') . "</td></tr>";
echo "<tr><td>Timezone</td><td>" . date_default_timezone_get() . "</td></tr>";
echo "<tr><td>Current Time</td><td>" . date('Y-m-d H:i:s') . "</td></tr>";
echo "</table>";
echo "</div>";

// ============================================================
// 2. فحص مسار cron الفعلي
// ============================================================
echo "<div class='box'>";
echo "<h2>2. فحص مسار cron الفعلي</h2>";

$cron_file = __DIR__ . '/send_push_notifications.php';
echo "<p><strong>المسار المتوقع:</strong> <code>$cron_file</code></p>";

if (file_exists($cron_file)) {
    echo "<p class='ok'>✅ الملف موجود</p>";
    $perms = substr(sprintf('%o', fileperms($cron_file)), -4);
    $owner = fileowner($cron_file);
    $size = filesize($cron_file);
    echo "<table>";
    echo "<tr><td>الصلاحيات</td><td>$perms</td></tr>";
    echo "<tr><td>المالك</td><td>$owner (" . get_current_user() . " должно يتطابق)</td></tr>";
    echo "<tr><td>الحجم</td><td>$size bytes</td></tr>";
    echo "<tr><td>آخر تعديل</td><td>" . date('Y-m-d H:i:s', filemtime($cron_file)) . "</td></tr>";
    echo "</table>";

    if (is_readable($cron_file)) {
        echo "<p class='ok'>✅ قابل للقراءة</p>";
    } else {
        echo "<p class='err'>❌ غير قابل للقراءة! نفّذ: chmod 644 $cron_file</p>";
    }
} else {
    echo "<p class='err'>❌ الملف غير موجود!</p>";
}
echo "</div>";

// ============================================================
// 3. فحص الملفات المطلوبة
// ============================================================
echo "<div class='box'>";
echo "<h2>3. فحص الملفات المطلوبة</h2>";

$required_files = [
    'includes/env.php' => __DIR__ . '/../includes/env.php',
    'includes/db_connect.php' => __DIR__ . '/../includes/db_connect.php',
    'includes/notifications.php' => __DIR__ . '/../includes/notifications.php',
    'includes/push_web.php' => __DIR__ . '/../includes/push_web.php',
    '.env' => __DIR__ . '/../.env',
];

echo "<table>";
echo "<tr><th>الملف</th><th>موجود؟</th><th>قابل للقراءة؟</th><th>الحجم</th></tr>";
foreach ($required_files as $name => $path) {
    $exists = file_exists($path);
    $readable = $exists && is_readable($path);
    $size = $exists ? filesize($path) : 0;
    echo "<tr>";
    echo "<td>$name</td>";
    echo "<td>" . ($exists ? "<span class='ok'>✅</span>" : "<span class='err'>❌</span>") . "</td>";
    echo "<td>" . ($readable ? "<span class='ok'>✅</span>" : "<span class='err'>❌</span>") . "</td>";
    echo "<td>$size</td>";
    echo "</tr>";
}
echo "</table>";
echo "</div>";

// ============================================================
// 4. فحص .env
// ============================================================
echo "<div class='box'>";
echo "<h2>4. فحص إعدادات .env</h2>";

echo "<table>";
echo "<tr><td>APP_ENV</td><td>" . env('APP_ENV', 'غير مضبوط') . "</td></tr>";
echo "<tr><td>SITE_URL</td><td>" . (env('SITE_URL', '') ?: '(فارغ - سيُكتشف تلقائياً)') . "</td></tr>";
echo "<tr><td>DB_HOST_PROD</td><td>" . (env('DB_HOST_PROD', '') ?: 'غير مضبوط') . "</td></tr>";
echo "<tr><td>DB_NAME_PROD</td><td>" . (env('DB_NAME_PROD', '') ?: 'غير مضبوط') . "</td></tr>";
echo "<tr><td>DB_USER_PROD</td><td>" . (env('DB_USER_PROD', '') ? '(مضبوط)' : 'غير مضبوط') . "</td></tr>";
echo "<tr><td>DB_PASS_PROD</td><td>" . (env('DB_PASS_PROD', '') ? '(مضبوط)' : 'غير مضبوط') . "</td></tr>";
echo "<tr><td>CRON_SECRET_KEY</td><td>" . (env('CRON_SECRET_KEY', '') ? '(مضبوط - ' . strlen(env('CRON_SECRET_KEY', '')) . ' حرف)' : 'غير مضبوط') . "</td></tr>";
echo "</table>";
echo "</div>";

// ============================================================
// 5. اختبار اتصال قاعدة البيانات
// ============================================================
echo "<div class='box'>";
echo "<h2>5. اختبار اتصال قاعدة البيانات</h2>";

try {
    require_once __DIR__ . '/../includes/db_connect.php';
    echo "<p class='ok'>✅ تم الاتصال بقاعدة البيانات بنجاح</p>";

    // اختبار استعلام بسيط
    $count = $conn->query("SELECT COUNT(*) FROM notifications WHERE is_sent = 0")->fetchColumn();
    echo "<p>الإشعارات المعلّقة (is_sent=0): <strong>$count</strong></p>";

    $subs = $conn->query("SELECT COUNT(*) FROM push_subscriptions WHERE is_active = 1")->fetchColumn();
    echo "<p>الاشتراكات النشطة: <strong>$subs</strong></p>";

} catch (Exception $e) {
    echo "<p class='err'>❌ خطأ في الاتصال: " . htmlspecialchars($e->getMessage()) . "</p>";
}
echo "</div>";

// ============================================================
// 6. تشغيل فعلي لـ cron مع التقاط كل المخرجات
// ============================================================
echo "<div class='box'>";
echo "<h2>6. تشغيل فعلي لـ send_push_notifications.php</h2>";

echo "<p>جاري التشغيل... (قد يستغرق عدة ثوان)</p>";

// التقاط كل المخرجات
ob_start();

// تعطيل exit لو موجود في الكود الأصلي
$exit_called = false;

try {
    // نسخ منطق cron مباشرة بدلاً من include (لتجنب exit)
    require_once __DIR__ . '/../includes/notifications.php';
    require_once __DIR__ . '/../includes/push_web.php';

    $manager = new NotificationsManager($conn);

    $web_push_enabled = $manager->getSetting('web_push_enabled', '0');
    echo "[INFO] Web Push enabled: $web_push_enabled\n";

    if ($web_push_enabled !== '1') {
        echo "[INFO] Web Push disabled. Exiting.\n";
    } else {
        // جلب الإشعارات المعلّقة
        $stmt = $conn->prepare("
            SELECT id, type, title, body, url, image, icon, created_at
            FROM notifications
            WHERE is_sent = 0
            AND (scheduled_at IS NULL OR scheduled_at <= NOW())
            AND (expires_at IS NULL OR expires_at > NOW())
            AND created_at > DATE_SUB(NOW(), INTERVAL 24 HOUR)
            ORDER BY created_at ASC
            LIMIT 50
        ");
        $stmt->execute();
        $pending = $stmt->fetchAll(PDO::FETCH_ASSOC);

        echo "[INFO] Pending notifications: " . count($pending) . "\n";

        if (!empty($pending)) {
            $subscriptions = $manager->getActiveSubscriptions();
            echo "[INFO] Active subscriptions: " . count($subscriptions) . "\n";

            if (!empty($subscriptions)) {
                $sent_count = 0;
                $failed_count = 0;

                foreach ($pending as $notif) {
                    echo "\n[PROCESSING] notif #{$notif['id']}: {$notif['title']}\n";

                    $success_count = 0;
                    $failure_count = 0;

                    foreach ($subscriptions as $sub) {
                        try {
                            $result = sendWebPushNotification($sub, $notif['id'], $conn);
                            if ($result === true) {
                                $success_count++;
                                echo "  ✅ sub#{$sub['id']} (user=" . ($sub['user_id'] ?? 'NULL') . ")\n";
                            } else {
                                $failure_count++;
                                $err_msg = is_string($result) ? $result : 'Unknown error';
                                echo "  ❌ sub#{$sub['id']} (user=" . ($sub['user_id'] ?? 'NULL') . "): {$err_msg}\n";
                            }
                        } catch (Exception $e) {
                            $failure_count++;
                            echo "  ❌ sub#{$sub['id']}: EXCEPTION: " . $e->getMessage() . "\n";
                        }
                    }

                    echo "  → Sent: {$success_count}/" . count($subscriptions) . "\n";

                    if ($success_count > 0) {
                        $stmt = $conn->prepare("UPDATE notifications SET is_sent = 1 WHERE id = ?");
                        $stmt->execute([$notif['id']]);
                        $sent_count++;
                    } else {
                        $failed_count++;
                        // لو قديم (>6h)، سلّم به
                        $age_hours = (time() - strtotime($notif['created_at'])) / 3600;
                        if ($age_hours > 6) {
                            $stmt = $conn->prepare("UPDATE notifications SET is_sent = 1 WHERE id = ?");
                            $stmt->execute([$notif['id']]);
                            echo "  ⚠ Old (>6h), marking as sent\n";
                        }
                    }

                    usleep(100000);
                }

                echo "\n[SUMMARY] Sent: $sent_count, Failed (will retry): $failed_count\n";
            }
        }
    }

} catch (Exception $e) {
    echo "[EXCEPTION] " . $e->getMessage() . "\n";
    echo "[TRACE] " . $e->getTraceAsString() . "\n";
}

$output = ob_get_clean();

echo "<pre>$output</pre>";
echo "</div>";

// ============================================================
// 7. فحص صلاحيات مجلد cron (للكتابة في log)
// ============================================================
echo "<div class='box'>";
echo "<h2>7. فحص صلاحيات الكتابة (للـ log files)</h2>";

$write_paths = [
    __DIR__ . '/push_notifications.log',
    __DIR__ . '/push_errors.log',
    __DIR__ . '/cron_errors.log',
];

echo "<table>";
echo "<tr><th>الملف</th><th>موجود؟</th><th>قابل للكتابة؟</th><th>الحجم</th></tr>";
foreach ($write_paths as $path) {
    $exists = file_exists($path);
    $writable = $exists && is_writable($path);
    $size = $exists ? filesize($path) : 0;
    echo "<tr>";
    echo "<td>" . basename($path) . "</td>";
    echo "<td>" . ($exists ? "<span class='ok'>✅</span>" : "<span class='warn'>⚠️ غير موجود</span>") . "</td>";
    echo "<td>" . ($writable ? "<span class='ok'>✅</span>" : "<span class='err'>❌</span>") . "</td>";
    echo "<td>$size</td>";
    echo "</tr>";
}
echo "</table>";

// اختبار كتابة فعلي
$test_file = __DIR__ . '/write_test_' . time() . '.txt';
$test_write = @file_put_contents($test_file, 'test');
if ($test_write !== false) {
    echo "<p class='ok'>✅ يمكن الكتابة في مجلد cron</p>";
    @unlink($test_file);
} else {
    echo "<p class='err'>❌ لا يمكن الكتابة في مجلد cron! نفّذ: chmod 755 " . __DIR__ . "</p>";
}
echo "</div>";

// ============================================================
// 8. اقتراحات الإصلاح
// ============================================================
echo "<div class='box'>";
echo "<h2>8. خطوات الإصلاح المقترحة</h2>";

echo "<ol>";
echo "<li><strong>تأكد أن أمر cron صحيح:</strong><br>
    <code>/usr/bin/php /home/u905256684/domains/mariastore1.com/public_html/cron/send_push_notifications.php</code>
    </li>";
echo "<li><strong>تأكد أن PHP CLI مثبت في:</strong> <code>/usr/bin/php</code><br>
    (لو لا، جرّب: <code>/usr/local/bin/php</code> أو <code>php</code>)</li>";
echo "<li><strong>صلاحيات الملفات:</strong><br>
    <code>chmod 644 cron/send_push_notifications.php</code><br>
    <code>chmod 755 cron/</code>
    </li>";
echo "<li><strong>لو cron لا يعمل، استخدم البديل:</strong><br>
    اضغط زر 'تشغيل cron يدوياً' في <a href='../admin/diagnose_push.php'>diagnose_push.php</a><br>
    أو استخدم <a href='https://cron-job.org' target='_blank'>cron-job.org</a> مع:<br>
    <code>https://mariastore1.com/cron/cron_runner.php?key=" . htmlspecialchars($valid_key) . "</code>
    </li>";
echo "</ol>";
echo "</div>";

echo "</body></html>";

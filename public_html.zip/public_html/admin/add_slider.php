<?php
session_start();
require_once __DIR__ . '/../includes/db_connect.php';
require_once __DIR__ . '/../includes/functions.php';

require_once __DIR__ . '/../includes/auth.php';
// التحقق من أن المستخدم مدير
checkAdminRole();

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title']);
    $description = trim($_POST['description']);
    $link = trim($_POST['link']);
    $sort_order = (int) $_POST['sort_order'];
    $is_active = isset($_POST['is_active']) ? 1 : 0;

    // رفع الصورة
    $image_url = '';
    if (isset($_FILES['image']) && $_FILES['image']['error'] === 0) {
        $ext = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
        $filename = uniqid() . '.' . $ext;
        move_uploaded_file($_FILES['image']['tmp_name'], __DIR__ . '/../assets/images/banners/' . $filename);
        $image_url = $filename;
    }

    $allowed_types = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
    $ext = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));

    if (!in_array($ext, $allowed_types)) {
        $error = "صيغة الصورة غير مدعومة. الصيغ المسموح بها: JPG, PNG, GIF, WEBP.";
    }

    if (empty($title) || empty($description)) {
        $error = "يجب تعبئة العنوان والوصف.";
    }



    if ($image_url) {
        $stmt = $conn->prepare("INSERT INTO sliders (title, description, link, image_url, sort_order, is_active) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->execute([$title, $description, $link, $image_url, $sort_order, $is_active]);
        $_SESSION['success'] = "تمت إضافة الشريحة بنجاح!";
        header("Location: " . SITE_URL . "admin/manage_sliders.php");
        exit;
    } else {
        $error = "يجب رفع صورة للشريحة.";
    }
}

include __DIR__ . '/../includes/admin_header.php';
?>

<div class="container">
    <h1 class="page-title">إضافة شريحة جديدة</h1>
    <?php if ($error): ?><p class="error"><?= $error ?></p><?php endif; ?>
    <form method="post" enctype="multipart/form-data">
        <div class="form-group">
            <label>العنوان</label>
            <input type="text" name="title" required>
        </div>
        <div class="form-group">
            <label>الوصف</label>
            <textarea name="description" rows="3"></textarea>
        </div>
        <div class="form-group">
            <label>الرابط (اختياري)</label>
            <input type="text" name="link">
        </div>
        <div class="form-group">
            <label>ترتيب الظهور</label>
            <input type="number" name="sort_order" value="0">
        </div>
        <div class="form-group">
            <label>الصورة</label>
            <input type="file" name="image" required>
        </div>
        <div class="form-group">
            <label><input type="checkbox" name="is_active" checked> نشطة</label>
        </div>
        <button type="submit" class="btn">حفظ</button>
        <a href="<?php echo SITE_URL; ?>admin/manage_sliders.php" class="btn btn-cancel">إلغاء</a>
    </form>
</div>

<?php include __DIR__ . '/../includes/admin_footer.php'; ?>
<?php
/**
 * admin/notification_settings.php
 * --------------------------------------------------------------------
 * صفحة إعدادات نظام الإشعارات في لوحة الإدارة
 * --------------------------------------------------------------------
 */

require_once __DIR__ . '/../includes/db_connect.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/notifications.php';

checkAdminRole();

$notifManager = new NotificationsManager($conn);

// معالجة حفظ الإعدادات
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_settings'])) {
    $settings = [
        'notify_new_product' => isset($_POST['notify_new_product']) ? '1' : '0',
        'notify_new_discount' => isset($_POST['notify_new_discount']) ? '1' : '0',
        'notify_min_discount_percentage' => max(0, min(100, floatval($_POST['notify_min_discount_percentage'] ?? 5))),
        'notify_sound' => isset($_POST['notify_sound']) ? '1' : '0',
        'notify_auto_dismiss_seconds' => max(3, min(60, intval($_POST['notify_auto_dismiss_seconds'] ?? 8))),
        'notify_max_per_page' => max(5, min(100, intval($_POST['notify_max_per_page'] ?? 20))),
        'web_push_enabled' => isset($_POST['web_push_enabled']) ? '1' : '0',
        'vapid_subject' => trim($_POST['vapid_subject'] ?? 'mailto:admin@mariastore1.com'),
    ];

    // حفظ المفاتيح لو تم إدخالها
    if (!empty($_POST['vapid_public_key'])) {
        $settings['vapid_public_key'] = trim($_POST['vapid_public_key']);
    }
    if (!empty($_POST['vapid_private_key'])) {
        $settings['vapid_private_key'] = trim($_POST['vapid_private_key']);
    }

    foreach ($settings as $key => $value) {
        $notifManager->setSetting($key, $value);
    }

    $_SESSION['success_message'] = "تم حفظ إعدادات الإشعارات بنجاح";
    header("Location: " . SITE_URL . "admin/notification_settings.php");
    exit;
}

// معالجة إنشاء إشعار تجريبي
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['test_notification'])) {
    $title = trim($_POST['test_title'] ?? 'إشعار تجريبي');
    $body = trim($_POST['test_body'] ?? 'هذا إشعار تجريبي للتحقق من عمل النظام');
    
    $notif_id = $notifManager->create([
        'type' => 'test',
        'title' => $title,
        'body' => $body,
        'icon' => 'fa-vial',
        'target_audience' => 'all',
    ]);
    
    if ($notif_id) {
        $_SESSION['success_message'] = "تم إنشاء إشعار تجريبي بنجاح (ID: $notif_id)";
    } else {
        $_SESSION['error_message'] = "فشل إنشاء الإشعار التجريبي";
    }
    header("Location: " . SITE_URL . "admin/notification_settings.php");
    exit;
}

// معالجة حذف إشعارات قديمة
if (isset($_GET['cleanup']) && $_GET['cleanup'] == '1') {
    $days = intval($_GET['days'] ?? 30);
    try {
        $stmt = $conn->prepare("DELETE FROM notifications WHERE created_at < DATE_SUB(NOW(), INTERVAL ? DAY)");
        $stmt->execute([$days]);
        $deleted = $stmt->rowCount();
        $_SESSION['success_message'] = "تم حذف $deleted إشعار أقدم من $days يوم";
    } catch (PDOException $e) {
        $_SESSION['error_message'] = "خطأ في الحذف: " . $e->getMessage();
    }
    header("Location: " . SITE_URL . "admin/notification_settings.php");
    exit;
}

// إحصائيات
$stats = [
    'total_notifications' => 0,
    'unread_count' => 0,
    'total_subscriptions' => 0,
    'active_subscriptions' => 0,
];

try {
    $stats['total_notifications'] = $conn->query("SELECT COUNT(*) FROM notifications")->fetchColumn();
    $stats['total_subscriptions'] = $conn->query("SELECT COUNT(*) FROM push_subscriptions")->fetchColumn();
    $stats['active_subscriptions'] = $conn->query("SELECT COUNT(*) FROM push_subscriptions WHERE is_active = 1")->fetchColumn();
} catch (PDOException $e) {}

// جلب آخر 10 إشعارات
$recent_notifications = [];
try {
    $recent_notifications = $conn->query("
        SELECT * FROM notifications 
        ORDER BY created_at DESC 
        LIMIT 10
    ")->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {}

include __DIR__ . '/../includes/admin_header.php';
?>

<div class="content-wrapper">
    <div class="container-fluid">
        <?php if (isset($_SESSION['success_message'])): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i> <?= htmlspecialchars($_SESSION['success_message']) ?>
                <?php unset($_SESSION['success_message']); ?>
            </div>
        <?php endif; ?>

        <?php if (isset($_SESSION['error_message'])): ?>
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-circle"></i> <?= htmlspecialchars($_SESSION['error_message']) ?>
                <?php unset($_SESSION['error_message']); ?>
            </div>
        <?php endif; ?>

        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header bg-primary text-white">
                        <h4><i class="fas fa-bell"></i> إعدادات نظام الإشعارات</h4>
                    </div>
                    <div class="card-body">
                        <!-- إحصائيات سريعة -->
                        <div class="row mb-4">
                            <div class="col-md-3">
                                <div class="stat-card text-center">
                                    <i class="fas fa-bell fa-2x text-primary"></i>
                                    <h3><?= $stats['total_notifications'] ?></h3>
                                    <p>إجمالي الإشعارات</p>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="stat-card text-center">
                                    <i class="fas fa-mobile-alt fa-2x text-success"></i>
                                    <h3><?= $stats['active_subscriptions'] ?></h3>
                                    <p>اشتراكات نشطة</p>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="stat-card text-center">
                                    <i class="fas fa-users fa-2x text-info"></i>
                                    <h3><?= $stats['total_subscriptions'] ?></h3>
                                    <p>إجمالي الاشتراكات</p>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="stat-card text-center">
                                    <i class="fas fa-box fa-2x text-warning"></i>
                                    <h3><?= $notifManager->getSetting('web_push_enabled', '0') === '1' ? 'مفعّل' : 'معطّل' ?></h3>
                                    <p>Web Push</p>
                                </div>
                            </div>
                        </div>

                        <!-- نموذج الإعدادات -->
                        <form method="post">
                            <input type="hidden" name="save_settings" value="1">
                            
                            <h5 class="mb-3"><i class="fas fa-cog"></i> الإعدادات العامة</h5>
                            
                            <div class="form-group">
                                <div class="custom-control custom-switch">
                                    <input type="checkbox" class="custom-control-input" id="notify_new_product" name="notify_new_product"
                                        <?= $notifManager->getSetting('notify_new_product', '1') === '1' ? 'checked' : '' ?>>
                                    <label class="custom-control-label" for="notify_new_product">
                                        إشعار عند إضافة منتج جديد
                                    </label>
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="custom-control custom-switch">
                                    <input type="checkbox" class="custom-control-input" id="notify_new_discount" name="notify_new_discount"
                                        <?= $notifManager->getSetting('notify_new_discount', '1') === '1' ? 'checked' : '' ?>>
                                    <label class="custom-control-label" for="notify_new_discount">
                                        إشعار عند إضافة خصم جديد
                                    </label>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="notify_min_discount_percentage">أقل نسبة خصم للإشعار (%)</label>
                                <input type="number" class="form-control" id="notify_min_discount_percentage" name="notify_min_discount_percentage"
                                    min="0" max="100" step="0.5" value="<?= htmlspecialchars($notifManager->getSetting('notify_min_discount_percentage', '5')) ?>">
                                <small class="form-text text-muted">الإشعارات تُرسل فقط للخصومات التي تتجاوز هذه النسبة</small>
                            </div>

                            <h5 class="mt-4 mb-3"><i class="fas fa-volume-up"></i> الإعدادات السلوكية</h5>

                            <div class="form-group">
                                <div class="custom-control custom-switch">
                                    <input type="checkbox" class="custom-control-input" id="notify_sound" name="notify_sound"
                                        <?= $notifManager->getSetting('notify_sound', '1') === '1' ? 'checked' : '' ?>>
                                    <label class="custom-control-label" for="notify_sound">
                                        تشغيل صوت عند وصول إشعار
                                    </label>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="notify_auto_dismiss_seconds">مدة عرض الإشعار (ثواني)</label>
                                <input type="number" class="form-control" id="notify_auto_dismiss_seconds" name="notify_auto_dismiss_seconds"
                                    min="3" max="60" value="<?= htmlspecialchars($notifManager->getSetting('notify_auto_dismiss_seconds', '8')) ?>">
                            </div>

                            <div class="form-group">
                                <label for="notify_max_per_page">عدد الإشعارات per page</label>
                                <input type="number" class="form-control" id="notify_max_per_page" name="notify_max_per_page"
                                    min="5" max="100" value="<?= htmlspecialchars($notifManager->getSetting('notify_max_per_page', '20')) ?>">
                            </div>

                            <h5 class="mt-4 mb-3"><i class="fas fa-mobile-alt"></i> Web Push (للمتصفح المغلق)</h5>

                            <div class="alert alert-info">
                                <i class="fas fa-info-circle"></i>
                                <strong>Web Push</strong> يسمح بإرسال إشعارات للمستخدمين حتى لو كان المتصفح مغلقاً.
                                يتطلب HTTPS ومفاتيح VAPID.
                            </div>

                            <div class="form-group">
                                <div class="custom-control custom-switch">
                                    <input type="checkbox" class="custom-control-input" id="web_push_enabled" name="web_push_enabled"
                                        <?= $notifManager->getSetting('web_push_enabled', '0') === '1' ? 'checked' : '' ?>>
                                    <label class="custom-control-label" for="web_push_enabled">
                                        تفعيل Web Push
                                    </label>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="vapid_subject">VAPID Subject (بريد الإدارة)</label>
                                <input type="text" class="form-control" id="vapid_subject" name="vapid_subject"
                                    value="<?= htmlspecialchars($notifManager->getSetting('vapid_subject', 'mailto:admin@mariastore1.com')) ?>"
                                    placeholder="mailto:admin@yoursite.com">
                            </div>

                            <div class="form-group">
                                <label for="vapid_public_key">VAPID Public Key</label>
                                <input type="text" class="form-control" id="vapid_public_key" name="vapid_public_key"
                                    value="<?= htmlspecialchars($notifManager->getSetting('vapid_public_key', '')) ?>"
                                    placeholder="BPxNi3..." dir="ltr">
                                <small class="form-text text-muted">
                                    لتوليد المفاتيح: <a href="https://web-push-codelab.glitch.me" target="_blank">https://web-push-codelab.glitch.me</a>
                                    أو شغّل <code>install_notifications.php</code>
                                </small>
                            </div>

                            <div class="form-group">
                                <label for="vapid_private_key">VAPID Private Key (سري)</label>
                                <input type="text" class="form-control" id="vapid_private_key" name="vapid_private_key"
                                    value="<?= htmlspecialchars($notifManager->getSetting('vapid_private_key', '')) ?>"
                                    placeholder="a1b2c3..." dir="ltr">
                            </div>

                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-save"></i> حفظ الإعدادات
                            </button>
                        </form>

                        <hr class="my-4">

                        <!-- إشعار تجريبي -->
                        <h5 class="mb-3"><i class="fas fa-vial"></i> إرسال إشعار تجريبي</h5>
                        <form method="post" class="form-inline">
                            <input type="hidden" name="test_notification" value="1">
                            <input type="text" class="form-control mb-2 mr-sm-2" name="test_title" placeholder="عنوان الإشعار" value="إشعار تجريبي" required>
                            <input type="text" class="form-control mb-2 mr-sm-2" name="test_body" placeholder="نص الإشعار" value="هذا إشعار تجريبي" required>
                            <button type="submit" class="btn btn-success mb-2">
                                <i class="fas fa-paper-plane"></i> إرسال
                            </button>
                        </form>

                        <hr class="my-4">

                        <!-- آخر الإشعارات -->
                        <h5 class="mb-3"><i class="fas fa-history"></i> آخر 10 إشعارات</h5>
                        <?php if (empty($recent_notifications)): ?>
                            <p class="text-muted">لا توجد إشعارات بعد.</p>
                        <?php else: ?>
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>النوع</th>
                                            <th>العنوان</th>
                                            <th>النص</th>
                                            <th>التاريخ</th>
                                            <th>الحالة</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($recent_notifications as $n): ?>
                                            <tr>
                                                <td><?= $n['id'] ?></td>
                                                <td>
                                                    <span class="badge badge-<?= $n['type'] === 'new_product' ? 'success' : ($n['type'] === 'new_discount' ? 'warning' : 'info') ?>">
                                                        <?= htmlspecialchars($n['type']) ?>
                                                    </span>
                                                </td>
                                                <td><?= htmlspecialchars($n['title']) ?></td>
                                                <td><?= htmlspecialchars(mb_substr($n['body'], 0, 50)) ?>...</td>
                                                <td><?= htmlspecialchars($n['created_at']) ?></td>
                                                <td>
                                                    <?php if ($n['is_sent']): ?>
                                                        <span class="badge badge-success">مُرسل</span>
                                                    <?php else: ?>
                                                        <span class="badge badge-secondary">معلّق</span>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php endif; ?>

                        <hr class="my-4">

                        <!-- صيانة -->
                        <h5 class="mb-3"><i class="fas fa-broom"></i> صيانة</h5>
                        <a href="?cleanup=1&days=30" class="btn btn-warning"
                           onclick="return confirm('سيتم حذف جميع الإشعارات الأقدم من 30 يوم. متابعة؟')">
                            <i class="fas fa-trash"></i> حذف إشعارات أقدم من 30 يوم
                        </a>
                        <a href="?cleanup=1&days=90" class="btn btn-outline-warning"
                           onclick="return confirm('سيتم حذف جميع الإشعارات الأقدم من 90 يوم. متابعة؟')">
                            <i class="fas fa-trash"></i> حذف أقدم من 90 يوم
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.stat-card {
    background: white;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.08);
    transition: transform 0.3s;
}
.stat-card:hover {
    transform: translateY(-3px);
}
.stat-card h3 {
    margin: 10px 0 5px;
    font-weight: bold;
    color: #333;
}
.stat-card p {
    margin: 0;
    color: #666;
    font-size: 14px;
}
</style>

<?php require_once '../includes/admin_footer.php'; ?>

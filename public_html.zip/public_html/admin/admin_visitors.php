<?php
// admin_visitors.php
require_once __DIR__ . '/../includes/db_connect.php';
require_once __DIR__ . '/../includes/auth.php';

// التحقق من صلاحية المدير
if ($_SESSION['role'] !== 'admin') {
    header("Location: " . SITE_URL);
    exit;
}

// جلب إحصائيات الزوار
$stmt = $conn->prepare("
    SELECT 
        COUNT(*) as total_visitors,
        COUNT(DISTINCT ip_address) as unique_visitors,
        COUNT(DISTINCT country) as countries,
        AVG(TIMESTAMPDIFF(MINUTE, created_at, updated_at)) as avg_session_duration
    FROM visitors
    WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
");
$stmt->execute();
$stats = $stmt->fetch();

// جلب الزوار الأخيرين
$stmt = $conn->prepare("
    SELECT v.*, u.username, u.email 
    FROM visitors v 
    LEFT JOIN users u ON v.user_id = u.id 
    ORDER BY v.created_at DESC 
    LIMIT 50
");
$stmt->execute();
$recent_visitors = $stmt->fetchAll();

// جلب إحصائيات الصفحات الأكثر زيارة
$stmt = $conn->prepare("
    SELECT page_url, COUNT(*) as visit_count 
    FROM page_views 
    WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
    GROUP BY page_url 
    ORDER BY visit_count DESC 
    LIMIT 10
");
$stmt->execute();
$popular_pages = $stmt->fetchAll();

// جلب إحصائيات حسب البلد
$stmt = $conn->prepare("
    SELECT country, COUNT(*) as visitor_count 
    FROM visitors 
    WHERE country != 'Unknown' AND created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
    GROUP BY country 
    ORDER BY visitor_count DESC
");
$stmt->execute();
$visitors_by_country = $stmt->fetchAll();

$pageTitle = "إحصاءات الزوار - لوحة التحكم";
include __DIR__ . '/../includes/admin_header.php';
?>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.rtl.min.css">

<div class="container-fluid py-4">
    <div class="row">
        <div class="col-12">
            <h1 class="h3 mb-4">إحصاءات الزوار</h1>

            <!-- بطاقات الإحصائيات -->
            <div class="row">
                <div class="col-xl-3 col-md-6 mb-4">
                    <div class="card border-left-primary shadow h-100 py-2">
                        <div class="card-body">
                            <div class="row no-gutters align-items-center">
                                <div class="col mr-2">
                                    <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                        إجمالي الزوار (30 يوم)</div>
                                    <div class="h5 mb-0 font-weight-bold text-gray-800">
                                        <?= number_format($stats['total_visitors']) ?>
                                    </div>
                                </div>
                                <div class="col-auto">
                                    <i class="fas fa-users fa-2x text-gray-300"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-xl-3 col-md-6 mb-4">
                    <div class="card border-left-success shadow h-100 py-2">
                        <div class="card-body">
                            <div class="row no-gutters align-items-center">
                                <div class="col mr-2">
                                    <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                        زوار فريدون</div>
                                    <div class="h5 mb-0 font-weight-bold text-gray-800">
                                        <?= number_format($stats['unique_visitors']) ?>
                                    </div>
                                </div>
                                <div class="col-auto">
                                    <i class="fas fa-user fa-2x text-gray-300"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-xl-3 col-md-6 mb-4">
                    <div class="card border-left-info shadow h-100 py-2">
                        <div class="card-body">
                            <div class="row no-gutters align-items-center">
                                <div class="col mr-2">
                                    <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                                        عدد الدول</div>
                                    <div class="h5 mb-0 font-weight-bold text-gray-800">
                                        <?= number_format($stats['countries']) ?>
                                    </div>
                                </div>
                                <div class="col-auto">
                                    <i class="fas fa-globe fa-2x text-gray-300"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-xl-3 col-md-6 mb-4">
                    <div class="card border-left-warning shadow h-100 py-2">
                        <div class="card-body">
                            <div class="row no-gutters align-items-center">
                                <div class="col mr-2">
                                    <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                        مدة المتوسط (دقائق)</div>
                                    <div class="h5 mb-0 font-weight-bold text-gray-800">
                                        <?= number_format($stats['avg_session_duration'], 1) ?>
                                    </div>
                                </div>
                                <div class="col-auto">
                                    <i class="fas fa-clock fa-2x text-gray-300"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- الزوار الأخيرين -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">الزوار الأخيرين</h6>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered" id="visitorsTable" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th>IP</th>
                                    <th>البلد</th>
                                    <th>المدينة</th>
                                    <th>المتصفح</th>
                                    <th>نظام التشغيل</th>
                                    <th>المستخدم</th>
                                    <th>وقت الزيارة</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($recent_visitors as $visitor): ?>
                                    <tr>
                                        <td><?= htmlspecialchars($visitor['ip_address']) ?></td>
                                        <td><?= htmlspecialchars($visitor['country']) ?></td>
                                        <td><?= htmlspecialchars($visitor['city']) ?></td>
                                        <td><?= htmlspecialchars($visitor['browser']) ?></td>
                                        <td><?= htmlspecialchars($visitor['operating_system']) ?></td>
                                        <td>
                                            <?php if ($visitor['user_id']): ?>
                                                <?= htmlspecialchars($visitor['username'] ?? $visitor['email']) ?>
                                            <?php else: ?>
                                                زائر
                                            <?php endif; ?>
                                        </td>
                                        <td><?= date('Y-m-d H:i', strtotime($visitor['created_at'])) ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- الصفحات الأكثر زيارة -->
            <div class="row">
                <div class="col-lg-6">
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">الصفحات الأكثر زيارة (أسبوع)</h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>الصفحة</th>
                                            <th>عدد الزيارات</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($popular_pages as $page): ?>
                                            <tr>
                                                <td><?= htmlspecialchars($page['page_url']) ?></td>
                                                <td><?= number_format($page['visit_count']) ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- الزوار حسب البلد -->
                <div class="col-lg-6">
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">الزوار حسب البلد (30 يوم)</h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>البلد</th>
                                            <th>عدد الزوار</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($visitors_by_country as $country): ?>
                                            <tr>
                                                <td><?= htmlspecialchars($country['country']) ?></td>
                                                <td><?= number_format($country['visitor_count']) ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include __DIR__ . '/../includes/admin_footer.php'; ?>
<?php
session_start();
require_once __DIR__ . '/../includes/db_connect.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

// التحقق من أن المستخدم مدير
checkAdminRole();

// معالجة AJAX للتحقق من الطلبات الجديدة
// معالجة AJAX للتحقق من الطلبات الجديدة
if (isset($_GET['check_new_orders'])) {
    header('Content-Type: application/json');

    $last_check = isset($_GET['last_check']) ? (int)$_GET['last_check'] : 0;

    try {
        $stmt = $conn->prepare("SELECT COUNT(*) as new_orders FROM orders WHERE created_at > FROM_UNIXTIME(?)");
        $stmt->execute([$last_check]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        // جلب تفاصيل الطلبات الجديدة إذا وجدت
        $new_orders_details = [];
        if ($result['new_orders'] > 0) {
            $stmt = $conn->prepare("SELECT o.*, 
                               COALESCE(u.username, o.guest_name) as username 
                        FROM orders o 
                        LEFT JOIN users u ON o.user_id = u.id 
                        WHERE o.created_at > FROM_UNIXTIME(?) 
                        ORDER BY o.created_at DESC");
            $stmt->execute([$last_check]);
            $new_orders_details = $stmt->fetchAll(PDO::FETCH_ASSOC);

            // حساب التكلفة والربح للطلبات الجديدة
            foreach ($new_orders_details as &$order) {
                $cost_stmt = $conn->prepare("
                    SELECT SUM(p.cost_price * oi.quantity) as total_cost 
                    FROM order_items oi 
                    JOIN products p ON oi.product_id = p.id 
                    WHERE oi.order_id = ?
                ");
                $cost_stmt->execute([$order['id']]);
                $cost_data = $cost_stmt->fetch(PDO::FETCH_ASSOC);

                $order['total_cost'] = $cost_data['total_cost'] ?? 0;
                $order['products_amount'] = $order['subtotal'];
                $order['products_profit'] = $order['products_amount'] - $order['total_cost'];
                $order['total_profit'] = $order['total_amount'] - $order['total_cost'] - $order['shipping_cost'];
            }
            unset($order);
        }

        echo json_encode([
            'new_orders' => $result['new_orders'],
            'orders_details' => $new_orders_details,
            'timestamp' => time()
        ]);
    } catch (PDOException $e) {
        echo json_encode(['error' => $e->getMessage()]);
    }
    exit;
}
// معالجة تغيير حالة الطلب
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_status'])) {
    $order_id = (int)$_POST['order_id'];
    $new_status = $_POST['status'];

    try {
        $stmt = $conn->prepare("UPDATE orders SET status = ? WHERE id = ?");
        $stmt->execute([$new_status, $order_id]);

        $_SESSION['success'] = "تم تحديث حالة الطلب بنجاح";
        header("Location: " . SITE_URL . "admin/orders.php");
        exit;
    } catch (PDOException $e) {
        $error = "خطأ في تحديث حالة الطلب: " . $e->getMessage();
    }
}

// معالجة حذف الطلب
if (isset($_GET['delete_id'])) {
    $order_id = (int)$_GET['delete_id'];

    try {
        $conn->beginTransaction();

        // حذف عناصر الطلب أولاً
        $stmt = $conn->prepare("DELETE FROM order_items WHERE order_id = ?");
        $stmt->execute([$order_id]);

        // ثم حذف الطلب نفسه
        $stmt = $conn->prepare("DELETE FROM orders WHERE id = ?");
        $stmt->execute([$order_id]);

        $conn->commit();

        $_SESSION['success'] = "تم حذف الطلب بنجاح";
        header("Location: " . SITE_URL . "admin/orders.php");
        exit;
    } catch (PDOException $e) {
        $conn->rollBack();
        $error = "خطأ في حذف الطلب: " . $e->getMessage();
    }
}

// جلب جميع الطلبات مع معلومات العملاء
$orders = [];
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$status_filter = isset($_GET['status']) ? $_GET['status'] : '';

try {
    $query = "SELECT 
    o.*, 
    COALESCE(u.username, o.guest_name) as customer_name,
    COALESCE(u.email, o.guest_email) as customer_email,
    COALESCE(u.phone, o.guest_phone) as customer_phone,
    pm.method_name AS payment_method_name,
    pm.account_number AS payment_account,
    CASE 
        WHEN o.user_id IS NOT NULL THEN 'مستخدم مسجل'
        ELSE 'زائر'
    END as customer_type
    FROM orders o
    LEFT JOIN users u ON o.user_id = u.id
    LEFT JOIN payment_methods pm ON o.payment_method = pm.id";

    $params = [];

    // تطبيق عوامل التصفية إذا وجدت
    $where = [];
    if (!empty($search)) {
        $where[] = "(o.id = :search 
                OR u.username LIKE :search_like 
                OR u.email LIKE :search_like 
                OR o.guest_name LIKE :search_like 
                OR o.guest_email LIKE :search_like
                OR o.guest_phone LIKE :search_like)";
        $params[':search'] = $search;
        $params[':search_like'] = "%$search%";
    }

    if (!empty($status_filter) && $status_filter != 'all') {
        $where[] = "o.status = :status";
        $params[':status'] = $status_filter;
    }

    if (!empty($where)) {
        $query .= " WHERE " . implode(" AND ", $where);
    }

    $query .= " ORDER BY o.created_at DESC";

    $stmt = $conn->prepare($query);
    $stmt->execute($params);
    $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // جلب إجمالي سعر التكلفة لكل طلب
    foreach ($orders as &$order) {
        $cost_stmt = $conn->prepare("
            SELECT SUM(p.cost_price * oi.quantity) as total_cost 
            FROM order_items oi 
            JOIN products p ON oi.product_id = p.id 
            WHERE oi.order_id = ?
        ");
        $cost_stmt->execute([$order['id']]);
        $cost_data = $cost_stmt->fetch(PDO::FETCH_ASSOC);

        $order['total_cost'] = $cost_data['total_cost'] ?? 0;

        // حساب سعر المنتجات فقط (بدون الشحن)
        $order['products_amount'] = $order['subtotal'];

        // حساب الربح (سعر المنتجات فقط - تكلفة المنتجات فقط)
        $order['products_profit'] = $order['products_amount'] - $order['total_cost'];

        // حساب الربح الإجمالي (بما في ذلك الشحن)
        $order['total_profit'] = $order['total_amount'] - $order['total_cost'] - $order['shipping_cost'];
    }
    unset($order); // كسر المرجع

} catch (PDOException $e) {
    $error = "خطأ في جلب الطلبات: " . $e->getMessage();
}

// تعيين عنوان الصفحة
$page_title = "إدارة الطلبات";
?>
<!-- <link rel="stylesheet" href="<?php echo SITE_URL; ?>assets/css/order_style.css"> -->


<?php include __DIR__ . '/../includes/admin_header.php'; ?>

<div class="admin-container">
    <div class="admin-actions">
        <div class="search-filter">
            <form method="get" class="search-form">
                <div class="form-group">
                    <input type="text" name="search" placeholder="ابحث برقم الطلب أو اسم العميل أو البريد"
                        value="<?= htmlspecialchars($search) ?>">
                    <button type="submit"><i class="fas fa-search"></i></button>
                </div>
            </form>

            <form method="get" class="filter-form">
                <div class="form-group">
                    <select name="status" onchange="this.form.submit()">
                        <option value="all" <?= $status_filter == 'all' ? 'selected' : '' ?>>جميع الحالات</option>
                        <option value="pending" <?= $status_filter == 'pending' ? 'selected' : '' ?>>قيد الانتظار</option>
                        <option value="processing" <?= $status_filter == 'processing' ? 'selected' : '' ?>>قيد المعالجة</option>
                        <option value="in_the_way" <?= $status_filter == 'in_the_way' ? 'selected' : '' ?>>في الطريق</option>
                        <option value="completed" <?= $status_filter == 'completed' ? 'selected' : '' ?>>مكتمل</option>
                        <option value="cancelled" <?= $status_filter == 'cancelled' ? 'selected' : '' ?>>ملغي</option>
                    </select>
                </div>
                <?php if (!empty($search)): ?>
                    <input type="hidden" name="search" value="<?= htmlspecialchars($search) ?>">
                <?php endif; ?>
            </form>
            <a href="<?php echo SITE_URL; ?>admin/logs.php">تقرير الطلبات</a>
        </div>
        <!-- إضافة سطر عدد النتائج هنا -->
        <div class="results-count">
            <?php if (!empty($orders)): ?>
                <p>عرض <?= count($orders) ?> طلب</p>
            <?php else: ?>
                <p>لا توجد نتائج</p>
            <?php endif; ?>
        </div>
    </div>

    <h1 class="page-title"><i class="fas fa-shopping-cart"></i> إدارة الطلبات</h1>

    <?php if (isset($_SESSION['success'])): ?>
        <div class="alert alert-success">
            <?= $_SESSION['success'] ?>
            <?php unset($_SESSION['success']); ?>
        </div>
    <?php endif; ?>

    <?php if (isset($error)): ?>
        <div class="alert alert-danger">
            <?= $error ?>
        </div>
    <?php endif; ?>

    <div class="orders-grid">
        <?php if (empty($orders)): ?>
            <div class="empty-state">
                <i class="fas fa-shopping-cart fa-3x"></i>
                <p>لا توجد طلبات متاحة</p>
                <a href="<?php echo SITE_URL; ?>admin/orders.php" class="btn btn-pink">عرض جميع الطلبات</a>
            </div>
        <?php else: ?>
            <div class="responsive-table">
                <table class="orders-table">
                    <thead>
                        <tr>
                            <th>رقم الطلب</th>
                            <th>نوع العميل</th>
                            <th>العميل</th>
                            <th>البريد الإلكتروني</th>
                            <th>سعر المنتجات</th> <!-- عمود جديد -->
                            <th>سعر الشحن</th> <!-- عمود جديد -->
                            <th>المبلغ الإجمالي</th>
                            <th>تكلفة المنتجات</th>
                            <th>ربح المنتجات</th> <!-- عمود جديد -->
                            <th>تاريخ الطلب</th>
                            <th>طريقة الدفع</th>
                            <th>الحالة</th>
                            <th>الإجراءات</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($orders as $order): ?>
                            <tr>
                                <td>#<?= $order['id'] ?></td>
                                <td>
                                    <?= $order['user_id'] !== null ? 'مستخدم مسجل' : 'زائر' ?>
                                </td>
                                <td>
                                    <div style="display: flex; align-items: center; gap: 5px; justify-content: flex-end;">
                                        <?= htmlspecialchars($order['customer_name']) ?>
                                        <?php if (!empty($order['customer_phone'])): ?>
                                            <a href="tel:<?= htmlspecialchars($order['customer_phone']) ?>" class="contact-icon phone-icon" title="اتصال بالعميل">
                                                <i class="fas fa-phone"></i>
                                            </a>
                                        <?php endif; ?>
                                        <?php if (!empty($order['customer_email'])): ?>
                                            <a href="mailto:<?= htmlspecialchars($order['customer_email']) ?>" class="contact-icon email-icon" title="إرسال بريد إلكتروني">
                                                <i class="fas fa-envelope"></i>
                                            </a>
                                        <?php endif; ?>
                                    </div>
                                    <?php if ($order['user_id'] === null): ?>
                                        <!-- <br><small class="text-muted">(زائر)</small> -->
                                    <?php endif; ?>
                                </td>
                                <td><?= htmlspecialchars($order['customer_email']) ?></td>
                                <td class="order-products-amount">
                                    <?= number_format($order['products_amount'], 2) ?> ر.ي
                                </td>
                                <td class="order-shipping-cost">
                                    <?= number_format($order['shipping_cost'], 2) ?> ر.ي
                                </td>
                                <td class="order-total-amount">
                                    <?= number_format($order['total_amount'], 2) ?> ر.ي
                                </td>
                                <td class="order-cost">
                                    <?= number_format($order['total_cost'], 2) ?> ر.ي
                                </td>
                                <td class="order-profit <?= $order['products_profit'] >= 0 ? 'positive-profit' : 'negative-profit' ?>">
                                    <?= number_format($order['products_profit'], 2) ?> ر.ي
                                </td>
                                <td><?= date('Y/m/d', strtotime($order['created_at'])) ?></td>
                                <td>
                                    <?php if ($order['payment_method'] === 'cash'): ?>
                                        <span class="status-badge completed">الدفع عند الاستلام</span>
                                    <?php elseif (!empty($order['payment_method_name'])): ?>
                                        <span class="status-badge processing">
                                            <?= htmlspecialchars($order['payment_method_name']) ?>
                                            <?php if (!empty($order['payment_account'])): ?>
                                                - <?= htmlspecialchars($order['payment_account']) ?>
                                            <?php endif; ?>
                                        </span>
                                    <?php else: ?>
                                        <span class="status-badge cancelled">غير محدد</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <span class="status-badge <?= $order['status'] ?>">
                                        <?= get_order_status($order['status']) ?>
                                    </span>
                                </td>
                                <td class="order-actions">
                                    <a href="<?php echo SITE_URL; ?>admin/order_details.php?id=<?= $order['id'] ?>"
                                        class="btn-action btn-view" title="تفاصيل الطلب">
                                        <i class="fas fa-eye"></i>
                                    </a>

                                    <?php if ($order['status'] != 'cancelled'): ?>
                                        <div class="dropdown">
                                            <button class="btn-action btn-more" title="المزيد">
                                                <i class="fas fa-ellipsis-v"></i>
                                            </button>
                                            <div class="dropdown-content">
                                                <form method="post" class="status-form">
                                                    <input type="hidden" name="order_id" value="<?= $order['id'] ?>">
                                                    <select name="status" onchange="this.form.submit()">
                                                        <option value="">تغيير الحالة</option>
                                                        <option value="pending" <?= $order['status'] == 'pending' ? 'selected' : '' ?>>قيد الانتظار</option>
                                                        <option value="processing" <?= $order['status'] == 'processing' ? 'selected' : '' ?>>قيد المعالجة</option>
                                                        <option value="in_the_way" <?= $order['status'] == 'in_the_way' ? 'selected' : '' ?>>في الطريق</option>
                                                        <option value="completed" <?= $order['status'] == 'completed' ? 'selected' : '' ?>>مكتمل</option>
                                                        <option value="cancelled" <?= $order['status'] == 'cancelled' ? 'selected' : '' ?>>ملغي</option>
                                                    </select>
                                                    <input type="hidden" name="update_status" value="1">
                                                </form>

                                                <a href="<?php echo SITE_URL; ?>admin/orders.php?delete_id=<?= $order['id'] ?>"
                                                    class="btn-delete"
                                                    onclick="return confirm('هل أنت متأكد من حذف هذا الطلب؟')">
                                                    <i class="fas fa-trash-alt"></i> حذف
                                                </a>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- نافذة التنبيهات -->
<div id="notification-container"></div>

<!-- عنصر للصوت (اختياري) -->
<audio id="notification-sound" preload="auto">
    <source src="<?php echo SITE_URL; ?>assets/sounds/notification.mp3" type="audio/mpeg">
</audio>

<?php include __DIR__ . '/../includes/admin_footer.php'; ?>

<link rel="stylesheet" href="<?php echo SITE_URL; ?>assets/css/orders.css">


<script>
    // تأكيد الحذف
    document.querySelectorAll('.btn-delete').forEach(btn => {
        btn.addEventListener('click', function(e) {
            if (!confirm('هل أنت متأكد من حذف هذا الطلب؟')) {
                e.preventDefault();
            }
        });
    });

    // متغير لتخزين وقت آخر تحقق
    let lastCheckTime = <?= time() ?>;

    // دالة لعرض التنبيهات
    // دالة لعرض التنبيهات
    function showNotification(message, orderDetails = null) {
        const notification = document.createElement('div');
        notification.className = 'notification';

        let notificationContent = `
        <div class="notification-content">
            <div class="notification-icon">
                <i class="fas fa-bell"></i>
            </div>
            <div class="notification-message">${message}</div>
            <button class="notification-close" onclick="this.parentElement.parentElement.remove()">
                <i class="fas fa-times"></i>
            </button>
        </div>
    `;

        if (orderDetails) {
            const productsProfit = orderDetails.products_profit || 0;
            const totalProfit = orderDetails.total_profit || 0;
            const productsProfitClass = productsProfit >= 0 ? 'positive-profit' : 'negative-profit';
            const totalProfitClass = totalProfit >= 0 ? 'positive-profit' : 'negative-profit';

            notificationContent += `
            <div class="notification-details">
                <p><strong>رقم الطلب:</strong> #${orderDetails.id}</p>
                <p><strong>العميل:</strong> ${orderDetails.username}</p>
                <p><strong>سعر المنتجات:</strong> ${orderDetails.products_amount || 0} ر.ي</p>
                <p><strong>سعر الشحن:</strong> ${orderDetails.shipping_cost || 0} ر.ي</p>
                <p><strong>المبلغ الإجمالي:</strong> ${orderDetails.total_amount} ر.ي</p>
                <p><strong>تكلفة المنتجات:</strong> ${orderDetails.total_cost || 0} ر.ي</p>
                <p><strong>ربح المنتجات:</strong> <span class="${productsProfitClass}">${productsProfit} ر.ي</span></p>
                <p><strong>الربح الشامل:</strong> <span class="${totalProfitClass}">${totalProfit} ر.ي</span></p>
                <p><strong>الوقت:</strong> ${new Date(orderDetails.created_at).toLocaleTimeString()}</p>
            </div>
            <div class="notification-actions">
                <a href="<?php echo SITE_URL; ?>admin/order_details.php?id=${orderDetails.id}" class="btn-view-order">عرض الطلب</a>
            </div>
        `;
        }

        notification.innerHTML = notificationContent;
        document.getElementById('notification-container').appendChild(notification);

        // إزالة التنبيه تلقائياً بعد 8 ثوان
        setTimeout(() => {
            if (notification.parentElement) {
                notification.remove();
            }
        }, 10000);

        // تشغيل صوت التنبيه (إذا كان مدعوماً)
        playNotificationSound();
    }

    // دالة لتشغيل صوت التنبيه
    function playNotificationSound() {
        try {
            const sound = document.getElementById('notification-sound');
            if (sound) {
                sound.currentTime = 0;
                sound.play().catch(e => console.log('لا يمكن تشغيل الصوت:', e));
            }
        } catch (error) {
            console.log('خطأ في تشغيل الصوت:', error);
        }
    }

    // دالة للتحقق من الطلبات الجديدة
    function checkForNewOrders() {
        fetch(`orders.php?check_new_orders&last_check=${lastCheckTime}&t=${new Date().getTime()}`)
            .then(response => response.json())
            .then(data => {
                if (data.error) {
                    console.error('خطأ في التحقق من الطلبات:', data.error);
                    return;
                }

                if (data.new_orders > 0) {
                    // عرض تنبيه لكل طلب جديد
                    data.orders_details.forEach(order => {
                        showNotification(`طلب جديد من ${order.username}`, order);
                    });

                    // تحديث الصفحة تلقائياً إذا كانت صفحة الطلبات
                    if (window.location.pathname.endsWith('orders.php')) {
                        // إعادة تحميل الصفحة بعد 3 ثوانٍ من ظهور التنبيه
                        setTimeout(() => {
                            window.location.reload();
                        }, 3000);
                    }
                }

                // تحديث وقت آخر تحقق
                lastCheckTime = data.timestamp;
            })
            .catch(error => console.error('خطأ في الاتصال:', error));
    }

    // بدء التحقق الدوري عند تحميل الصفحة
    document.addEventListener('DOMContentLoaded', function() {
        // التحقق أول مرة بعد تحميل الصفحة مباشرة
        setTimeout(checkForNewOrders, 2000);

        // ثم التحقق كل 10 ثوان
        setInterval(checkForNewOrders, 10000);
    });
</script>
<?php
// require_once __DIR__ . '/../../includes/db_connect.php';

// if (!isset($_GET['product_id'])) {
//     echo json_encode(['colors' => []]);
//     exit;
// }

// $product_id = (int)$_GET['product_id'];
// $stmt = $conn->prepare("SELECT DISTINCT color FROM product_variants WHERE product_id = ?");
// $stmt->execute([$product_id]);
// $colors = $stmt->fetchAll(PDO::FETCH_COLUMN);

// header('Content-Type: application/json');
// echo json_encode(['colors' => $colors]);
?>
<!-- ملغي للتاكد -->
<?php
session_start();
require_once __DIR__ . '/../includes/db_connect.php';
require_once __DIR__ . '/../includes/auth.php';

// التحقق من أن المستخدم مدير
checkAdminRole();

$message = '';
$settings = [
    'free_shipping_threshold' => null,
    'shipping_discount_percentage' => 0,
    'is_active' => true
];

// جلب الإعدادات الحالية
try {
    $stmt = $conn->query("SELECT * FROM shipping_settings ORDER BY id DESC LIMIT 1");
    $current_settings = $stmt->fetch();

    if ($current_settings) {
        $settings = $current_settings;
    }
} catch (PDOException $e) {
    $message = "خطأ في جلب الإعدادات: " . $e->getMessage();
}

// معالجة تحديث الإعدادات
// معالجة تحديث الإعدادات
// معالجة تحديث الإعدادات
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $free_shipping_threshold = !empty($_POST['free_shipping_threshold']) ? $_POST['free_shipping_threshold'] : null;
    $shipping_discount_percentage = $_POST['shipping_discount_percentage'] ?? 0;
    $is_active = isset($_POST['is_active']) ? 1 : 0;

    // الحقول الجديدة لشريط التنبيهات
    $alert_text = $_POST['alert_text'] ?? '';
    $alert_bg_color = $_POST['alert_bg_color'] ?? '#f8d7da';
    $alert_text_color = $_POST['alert_text_color'] ?? '#721c24';
    $alert_enabled = isset($_POST['alert_enabled']) ? 1 : 0;

    // الحقول الجديدة لأسعار الشحن
    $base_cost = $_POST['base_cost'] ?? 1000;
    $cost_per_km = $_POST['cost_per_km'] ?? 100;
    $min_cost = $_POST['min_cost'] ?? 1000;
    $max_cost = $_POST['max_cost'] ?? 5000;

    try {
        // التحقق من وجود إعدادات سابقة
        $stmt = $conn->query("SELECT COUNT(*) as count FROM shipping_settings");
        $count = $stmt->fetch()['count'];

        if ($count > 0) {
            // تحديث الإعدادات الموجودة
            $stmt = $conn->prepare("
                UPDATE shipping_settings 
                SET free_shipping_threshold = ?, 
                    shipping_discount_percentage = ?, 
                    is_active = ?,
                    alert_text = ?,
                    alert_bg_color = ?,
                    alert_text_color = ?,
                    alert_enabled = ?,
                    base_cost = ?,
                    cost_per_km = ?,
                    min_cost = ?,
                    max_cost = ?,
                    updated_at = NOW()
            ");
            $stmt->execute([
                $free_shipping_threshold,
                $shipping_discount_percentage,
                $is_active,
                $alert_text,
                $alert_bg_color,
                $alert_text_color,
                $alert_enabled,
                $base_cost,
                $cost_per_km,
                $min_cost,
                $max_cost
            ]);
        } else {
            // إضافة إعدادات جديدة
            $stmt = $conn->prepare("
                INSERT INTO shipping_settings 
                (free_shipping_threshold, shipping_discount_percentage, is_active,
                 alert_text, alert_bg_color, alert_text_color, alert_enabled,
                 base_cost, cost_per_km, min_cost, max_cost)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");
            $stmt->execute([
                $free_shipping_threshold,
                $shipping_discount_percentage,
                $is_active,
                $alert_text,
                $alert_bg_color,
                $alert_text_color,
                $alert_enabled,
                $base_cost,
                $cost_per_km,
                $min_cost,
                $max_cost
            ]);
        }

        $message = "تم تحديث إعدادات الشحن والتنبيهات بنجاح!";

        // تحديث الإعدادات المحلية
        $settings = [
            'free_shipping_threshold' => $free_shipping_threshold,
            'shipping_discount_percentage' => $shipping_discount_percentage,
            'is_active' => $is_active,
            'alert_text' => $alert_text,
            'alert_bg_color' => $alert_bg_color,
            'alert_text_color' => $alert_text_color,
            'alert_enabled' => $alert_enabled,
            'base_cost' => $base_cost,
            'cost_per_km' => $cost_per_km,
            'min_cost' => $min_cost,
            'max_cost' => $max_cost
        ];
    } catch (PDOException $e) {
        $message = "خطأ في حفظ الإعدادات: " . $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إعدادات الشحن - لوحة التحكم</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.rtl.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@300;400;500;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #4e73df;
            --primary-dark: #3a5bce;
            --secondary: #6f42c1;
            --success: #1cc88a;
            --info: #36b9cc;
            --warning: #f6c23e;
            --danger: #e74a3b;
            --light: #f8f9fc;
            --dark: #5a5c69;
            --border-radius: 0.75rem;
        }

        * {
            font-family: 'Tajawal', sans-serif;
        }

        body {
            background-color: #f8f9fc;
            color: #5a5c69;
        }

        .main-container {
            max-width: 1000px;
            margin: 0 auto;
        }

        .page-header {
            border-bottom: 1px solid #e3e6f0;
            padding-bottom: 1rem;
            margin-bottom: 2rem;
        }

        .settings-card {
            border: none;
            border-radius: var(--border-radius);
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
            margin-bottom: 2rem;
        }

        .card-header {
            background: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%);
            color: white;
            border-radius: var(--border-radius) var(--border-radius) 0 0 !important;
            padding: 1.2rem 1.5rem;
            font-weight: 700;
            border: none;
        }

        .card-header-secondary {
            background: linear-gradient(135deg, var(--info) 0%, #2c9faf 100%);
        }

        .section-title {
            position: relative;
            padding-right: 1.2rem;
            margin: 1.5rem 0 1.2rem;
            font-weight: 600;
            color: var(--dark);
        }

        .section-title::before {
            content: "";
            position: absolute;
            right: 0;
            top: 50%;
            transform: translateY(-50%);
            width: 0.4rem;
            height: 1.4rem;
            background: var(--primary);
            border-radius: 1rem;
        }

        .form-control:focus,
        .form-select:focus,
        .form-check-input:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 0.25rem rgba(78, 115, 223, 0.25);
        }

        .preview-box {
            transition: all 0.3s ease;
            min-height: 60px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 0.5rem;
            padding: 1rem;
        }

        .form-check-input:checked {
            background-color: var(--primary);
            border-color: var(--primary);
        }

        .btn-primary {
            background: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%);
            border: none;
            padding: 0.6rem 1.5rem;
            font-weight: 500;
        }

        .btn-primary:hover {
            background: linear-gradient(135deg, var(--primary-dark) 0%, #2a4bc0 100%);
            transform: translateY(-2px);
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.3);
        }

        .btn-success {
            background: linear-gradient(135deg, var(--success) 0%, #18a873 100%);
            border: none;
            padding: 0.8rem 2rem;
            font-weight: 600;
            font-size: 1.1rem;
        }

        .btn-success:hover {
            background: linear-gradient(135deg, #18a873 0%, #158c65 100%);
            transform: translateY(-2px);
            box-shadow: 0 0.15rem 1.75rem 0 rgba(28, 200, 138, 0.3);
        }

        .nav-tabs .nav-link.active {
            color: var(--primary);
            font-weight: bold;
            border-bottom: 3px solid var(--primary);
            background: transparent;
        }

        .nav-tabs .nav-link {
            color: #6e707e;
            border: none;
            padding: 0.8rem 1.2rem;
            transition: all 0.3s;
        }

        .nav-tabs .nav-link:hover {
            color: var(--primary);
            background: rgba(78, 115, 223, 0.05);
            border-radius: 0.5rem;
        }

        .calculation-formula {
            background: linear-gradient(135deg, #f8f9fc 0%, #e9ecef 100%);
            border-left: 4px solid var(--primary);
            border-radius: 0.5rem;
            padding: 1.5rem;
        }

        .input-group-text {
            background-color: #eaecf4;
            border: 1px solid #d1d3e2;
        }

        .form-text {
            font-size: 0.85rem;
            color: #858796;
        }

        .alert-box {
            border-radius: 0.5rem;
            border: none;
            box-shadow: 0 0.15rem 0.5rem 0 rgba(58, 59, 69, 0.1);
        }

        @media (max-width: 768px) {
            .section-title::before {
                width: 0.3rem;
                height: 1.2rem;
            }

            .btn-success {
                padding: 0.7rem 1.5rem;
                font-size: 1rem;
            }
        }

        .setting-item {
            background: white;
            border-radius: 0.5rem;
            padding: 1.5rem;
            margin-bottom: 1.5rem;
            box-shadow: 0 0.15rem 0.5rem 0 rgba(58, 59, 69, 0.05);
            border: 1px solid #e3e6f0;
            transition: all 0.3s;
        }

        .setting-item:hover {
            box-shadow: 0 0.5rem 1.5rem 0 rgba(58, 59, 69, 0.1);
            transform: translateY(-3px);
        }

        .color-preview {
            width: 30px;
            height: 30px;
            border-radius: 50%;
            display: inline-block;
            margin-left: 10px;
            vertical-align: middle;
            border: 1px solid #ddd;
        }
    </style>
</head>

<body>

    <div class="container py-4">
        <div class="main-container">
            <div class="page-header">
                <div class="d-flex justify-content-between align-items-center flex-wrap">
                    <h2 class="h3 mb-0"><i class="fas fa-shipping-fast me-2 text-primary"></i>إعدادات الشحن والتوصيل</h2>
                    <a href="<?php echo SITE_URL; ?>admin/dashboard.php" class="btn btn-outline-secondary">
                        <i class="fas fa-arrow-right me-1"></i> العودة للوحة التحكم
                    </a>
                </div>
                <p class="text-muted mb-0">إدارة إعدادات الشحن والتوصيل وعروض التخفيضات</p>
            </div>

            <?php if (!empty($message)): ?>
                <div class="alert alert-info alert-box alert-dismissible fade show" role="alert">
                    <i class="fas fa-info-circle me-2"></i>
                    <?= $message ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <div class="settings-card card">
                <div class="card-header">
                    <h5 class="mb-0"><i class="fas fa-cogs me-2"></i>الإعدادات العامة</h5>
                </div>
                <div class="card-body">
                    <form method="POST">
                        <div class="setting-item">
                            <div class="form-check form-switch mb-0">
                                <input class="form-check-input" type="checkbox" id="is_active" name="is_active" <?= $settings['is_active'] ? 'checked' : '' ?>>
                                <label class="form-check-label fw-bold fs-5" for="is_active">تفعيل نظام الشحن</label>
                                <div class="form-text">سيتم احتساب تكاليف الشحن عند تفعيل هذا الخيار</div>
                            </div>
                        </div>

                        <div class="setting-item">
                            <div class="row">
                                <div class="col-md-6">
                                    <label for="free_shipping_threshold" class="form-label fw-bold">الحد الأدنى للطلب للتوصيل المجاني (ريال يمني)</label>
                                    <div class="input-group">
                                        <span class="input-group-text"><i class="fas fa-truck"></i></span>
                                        <input type="number" class="form-control" id="free_shipping_threshold" name="free_shipping_threshold"
                                            value="<?= $settings['free_shipping_threshold'] ?>"
                                            placeholder="اتركه فارغاً لتعطيل التوصيل المجاني">
                                    </div>
                                    <div class="form-text mt-2">إذا كان المجموع الفرعي للطلب يساوي أو يزيد عن هذا المبلغ، سيصبح الشحن مجاناً.</div>
                                </div>
                                <div class="col-md-6">
                                    <label for="shipping_discount_percentage" class="form-label fw-bold">نسبة خصم الشحن (%)</label>
                                    <div class="input-group">
                                        <span class="input-group-text"><i class="fas fa-percentage"></i></span>
                                        <input type="number" class="form-control" id="shipping_discount_percentage"
                                            name="shipping_discount_percentage" min="0" max="100"
                                            value="<?= $settings['shipping_discount_percentage'] ?>">
                                    </div>
                                    <div class="form-text mt-2">نسبة الخصم التي سيتم تطبيقها على تكلفة الشحن (من 0 إلى 100).</div>
                                </div>
                            </div>
                        </div>

                        <!-- أعدادات اسعار الشحن -->

                        <div class="setting-item">
                            <h5 class="section-title">إعدادات أسعار الشحن</h5>

                            <div class="row">
                                <div class="col-md-6">
                                    <div class="mb-4">
                                        <label for="base_cost" class="form-label fw-bold">التكلفة الثابتة (ريال يمني)</label>
                                        <div class="input-group">
                                            <span class="input-group-text"><i class="fas fa-money-bill-wave"></i></span>
                                            <input type="number" class="form-control" id="base_cost" name="base_cost"
                                                value="<?= $settings['base_cost'] ?? 1000 ?>" step="100" min="0" required>
                                        </div>
                                        <div class="form-text mt-2">التكلفة الأساسية للشحن بغض النظر عن المسافة.</div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-4">
                                        <label for="cost_per_km" class="form-label fw-bold">التكلفة لكل كيلومتر (ريال يمني)</label>
                                        <div class="input-group">
                                            <span class="input-group-text"><i class="fas fa-road"></i></span>
                                            <input type="number" class="form-control" id="cost_per_km" name="cost_per_km"
                                                value="<?= $settings['cost_per_km'] ?? 100 ?>" step="10" min="0" required>
                                        </div>
                                        <div class="form-text mt-2">التكلفة الإضافية لكل كيلومتر بعد المسافة الأساسية.</div>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6">
                                    <div class="mb-4">
                                        <label for="min_cost" class="form-label fw-bold">أقل تكلفة للشحن (ريال يمني)</label>
                                        <div class="input-group">
                                            <span class="input-group-text"><i class="fas fa-arrow-down"></i></span>
                                            <input type="number" class="form-control" id="min_cost" name="min_cost"
                                                value="<?= $settings['min_cost'] ?? 1000 ?>" step="100" min="0" required>
                                        </div>
                                        <div class="form-text mt-2">أقل مبلغ للشحن حتى لو كانت التكلفة المحسوبة أقل.</div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-4">
                                        <label for="max_cost" class="form-label fw-bold">أعلى تكلفة للشحن (ريال يمني)</label>
                                        <div class="input-group">
                                            <span class="input-group-text"><i class="fas fa-arrow-up"></i></span>
                                            <input type="number" class="form-control" id="max_cost" name="max_cost"
                                                value="<?= $settings['max_cost'] ?? 5000 ?>" step="100" min="0" required>
                                        </div>
                                        <div class="form-text mt-2">أعلى مبلغ للشحن حتى لو كانت التكلفة المحسوبة أعلى.</div>
                                    </div>
                                </div>
                            </div>

                            <div class="calculation-formula">
                                <div class="d-flex align-items-center mb-2">
                                    <div class="bg-white p-3 rounded shadow-sm me-3">
                                        <p class="mb-0 text-muted"><i class="fas fa-info-circle me-1"></i>اذا عطلت نظام الشحن سوف يتم حساب هاذي الارقام بشكل تلقائي</br> التكلفة الثابتة = 1000 </br> التكلفة لكل كيلومتر 100 </br> أقل تكلفة للشحن 1000 </br> أعلى تكلفة للشحن 5000</p>

                                    </div>
                                </div>
                            </div>

                            <div class="calculation-formula">
                                <h5 class="fw-bold mb-3"><i class="fas fa-calculator me-2"></i>معادلة حساب تكلفة الشحن:</h5>
                                <div class="d-flex align-items-center mb-2">
                                    <div class="bg-white p-3 rounded shadow-sm me-3">
                                        <code class="text-dark fs-6">التكلفة = التكلفة الثابتة + (المسافة × التكلفة لكل كيلومتر)</code>
                                    </div>
                                </div>
                                <p class="mb-0 text-muted"><i class="fas fa-info-circle me-1"></i>سيتم تقريب النتيجة لأقرب 100 ريال وتطبيق الحد الأدنى والأقصى.</p>
                            </div>
                        </div>

                        <!-- أعدادات اسعار التنبيه العلوي -->
                        <div class="setting-item">
                            <h5 class="section-title">إعدادات شريط التنبيهات العلوي</h5>

                            <div class="form-check form-switch mb-4">
                                <input class="form-check-input" type="checkbox" id="alert_enabled" name="alert_enabled" <?= $settings['alert_enabled'] ? 'checked' : '' ?>>
                                <label class="form-check-label fw-bold" for="alert_enabled">تفعيل شريط التنبيهات</label>
                                <div class="form-text">سيظهر شريط التنبيهات في أعلى الموقع</div>
                            </div>

                            <div class="mb-4">
                                <label for="alert_text" class="form-label fw-bold">نص التنبيه</label>
                                <textarea class="form-control" id="alert_text" name="alert_text" rows="3" placeholder="أدخل نص التنبيه الذي سيظهر في الشريط العلوي"><?= htmlspecialchars($settings['alert_text'] ?? '') ?></textarea>
                                <div class="form-text mt-2">يمكنك استخدام HTML بسيط مثل &lt;strong&gt; لنص عريض.</div>
                            </div>

                            <div class="row mb-4">
                                <div class="col-md-6">
                                    <label for="alert_bg_color" class="form-label fw-bold">لون خلفية التنبيه</label>
                                    <div class="d-flex align-items-center">
                                        <input type="color" class="form-control form-control-color me-2" id="alert_bg_color" name="alert_bg_color" value="<?= $settings['alert_bg_color'] ?? '#f8d7da' ?>">
                                        <span class="color-preview" id="bgColorPreview" style="background-color: <?= $settings['alert_bg_color'] ?? '#f8d7da' ?>"></span>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <label for="alert_text_color" class="form-label fw-bold">لون نص التنبيه</label>
                                    <div class="d-flex align-items-center">
                                        <input type="color" class="form-control form-control-color me-2" id="alert_text_color" name="alert_text_color" value="<?= $settings['alert_text_color'] ?? '#721c24' ?>">
                                        <span class="color-preview" id="textColorPreview" style="background-color: <?= $settings['alert_text_color'] ?? '#721c24' ?>"></span>
                                    </div>
                                </div>
                            </div>

                            <div class="mb-4">
                                <label class="form-label fw-bold">معاينة شريط التنبيهات</label>
                                <div id="alert_preview" class="preview-box rounded p-3">
                                    <?= $settings['alert_text'] ? htmlspecialchars($settings['alert_text']) : 'هذه معاينة لنص التنبيه' ?>
                                </div>
                                <div class="form-text mt-2">سيظهر الشريط بهذا الشكل في الموقع</div>
                            </div>
                        </div>



                        <div class="d-grid mt-4">
                            <button type="submit" class="btn btn-success btn-lg py-3">
                                <i class="fas fa-save me-2"></i> حفظ الإعدادات
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script src="<?php echo SITE_URL; ?>assets/js/bootstrap.bundle.min.js"></script>
    <script>
        // تحديث معاينة شريط التنبيهات
        function updateAlertPreview() {
            const text = document.getElementById('alert_text').value;
            const bgColor = document.getElementById('alert_bg_color').value;
            const textColor = document.getElementById('alert_text_color').value;

            document.getElementById('alert_preview').textContent = text || 'هذه معاينة لنص التنبيه';
            document.getElementById('alert_preview').style.backgroundColor = bgColor;
            document.getElementById('alert_preview').style.color = textColor;

            // تحديث معاينة الألوان
            document.getElementById('bgColorPreview').style.backgroundColor = bgColor;
            document.getElementById('textColorPreview').style.backgroundColor = textColor;
        }

        // إضافة مستمعي الأحداث
        document.getElementById('alert_text').addEventListener('input', updateAlertPreview);
        document.getElementById('alert_bg_color').addEventListener('input', updateAlertPreview);
        document.getElementById('alert_text_color').addEventListener('input', updateAlertPreview);

        // التهيئة الأولية
        document.addEventListener('DOMContentLoaded', function() {
            updateAlertPreview();
        });
    </script>
    <?php include __DIR__ . '/../includes/admin_footer.php'; ?>
</body>

</html>
<?php
session_start();
require_once __DIR__ . '/../includes/db_connect.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

// التحقق من أن المستخدم مدير
checkAdminRole();

// حذف شريحة
if (isset($_GET['delete'])) {
    $id = (int) $_GET['delete'];
    $stmt = $conn->prepare("DELETE FROM sliders WHERE id = ?");
    $stmt->execute([$id]);
    header("Location: " . SITE_URL . "admin/manage_sliders.php");
    exit;
}

// جلب الشرائح
$sliders = $conn->query("SELECT * FROM sliders ORDER BY sort_order ASC, created_at DESC")->fetchAll(PDO::FETCH_ASSOC);

// تعيين عنوان الصفحة
$page_title = "إدارة السلايد";

include __DIR__ . '/../includes/admin_header.php';
?>


<div class="container">
    <h1 class="page-title">إدارة السلايدر</h1>
    <a href="<?php echo SITE_URL; ?>admin/add_slider.php" class="btn">إضافة شريحة جديدة</a>
    <?php if (!empty($_SESSION['success'])): ?>
        <div class="success-message" style="background: #d4edda; color: #155724; padding: 10px; margin: 15px 0; border-radius: 5px;">
            <?= $_SESSION['success'];
            unset($_SESSION['success']); ?>
        </div>
    <?php endif; ?>
    <div class="responsive-table">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>الصورة</th>
                    <th>العنوان</th>
                    <th>الوصف</th>
                    <th>الرابط</th>
                    <th>الترتيب</th>
                    <th>الحالة</th>
                    <th>إجراءات</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($sliders as $slide): ?>
                    <tr>
                        <td><img src="<?php echo SITE_URL; ?>assets/images/banners/<?= htmlspecialchars($slide['image_url']) ?>" width="80"></td>
                        <td><?= htmlspecialchars($slide['title']) ?></td>
                        <td><?= htmlspecialchars($slide['description']) ?></td>
                        <td><?= htmlspecialchars($slide['link']) ?></td>
                        <td><?= $slide['sort_order'] ?></td>
                        <td><?= $slide['is_active'] ? 'نشطة' : 'غير نشطة' ?></td>
                        <td>
                            <a href="<?php echo SITE_URL; ?>admin/edit_slider.php?id=<?= $slide['id'] ?>" class="btn-edit">تعديل</a>
                            <a href="?delete=<?= $slide['id'] ?>" class="btn-delete" onclick="return confirm('هل أنت متأكد؟')">حذف</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include __DIR__ . '/../includes/admin_footer.php'; ?>
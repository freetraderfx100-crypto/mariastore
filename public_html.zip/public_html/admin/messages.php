<?php
session_start();
require_once __DIR__ . '/../includes/db_connect.php';

require_once __DIR__ . '/../includes/auth.php';
// التحقق من أن المستخدم مدير
checkAdminRole();

try {
    $stmt = $conn->query("SELECT * FROM contact_messages ORDER BY created_at DESC");
    $messages = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("خطأ في جلب الرسائل: " . $e->getMessage());
}


// تعيين عنوان الصفحة
$page_title = "الرسائل الزوار";
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">

<head>
    <meta charset="UTF-8">
    <title>📩 رسائل الزوار</title>
    <!-- <link rel="stylesheet" href="<?php echo SITE_URL; ?>assets/css/admin.css"> -->


</head>

<body>
    <?php include __DIR__ . '/../includes/admin_header.php'; ?>

    <div class="container">
        <h2>📬 رسائل "اتصل بنا"</h2>

        <?php if (empty($messages)): ?>
            <p>لا توجد رسائل حتى الآن.</p>
        <?php else: ?>
            <div class="responsive-table">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>الاسم</th>
                            <th>البريد الإلكتروني</th>
                            <th>رقم الهاتف</th>
                            <th>الموضوع</th>
                            <th>الرسالة</th>
                            <th>التاريخ</th>
                            <th>حذف الرساله</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($messages as $msg): ?>
                            <tr>
                                <td><?= htmlspecialchars($msg['name']) ?></td>
                                <td><?= htmlspecialchars($msg['email']) ?></td>
                                <td><?= htmlspecialchars($msg['phone']) ?></td>
                                <td><?= htmlspecialchars($msg['subject']) ?></td>
                                <td><?= nl2br(htmlspecialchars($msg['message'])) ?></td>
                                <td><?= $msg['created_at'] ?></td>
                                <td>
                                    <form method="POST" action="delete_message.php" onsubmit="return confirm('هل أنت متأكد من حذف هذه الرسالة؟');">
                                        <input type="hidden" name="id" value="<?= $msg['id'] ?>">
                                        <button type="submit" style="color: red; background: none; border: none; cursor: pointer;">🗑️ حذف</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</body>

</html>
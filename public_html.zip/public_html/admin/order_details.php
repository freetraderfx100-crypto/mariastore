<?php
session_start();
require_once __DIR__ . '/../includes/db_connect.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

// التحقق من أن المستخدم مدير
checkAdminRole();

// التحقق من وجود معرف الطلب
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: " . SITE_URL . "admin/orders.php");
    exit;
}

$order_id = (int)$_GET['id'];

// معالجة استرجاع المنتجات إلى المخزون
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['restore_stock'])) {
    $conn->beginTransaction();

    try {
        // جلب جميع عناصر الطلب
        $items_stmt = $conn->prepare("
            SELECT product_id, color, size, quantity 
            FROM order_items 
            WHERE order_id = ?
        ");
        $items_stmt->execute([$order_id]);
        $items = $items_stmt->fetchAll(PDO::FETCH_ASSOC);

        if (!empty($items)) {
            foreach ($items as $item) {
                // إعادة الكمية للمخزون
                $update_stmt = $conn->prepare("
                    UPDATE product_variants 
                    SET quantity = quantity + ? 
                    WHERE product_id = ? AND color = ? AND size = ?
                ");
                $update_stmt->execute([
                    $item['quantity'],
                    $item['product_id'],
                    $item['color'],
                    $item['size']
                ]);

                // تسجيل العملية في سجل المخزون
                $log_stmt = $conn->prepare("
                    INSERT INTO stock_logs 
                    (order_id, product_id, quantity, action_type, description) 
                    VALUES (?, ?, ?, 'return', ?)
                ");
                $log_desc = "استرجاع كمية المنتج من الطلب الملغي #$order_id";
                $log_stmt->execute([
                    $order_id,
                    $item['product_id'],
                    $item['quantity'],
                    $log_desc
                ]);
            }

            // تحديث حالة استرجاع المخزون في الطلب
            $update_order_stmt = $conn->prepare("
                UPDATE orders SET stock_restored = TRUE WHERE id = ?
            ");
            $update_order_stmt->execute([$order_id]);

            $_SESSION['success'] = "تم استرجاع جميع المنتجات إلى المخزون بنجاح";
        } else {
            $_SESSION['info'] = "لا توجد عناصر في الطلب لاسترجاعها";
        }

        $conn->commit();
    } catch (Exception $e) {
        $conn->rollBack();
        $_SESSION['error'] = "حدث خطأ أثناء استرجاع المنتجات: " . $e->getMessage();
    }

    header("Location: " . SITE_URL . "admin/order_details.php?id=" . $order_id);
    exit;
}


// تحديث حالة الطلب عند إرسال النموذج
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    $new_status = $_POST['status'] ?? '';
    $order_id = (int)($_POST['order_id'] ?? 0);

    // التحقق من صلاحية الحالة الجديدة
    $valid_statuses = ['pending', 'processing', 'in_the_way', 'completed', 'cancelled'];

    if (in_array($new_status, $valid_statuses)) {
        $conn->beginTransaction();
        try {
            $update_stmt = $conn->prepare("
                UPDATE orders 
                SET status = ?, 
                    stock_restored = CASE WHEN ? = 'cancelled' THEN FALSE ELSE stock_restored END,
                    updated_at = NOW() 
                WHERE id = ?
            ");
            $update_stmt->execute([$new_status, $new_status, $order_id]);

            $conn->commit();
            $_SESSION['success'] = "تم تحديث حالة الطلب بنجاح";
        } catch (Exception $e) {
            $conn->rollBack();
            $_SESSION['error'] = "حدث خطأ أثناء تحديث حالة الطلب: " . $e->getMessage();
        }

        header("Location: " . SITE_URL . "admin/order_details.php?id=$order_id");
        exit;
    }
}

// معالجة تحديث تكلفة الشحن
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_shipping_cost'])) {
    $new_shipping_cost = (float)$_POST['shipping_cost'];

    if ($new_shipping_cost >= 0) {
        try {
            // حساب الإجمالي الجديد
            $new_total = $order['subtotal'] + $new_shipping_cost;

            $update_stmt = $conn->prepare("
                UPDATE orders 
                SET shipping_cost = ?, total_amount = ?, updated_at = NOW() 
                WHERE id = ?
            ");
            $update_stmt->execute([$new_shipping_cost, $new_total, $order_id]);

            $_SESSION['success'] = "تم تحديث تكلفة الشحن بنجاح";

            // إعادة التوجيه إلى نفس الصفحة لتحديث البيانات
            header("Location: " . SITE_URL . "admin/order_details.php?id=$order_id");
            exit;
        } catch (Exception $e) {
            $_SESSION['error'] = "حدث خطأ أثناء تحديث تكلفة الشحن: " . $e->getMessage();
        }
    } else {
        $_SESSION['error'] = "تكلفة الشحن يجب أن تكون قيمة موجبة";
    }
}

// جلب بيانات الطلب
try {
    // جلب بيانات الطلب مع تفاصيل الشحن (معدل للتعامل مع الزوار)
    $stmt = $conn->prepare("
    SELECT 
        o.*, 
        COALESCE(u.username, o.guest_name) AS customer_name,
        COALESCE(u.email, o.guest_email) AS customer_email,
        COALESCE(u.phone, o.guest_phone) AS customer_phone,
        o.subtotal,
        o.shipping_cost,
        o.total_amount,
        pm.method_name AS payment_method_name,
        pm.account_number AS payment_account
    FROM orders o
    LEFT JOIN users u ON o.user_id = u.id
    LEFT JOIN payment_methods pm ON o.payment_method = pm.id
    WHERE o.id = ?
");

    $stmt->execute([$order_id]);
    $order = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$order) {
        header("Location: " . SITE_URL . "admin/orders.php");
        exit;
    }

    // جلب عناصر الطلب - تم التعديل هنا
    // جلب عناصر الطلب - تم التعديل هنا
    $items_stmt = $conn->prepare("
    SELECT 
        oi.*, 
        p.name,
        p.sku,
        pv.color,
        pv.size
        FROM order_items oi
        JOIN products p ON oi.product_id = p.id
        JOIN product_variants pv ON oi.product_id = pv.product_id 
            AND oi.color = pv.color 
            AND oi.size = pv.size
        WHERE oi.order_id = ?
    ");
    $items_stmt->execute([$order_id]);
    $order_items = $items_stmt->fetchAll(PDO::FETCH_ASSOC);

    $product_options = []; // مصفوفة لتخزين الألوان والمقاسات لكل منتج

    // جلب خيارات المنتجات - تم التعديل هنا
    if (!empty($order_items)) {
        foreach ($order_items as $item) {
            $product_id = $item['product_id'];

            if (!isset($product_options[$product_id])) {
                // جلب الألوان والمقاسات المتاحة من product_variants
                $variants_stmt = $conn->prepare("
                    SELECT DISTINCT color, size 
                    FROM product_variants 
                    WHERE product_id = ?
                ");
                $variants_stmt->execute([$product_id]);
                $variants = $variants_stmt->fetchAll(PDO::FETCH_ASSOC);

                // تنظيم البيانات بشكل مناسب
                $colors = [];
                $sizes = [];
                foreach ($variants as $variant) {
                    if (!in_array($variant['color'], $colors)) {
                        $colors[] = $variant['color'];
                    }
                    if (!in_array($variant['size'], $sizes)) {
                        $sizes[] = $variant['size'];
                    }
                }

                $product_options[$product_id] = [
                    'colors' => $colors,
                    'sizes' => $sizes
                ];
            }
        }
    }
} catch (PDOException $e) {
    die("خطأ في قاعدة البيانات: " . $e->getMessage());
}

// تعيين عنوان الصفحة
$page_title = "تفاصيل الطلب #" . $order['id'];
?>

<?php include __DIR__ . '/../includes/admin_header.php'; ?>

<head>
    <!-- Leaflet CSS الخريطه-->
    <link rel="stylesheet" href="https://unpkg.com/leaflet/dist/leaflet.css" />
    <style>
        :root {
            --primary-color: #3498db;
            --secondary-color: #7f8c8d;
            --dark-color: #2c3e50;
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f5f7fa;
            color: #333;
            line-height: 1.6;
            padding: 15px;
        }

        .btn-blue {
            background-color: #3498db;
            color: white;
            padding: 10px 15px;
            border-radius: 5px;
            text-decoration: none;
            display: inline-block;
            margin-left: 0;
            margin-top: 10px;
            border: none;
            cursor: pointer;
            font-size: 14px;
            width: 100%;
            text-align: center;
        }

        .btn-blue:hover {
            background-color: #2980b9;
        }

        /* تنسيق صفحة تفاصيل الطلب */
        .order-details-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            flex-direction: column;
            align-items: flex-start;
            gap: 15px;
        }

        .order-details-header h2 {
            font-size: 22px;
            color: var(--dark-color);
        }

        .order-details-container {
            display: grid;
            grid-template-columns: 1fr;
            gap: 15px;
        }

        .order-info-card {
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            padding: 15px;
            margin-bottom: 15px;
        }

        .order-info-card h3 {
            margin-bottom: 15px;
            color: var(--dark-color);
            display: flex;
            align-items: center;
            font-size: 18px;
        }

        .order-info-card h3 i {
            margin-left: 10px;
            color: var(--primary-color);
        }

        .info-grid {
            display: grid;
            grid-template-columns: 1fr;
            gap: 12px;
        }

        .info-item {
            display: flex;
            flex-direction: column;
        }

        .info-item.full-width {
            grid-column: span 1;
        }

        .info-label {
            font-size: 0.9rem;
            color: var(--secondary-color);
            margin-bottom: 5px;
        }

        .info-value {
            font-weight: 500;
            font-size: 16px;
        }

        .order-items-section {
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            padding: 15px;
            overflow-x: auto;
        }

        .order-items-section h3 {
            margin-bottom: 15px;
            color: var(--dark-color);
            display: flex;
            align-items: center;
            font-size: 18px;
        }

        .order-items-section h3 i {
            margin-left: 10px;
            color: var(--primary-color);
        }

        .order-items-table {
            width: 100%;
            min-width: 600px;
        }

        .order-items-table table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        .order-items-table th,
        .order-items-table td {
            padding: 10px;
            border-bottom: 1px solid #eee;
            text-align: right;
            font-size: 14px;
        }

        .order-items-table th {
            background-color: #f9f9f9;
            color: var(--secondary-color);
            font-weight: normal;
        }

        .product-image {
            width: 50px;
            height: 50px;
        }

        .product-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            border-radius: 5px;
        }

        .no-image {
            width: 50px;
            height: 50px;
            background-color: #f9f9f9;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #ccc;
            border-radius: 5px;
            font-size: 12px;
        }

        .order-items-table tfoot td {
            font-weight: 500;
        }

        .total-amount {
            font-weight: bold;
            color: var(--primary-color);
            font-size: 18px;
        }

        .text-right {
            text-align: left !important;
        }

        .order-status-update {
            margin-top: 20px;
        }

        .status-form .form-group {
            margin-bottom: 15px;
        }

        .status-form select {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
        }

        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border: 1px solid transparent;
            border-radius: 4px;
            font-size: 14px;
        }

        .alert-success {
            color: #3c763d;
            background-color: #dff0d8;
            border-color: #d6e9c6;
        }

        .alert-danger {
            color: #a94442;
            background-color: #f2dede;
            border-color: #ebccd1;
        }

        .alert-info {
            color: #31708f;
            background-color: #d9edf7;
            border-color: #bce8f1;
        }

        .product-sku {
            font-family: 'Courier New', monospace;
            font-size: 0.85em;
            color: #666;
            background-color: #f8f9fa;
            padding: 8px;
            text-align: center;
            font-weight: bold;
        }

        .product-sku:hover {
            background-color: #e9ecef;
        }

        /* تعديل عرض الأعمدة */
        .order-items-table th:nth-child(2),
        .order-items-table td:nth-child(2) {
            width: 100px;
        }

        /* باقي التنسيقات */
        :root {
            --primary-color: #3498db;
            --secondary-color: #7f8c8d;
            --dark-color: #2c3e50;
        }

        /* وسائط الاستعلام للأجهزة اللوحية */
        @media (min-width: 768px) {
            .order-details-header {
                flex-direction: row;
                align-items: center;
            }

            .btn-blue {
                width: auto;
                margin-top: 0;
                margin-left: 10px;
            }

            .order-details-container {
                grid-template-columns: 1fr 2fr;
                gap: 20px;
            }

            .info-grid {
                grid-template-columns: 1fr 1fr;
            }

            .info-item.full-width {
                grid-column: span 2;
            }

            .order-items-table {
                min-width: auto;
            }
        }

        /* وسائط الاستعلام لأجهزة الكمبيوتر */
        @media (min-width: 992px) {
            body {
                padding: 25px;
            }

            .order-info-card {
                padding: 20px;
            }

            .order-items-section {
                padding: 20px;
            }
        }

        /* طباعة */
        @media print {

            .admin-header,
            .admin-sidebar,
            .admin-topbar,
            .admin-footer,
            .order-actions {
                display: none !important;
            }

            .admin-content {
                margin: 0 !important;
                padding: 0 !important;
            }

            .order-details-container {
                display: block !important;
            }

            .btn-blue {
                display: none !important;
            }

            .product-sku {
                font-size: 10pt;
                background-color: transparent !important;
                color: #000 !important;
            }

            .order-items-table th:nth-child(2),
            .order-items-table td:nth-child(2) {
                width: 80px;
            }
        }

        .btn-sm {
            padding: 3px 8px;
            font-size: 11px;
            margin: 2px;
        }

        .info-value .btn-sm {
            margin-top: 5px;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-control {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 14px;
        }

        .form-actions {
            display: flex;
            gap: 10px;
        }
    </style>
</head>

<div class="admin-container">
    <div class="order-details-header">
        <h1 class="page-title">
            <i class="fas fa-file-invoice"></i> تفاصيل الطلب #<?= $order['id'] ?>
        </h1>

        <div class="order-actions">
            <a href="<?php echo SITE_URL; ?>admin/orders.php" class="btn btn-outline">
                <i class="fas fa-arrow-left"></i> العودة إلى الطلبات
            </a>
            <a href="<?php echo SITE_URL; ?>admin/edit_order_items.php?id=<?= $order_id ?>" class="btn btn-blue">
                <i class="fas fa-edit"></i> تعديل العناصر
            </a>
            <a href="#" class="btn btn-pink" onclick="window.print()">
                <i class="fas fa-print"></i> طباعة الفاتورة
            </a>
        </div>
    </div>

    <div class="order-details-container">
        <div class="order-info-section">
            <div class="order-info-card">
                <h3><i class="fas fa-info-circle"></i> معلومات الطلب</h3>
                <div class="info-grid">
                    <div class="info-item">
                        <span class="info-label">رقم الطلب:</span>
                        <span class="info-value">#<?= $order['id'] ?></span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">تاريخ الطلب:</span>
                        <span class="info-value"><?= date('Y/m/d H:i', strtotime($order['created_at'])) ?></span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">حالة الطلب:</span>
                        <span class="info-value">
                            <span class="status-badge <?= $order['status'] ?>">
                                <?= get_order_status($order['status']) ?>
                            </span>
                        </span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">طريقة الدفع:</span>
                        <span class="info-value">
                            <?php if ($order['payment_method'] === 'cash'): ?>
                                <span class="status-badge completed">الدفع عند الاستلام</span>
                            <?php elseif (!empty($order['payment_method_name'])): ?>
                                <span class="status-badge processing">
                                    <?= htmlspecialchars($order['payment_method_name']) ?>
                                    <?php if (!empty($order['payment_account'])): ?>
                                        - <?= htmlspecialchars($order['payment_account']) ?>
                                    <?php endif; ?>
                                </span>
                            <?php else: ?>
                                <span class="status-badge cancelled">غير محدد</span>
                            <?php endif; ?>
                        </span>
                    </div>

                    <div class="info-item">
                        <span class="info-label">المجموع الفرعي:</span>
                        <span class="info-value"><?= number_format($order['subtotal'], 2) ?> ر.ي</span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">تكلفة الشحن:</span>
                        <span class="info-value">
                            <?= number_format($order['shipping_cost'], 2) ?> ر.ي
                            <button type="button" class="btn btn-sm btn-outline" onclick="showEditShippingForm()" style="margin-right: 10px;">
                                <i class="fas fa-edit"></i> تعديل
                            </button>
                        </span>
                    </div>
                    <div class="info-item full-width" style="border-top: 1px solid #eee; padding-top: 10px;">
                        <span class="info-label">الإجمالي النهائي:</span>
                        <span class="info-value total-amount">
                            <?= number_format($order['subtotal'] + $order['shipping_cost'], 2) ?> ر.ي
                        </span>
                    </div>
                </div>

                <!-- نموذج تعديل تكلفة الشحن (مخفي بشكل افتراضي) -->
                <div id="editShippingForm" style="display: none; margin-top: 20px; padding: 15px; border: 1px solid #ddd; border-radius: 5px;">
                    <h4><i class="fas fa-edit"></i> تعديل تكلفة الشحن</h4>
                    <form method="POST">
                        <div class="form-group">
                            <label for="shipping_cost">تكلفة الشحن الجديدة (ريال يمني):</label>
                            <input type="number" class="form-control" id="shipping_cost" name="shipping_cost"
                                value="<?= $order['shipping_cost'] ?>" step="0.01" min="0" required>
                        </div>

                        <div class="form-actions" style="margin-top: 15px;">
                            <button type="submit" name="update_shipping_cost" class="btn btn-primary">
                                <i class="fas fa-save"></i> حفظ التغييرات
                            </button>
                            <button type="button" class="btn btn-outline" onclick="hideEditShippingForm()">
                                <i class="fas fa-times"></i> إلغاء
                            </button>
                        </div>
                    </form>
                </div>
            </div>

            <div class="order-info-card">
                <h3><i class="fas fa-user"></i> معلومات العميل</h3>
                <div class="info-grid">
                    <div class="info-item">
                        <span class="info-label">اسم العميل:</span>
                        <span class="info-value"><?= htmlspecialchars($order['customer_name']) ?></span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">البريد الإلكتروني:</span>
                        <span class="info-value"><?= htmlspecialchars($order['customer_email']) ?></span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">الهاتف:</span>
                        <span class="info-value"><?= htmlspecialchars($order['customer_phone'] ?? 'غير متوفر') ?></span>
                    </div>
                    <div class="info-item full-width">
                        <span class="info-label">عنوان الشحن:</span>
                        <span class="info-value"><?= nl2br(htmlspecialchars($order['shipping_address'])) ?></span>
                    </div>

                    <?php if (!empty($order['latitude']) && !empty($order['longitude'])): ?>
                        <div class="order-info-card">
                            <h3><i class="fas fa-map-marker-alt"></i> موقع العميل</h3>
                            <div id="customerMap" style="height: 300px; width: 300px; border-radius: 10px;"></div>
                        </div>
                    <?php endif; ?>

                    <?php if (!empty($order['latitude']) && !empty($order['longitude'])): ?>
                        <div class="info-item full-width">
                            <span class="info-label">موقع العميل على الخريطة:</span>
                            <span class="info-value">
                                <a href="https://www.google.com/maps?q=<?= $order['latitude'] ?>,<?= $order['longitude'] ?>" &zoom=15"
                                    target="_blank"
                                    class="btn btn-outline"
                                    style="margin-top: 5px; display: inline-block;">
                                    عرض الموقع على الخريطة
                                </a>
                            </span>
                        </div>
                    <?php endif; ?>

                </div>
            </div>
        </div>

        <div class="order-items-section">
            <h3><i class="fas fa-boxes"></i> عناصر الطلب</h3>

            <div class="order-items-table">
                <table>
                    <thead>
                        <tr>
                            <th>الصورة</th>
                            <th>SKU</th> <!-- العمود الجديد -->
                            <th>المنتج</th>
                            <th>السعر</th>
                            <th>الكمية</th>
                            <th>الإجمالي</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($order_items)): ?>
                            <?php foreach ($order_items as $item): ?>
                                <tr>
                                    <td class="product-image">
                                        <?php if (!empty($item['image_url'])): ?>
                                            <img src="<?php echo SITE_URL; ?>assets/images/<?= htmlspecialchars($item['image_url']) ?>" alt="<?= htmlspecialchars($item['name']) ?>">
                                        <?php else: ?>
                                            <div class="no-image"><i class="fas fa-box-open"></i></div>
                                        <?php endif; ?>
                                    </td>
                                    <td class="product-sku"> <!-- الخلية الجديدة -->
                                        <?= !empty($item['sku']) ? htmlspecialchars($item['sku']) : '<span style="color: #999; font-style: italic;">N/A</span>' ?>
                                    </td>
                                    <td>
                                        <strong><?= htmlspecialchars($item['name']) ?></strong><br>
                                        <small>اللون: <?= htmlspecialchars($item['color']) ?></small><br>
                                        <small>المقاس: <?= htmlspecialchars($item['size']) ?></small>
                                    </td>
                                    <td><?= number_format($item['price'], 2) ?> ر.ي</td>
                                    <td><?= $item['quantity'] ?></td>
                                    <td><?= number_format($item['price'] * $item['quantity'], 2) ?> ر.ي</td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="6" class="text-center">لا توجد عناصر في هذا الطلب</td> <!-- تغيير من 5 إلى 6 -->
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <div class="order-status-update">
                <h3><i class="fas fa-sync-alt"></i> تحديث حالة الطلب</h3>

                <?php if (isset($_SESSION['success'])): ?>
                    <div class="alert alert-success">
                        <?= $_SESSION['success'] ?>
                        <?php unset($_SESSION['success']); ?>
                    </div>
                <?php endif; ?>

                <?php if ($order['status'] === 'cancelled' && !$order['stock_restored']): ?>
                    <form method="post" class="status-form">
                        <input type="hidden" name="order_id" value="<?= $order['id'] ?>">
                        <div class="form-group">
                            <select name="status" required>
                                <option value="pending" <?= $order['status'] == 'pending' ? 'selected' : '' ?>>قيد الانتظار</option>
                                <option value="processing" <?= $order['status'] == 'processing' ? 'selected' : '' ?>>قيد المعالجة</option>
                                <option value="in_the_way" <?= $order['status'] == 'in_the_way' ? 'selected' : '' ?>>في الطريق</option>
                                <option value="completed" <?= $order['status'] == 'completed' ? 'selected' : '' ?>>مكتمل</option>
                                <option value="cancelled" <?= $order['status'] == 'cancelled' ? 'selected' : '' ?>>ملغي</option>
                            </select>
                        </div>
                        <button type="submit" name="update_status" class="btn btn-pink">
                            <i class="fas fa-save"></i> حفظ التغييرات
                        </button>
                    </form>

                    <form method="post" onsubmit="return confirm('هل أنت متأكد من استرجاع الكمية إلى المخزون؟');" style="margin-top: 15px;">
                        <input type="hidden" name="restore_stock" value="1">
                        <button type="submit" class="btn btn-outline">
                            <i class="fas fa-undo"></i> استرجاع المنتجات إلى المخزون
                        </button>
                    </form>
                <?php elseif ($order['status'] === 'cancelled' && $order['stock_restored']): ?>
                    <div class="alert alert-success" style="margin-bottom: 20px;">
                        <i class="fas fa-check-circle"></i> تم استرجاع الكميات إلى المخزون بنجاح
                    </div>
                <?php else: ?>
                    <form method="post" class="status-form">
                        <input type="hidden" name="order_id" value="<?= $order['id'] ?>">
                        <div class="form-group">
                            <select name="status" required>
                                <option value="pending" <?= $order['status'] == 'pending' ? 'selected' : '' ?>>قيد الانتظار</option>
                                <option value="processing" <?= $order['status'] == 'processing' ? 'selected' : '' ?>>قيد المعالجة</option>
                                <option value="in_the_way" <?= $order['status'] == 'in_the_way' ? 'selected' : '' ?>>في الطريق</option>
                                <option value="completed" <?= $order['status'] == 'completed' ? 'selected' : '' ?>>مكتمل</option>
                                <option value="cancelled" <?= $order['status'] == 'cancelled' ? 'selected' : '' ?>>ملغي</option>
                            </select>
                        </div>
                        <button type="submit" name="update_status" class="btn btn-pink">
                            <i class="fas fa-save"></i> حفظ التغييرات
                        </button>
                    </form>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>


<!-- Leaflet JS -->
<script src="https://unpkg.com/leaflet/dist/leaflet.js"></script>


<?php include __DIR__ . '/../includes/admin_footer.php'; ?>

<!-- عرض الخريطه في الصفحه -->
<?php if (!empty($order['latitude']) && !empty($order['longitude'])): ?>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const lat = <?= $order['latitude'] ?>;
            const lng = <?= $order['longitude'] ?>;

            const map = L.map('customerMap').setView([lat, lng], 15);

            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                attribution: '&copy; OpenStreetMap contributors'
            }).addTo(map);

            L.marker([lat, lng]).addTo(map)
                .bindPopup("موقع العميل")
                .openPopup();
        });
    </script>

    <script src="<?php echo SITE_URL; ?>assets/js/coby_code_SKU.js"></script>

    <script>
        // وظائف تعديل تكلفة الشحن
        function showEditShippingForm() {
            document.getElementById('editShippingForm').style.display = 'block';
        }

        function hideEditShippingForm() {
            document.getElementById('editShippingForm').style.display = 'none';
        }
    </script>

<?php endif; ?>
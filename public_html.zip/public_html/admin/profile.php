<?php
require_once __DIR__ . '/../includes/auth.php';

// ✅ حماية: يجب أن يكون مديراً (قبل أي إخراج للـ header)
checkAdminRole();

include __DIR__ . '/../includes/admin_header.php';
require_once '../includes/db_connect.php';

// جلب بيانات المدير الحالي
$user_id = (int) $_SESSION['user_id'];
$stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

// معالجة تحديث البيانات
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);

    // ✅ التحقق من البريد الإلكتروني
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $_SESSION['error_message'] = "البريد الإلكتروني غير صالح";
        header("Location: " . SITE_URL . "admin/profile.php");
        exit();
    }

    // ✅ التحقق من اسم المستخدم (حروف + أرقام + _- فقط)
    if (!preg_match('/^[a-zA-Z0-9_\-]{3,20}$/u', $username)) {
        $_SESSION['error_message'] = "اسم المستخدم غير صالح (3-20 حرفًا)
        </br>
        تاكد من عدم وجود فراغات واستبدلها ب(_)
        ";
        header("Location: " . SITE_URL . "admin/profile.php");
        exit();
    }

    // معالجة رفع الصورة
    if (!empty($_FILES['avatar']['name'])) {
        $avatar = uploadAvatar();
        if ($avatar) {
            // حذف الصورة القديمة إذا كانت ليست الصورة الافتراضية
            if ($user['avatar'] != 'default-avatar.png') {
                $old_avatar = basename($user['avatar']); // ✅ حماية المسار
                $old_avatar_path = $_SERVER['DOCUMENT_ROOT'] . parse_url(SITE_URL, PHP_URL_PATH) . 'assets/images/users/avatars/' . $old_avatar;
                if (file_exists($old_avatar_path)) {
                    unlink($old_avatar_path);
                }
            }
        } else {
            $avatar = $user['avatar'];
        }
    } else {
        $avatar = $user['avatar'];
    }

    // تحديث البيانات في قاعدة البيانات
    $stmt = $conn->prepare("UPDATE users SET username = ?, email = ?, avatar = ? WHERE id = ?");
    if ($stmt->execute([$username, $email, $avatar, $user_id])) {
        $_SESSION['username'] = $username;
        $_SESSION['user_avatar'] = $avatar;
        $_SESSION['success_message'] = "تم تحديث الملف الشخصي بنجاح";
        header("Location: " . SITE_URL . "admin/profile.php");
        exit();
    }
}

function uploadAvatar()
{
    $target_dir = $_SERVER['DOCUMENT_ROOT'] . parse_url(SITE_URL, PHP_URL_PATH) . 'assets/images/users/avatars/';
    $imageFileType = strtolower(pathinfo($_FILES["avatar"]["name"], PATHINFO_EXTENSION));
    $new_filename = uniqid('', true) . '.' . $imageFileType;
    $target_file = $target_dir . $new_filename;

    // ✅ التحقق باستخدام finfo بدلاً من getimagesize
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime = finfo_file($finfo, $_FILES["avatar"]["tmp_name"]);
    finfo_close($finfo);

    if (!in_array($mime, ['image/jpeg', 'image/png', 'image/gif'])) {
        $_SESSION['error_message'] = "نوع الملف غير مسموح به (JPG, JPEG, PNG, GIF فقط)";
        return false;
    }

    // التحقق من حجم الصورة
    if ($_FILES["avatar"]["size"] > 2000000) {
        $_SESSION['error_message'] = "حجم الصورة كبير جداً (الحد الأقصى 2MB)";
        return false;
    }

    // التأكد من وجود المجلد
    if (!file_exists($target_dir)) {
        mkdir($target_dir, 0755, true); // ✅ صلاحيات أكثر أمانًا
    }

    if (move_uploaded_file($_FILES["avatar"]["tmp_name"], $target_file)) {
        return $new_filename;
    } else {
        $_SESSION['error_message'] = "حدث خطأ أثناء رفع الصورة";
        return false;
    }
}
?>


<div class="content-wrapper">
    <div class="container-fluid">
        <!-- رسائل التنبيه -->
        <?php if (isset($_SESSION['success_message'])): ?>
            <div class="alert alert-success">
                <?= $_SESSION['success_message'];
                unset($_SESSION['success_message']); ?>
            </div>
        <?php endif; ?>

        <?php if (isset($_SESSION['error_message'])): ?>
            <div class="alert alert-danger">
                <?= $_SESSION['error_message'];
                unset($_SESSION['error_message']); ?>
            </div>
        <?php endif; ?>

        <div class="row">
            <div class="col-md-8 mx-auto">
                <div class="card">
                    <div class="card-header bg-primary text-white">
                        <h4><i class="fas fa-user"></i> الملف الشخصي</h4>
                    </div>
                    <div class="card-body">
                        <form action="" method="post" enctype="multipart/form-data">
                            <div class="row">
                                <div class="col-md-4 text-center">
                                    <div class="avatar-upload">
                                        <div class="avatar-preview">
                                            <img src="<?php echo SITE_URL; ?>assets/images/users/avatars/<?= htmlspecialchars($user['avatar'] ?? 'default-avatar.png') ?>"
                                                alt="صورة المستخدم" class="img-thumbnail" id="avatarPreview">
                                        </div>
                                        <div class="mt-3">
                                            <label class="btn btn-primary btn-sm">
                                                تغيير الصورة
                                                <input type="file" name="avatar" id="avatarInput" accept="image/*" style="display: none;">
                                            </label>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-8">
                                    <div class="form-group">
                                        <label for="username">اسم المستخدم</label>
                                        <input type="text" class="form-control" id="username" name="username"
                                            value="<?= htmlspecialchars($user['username'] ?? '') ?>" required>
                                    </div>
                                    
                                    <div class="form-group">
                                        <label for="email">البريد الإلكتروني</label>
                                        <input type="email" class="form-control" id="email" name="email"
                                            value="<?= htmlspecialchars($user['email'] ?? '') ?>" required>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group mt-4">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-save"></i> حفظ التغييرات
                                </button>
                                <a href="<?php echo SITE_URL; ?>admin/change_password.php" class="btn btn-secondary">
                                    <i class="fas fa-lock"></i> تغيير كلمة المرور
                                </a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    // عرض معاينة الصورة قبل الرفع
    document.getElementById('avatarInput').addEventListener('change', function(e) {
        const file = e.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function(e) {
                document.getElementById('avatarPreview').src = e.target.result;
            }
            reader.readAsDataURL(file);
        }
    });
</script>

<?php require_once '../includes/admin_footer.php'; ?>
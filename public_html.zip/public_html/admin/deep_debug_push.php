<?php
/**
 * admin/deep_debug_push.php
 * --------------------------------------------------------------------
 * ✅ تشخيص عميق لـ Web Push - يكشف السبب الحقيقي لفشل الإرسال
 *
 * يقوم بـ:
 *   1. فحص VAPID keys (Base64URL decode + length check)
 *   2. فحص p256dh و auth للاشتراك (Base64URL decode + length check)
 *   3. اختبار تشفير AES128GCM فعلياً
 *   4. اختبار إنشاء VAPID JWT
 *   5. إرسال طلب فعلي لـ FCM وعرض:
 *      - HTTP status code
 *      - Response body (الرسالة الفعلية من FCM)
 *      - cURL error (لووجد)
 *   6. اقتراحات إصلاح بناءً على الخطأ
 * --------------------------------------------------------------------
 */

require_once __DIR__ . '/../includes/db_connect.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/notifications.php';
require_once __DIR__ . '/../includes/push_web.php';

checkAdminRole();

$debug_results = [];

// ============================================================
// 1. فحص VAPID Keys
// ============================================================
$debug_results['vapid'] = [
    'title' => '1️⃣ فحص VAPID Keys',
    'steps' => [],
];

try {
    $notifMgr = new NotificationsManager($conn);
    $vapid_public = $notifMgr->getSetting('vapid_public_key', '');
    $vapid_private = $notifMgr->getSetting('vapid_private_key', '');
    $vapid_subject = $notifMgr->getSetting('vapid_subject', '');

    // فحص المفتاح العمومي
    $public_decoded = base64UrlDecode($vapid_public);
    $public_len = strlen($public_decoded);
    $public_valid = ($public_len === 65) && ($public_decoded[0] === "\x04");

    $debug_results['vapid']['steps'][] = [
        'name' => 'VAPID Public Key',
        'input' => $vapid_public,
        'input_length' => strlen($vapid_public),
        'decoded_length' => $public_len,
        'expected_decoded_length' => 65,
        'first_byte_hex' => bin2hex($public_decoded[0] ?? ''),
        'expected_first_byte' => '04',
        'status' => $public_valid ? 'pass' : 'fail',
        'hint' => $public_valid ? '' : 'المفتاح العمومي يجب أن يكون 65 بايت (0x04 + X + Y) بعد Base64URL decode',
    ];

    // فحص المفتاح الخاص
    $private_decoded = base64UrlDecode($vapid_private);
    $private_len = strlen($private_decoded);
    $private_valid = ($private_len === 32);

    $debug_results['vapid']['steps'][] = [
        'name' => 'VAPID Private Key',
        'input_length' => strlen($vapid_private),
        'decoded_length' => $private_len,
        'expected_decoded_length' => 32,
        'status' => $private_valid ? 'pass' : 'fail',
        'hint' => $private_valid ? '' : 'المفتاح الخاص يجب أن يكون 32 بايت بعد Base64URL decode',
    ];

    $debug_results['vapid']['steps'][] = [
        'name' => 'VAPID Subject',
        'input' => $vapid_subject,
        'status' => !empty($vapid_subject) ? 'pass' : 'fail',
        'hint' => empty($vapid_subject) ? 'مطلوب mailto: أو https:// URL' : '',
    ];

} catch (Exception $e) {
    $debug_results['vapid']['error'] = $e->getMessage();
}

// ============================================================
// 2. فحص أحدث اشتراك
// ============================================================
$debug_results['subscription'] = [
    'title' => '2️⃣ فحص أحدث اشتراك',
    'steps' => [],
];

try {
    $stmt = $conn->prepare("
        SELECT * FROM push_subscriptions
        WHERE is_active = 1
        ORDER BY id DESC
        LIMIT 1
    ");
    $stmt->execute();
    $sub = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$sub) {
        $debug_results['subscription']['steps'][] = [
            'name' => 'اشتراك نشط',
            'status' => 'fail',
            'hint' => 'لا يوجد اشتراكات نشطة! افتح الموقع من متصفح وفعّل الإشعارات',
        ];
    } else {
        $debug_results['subscription']['data'] = $sub;

        // فحص p256dh
        $p256dh_decoded = base64UrlDecode($sub['p256dh']);
        $p256dh_len = strlen($p256dh_decoded);
        $p256dh_valid = ($p256dh_len === 65) && ($p256dh_decoded[0] === "\x04");

        $debug_results['subscription']['steps'][] = [
            'name' => 'p256dh (User Public Key)',
            'input_length' => strlen($sub['p256dh']),
            'decoded_length' => $p256dh_len,
            'expected_decoded_length' => 65,
            'first_byte_hex' => bin2hex($p256dh_decoded[0] ?? ''),
            'expected_first_byte' => '04',
            'status' => $p256dh_valid ? 'pass' : 'fail',
            'hint' => $p256dh_valid ? '' : 'p256dh يجب أن يكون 65 بايت (0x04 + X + Y)',
        ];

        // فحص auth
        $auth_decoded = base64UrlDecode($sub['auth']);
        $auth_len = strlen($auth_decoded);
        $auth_valid = ($auth_len === 16);

        $debug_results['subscription']['steps'][] = [
            'name' => 'auth (User Auth Secret)',
            'input_length' => strlen($sub['auth']),
            'decoded_length' => $auth_len,
            'expected_decoded_length' => 16,
            'status' => $auth_valid ? 'pass' : 'fail',
            'hint' => $auth_valid ? '' : 'auth يجب أن يكون 16 بايت',
        ];

        // فحص endpoint
        $endpoint_ok = strpos($sub['endpoint'], 'https://fcm.googleapis.com/fcm/send/') === 0;
        $debug_results['subscription']['steps'][] = [
            'name' => 'Endpoint URL',
            'input' => substr($sub['endpoint'], 0, 100) . '...',
            'is_fcm' => $endpoint_ok,
            'status' => $endpoint_ok ? 'pass' : 'warn',
            'hint' => $endpoint_ok ? '' : 'Endpoint غير معتاد - قد لا يكون FCM',
        ];
    }

} catch (Exception $e) {
    $debug_results['subscription']['error'] = $e->getMessage();
}

// ============================================================
// 3. اختبار التشفير + JWT + الإرسال الفعلي
// ============================================================
$debug_results['send_test'] = [
    'title' => '3️⃣ اختبار إرسال فعلي مع تفاصيل كاملة',
    'steps' => [],
];

if (!empty($sub) && !empty($vapid_public) && !empty($vapid_private)) {
    try {
        // إنشاء إشعار تجريبي
        $notifMgr = new NotificationsManager($conn);
        $notif_id = $notifMgr->create([
            'type' => 'test',
            'title' => '🔧 Deep Debug Test',
            'body' => 'Test from deep_debug_push.php at ' . date('H:i:s'),
            'url' => SITE_URL,
            'icon' => 'fa-bug',
            'target_audience' => 'all',
            'send_push' => false,
        ]);

        $debug_results['send_test']['notif_id'] = $notif_id;

        // جلب بيانات الإشعار
        $stmt = $conn->prepare("SELECT * FROM notifications WHERE id = ?");
        $stmt->execute([$notif_id]);
        $notif = $stmt->fetch(PDO::FETCH_ASSOC);

        // === Step 1: بناء payload ===
        $payload = json_encode([
            'id' => (int)$notif['id'],
            'type' => $notif['type'],
            'title' => $notif['title'],
            'body' => $notif['body'],
            'url' => $notif['url'] ?: '/',
            'icon' => SITE_URL . 'assets/icons/icon-192.png',
            'badge' => SITE_URL . 'assets/icons/badge-72.png',
            'tag' => 'notif-' . $notif['id'],
        ], JSON_UNESCAPED_UNICODE);

        $debug_results['send_test']['steps'][] = [
            'name' => 'بناء Payload',
            'status' => 'pass',
            'payload_size' => strlen($payload) . ' bytes',
            'payload_preview' => substr($payload, 0, 200),
        ];

        // === Step 2: تشفير AES128GCM ===
        $encrypted = encryptPayload($payload, $sub['p256dh'], $sub['auth']);

        if ($encrypted === false) {
            $debug_results['send_test']['steps'][] = [
                'name' => 'تشفير AES128GCM',
                'status' => 'fail',
                'hint' => 'فشل التشفير! راجع error_log',
                'openssl_last_error' => openssl_error_string(),
            ];
        } else {
            $debug_results['send_test']['steps'][] = [
                'name' => 'تشفير AES128GCM',
                'status' => 'pass',
                'encrypted_size' => strlen($encrypted) . ' bytes',
            ];
        }

        // === Step 3: إنشاء VAPID JWT ===
        $jwt = createVapidJWT($vapid_private, $vapid_public, $sub['endpoint'], $vapid_subject);

        if ($jwt === false) {
            $debug_results['send_test']['steps'][] = [
                'name' => 'إنشاء VAPID JWT',
                'status' => 'fail',
                'hint' => 'فشل إنشاء JWT - تحقق من المفتاح الخاص',
                'openssl_last_error' => openssl_error_string(),
            ];
        } else {
            $jwt_parts = explode('.', $jwt);
            $debug_results['send_test']['steps'][] = [
                'name' => 'إنشاء VAPID JWT',
                'status' => 'pass',
                'jwt_length' => strlen($jwt),
                'jwt_parts' => count($jwt_parts),
                'header_preview' => base64UrlDecode($jwt_parts[0] ?? ''),
                'payload_preview' => base64UrlDecode($jwt_parts[1] ?? ''),
            ];
        }

        // === Step 4: إرسال الطلب لـ FCM ===
        if ($encrypted !== false && $jwt !== false) {
            // بناء Authorization header
            $auth_header = 'Authorization: vapid t=' . $jwt . '; k=' . $vapid_public;

            $ch = curl_init($sub['endpoint']);
            curl_setopt_array($ch, [
                CURLOPT_POST => true,
                CURLOPT_POSTFIELDS => $encrypted,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_HTTPHEADER => [
                    'Content-Type: application/octet-stream',
                    'Content-Encoding: aes128gcm',
                    'Content-Length: ' . strlen($encrypted),
                    'TTL: 2419200',
                    $auth_header,
                    'Urgency: high',
                ],
                CURLOPT_TIMEOUT => 30,
                CURLOPT_SSL_VERIFYPEER => true,
                CURLOPT_SSL_VERIFYHOST => 2,
                CURLOPT_VERBOSE => true,
                CURLOPT_STDERR => $verbose = fopen('php://temp', 'w+'),
            ]);

            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $curl_error = curl_error($ch);
            $curl_info = curl_getinfo($ch);

            // قراءة verbose log
            rewind($verbose);
            $verbose_log = stream_get_contents($verbose);
            fclose($verbose);

            curl_close($ch);

            $debug_results['send_test']['steps'][] = [
                'name' => 'إرسال cURL لـ FCM',
                'status' => ($httpCode >= 200 && $httpCode < 300) ? 'pass' : 'fail',
                'http_code' => $httpCode,
                'curl_error' => $curl_error ?: null,
                'response_body' => $response ?: '(empty)',
                'response_size' => strlen($response ?: ''),
                'total_time' => round($curl_info['total_time'], 3) . 's',
                'verbose_log' => substr($verbose_log, 0, 3000),
            ];

            // تحليل HTTP code
            $http_hints = [
                200 => '✅ نجح الإرسال!',
                201 => '✅ نجح الإرسال!',
                400 => '❌ Bad Request - payload مشوّه أو Content-Encoding خاطئ',
                401 => '❌ Unauthorized - VAPID JWT غير صالح أو المفتاح الخاص خاطئ',
                403 => '❌ Forbidden - VAPID subject لا يطابق، أو المفاتيح غير مرتبطة ببعضها',
                404 => '❌ Not Found - الاشتراك منتهي الصلاحية (طبيعي)',
                410 => '❌ Gone - الاشتراك محذوف من FCM',
                413 => '❌ Payload Too Large - يجب أن يكون < 4096 بايت',
                429 => '❌ Too Many Requests - rate limit exceeded',
            ];

            $debug_results['send_test']['steps'][] = [
                'name' => 'تحليل استجابة FCM',
                'status' => ($httpCode >= 200 && $httpCode < 300) ? 'pass' : 'fail',
                'http_code' => $httpCode,
                'interpretation' => $http_hints[$httpCode] ?? '❌ خطأ غير معروف',
                'response_body_decoded' => json_decode($response, true) ?: $response,
            ];

            // لو نجح، حدّث is_sent + last_used_at
            if ($httpCode >= 200 && $httpCode < 300) {
                $stmt = $conn->prepare("UPDATE notifications SET is_sent = 1 WHERE id = ?");
                $stmt->execute([$notif_id]);
                $stmt = $conn->prepare("UPDATE push_subscriptions SET last_used_at = NOW() WHERE id = ?");
                $stmt->execute([$sub['id']]);
            }
        }

    } catch (Exception $e) {
        $debug_results['send_test']['error'] = $e->getMessage() . "\n" . $e->getTraceAsString();
    }
}

// ============================================================
// 4. فحص سجل أخطاء PHP
// ============================================================
$debug_results['php_errors'] = [
    'title' => '4️⃣ آخر أخطاء PHP المسجّلة',
    'steps' => [],
];

// محاولة قراءة error_log من المسارات الشائعة
$error_log_paths = [
    __DIR__ . '/../error_log',
    __DIR__ . '/../logs/error.log',
    ini_get('error_log'),
];

foreach ($error_log_paths as $path) {
    if (!empty($path) && file_exists($path)) {
        $debug_results['php_errors']['steps'][] = [
            'name' => 'ملف error_log',
            'path' => $path,
            'size' => filesize($path),
            'last_lines' => array_slice(file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES), -15),
        ];
        break;
    }
}

if (empty($debug_results['php_errors']['steps'])) {
    $debug_results['php_errors']['steps'][] = [
        'name' => 'ملف error_log',
        'status' => 'warn',
        'hint' => 'لم يتم العثور على error_log - راجع إعدادات error_log في php.ini',
    ];
}

// ============================================================
// 5. اقتراحات الإصلاح
// ============================================================
$debug_results['suggestions'] = [
    'title' => '5️⃣ اقتراحات الإصلاح',
    'items' => [],
];

// تحليل النتائج وتقديم اقتراحات
$httpCode = $debug_results['send_test']['steps'][3]['http_code'] ?? null;

if ($httpCode === 401 || $httpCode === 403) {
    $debug_results['suggestions']['items'][] = [
        'priority' => 'عالية',
        'issue' => 'VAPID JWT غير مقبول من FCM',
        'fix' => 'المفاتيح VAPID غير مرتبطة ببعضها (Public ≠ pair of Private).
                  أعد توليدها من admin/notification_settings.php أو install_notifications.php',
    ];
}

if ($httpCode === 400) {
    $debug_results['suggestions']['items'][] = [
        'priority' => 'عالية',
        'issue' => 'Payload مشوّه',
        'fix' => 'تحقق من تشفير AES128GCM. لو الخطأ يستمر، استخدم مكتبة minishlink/web-push بدلاً من التشفير اليدوي',
    ];
}

if (!empty($debug_results['vapid']['steps'][0]) && $debug_results['vapid']['steps'][0]['status'] === 'fail') {
    $debug_results['suggestions']['items'][] = [
        'priority' => 'حرجة',
        'issue' => 'VAPID Public Key غير صالح',
        'fix' => 'المفتاح العمومي ليس 65 بايت بعد Base64URL decode. أعد توليده من install_notifications.php',
    ];
}

if (!empty($debug_results['vapid']['steps'][1]) && $debug_results['vapid']['steps'][1]['status'] === 'fail') {
    $debug_results['suggestions']['items'][] = [
        'priority' => 'حرجة',
        'issue' => 'VAPID Private Key غير صالح',
        'fix' => 'المفتاح الخاص ليس 32 بايت. أعد توليده من install_notifications.php',
    ];
}

if (empty($debug_results['suggestions']['items'])) {
    $debug_results['suggestions']['items'][] = [
        'priority' => 'معلومة',
        'issue' => 'لا توجد اقتراحات محددة',
        'fix' => 'ارفع لي مخرجات هذه الصفحة وسأحللها لك',
    ];
}

// ============================================================
// عرض الصفحة
// ============================================================
include __DIR__ . '/../includes/admin_header.php';
?>

<div class="content-wrapper">
    <div class="container-fluid">
        <h2 class="mt-4 mb-4">
            <i class="fas fa-bug text-danger"></i>
            Deep Debug - تشخيص عميق لـ Web Push
        </h2>

        <div class="alert alert-info">
            <strong>💡 معلومة:</strong> هذه الصفحة تنشئ إشعاراً تجريبياً وترسله للاشتراك الأحدث
            مع عرض <strong>كل تفاصيل الإرسال</strong> بما فيها استجابة FCM الفعلية.
        </div>

        <div class="mb-3">
            <a href="?refresh=1" class="btn btn-primary">
                <i class="fas fa-sync"></i> إعادة الاختبار
            </a>
            <a href="diagnose_push.php" class="btn btn-secondary">
                <i class="fas fa-arrow-right"></i> العودة للتشخيص العادي
            </a>
        </div>

        <?php foreach ($debug_results as $section_key => $section): ?>
            <div class="card mb-4">
                <div class="card-header bg-<?= $section_key === 'suggestions' ? 'success' : 'info' ?> text-white">
                    <h5 class="mb-0"><?= $section['title'] ?></h5>
                </div>
                <div class="card-body">
                    <?php if ($section_key === 'suggestions'): ?>
                        <?php foreach ($section['items'] as $item): ?>
                            <div class="alert alert-<?= $item['priority'] === 'حرجة' ? 'danger' : ($item['priority'] === 'عالية' ? 'warning' : 'info') ?>">
                                <strong>[<?= $item['priority'] ?>]</strong>
                                <?= htmlspecialchars($item['issue']) ?><br>
                                <strong>الإصلاح:</strong> <?= htmlspecialchars($item['fix']) ?>
                            </div>
                        <?php endforeach; ?>
                    <?php elseif ($section_key === 'php_errors'): ?>
                        <?php foreach ($section['steps'] as $step): ?>
                            <p>
                                <strong>الملف:</strong> <code><?= htmlspecialchars($step['path'] ?? '') ?></code>
                                (<?= number_format($step['size'] ?? 0) ?> bytes)
                            </p>
                            <?php if (!empty($step['last_lines'])): ?>
                                <pre class="bg-dark text-light p-3" style="max-height: 300px; overflow-y: auto; direction: ltr; text-align: left;"><?php
                                    foreach ($step['last_lines'] as $line) {
                                        echo htmlspecialchars($line) . "\n";
                                    }
                                ?></pre>
                            <?php else: ?>
                                <div class="text-warning"><?= $step['hint'] ?? '' ?></div>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <?php foreach ($section['steps'] as $step): ?>
                            <div class="border-bottom pb-3 mb-3">
                                <h6 class="<?= $step['status'] === 'pass' ? 'text-success' : ($step['status'] === 'fail' ? 'text-danger' : 'text-warning') ?>">
                                    <?= $step['status'] === 'pass' ? '✅' : ($step['status'] === 'fail' ? '❌' : '⚠️') ?>
                                    <?= htmlspecialchars($step['name'] ?? '') ?>
                                </h6>
                                <div class="row">
                                    <?php foreach ($step as $key => $value): ?>
                                        <?php if (in_array($key, ['name', 'status', 'hint'])) continue; ?>
                                        <?php if (is_array($value)): ?>
                                            <div class="col-12 mb-2">
                                                <strong><?= htmlspecialchars($key) ?>:</strong>
                                                <pre class="small bg-light p-2 mb-0" style="max-height: 200px; overflow: auto;"><?= htmlspecialchars(print_r($value, true)) ?></pre>
                                            </div>
                                        <?php elseif (is_string($value) && strlen($value) > 200): ?>
                                            <div class="col-12 mb-2">
                                                <strong><?= htmlspecialchars($key) ?>:</strong>
                                                <pre class="small bg-light p-2 mb-0" style="max-height: 200px; overflow: auto; direction: ltr; text-align: left;"><?= htmlspecialchars($value) ?></pre>
                                            </div>
                                        <?php else: ?>
                                            <div class="col-md-6 mb-1">
                                                <strong><?= htmlspecialchars($key) ?>:</strong>
                                                <span><?= htmlspecialchars((string)$value) ?></span>
                                            </div>
                                        <?php endif; ?>
                                    <?php endforeach; ?>
                                </div>
                                <?php if (!empty($step['hint'])): ?>
                                    <div class="text-muted small mt-2">
                                        💡 <?= htmlspecialchars($step['hint']) ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>

                        <?php if (!empty($section['data'])): ?>
                            <details class="mt-2">
                                <summary>بيانات الاشتراك الكاملة</summary>
                                <pre class="small bg-light p-2"><?= htmlspecialchars(print_r($section['data'], true)) ?></pre>
                            </details>
                        <?php endif; ?>

                        <?php if (!empty($section['error'])): ?>
                            <div class="alert alert-danger">
                                <strong>خطأ:</strong>
                                <pre><?= htmlspecialchars($section['error']) ?></pre>
                            </div>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; ?>

        <div class="alert alert-warning">
            <strong>📋 الخطوة التالية:</strong>
            انسخ محتوى هذه الصفحة (خصوصاً قسم "إرسال cURL لـ FCM" و"تحليل استجابة FCM")
            وأرسله لي وسأحدد لك الإصلاح الدقيق.
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>

<?php
require_once __DIR__ . '/../includes/db_connect.php';
require_once __DIR__ . '/../includes/auth.php';

// التحقق من أن المستخدم مدير
checkAdminRole();

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: " . SITE_URL . "admin/customers.php");
    exit;
}

$id = intval($_GET['id']);
$stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$id]);
$user = $stmt->fetch();

if (!$user) {
    echo "المستخدم غير موجود.";
    exit;
}

// تحديث البيانات بعد إرسال النموذج
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $role = $_POST['role'];
    $avatar = $user['avatar']; // الصورة القديمة

    // تحديث الصورة الرمزية إن تم رفع صورة جديدة
    if (isset($_FILES['avatar']) && $_FILES['avatar']['error'] === UPLOAD_ERR_OK) {
        $fileTmpPath = $_FILES['avatar']['tmp_name'];
        $fileName = time() . '_' . $_FILES['avatar']['name'];
        $destPath = __DIR__ . '/../assets/images/users/avatars/' . $fileName;

        // التحقق من نوع الملف
        $allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
        $fileType = mime_content_type($fileTmpPath);

        if (!in_array($fileType, $allowedTypes)) {
            $errors[] = "نوع الملف غير مسموح به. يرجى رفع صورة (JPEG, PNG, GIF, WebP).";
        } elseif ($_FILES['avatar']['size'] > 5 * 1024 * 1024) { // 5MB كحد أقصى
            $errors[] = "حجم الصورة كبير جداً. الحد الأقصى هو 5MB.";
        } elseif (move_uploaded_file($fileTmpPath, $destPath)) {
            // حذف الصورة القديمة
            if ($avatar && file_exists(__DIR__ . '/../assets/images/users/avatars/' . $avatar)) {
                unlink(__DIR__ . '/../assets/images/users/avatars/' . $avatar);
            }
            $avatar = $fileName;
        } else {
            $errors[] = "فشل في رفع الصورة.";
        }
    }

    $newPassword = $_POST['new_password'];
    $updatePassword = false;
    $passwordHash = $user['password'];

    if (!empty($newPassword)) {
        if (strlen($newPassword) < 6) {
            $errors[] = "كلمة المرور يجب أن تحتوي على الأقل 6 أحرف.";
        } else {
            $passwordHash = password_hash($newPassword, PASSWORD_DEFAULT);
            $updatePassword = true;
        }
    }

    // إذا لا يوجد أخطاء، قم بالتحديث
    if (empty($errors)) {
        if ($updatePassword) {
            $stmt = $conn->prepare("UPDATE users SET username = ?, email = ?, role = ?, avatar = ?, password = ?, updated_at = NOW() WHERE id = ?");
            $stmt->execute([$username, $email, $role, $avatar, $passwordHash, $id]);
        } else {
            $stmt = $conn->prepare("UPDATE users SET username = ?, email = ?, role = ?, avatar = ?, updated_at = NOW() WHERE id = ?");
            $stmt->execute([$username, $email, $role, $avatar, $id]);
        }

        header("Location: " . SITE_URL . "admin/customers.php");
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تعديل عميل</title>
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>assets/css/customers.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>

<body>
    <div class="container">
        <div class="header">
            <h2><i class="fas fa-user-edit"></i> تعديل بيانات العميل</h2>
            <a href="<?php echo SITE_URL; ?>admin/customers.php" class="back-btn"><i class="fas fa-arrow-right"></i> العودة إلى العملاء</a>
        </div>

        <div class="form-container">
            <?php if (!empty($errors)): ?>
                <div class="alert error">
                    <?php foreach ($errors as $error): ?>
                        <p><i class="fas fa-exclamation-circle"></i> <?= htmlspecialchars($error) ?></p>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

            <form method="POST" enctype="multipart/form-data" id="customerForm">
                <div class="form-grid">
                    <div class="form-group">
                        <label for="username"><i class="fas fa-user"></i> اسم المستخدم</label>
                        <input type="text" name="username" id="username" required value="<?= htmlspecialchars($user['username']) ?>">
                    </div>

                    <div class="form-group">
                        <label for="email"><i class="fas fa-envelope"></i> البريد الإلكتروني</label>
                        <input type="email" name="email" id="email" required value="<?= htmlspecialchars($user['email']) ?>">
                    </div>

                    <div class="form-group">
                        <label for="new_password"><i class="fas fa-lock"></i> كلمة المرور الجديدة (اختياري)</label>
                        <input type="password" name="new_password" id="new_password" placeholder="اتركه فارغاً إذا لم ترد التغيير">
                    </div>

                    <div class="form-group">
                        <label for="role"><i class="fas fa-user-tag"></i> الدور</label>
                        <select name="role" id="role" required>
                            <option value="user" <?= $user['role'] === 'user' ? 'selected' : '' ?>>مستخدم</option>
                            <option value="admin" <?= $user['role'] === 'admin' ? 'selected' : '' ?>>مدير</option>
                        </select>
                    </div>

                    <div class="form-group full-width">
                        <div class="current-avatar">
                            <label>الصورة الحالية</label><br>
                            <?php if ($user['avatar']): ?>
                                <img src="<?php echo SITE_URL; ?>assets/images/users/avatars/<?= htmlspecialchars($user['avatar']) ?>" alt="صورة المستخدم">
                            <?php else: ?>
                                <p>لا توجد صورة</p>
                            <?php endif; ?>
                        </div>

                        <label>تغيير الصورة (اختياري)</label>
                        <div class="file-input-container">
                            <label class="file-input-label" for="avatar">
                                <i class="fas fa-cloud-upload-alt"></i>
                                <span>انقر أو اسحب الصورة هنا</span>
                                <small>الحجم الأقصى: 5MB (JPEG, PNG, GIF, WebP)</small>
                            </label>
                            <input type="file" class="file-input" name="avatar" id="avatar" accept="image/*">
                        </div>
                        <div class="preview-container" id="previewContainer" style="display: none;">
                            <img src="" class="preview-image" id="previewImage">
                            <div><small>معاينة الصورة الجديدة</small></div>
                        </div>
                    </div>
                </div>

                <button type="submit"><i class="fas fa-save"></i> حفظ التعديلات</button>
            </form>
        </div>
    </div>

    <script>
        // معاينة الصورة قبل الرفع
        document.getElementById('avatar').addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    const previewImage = document.getElementById('previewImage');
                    const previewContainer = document.getElementById('previewContainer');

                    previewImage.src = e.target.result;
                    previewContainer.style.display = 'block';
                }
                reader.readAsDataURL(file);
            } else {
                document.getElementById('previewContainer').style.display = 'none';
            }
        });

        // التحقق من صحة النموذج قبل الإرسال
        document.getElementById('customerForm').addEventListener('submit', function(e) {
            const newPassword = document.getElementById('new_password').value;
            if (newPassword && newPassword.length < 6) {
                e.preventDefault();
                alert('كلمة المرور يجب أن تحتوي على الأقل 6 أحرف');
                return false;
            }
        });
    </script>
</body>

</html>
<?php
require_once __DIR__ . '/../includes/db_connect.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

// بدء الجلسة إذا لم تكن بدأت الجلسه بدات في ملف auth.php

// التحقق من أن المستخدم مدير
checkAdminRole();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // استقبال وتنظيف البيانات
    $name = trim(filter_input(INPUT_POST, 'name', FILTER_SANITIZE_FULL_SPECIAL_CHARS));
    $slug = trim(filter_input(INPUT_POST, 'slug', FILTER_SANITIZE_FULL_SPECIAL_CHARS));
    $description = trim(filter_input(INPUT_POST, 'description', FILTER_SANITIZE_FULL_SPECIAL_CHARS));
    $type = filter_input(INPUT_POST, 'type', FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $parent_id = ($type === 'sub') ? filter_input(INPUT_POST, 'parent_id', FILTER_VALIDATE_INT) : null;

    // التحقق من البيانات المطلوبة
    if (empty($name)) {
        $_SESSION['error'] = "اسم التصنيف مطلوب";
        header("Location: " . SITE_URL . "admin/manage_categories.php");
        exit();
    }

    if (empty($slug)) {
        $_SESSION['error'] = "رابط التصنيف مطلوب";
        header("Location: " . SITE_URL . "admin/manage_categories.php");
        exit();
    }

    // التحقق من عدم تكرار اسم التصنيف أو الرابط
    try {
        $check_stmt = $conn->prepare("SELECT COUNT(*) FROM categories WHERE name = ? OR slug = ?");
        $check_stmt->execute([$name, $slug]);
        $exists = $check_stmt->fetchColumn();

        if ($exists) {
            $_SESSION['error'] = "اسم التصنيف أو الرابط موجود مسبقاً";
            header("Location: " . SITE_URL . "admin/manage_categories.php");
            exit();
        }
    } catch (PDOException $e) {
        $_SESSION['error'] = "خطأ في التحقق من البيانات: " . $e->getMessage();
        header("Location: " . SITE_URL . "admin/manage_categories.php");
        exit();
    }

    // معالجة رفع الصورة
    $image = '';
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $uploadDir = __DIR__ . '/../assets/images/uploads/categories/';
        if (!file_exists($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }

        // التحقق من نوع الملف
        $allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
        $fileInfo = finfo_open(FILEINFO_MIME_TYPE);
        $detectedType = finfo_file($fileInfo, $_FILES['image']['tmp_name']);
        finfo_close($fileInfo);

        if (!in_array($detectedType, $allowedTypes)) {
            $_SESSION['error'] = "نوع الملف غير مسموح به. يرجى رفع صورة بصيغة JPEG, PNG, GIF, أو WebP.";
            header("Location: " . SITE_URL . "admin/manage_categories.php");
            exit();
        }

        // التحقق من حجم الملف (5MB كحد أقصى)
        if ($_FILES['image']['size'] > 5 * 1024 * 1024) {
            $_SESSION['error'] = "حجم الملف كبير جداً. الحد الأقصى هو 5 ميجابايت";
            header("Location: " . SITE_URL . "admin/manage_categories.php");
            exit();
        }

        $extension = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
        $filename = 'category_' . time() . '_' . uniqid() . '.' . $extension;
        $destination = $uploadDir . $filename;

        if (move_uploaded_file($_FILES['image']['tmp_name'], $destination)) {
            $image = $filename;
        } else {
            $_SESSION['error'] = "حدث خطأ أثناء رفع الصورة";
            header("Location: " . SITE_URL . "admin/manage_categories.php");
            exit();
        }
    }

    try {
        $stmt = $conn->prepare("INSERT INTO categories (parent_id, name, slug, description, image, created_at, updated_at) 
                               VALUES (:parent_id, :name, :slug, :description, :image, NOW(), NOW())");
        $stmt->execute([
            ':parent_id' => $parent_id,
            ':name' => $name,
            ':slug' => $slug,
            ':description' => $description,
            ':image' => $image
        ]);

        $_SESSION['success'] = "تم إضافة التصنيف بنجاح";
        header("Location: " . SITE_URL . "admin/manage_categories.php");
        exit();
    } catch (PDOException $e) {
        $_SESSION['error'] = "حدث خطأ أثناء إضافة التصنيف: " . $e->getMessage();
        header("Location: " . SITE_URL . "admin/manage_categories.php");
        exit();
    }
} else {
    header("Location: " . SITE_URL . "admin/manage_categories.php");
    exit();
}

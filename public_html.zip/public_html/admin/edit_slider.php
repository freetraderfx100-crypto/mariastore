<?php
session_start();
require_once __DIR__ . '/../includes/db_connect.php';
require_once __DIR__ . '/../includes/functions.php';

require_once __DIR__ . '/../includes/auth.php';
// التحقق من أن المستخدم مدير
checkAdminRole();

if (!isset($_GET['id'])) {
    header("Location: " . SITE_URL . "admin/manage_sliders.php");
    exit;
}

$id = (int)$_GET['id'];

// جلب بيانات الشريحة الحالية
$stmt = $conn->prepare("SELECT * FROM sliders WHERE id = ?");
$stmt->execute([$id]);
$slider = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$slider) {
    die("الشريحة غير موجودة");
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title']);
    $description = trim($_POST['description']);
    $link = trim($_POST['link']);
    $sort_order = (int) $_POST['sort_order'];
    $is_active = isset($_POST['is_active']) ? 1 : 0;

    // رفع صورة جديدة إذا تم اختيارها
    $image_url = $slider['image_url'];
    if (isset($_FILES['image']) && $_FILES['image']['error'] === 0) {
        $ext = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
        // ✅ التحقق من نوع الصورة
        $allowed = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
        if (!in_array($ext, $allowed, true)) {
            die('نوع الصورة غير مسموح به');
        }
        $filename = uniqid() . '.' . $ext;
        // ✅ إصلاح: كان هناك شرطة مائلة مفقودة في المسار ('banners' . $filename)
        move_uploaded_file($_FILES['image']['tmp_name'], __DIR__ . '/../assets/images/banners/' . $filename);
        $image_url = $filename;
    }

    $stmt = $conn->prepare("UPDATE sliders SET title = ?, description = ?, link = ?, image_url = ?, sort_order = ?, is_active = ? WHERE id = ?");
    $stmt->execute([$title, $description, $link, $image_url, $sort_order, $is_active, $id]);

    header("Location: " . SITE_URL . "admin/manage_sliders.php");
    exit;
}

include __DIR__ . '/../includes/admin_header.php';
?>

<div class="container">
    <h1 class="page-title">تعديل الشريحة</h1>
    <?php if ($error): ?><p class="error"><?= $error ?></p><?php endif; ?>
    <form method="post" enctype="multipart/form-data">
        <div class="form-group">
            <label>العنوان</label>
            <input type="text" name="title" value="<?= htmlspecialchars($slider['title']) ?>" >
        </div>
        <div class="form-group">
            <label>الوصف</label>
            <textarea name="description" rows="3"><?= htmlspecialchars($slider['description']) ?></textarea>
        </div>
        <div class="form-group">
            <label>الرابط (اختياري)</label>
            <input type="text" name="link" value="<?= htmlspecialchars($slider['link']) ?>">
        </div>
        <div class="form-group">
            <label>ترتيب الظهور</label>
            <input type="number" name="sort_order" value="<?= $slider['sort_order'] ?>">
        </div>
        <div class="form-group">
            <label>الصورة الحالية</label><br>
            <img src="<?php echo SITE_URL; ?>assets/images/banners/<?= htmlspecialchars($slider['image_url']) ?>" width="150"><br>
            <input type="file" name="image">
        </div>
        <div class="form-group">
            <label><input type="checkbox" name="is_active" <?= $slider['is_active'] ? 'checked' : '' ?>> نشطة</label>
        </div>
        <button type="submit" class="btn">تحديث</button>
        <a href="<?php echo SITE_URL; ?>admin/manage_sliders.php" class="btn btn-cancel">إلغاء</a>
    </form>
</div>

<?php include __DIR__ . '/../includes/admin_footer.php'; ?>
<?php
session_start();
require_once __DIR__ . '/../includes/db_connect.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

// التحقق من أن المستخدم مدير
checkAdminRole();

// التحقق من وجود معرف الطلب
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: " . SITE_URL . "admin/orders.php");
    exit;
}

$order_id = (int)$_GET['id'];

// جلب بيانات الطلب الأساسية
$stmt = $conn->prepare("SELECT id FROM orders WHERE id = ?");
$stmt->execute([$order_id]);
$order = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$order) {
    header("Location: " . SITE_URL . "admin/orders.php");
    exit;
}

// معالجة البحث عن المنتجات
// معالجة البحث عن المنتجات
$search_results = [];
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['search'])) {
    $search_term = '%' . trim($_GET['search']) . '%';
    $search_stmt = $conn->prepare("
    SELECT p.id, p.name, p.sku, p.price, p.discount_percentage, pv.color, pv.size, pv.quantity, pv.image_urls
    FROM products p
    JOIN product_variants pv ON p.id = pv.product_id
    WHERE p.name LIKE ? OR p.sku LIKE ? OR p.id LIKE ?
    ORDER BY p.name ASC, pv.color ASC, pv.size ASC
    ");
    $search_stmt->execute([$search_term, $search_term, $search_term]);
    $search_results = $search_stmt->fetchAll(PDO::FETCH_ASSOC);

    // استخراج الصور الأولى من image_urls
    foreach ($search_results as &$product) {
        if (!empty($product['image_urls'])) {
            $images = json_decode($product['image_urls'], true);
            if (is_array($images) && !empty($images)) {
                $product['image_url'] = $images[0]; // استخدام الصورة الأولى
            } else {
                $product['image_url'] = null;
            }
        } else {
            $product['image_url'] = null;
        }
    }
}

// معالجة إضافة المنتج
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_item'])) {
    $product_id = (int)$_POST['product_id'];
    $color = trim($_POST['color']);
    $size = trim($_POST['size']);
    $quantity = (int)$_POST['quantity'];

    // التحقق من توفر الكمية
    $check_stmt = $conn->prepare("
    SELECT pv.quantity, p.price, p.discount_percentage, pv.image_urls 
    FROM product_variants pv
    JOIN products p ON pv.product_id = p.id
    WHERE pv.product_id = ? AND pv.color = ? AND pv.size = ?
    FOR UPDATE
    ");
    $check_stmt->execute([$product_id, $color, $size]);
    $variant = $check_stmt->fetch(PDO::FETCH_ASSOC);

    // استخراج الصورة الأولى من image_urls
    $image_url = null;
    if (!empty($variant['image_urls'])) {
        $images = json_decode($variant['image_urls'], true);
        if (is_array($images) && !empty($images)) {
            $image_url = $images[0]; // استخدام الصورة الأولى
        }
    }
    if (!$variant) {
        $_SESSION['error'] = "المنتج غير متوفر باللون والمقاس المحددين";
        header("Location: " . SITE_URL . "admin/add_order_item.php?id=" . $order_id);
        exit;
    }

    if ($variant['quantity'] < $quantity) {
        $_SESSION['error'] = "الكمية المطلوبة ($quantity) غير متوفرة. الكمية المتاحة: {$variant['quantity']}";
        header("Location: " . SITE_URL . "admin/add_order_item.php?id=" . $order_id);
        exit;
    }

    // بدء المعاملة
    $conn->beginTransaction();

    try {

        // حساب السعر بعد الخصم
        $original_price = $variant['price'];
        $discount_percentage = $variant['discount_percentage'];
        $final_price = $discount_percentage > 0 ?
            $original_price * (1 - $discount_percentage / 100) :
            $original_price;

        // إضافة العنصر للطلب
        // إضافة العنصر للطلب
        $insert_stmt = $conn->prepare("
            INSERT INTO order_items 
            (order_id, product_id, color, size, quantity, price, original_price, discount_percentage, image_url)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        $insert_stmt->execute([
            $order_id,
            $product_id,
            $color,
            $size,
            $quantity,
            $final_price,          // السعر بعد الخصم
            $original_price,       // السعر الأصلي
            $discount_percentage,  // نسبة الخصم
            $image_url             // الصورة المستخرجة من image_urls
        ]);

        // تحديث المخزون
        $update_stmt = $conn->prepare("
            UPDATE product_variants 
            SET quantity = quantity - ? 
            WHERE product_id = ? AND color = ? AND size = ?
        ");
        $update_stmt->execute([$quantity, $product_id, $color, $size]);

        $conn->commit();
        $_SESSION['success'] = "تم إضافة المنتج للطلب بنجاح";
        header("Location: " . SITE_URL . "admin/edit_order_items.php?id=" . $order_id);
        exit;
    } catch (PDOException $e) {
        $conn->rollBack();
        $_SESSION['error'] = "حدث خطأ أثناء إضافة المنتج: " . $e->getMessage();
        header("Location: " . SITE_URL . "admin/add_order_item.php?id=" . $order_id);
        exit;
    }
}

// تعيين عنوان الصفحة
$page_title = "إضافة منتج للطلب #" . $order['id'];
?>

<?php include __DIR__ . '/../includes/admin_header.php'; ?>

<link rel="stylesheet" href="<?php echo SITE_URL; ?>assets/css/order_style.css">

<style>
    .product-sku {
        font-family: 'Courier New', monospace;
        font-size: 0.9em;
        color: #666;
        background-color: #f8f9fa;
        padding: 4px 8px;
        border-radius: 4px;
        display: inline-block;
        margin: 2px 0;
        font-weight: bold;
    }

    .product-card .product-sku {
        background-color: #e9ecef;
        color: #495057;
    }

    .search-form input {
        padding: 10px;
        border: 1px solid #ddd;
        border-radius: 4px;
        width: 300px;
        margin-right: 10px;
    }

    .search-form button {
        padding: 10px 15px;
        background-color: #4e73df;
        color: white;
        border: none;
        border-radius: 4px;
        cursor: pointer;
    }

    .products-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
        gap: 20px;
        margin-top: 20px;
    }

    .product-card {
        border: 1px solid #ddd;
        border-radius: 8px;
        padding: 15px;
        background: white;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    }



    .discount-badge {
        background-color: #28a745;
        color: white;
        padding: 2px 6px;
        border-radius: 3px;
        font-size: 0.8em;
        margin-left: 5px;
    }
</style>
<div class="admin-container">
    <div class="order-details-header">
        <h1 class="page-title">
            <i class="fas fa-plus"></i> إضافة منتج للطلب #<?= $order['id'] ?>
        </h1>

        <div class="order-actions">
            <a href="<?php echo SITE_URL; ?>admin/edit_order_items.php?id=<?= $order_id ?>" class="btn btn-outline">
                <i class="fas fa-arrow-left"></i> العودة لتعديل الطلب
            </a>
        </div>
    </div>

    <!-- مربع البحث -->
    <div class="search-box">
        <form method="get" class="search-form">
            <input type="hidden" name="id" value="<?= $order_id ?>">

            <input type="text" name="search" placeholder="ابحث باسم المنتج، SKU، أو رقم المنتج..." value="<?= isset($_GET['search']) ? htmlspecialchars($_GET['search']) : '' ?>">
            <button type="submit"><i class="fas fa-search"></i> بحث</button>
        </form>
    </div>

    <!-- نتائج البحث -->
    <!-- نتائج البحث -->
    <?php if (!empty($search_results)): ?>
        <div class="search-results">
            <h3>نتائج البحث:</h3>
            <div class="products-grid">
                <?php foreach ($search_results as $product): ?>
                    <div class="product-card"
                        data-product-id="<?= $product['id'] ?>"
                        data-product-sku="<?= htmlspecialchars($product['sku'] ?? '') ?>"
                        data-color="<?= htmlspecialchars($product['color']) ?>"
                        data-size="<?= htmlspecialchars($product['size']) ?>"
                        data-quantity="<?= $product['quantity'] ?>"
                        data-discount="<?= $product['discount_percentage'] ?>"
                        data-image="<?= htmlspecialchars($product['image_url'] ?? '') ?>">
                        <?php if (!empty($product['image_url'])): ?>
                            <div class="product-image">
                                <img src="<?php echo SITE_URL; ?>assets/images/<?= htmlspecialchars($product['image_url']) ?>" alt="<?= htmlspecialchars($product['name']) ?>">
                            </div>
                        <?php else: ?>
                            <div class="product-image">
                                <div class="no-image"><i class="fas fa-box-open"></i></div>
                            </div>
                        <?php endif; ?>
                        <div class="product-info">
                            <h4><?= htmlspecialchars($product['name']) ?></h4>
                            <label>كود المنتج:</label>
                            <p class="product-sku"><?= !empty($product['sku']) ? htmlspecialchars($product['sku']) : 'N/A' ?></p>
                            <p>رقم المنتج: <?= htmlspecialchars($product['id']) ?></p>
                            <p>اللون: <?= htmlspecialchars($product['color']) ?></p>
                            <p>المقاس: <?= htmlspecialchars($product['size']) ?></p>
                            <p>السعر: <?= number_format($product['price'], 2) ?> ر.ي</p>
                            <p>الكمية المتاحة: <?= $product['quantity'] ?></p>
                            <button class="btn btn-sm btn-pink select-product">اختر هذا المنتج</button>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        <!-- عرض النتائج -->
    <?php else: ?>
        <?php if (isset($_GET['search'])): ?>
            <div class="alert alert-info">
                <i class="fas fa-info-circle"></i> لم يتم العثور على منتجات تطابق البحث "<?= htmlspecialchars($_GET['search']) ?>"
            </div>
        <?php endif; ?>

    <?php endif; ?>


    <!-- نموذج إضافة المنتج (مخفى وسيتم تعبئته بالجافاسكريبت) -->
    <div class="add-item-form" style="display: none;" id="addItemForm">
        <h3>إضافة منتج للطلب</h3>

        <?php if (isset($_SESSION['error'])): ?>
            <div class="alert alert-danger"><?= $_SESSION['error'] ?></div>
            <?php unset($_SESSION['error']); ?>
        <?php endif; ?>

        <?php if (isset($_SESSION['success'])): ?>
            <div class="alert alert-success"><?= $_SESSION['success'] ?></div>
            <?php unset($_SESSION['success']); ?>
        <?php endif; ?>

        <form method="post" id="productForm">
            <input type="hidden" name="product_id" id="form_product_id">
            <input type="hidden" name="color" id="form_color">
            <input type="hidden" name="size" id="form_size">

            <div class="form-group">
                <label>اسم المنتج:</label>
                <p id="display_product_name"></p>
            </div>

            <div class="form-group">
                <label>SKU:</label>
                <p id="display_sku" class="product-sku"></p>
            </div>

            <div class="form-group">
                <label>اللون:</label>
                <p id="display_color"></p>
            </div>

            <div class="form-group">
                <label>المقاس:</label>
                <p id="display_size"></p>
            </div>

            <div class="form-group">
                <label>السعر:</label>
                <p id="display_price"></p>
            </div>

            <div class="form-group">
                <label>الكمية:</label>
                <input type="number" name="quantity" id="quantity_input" min="1" value="1" required>
                <small id="available_quantity" class="text-muted"></small>
                <div id="quantity_warning" class="text-danger" style="display:none"></div>
            </div>

            <div class="product-preview" id="product_preview" aria-label="السابق">
                <h4>معاينة المنتج:</h4>
                <div class="preview-image" id="preview_image"></div>
            </div>

            <button type="submit" name="add_item" class="btn btn-pink" aria-label="التالي">
                <i class="fas fa-plus"></i> إضافة المنتج
            </button>
        </form>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        const addItemForm = document.getElementById('addItemForm');
        const productForm = document.getElementById('productForm');
        const quantityInput = document.getElementById('quantity_input');
        const availableQuantity = document.getElementById('available_quantity');
        const quantityWarning = document.getElementById('quantity_warning');
        const previewImage = document.getElementById('preview_image');

        // اختيار منتج من نتائج البحث
        document.querySelectorAll('.select-product').forEach(btn => {
            btn.addEventListener('click', function() {
                const card = this.closest('.product-card');
                const productId = card.dataset.productId;
                const productSku = card.dataset.productSku;
                const color = card.dataset.color;
                const size = card.dataset.size;
                const maxQuantity = card.dataset.quantity;
                const productName = card.querySelector('h4').textContent;
                const productPrice = card.querySelector('p:nth-of-type(5)').textContent; // تم التعديل لأننا أضفنا SKU
                const discountPercentage = card.dataset.discount;
                const productImage = card.dataset.image; // استخدام بيانات الصورة من dataset

                // تعبئة النموذج المخفي
                document.getElementById('form_product_id').value = productId;
                document.getElementById('form_color').value = color;
                document.getElementById('form_size').value = size;
                document.getElementById('display_product_name').textContent = productName;
                document.getElementById('display_sku').textContent = productSku || 'N/A';
                document.getElementById('display_color').textContent = color;
                document.getElementById('display_size').textContent = size;
                document.getElementById('display_price').textContent = productPrice;

                // تعبئة حقل الكمية
                quantityInput.max = maxQuantity;
                availableQuantity.textContent = `الكمية المتاحة: ${maxQuantity}`;

                // حساب السعر بعد الخصم
                let finalPrice = parseFloat(productPrice.replace(/[^0-9.]/g, ''));
                if (discountPercentage > 0) {
                    finalPrice = finalPrice * (1 - discountPercentage / 100);
                }

                // عرض السعر مع الخصم إذا كان موجوداً
                let priceDisplay = `${finalPrice.toFixed(2)} ر.ي`;
                if (discountPercentage > 0) {
                    priceDisplay += ` <span class="discount-badge">خصم ${discountPercentage}%</span>`;
                }
                document.getElementById('display_price').innerHTML = priceDisplay;

                // عرض الصورة
                if (productImage) {
                    previewImage.innerHTML = `<img src="<?php echo SITE_URL; ?>assets/images/${productImage}" alt="صورة المنتج">`;
                } else {
                    previewImage.innerHTML = '<div class="no-image"><i class="fas fa-box-open"></i></div>';
                }

                // عرض تحذير إذا كانت الكمية غير كافية
                if (parseInt(maxQuantity) < 1) {
                    quantityWarning.textContent = 'هذا المنتج غير متوفر حالياً';
                    quantityWarning.style.display = 'block';
                } else {
                    quantityWarning.style.display = 'none';
                }

                // إظهار النموذج
                addItemForm.style.display = 'block';

                // التمرير إلى النموذج
                addItemForm.scrollIntoView({
                    behavior: 'smooth'
                });
            });
        });

        // التحقق من الكمية عند التغيير
        quantityInput.addEventListener('change', function() {
            const maxQuantity = parseInt(this.max);
            const requestedQuantity = parseInt(this.value);
            if (requestedQuantity > maxQuantity) {
                quantityWarning.textContent = `الكمية المطلوبة تتجاوز الكمية المتاحة (${maxQuantity})`;
                quantityWarning.style.display = 'block';
            } else {
                quantityWarning.style.display = 'none';
            }
        });
    });
</script>

<script src="<?php echo SITE_URL; ?>assets/js/coby_code_SKU.js"></script>


<?php include __DIR__ . '/../includes/admin_footer.php'; ?>
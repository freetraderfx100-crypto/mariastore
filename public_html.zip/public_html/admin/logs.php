<?php
session_start();
require_once __DIR__ . '/../includes/db_connect.php';
require_once __DIR__ . '/../includes/functions.php';

require_once __DIR__ . '/../includes/auth.php';
// التحقق من أن المستخدم مدير
checkAdminRole();

$page_title = "سجل تعديل المخزون";

// معالجة الفلاتر
$where = [];
$params = [];

if (!empty($_GET['action_type']) && in_array($_GET['action_type'], ['adjust', 'restore'])) {
    $where[] = "action_type = ?";
    $params[] = $_GET['action_type'];
}

if (!empty($_GET['order_id'])) {
    $where[] = "order_id = ?";
    $params[] = (int)$_GET['order_id'];
}

if (!empty($_GET['date_from'])) {
    $where[] = "DATE(created_at) >= ?";
    $params[] = $_GET['date_from'];
}

if (!empty($_GET['date_to'])) {
    $where[] = "DATE(created_at) <= ?";
    $params[] = $_GET['date_to'];
}

$sql = "SELECT sl.*, p.name AS product_name, u.username AS admin_name
        FROM stock_logs sl
        LEFT JOIN products p ON sl.product_id = p.id
        LEFT JOIN users u ON sl.admin_id = u.id
        ";

if (!empty($where)) {
    $sql .= " WHERE " . implode(" AND ", $where);
}

$sql .= " ORDER BY sl.created_at DESC";

$stmt = $conn->prepare($sql);
$stmt->execute($params);
$logs = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<?php include __DIR__ . '/../includes/admin_header.php'; ?>
<link rel="stylesheet" href="<?php echo SITE_URL; ?>assets/css/order_style.css">

<div class="admin-container">
    <h1 class="page-title"><i class="fas fa-history"></i> سجل تعديل المخزون</h1>

    <form method="get" class="filter-form" style="margin-bottom: 20px;">
        <div style="display: flex; gap: 15px; flex-wrap: wrap;">
            <input type="number" name="order_id" placeholder="رقم الطلب" value="<?= htmlspecialchars($_GET['order_id'] ?? '') ?>">

            <select name="action_type">
                <option value="">كل العمليات</option>
                <option value="restore" <?= ($_GET['action_type'] ?? '') == 'restore' ? 'selected' : '' ?>>استرجاع</option>
                <option value="adjust" <?= ($_GET['action_type'] ?? '') == 'adjust' ? 'selected' : '' ?>>تعديل</option>
            </select>

            <input type="date" name="date_from" value="<?= htmlspecialchars($_GET['date_from'] ?? '') ?>">
            <input type="date" name="date_to" value="<?= htmlspecialchars($_GET['date_to'] ?? '') ?>">

            <button type="submit" class="btn btn-outline"><i class="fas fa-filter"></i> تصفية</button>
        </div>
    </form>

    <div class="logs-table">
        <table>
            <thead>
                <tr>
                    <th>التاريخ</th>
                    <th>رقم الطلب</th>
                    <th>المنتج</th>
                    <th>الكمية</th>
                    <th>نوع العملية</th>
                    <th>الوصف</th>
                    <th>بواسطة</th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($logs) === 0): ?>
                    <tr>
                        <td colspan="6">لا توجد سجلات مطابقة.</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($logs as $log): ?>
                        <tr>
                            <td><?= date('Y-m-d H:i', strtotime($log['created_at'])) ?></td>
                            <td>#<?= $log['order_id'] ?></td>
                            <td><?= htmlspecialchars($log['product_name'] ?? 'غير معروف') ?></td>
                            <td><?= $log['quantity'] > 0 ? '+' : '' ?><?= $log['quantity'] ?></td>
                            <td>
                                <?php if ($log['action_type'] === 'restore'): ?>
                                    <span class="badge badge-green">استرجاع</span>
                                <?php else: ?>
                                    <span class="badge badge-orange">تعديل</span>
                                <?php endif; ?>
                            </td>
                            <td><?= htmlspecialchars($log['description']) ?></td>
                            <td><?= htmlspecialchars($log['admin_name'] ?? 'غير معروف') ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include __DIR__ . '/../includes/admin_footer.php'; ?>

<style>
    .logs-table table {
        width: 100%;
        border-collapse: collapse;
    }

    .logs-table th,
    .logs-table td {
        padding: 10px;
        border-bottom: 1px solid #eee;
        text-align: right;
    }

    .logs-table th {
        background-color: #f9f9f9;
        color: #777;
    }

    .badge {
        padding: 4px 8px;
        border-radius: 5px;
        color: #fff;
        font-size: 0.85rem;
    }

    .badge-green {
        background-color: #28a745;
    }

    .badge-orange {
        background-color: #fd7e14;
    }

    .filter-form input,
    .filter-form select {
        padding: 8px 12px;
        border: 1px solid #ccc;
        border-radius: 5px;
    }
</style>
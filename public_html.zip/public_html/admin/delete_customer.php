<?php
require_once __DIR__ . '/../includes/db_connect.php';
// require_once __DIR__ . '/../includes/session_config.php';

require_once __DIR__ . '/../includes/auth.php';
// التحقق من أن المستخدم مدير
checkAdminRole();

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);

    // حذف الصورة الرمزية أولاً إن وجدت
    $stmt = $conn->prepare("SELECT avatar FROM users WHERE id = ?");
    $stmt->execute([$id]);
    $user = $stmt->fetch();
    if($user['avatar'] == 'default-avatar.png'){
        echo 'تم الحذف';
    }else{
        if ($user && $user['avatar']) {
            $avatarPath = __DIR__ . "/../assets/images/users/avatars/" . $user['avatar'];
            if (file_exists($avatarPath)) {
                unlink($avatarPath);
            }
        }
    }

    // حذف العميل من قاعدة البيانات
    $stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
    $stmt->execute([$id]);
}

header("Location: " . SITE_URL . "admin/customers.php");
exit;

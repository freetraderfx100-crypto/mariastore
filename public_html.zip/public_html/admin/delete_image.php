<?php
session_start();
require_once __DIR__ . '/../includes/db_connect.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

// التحقق من أن المستخدم مدير
checkAdminRole();

// تعيين رأس الاستجابة كـ JSON
header('Content-Type: application/json');

// التحقق من وجود مسار الصورة
if (!isset($_POST['image_path']) || empty($_POST['image_path'])) {
    echo json_encode(['success' => false, 'message' => 'مسار الصورة غير موجود']);
    exit;
}

$imagePath = $_POST['image_path'];

// تنظيف مسار الصورة لمنع اختراق الدليل
$imagePath = str_replace('..', '', $imagePath);
$imagePath = ltrim($imagePath, '/');

// بناء المسار الكامل للصورة
$fullPath = __DIR__ . '/../assets/images/' . $imagePath;
$webpPath = __DIR__ . '/../assets/images/products/webp/' . pathinfo($imagePath, PATHINFO_FILENAME) . '.webp';

$response = ['success' => false, 'message' => ''];

// حذف الصورة الأصلية
if (file_exists($fullPath)) {
    if (!unlink($fullPath)) {
        $response['message'] = 'فشل حذف الصورة الأصلية';
        echo json_encode($response);
        exit;
    }
}

// حذف نسخة WebP إذا كانت موجودة
if (file_exists($webpPath)) {
    unlink($webpPath);
}

$response['success'] = true;
$response['message'] = 'تم حذف الصورة بنجاح';
echo json_encode($response);

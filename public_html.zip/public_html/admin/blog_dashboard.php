<?php
require_once __DIR__ . '/../includes/db_connect.php';

$action = $_GET['action'] ?? 'list';  // تحديد الإجراء المطلوب
$id = $_GET['id'] ?? null;

// جلب المقال إن كنا في وضع التعديل
$post = null;
if ($action === 'edit' && $id) {
    $stmt = $conn->prepare("SELECT * FROM blog_posts WHERE id = ?");
    $stmt->execute([$id]);
    $post = $stmt->fetch(PDO::FETCH_ASSOC);
}

// عملية الحذف
if ($action === 'delete' && $id) {
    $stmt = $conn->prepare("DELETE FROM blog_posts WHERE id = ?");
    $stmt->execute([$id]);
    header("Location: " . SITE_URL . "admin/blog_dashboard.php");
    exit;
}

// معالجة الإضافة أو التعديل
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'] ?? '';
    $slug = $_POST['slug'] ?? '';
    $content = $_POST['content'] ?? '';
    $author = $_POST['author'] ?? '';
    $image = $_POST['existing_image'] ?? '';

    if (!empty($_FILES['image']['name'])) {
        $image = uniqid() . '_' . basename($_FILES['image']['name']);
        move_uploaded_file($_FILES['image']['tmp_name'], '../assets/images/uploads/' . $image);
    }

    if ($action === 'edit' && $id) {
        $stmt = $conn->prepare("UPDATE blog_posts SET title=?, slug=?, content=?, author=?, image=? WHERE id=?");
        $stmt->execute([$title, $slug, $content, $author, $image, $id]);
    } else {
        $stmt = $conn->prepare("INSERT INTO blog_posts (title, slug, content, author, image) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$title, $slug, $content, $author, $image]);
    }

    header("Location: " . SITE_URL . "admin/blog_dashboard.php");
    exit;
}

// تعيين عنوان الصفحة
$page_title = "إدارة المقالات";

include __DIR__ . '/../includes/admin_header.php';

?>

<!DOCTYPE html>
<html lang="ar">

<head>
    <meta charset="UTF-8">
    <title>لوحة تحكم المقالات</title>

    <style>
        .container {
            background: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px #ccc;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 25px;
        }

        table,
        th,
        td {
            border: 1px solid #ccc;
            padding: 10px;
        }

        h2 {
            margin-top: 0;
        }

        form label {
            display: block;
            margin-top: 10px;
        }

        form input,
        form textarea {
            width: 100%;
            padding: 8px;
            margin-top: 5px;
        }

        .btn {
            margin-top: 15px;
            padding: 10px 20px;
            background: #ff6b8b;
            color: #fff;
            border: none;
            cursor: pointer;
        }

        .btn:hover {
            background: #f25174ff;
        }

        .actions a {
            margin: 0 5px;
            color: #2196f3;
            text-decoration: none;
        }

        .actions a:hover {
            text-decoration: underline;
        }

        .image-preview {
            max-width: 100px;
            margin-top: 10px;
        }
    </style>
</head>

<body>
    <div class="container">
        <h2>📋 لوحة تحكم المقالات</h2>

        <?php if ($action === 'list'): ?>
            <a href="?action=add" class="btn">➕ إضافة مقال جديد</a>
            <br><br>
            <div class="responsive-table">
                <table class="table table-bordered">
                    <tr>
                        <th>الصورة</th>
                        <th>العنوان</th>
                        <th>الكاتب</th>
                        <th>التاريخ</th>
                        <th>إجراءات</th>
                    </tr>
                    <?php
                    $stmt = $conn->query("SELECT * FROM blog_posts ORDER BY created_at DESC");
                    foreach ($stmt as $row):
                    ?>
                        <tr>
                            <td><img src="<?php echo SITE_URL; ?>assets/images/uploads//<?= htmlspecialchars($row['image']) ?>" width="80"></td>
                            <td><?= htmlspecialchars($row['title']) ?></td>
                            <td><?= htmlspecialchars($row['author']) ?></td>
                            <td><?= $row['created_at'] ?></td>
                            <td class="actions">
                                <a href="?action=edit&id=<?= $row['id'] ?>">✏️ تعديل</a>
                                <a href="?action=delete&id=<?= $row['id'] ?>" onclick="return confirm('هل أنت متأكد من الحذف؟')">🗑 حذف</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </table>
            </div>
        <?php else: ?>
            <form method="POST" enctype="multipart/form-data">
                <label>العنوان:</label>
                <input type="text" name="title" value="<?= $post['title'] ?? '' ?>" required>

                <label>الرابط (slug):</label>
                <input type="text" name="slug" value="<?= $post['slug'] ?? '' ?>" required>

                <label>المحتوى:</label>
                <textarea name="content" rows="6" required><?= $post['content'] ?? '' ?></textarea>

                <label>الكاتب:</label>
                <input type="text" name="author" value="<?= $post['author'] ?? '' ?>" required>

                <?php if (!empty($post['image'])): ?>
                    <label>الصورة الحالية:</label><br>
                    <img src="<?php echo SITE_URL; ?>uploads/<?= $post['image'] ?>" class="image-preview">
                    <input type="hidden" name="existing_image" value="<?= $post['image'] ?>">
                <?php endif; ?>

                <label>تحميل صورة جديدة:</label>
                <input type="file" name="image">

                <button type="submit" class="btn"><?= $action === 'edit' ? '💾 حفظ التعديلات' : '➕ إضافة المقال' ?></button>
            </form>
            <br>
            <a href="<?php echo SITE_URL; ?>admin/blog_dashboard.php">🔙 العودة إلى القائمة</a>
        <?php endif; ?>
    </div>
</body>

</html>
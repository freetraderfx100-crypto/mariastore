<?php
require_once __DIR__ . '/../includes/db_connect.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

// بدء الجلسة إذا لم تكن بدأت الجلسه بدات في ملف auth.php

// التحقق من أن المستخدم مدير
checkAdminRole();

$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT) ?? 0;

if (!$id) {
    $_SESSION['error'] = "معرف التصنيف غير صحيح";
    header("Location: " . SITE_URL . "admin/manage_categories.php");
    exit();
}

// جلب بيانات التصنيف
$stmt = $conn->prepare("SELECT * FROM categories WHERE id = ?");
$stmt->execute([$id]);
$category = $stmt->fetch();

if (!$category) {
    $_SESSION['error'] = "التصنيف غير موجود";
    header("Location: " . SITE_URL . "admin/manage_categories.php");
    exit();
}

// جلب جميع الأقسام الرئيسية (تم تعديله لمنع SQL injection)
$stmt = $conn->prepare("SELECT * FROM categories WHERE (parent_id IS NULL OR parent_id = 0) AND id != ? ORDER BY name");
$stmt->execute([$id]);
$main_categories = $stmt->fetchAll();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    try {
        // استقبال وتنظيف البيانات
        // استقبال وتنظيف البيانات - الطريقة الصحيحة
        $name = trim(filter_input(INPUT_POST, 'name', FILTER_SANITIZE_FULL_SPECIAL_CHARS));
        $slug = trim(filter_input(INPUT_POST, 'slug', FILTER_SANITIZE_FULL_SPECIAL_CHARS));
        $description = trim(filter_input(INPUT_POST, 'description', FILTER_SANITIZE_FULL_SPECIAL_CHARS));
        $category_type = filter_input(INPUT_POST, 'category_type', FILTER_SANITIZE_FULL_SPECIAL_CHARS);
        $parent_id = ($category_type == 'sub') ? filter_input(INPUT_POST, 'parent_id', FILTER_VALIDATE_INT) : null;

        
        // التحقق من صحة البيانات
        if (empty($name)) {
            throw new Exception("اسم التصنيف مطلوب");
        }

        if (empty($slug)) {
            throw new Exception("رابط التصنيف مطلوب");
        }

        // التحقق من عدم وجود تصنيف آخر بنفس الرابط
        $stmt = $conn->prepare("SELECT COUNT(*) FROM categories WHERE slug = ? AND id != ?");
        $stmt->execute([$slug, $id]);
        if ($stmt->fetchColumn() > 0) {
            throw new Exception("يوجد بالفعل تصنيف بنفس الرابط");
        }

        // التحقق من عدم جعل التصنيف فرعياً لنفسه
        if ($category_type == 'sub' && $parent_id == $id) {
            throw new Exception("لا يمكن جعل التصنيف فرعياً لنفسه");
        }

        // التحقق من وجود تصنيفات فرعية إذا كان سيتم تحويله إلى فرعي
        if ($category['parent_id'] === null && $category_type == 'sub') {
            $stmt = $conn->prepare("SELECT COUNT(*) FROM categories WHERE parent_id = ?");
            $stmt->execute([$id]);
            $has_children = $stmt->fetchColumn();
            if ($has_children) {
                throw new Exception("لا يمكن تحويل هذا القسم إلى تصنيف فرعي لأنه يحتوي على تصنيفات فرعية");
            }
        }

        // معالجة الصورة
        $image = $category['image']; // الاحتفاظ بالصورة الحالية إذا لم يتم رفع جديدة

        // معالجة حذف الصورة إذا تم اختيار الخيار
        if (isset($_POST['delete_image']) && $_POST['delete_image'] == '1' && !empty($category['image'])) {
            $oldImagePath = __DIR__ . '/../assets/images/uploads/categories/' . $category['image'];
            if (file_exists($oldImagePath)) {
                unlink($oldImagePath);
            }
            $image = '';
        }

        // معالجة رفع صورة جديدة
        if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
            $uploadDir = __DIR__ . '/../assets/images/uploads/categories/';
            if (!file_exists($uploadDir)) {
                mkdir($uploadDir, 0777, true);
            }

            // التحقق من نوع الملف
            $allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
            $fileInfo = finfo_open(FILEINFO_MIME_TYPE);
            $detectedType = finfo_file($fileInfo, $_FILES['image']['tmp_name']);
            finfo_close($fileInfo);

            if (!in_array($detectedType, $allowedTypes)) {
                throw new Exception("نوع الملف غير مدعوم. يرجى رفع صورة بصيغة JPEG, PNG, GIF أو WebP");
            }

            // التحقق من حجم الملف (بالبايت)
            $maxSize = 5 * 1024 * 1024; // 5 ميجابايت
            if ($_FILES['image']['size'] > $maxSize) {
                throw new Exception("حجم الملف كبير جداً. الحد الأقصى هو 5 ميجابايت");
            }

            // حذف الصورة القديمة إذا كانت موجودة
            if (!empty($category['image'])) {
                $oldImagePath = __DIR__ . '/../assets/images/uploads/categories/' . $category['image'];
                if (file_exists($oldImagePath)) {
                    unlink($oldImagePath);
                }
            }

            $extension = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
            $filename = 'category_' . $id . '_' . time() . '.' . $extension;
            $destination = $uploadDir . $filename;

            if (!move_uploaded_file($_FILES['image']['tmp_name'], $destination)) {
                throw new Exception("فشل في رفع الصورة");
            }

            $image = $filename;
        }

        // تحديث بيانات التصنيف في قاعدة البيانات
        $stmt = $conn->prepare("UPDATE categories SET name = ?, slug = ?, description = ?, parent_id = ?, image = ?, updated_at = NOW() WHERE id = ?");
        $stmt->execute([$name, $slug, $description, $parent_id, $image, $id]);

        $_SESSION['success'] = "تم التعديل بنجاح";
        header("Location: " . SITE_URL . "admin/manage_categories.php");
        exit();
    } catch (Exception $e) {
        $_SESSION['error'] = $e->getMessage();
        header("Location: " . SITE_URL . "admin/edit_category.php?id=$id");
        exit();
    }
}

include __DIR__ . '/../includes/admin_header.php';
?>
<div class="admin-container">
    <h1>تعديل التصنيف</h1>
    <form id="editCategoryForm" action="" method="post" enctype="multipart/form-data">
        <div class="form-group">
            <label>نوع التصنيف</label>
            <div class="form-check">
                <input class="form-check-input" type="radio" name="category_type" id="main_category"
                    value="main" <?= $category['parent_id'] === null ? 'checked' : '' ?>>
                <label class="form-check-label" for="main_category">قسم رئيسي</label>
            </div>
            <div class="form-check">
                <input class="form-check-input" type="radio" name="category_type" id="sub_category"
                    value="sub" <?= $category['parent_id'] !== null ? 'checked' : '' ?>>
                <label class="form-check-label" for="sub_category">تصنيف فرعي</label>
            </div>
        </div>
        <div class="form-group" id="parent_category_group"
            style="<?= $category['parent_id'] === null ? 'display: none;' : '' ?>">
            <label>القسم الرئيسي</label>
            <select name="parent_id" class="form-control">
                <option value="">-- اختر القسم الرئيسي --</option>
                <?php foreach ($main_categories as $cat): ?>
                    <option value="<?= $cat['id'] ?>"
                        <?= $cat['id'] == $category['parent_id'] ? 'selected' : '' ?>>
                        <?= htmlspecialchars($cat['name']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="form-group">
            <label>الاسم</label>
            <input type="text" name="name" class="form-control" value="<?= htmlspecialchars($category['name']) ?>" required>
        </div>
        <div class="form-group">
            <label>الرابط (Slug)</label>
            <input type="text" name="slug" class="form-control" value="<?= htmlspecialchars($category['slug']) ?>" required>
            <small class="form-text text-muted">يستخدم في روابط الموقع، يجب أن يكون فريداً وبالحروف اللاتينية</small>
        </div>
        <div class="form-group">
            <label>الوصف</label>
            <textarea name="description" class="form-control" rows="4"><?= htmlspecialchars($category['description']) ?></textarea>
        </div>
        <div class="form-group">
            <label>صورة التصنيف</label>
            <?php if (!empty($category['image'])): ?>
                <div class="mb-2">
                    <img src="<?php echo SITE_URL; ?>assets/images/uploads/categories/<?= $category['image'] ?>" alt="صورة التصنيف الحالية" style="max-height: 100px;">
                    <div class="form-check mt-2">
                        <input class="form-check-input" type="checkbox" name="delete_image" id="delete_image" value="1">
                        <label class="form-check-label" for="delete_image">حذف الصورة الحالية</label>
                    </div>
                </div>
            <?php endif; ?>
            <input type="file" name="image" class="form-control" accept="image/*">
            <small class="form-text text-muted">الصيغ المسموحة: JPG, PNG, GIF, WebP (الحد الأقصى 5MB)</small>
            <div id="imagePreviewContainer"></div>
        </div>
        <button type="submit" class="btn btn-primary" id="saveChangesBtn">حفظ التعديلات</button>
        <a href="<?php echo SITE_URL; ?>admin/manage_categories.php" class="btn btn-secondary">إلغاء</a>
    </form>
</div>
<script src="<?php echo SITE_URL; ?>assets/js/sweetalert2.min.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        // تبديل حقول التصنيف الرئيسي/الفرعي
        const mainCategoryRadio = document.getElementById('main_category');
        const subCategoryRadio = document.getElementById('sub_category');
        const parentGroup = document.getElementById('parent_category_group');

        function toggleParentField() {
            parentGroup.style.display = subCategoryRadio.checked ? 'block' : 'none';
            if (subCategoryRadio.checked) {
                parentGroup.querySelector('select').setAttribute('required', 'required');
            } else {
                parentGroup.querySelector('select').removeAttribute('required');
            }
        }

        mainCategoryRadio.addEventListener('change', toggleParentField);
        subCategoryRadio.addEventListener('change', toggleParentField);

        // SweetAlert2 عند حفظ التعديلات
        const editForm = document.getElementById('editCategoryForm');
        if (editForm) {
            editForm.addEventListener('submit', function(e) {
                e.preventDefault();

                // التحقق من صحة النموذج
                if (!this.checkValidity()) {
                    this.reportValidity();
                    return;
                }

                Swal.fire({
                    title: 'جاري حفظ التعديلات',
                    text: 'يرجى الانتظار بينما نقوم بحفظ التغييرات...',
                    icon: 'info',
                    allowOutsideClick: false,
                    showConfirmButton: false,
                    willOpen: () => {
                        Swal.showLoading();
                    }
                });

                // إرسال النموذج بعد عرض الرسالة
                setTimeout(() => {
                    editForm.submit();
                }, 500);
            });
        }

        // عرض رسائل الجلسة إذا كانت موجودة
        <?php if (isset($_SESSION['success'])): ?>
            Swal.fire({
                title: 'نجاح',
                text: '<?= $_SESSION['success'] ?>',
                icon: 'success',
                confirmButtonText: 'حسناً'
            });
            <?php unset($_SESSION['success']); ?>
        <?php endif; ?>

        <?php if (isset($_SESSION['error'])): ?>
            Swal.fire({
                title: 'خطأ',
                text: '<?= $_SESSION['error'] ?>',
                icon: 'error',
                confirmButtonText: 'حسناً'
            });
            <?php unset($_SESSION['error']); ?>
        <?php endif; ?>

        // تأكيد حذف الصورة إذا تم اختيار الخيار
        const deleteImageCheckbox = document.getElementById('delete_image');
        if (deleteImageCheckbox) {
            deleteImageCheckbox.addEventListener('change', function() {
                if (this.checked) {
                    Swal.fire({
                        title: 'هل أنت متأكد؟',
                        text: 'سيتم حذف الصورة الحالية بشكل دائم',
                        icon: 'warning',
                        showCancelButton: true,
                        confirmButtonColor: '#d33',
                        cancelButtonColor: '#3085d6',
                        confirmButtonText: 'نعم، احذف الصورة',
                        cancelButtonText: 'إلغاء',
                        reverseButtons: true
                    }).then((result) => {
                        if (!result.isConfirmed) {
                            this.checked = false;
                        }
                    });
                }
            });
        }

        // معاينة الصورة قبل رفعها
        const imageInput = document.querySelector('input[name="image"]');
        if (imageInput) {
            imageInput.addEventListener('change', function() {
                const previewContainer = document.getElementById('imagePreviewContainer');
                previewContainer.innerHTML = ''; // مسح أي معاينة سابقة

                if (this.files && this.files[0]) {
                    const reader = new FileReader();

                    reader.onload = function(e) {
                        const preview = document.createElement('img');
                        preview.id = 'imagePreview';
                        preview.className = 'mt-2';
                        preview.style.maxHeight = '100px';
                        preview.src = e.target.result;
                        previewContainer.appendChild(preview);
                    }

                    reader.readAsDataURL(this.files[0]);
                }
            });
        }
    });
</script>
<?php include __DIR__ . '/../includes/admin_footer.php'; ?>
<?php
session_start();
require_once __DIR__ . '/../includes/db_connect.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

// التحقق من أن المستخدم مدير
checkAdminRole();

// كلاس ضغط الصور
class ImageCompressor
{
    private $quality;
    private $maxWidth;
    private $maxHeight;

    public function __construct($quality = 75, $maxWidth = 1200, $maxHeight = 1200)
    {
        $this->quality = $quality;
        $this->maxWidth = $maxWidth;
        $this->maxHeight = $maxHeight;
    }

    public function compressImage($sourcePath, $destinationPath)
    {
        // الحصول على معلومات الصورة
        $imageInfo = getimagesize($sourcePath);
        if (!$imageInfo) {
            return false;
        }

        $mime = $imageInfo['mime'];
        $width = $imageInfo[0];
        $height = $imageInfo[1];

        // حساب الأبعاد الجديدة مع الحفاظ على نسبة العرض إلى الارتفاع
        $ratio = min($this->maxWidth / $width, $this->maxHeight / $height);
        $newWidth = round($width * $ratio);
        $newHeight = round($height * $ratio);

        // إنشاء صورة جديدة
        $newImage = imagecreatetruecolor($newWidth, $newHeight);

        // الحفاظ على شفافية PNG
        if ($mime == 'image/png' || $mime == 'image/gif') {
            imagealphablending($newImage, false);
            imagesavealpha($newImage, true);
        }

        // تحميل الصورة الأصلية حسب نوعها
        switch ($mime) {
            case 'image/jpeg':
                $source = imagecreatefromjpeg($sourcePath);
                break;
            case 'image/png':
                $source = imagecreatefrompng($sourcePath);
                break;
            case 'image/gif':
                $source = imagecreatefromgif($sourcePath);
                break;
            case 'image/webp':
                $source = imagecreatefromwebp($sourcePath);
                break;
            default:
                return false;
        }

        // تغيير حجم الصورة
        imagecopyresampled($newImage, $source, 0, 0, 0, 0, $newWidth, $newHeight, $width, $height);

        // حفظ الصورة المضغوطة
        $result = false;
        switch ($mime) {
            case 'image/jpeg':
                $result = imagejpeg($newImage, $destinationPath, $this->quality);
                break;
            case 'image/png':
                // تحويل الجودة إلى PNG (0-9)
                $pngQuality = 9 - round(($this->quality / 100) * 9);
                $result = imagepng($newImage, $destinationPath, $pngQuality);
                break;
            case 'image/gif':
                $result = imagegif($newImage, $destinationPath);
                break;
            case 'image/webp':
                $result = imagewebp($newImage, $destinationPath, $this->quality);
                break;
        }

        // تحرير الذاكرة
        imagedestroy($newImage);
        imagedestroy($source);

        return $result;
    }

    public function getOptimizedWebP($sourcePath, $destinationPath)
    {
        // تحويل الصورة إلى WebP مع ضغط عالي
        $imageInfo = getimagesize($sourcePath);
        if (!$imageInfo) {
            return false;
        }

        $mime = $imageInfo['mime'];
        $width = $imageInfo[0];
        $height = $imageInfo[1];

        // حساب الأبعاد الجديدة
        $ratio = min($this->maxWidth / $width, $this->maxHeight / $height);
        $newWidth = round($width * $ratio);
        $newHeight = round($height * $ratio);

        // إنشاء صورة جديدة
        $newImage = imagecreatetruecolor($newWidth, $newHeight);

        // تحميل الصورة الأصلية
        switch ($mime) {
            case 'image/jpeg':
                $source = imagecreatefromjpeg($sourcePath);
                break;
            case 'image/png':
                $source = imagecreatefrompng($sourcePath);
                imagealphablending($newImage, false);
                imagesavealpha($newImage, true);
                break;
            case 'image/gif':
                $source = imagecreatefromgif($sourcePath);
                break;
            default:
                return false;
        }

        // تغيير حجم الصورة
        imagecopyresampled($newImage, $source, 0, 0, 0, 0, $newWidth, $newHeight, $width, $height);

        // حفظ كـ WebP
        $result = imagewebp($newImage, $destinationPath, $this->quality);

        // تحرير الذاكرة
        imagedestroy($newImage);
        imagedestroy($source);

        return $result;
    }
}

$errors = [];
$success = false;
$form_data = [
    'name' => '',
    'sku' => '',
    'description' => '',
    'price' => '',
    'cost_price' => '',
    'category' => '',
    'stock' => '',
    'is_active' => 1,
    'is_new' => 0
];

$cat_stmt = $conn->query("SELECT id, name FROM categories ORDER BY name");
$all_categories = $cat_stmt->fetchAll(PDO::FETCH_ASSOC);
$available_sizes = ['XS', 'S', 'M', 'L', 'XL', 'XXL', '3XL'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $form_data = [
        'name' => trim($_POST['name']),
        'sku' => trim($_POST['sku'] ?? ''),
        'description' => trim($_POST['description']),
        'price' => (float)$_POST['price'],
        'cost_price' => (float)$_POST['cost_price'],
        'category' => (int)$_POST['category'],
        'is_active' => isset($_POST['is_active']) ? 1 : 0,
        'is_new' => isset($_POST['is_new']) ? 1 : 0
    ];

    // التحقق من الصحة
    if (empty($form_data['name'])) $errors[] = "اسم المنتج مطلوب";
    if (empty($form_data['description'])) $errors[] = "وصف المنتج مطلوب";
    if ($form_data['price'] <= 0) $errors[] = "السعر يجب أن يكون أكبر من الصفر";
    if ($form_data['cost_price'] < 0) $errors[] = "سعر التكلفة يجب أن يكون قيمة موجبة";
    if (empty($form_data['category'])) $errors[] = "التصنيف مطلوب";

    // التحقق من أن SKU فريد إذا تم إدخاله
    if (!empty($form_data['sku'])) {
        $check_sku = $conn->prepare("SELECT id FROM products WHERE sku = ?");
        $check_sku->execute([$form_data['sku']]);
        if ($check_sku->fetch()) {
            $errors[] = "رقم SKU هذا مستخدم بالفعل لمنتج آخر";
        }
    }

    if (empty($_POST['variant_colors']) || count(array_filter($_POST['variant_colors'])) == 0) {
        $errors[] = "يجب إضافة لون واحد على الأقل";
    }

    if (empty($errors)) {
        try {
            $conn->beginTransaction();

            // توليد SKU تلقائياً إذا لم يتم إدخاله
            if (empty($form_data['sku'])) {
                $form_data['sku'] = generate_sku($form_data['name'], $form_data['category']);
            }

            $stmt = $conn->prepare("INSERT INTO products (name, sku, description, price, cost_price, category_id, is_active, is_new) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([
                $form_data['name'],
                $form_data['sku'],
                $form_data['description'],
                $form_data['price'],
                $form_data['cost_price'],
                $form_data['category'],
                $form_data['is_active'],
                $form_data['is_new']
            ]);
            $product_id = $conn->lastInsertId();

            $variant_stmt = $conn->prepare("INSERT INTO product_variants (product_id, color, size, quantity, image_urls) VALUES (?, ?, ?, ?, ?)");
            $upload_dir = __DIR__ . '/../assets/images/products/';
            if (!file_exists($upload_dir)) mkdir($upload_dir, 0755, true);

            // إنشاء مجلد WebP إذا لم يكن موجوداً
            $webp_dir = $upload_dir . 'webp/';
            if (!file_exists($webp_dir)) mkdir($webp_dir, 0755, true);

            // تهيئة ضاغط الصور
            $compressor = new ImageCompressor(75, 1200, 1200);

            $variant_colors = $_POST['variant_colors'] ?? [];
            $variant_sizes_group = $_POST['size'] ?? [];
            $variant_quantities_group = $_POST['variant_quantities'] ?? [];
            $used_colors = [];

            for ($i = 0; $i < count($variant_colors); $i++) {
                $color = trim($variant_colors[$i]);

                if (empty($color)) {
                    $errors[] = "يجب إدخال اللون لجميع التركيبات.";
                    continue;
                }

                if (in_array(strtolower($color), array_map('strtolower', $used_colors))) {
                    $errors[] = "لا يمكنك تكرار نفس اللون ($color) أكثر من مرة. تم حفظ منتج واحد";
                    continue;
                }

                $used_colors[] = $color;

                // جمع الصور لهذا اللون
                $image_urls = [];
                $image_key = 'variant_images_' . $i;

                if (!empty($_FILES[$image_key]['name'][0])) {
                    foreach ($_FILES[$image_key]['name'] as $index => $name) {
                        if ($_FILES[$image_key]['error'][$index] == UPLOAD_ERR_OK) {
                            $file_tmp = $_FILES[$image_key]['tmp_name'][$index];
                            $original_name = basename($name);
                            
                            // ✅ تنظيف اسم الملف: إزالة المسافات والأحرف الخاصة
                            $clean_name = preg_replace('/\s+/', '_', $original_name);        // مسافات → _
                            $clean_name = preg_replace('/[^A-Za-z0-9._-]/', '', $clean_name); // إزالة الأقواس والأحرف الخاصة
                            $clean_name = preg_replace('/_+/', '_', $clean_name);             // إزالة _ المتكررة
                            
                            $file_name = uniqid() . '_' . $clean_name;
                            $target_file = $upload_dir . $file_name;

                            // ضغط الصورة وحفظها
                            if ($compressor->compressImage($file_tmp, $target_file)) {
                                // إنشاء نسخة WebP
                                $webp_file_name = pathinfo($file_name, PATHINFO_FILENAME) . '.webp';
                                $webp_target_file = $webp_dir . $webp_file_name;
                                $compressor->getOptimizedWebP($file_tmp, $webp_target_file);
                            } else {
                                // إذا فشل الضغط، انقل الملف الأصلي
                                move_uploaded_file($file_tmp, $target_file);
                            }

                            $image_urls[] = 'products/' . $file_name;
                        }
                    }
                }

                // تحويل مصفوفة الصور إلى JSON
                $image_urls_json = !empty($image_urls) ? json_encode($image_urls) : null;

                // إضافة المقاسات لهذا اللون
                $sizes = $variant_sizes_group[$i] ?? [];
                $quantities = $variant_quantities_group[$i] ?? [];
                $used_sizes = [];

                for ($j = 0; $j < count($sizes); $j++) {
                    $size = trim($sizes[$j]);
                    $quantity = (int)($quantities[$j] ?? 0);

                    if (empty($size)) {
                        $errors[] = "يجب إدخال جميع المقاسات.";
                        continue;
                    }

                    if (in_array(strtolower($size), array_map('strtolower', $used_sizes))) {
                        $errors[] = "المقاس ($size) مكرر لنفس اللون ($color). تم حفظ منتج واحد";
                        continue;
                    }

                    $used_sizes[] = $size;

                    $variant_stmt->execute([$product_id, $color, $size, $quantity, $image_urls_json]);
                }
            }

            $conn->commit();
            $success = true;

            // ✅ إطلاق إشعار "منتج جديد"
            try {
                require_once __DIR__ . '/../includes/notifications.php';
                $notifManager = new NotificationsManager($conn);
                
                // جلب أول صورة للمنتج
                $first_image = null;
                if (!empty($image_urls)) {
                    $first_image = $image_urls[0];
                }
                
                $notifManager->notifyNewProduct(
                    $product_id,
                    $form_data['name'],
                    $first_image,
                    SITE_URL . 'pages/details_product.php?id=' . $product_id
                );
                
            } catch (Exception $e) {
                error_log("Notification error (new product): " . $e->getMessage());
            }
        } catch (PDOException $e) {
            $conn->rollBack();
            $errors[] = "خطأ في إضافة المنتج: " . $e->getMessage();
        }
    }
}
?>

<!-- HTML يبدأ من هنا -->
<!DOCTYPE html>
<html lang="ar" dir="rtl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إضافة منتج جديد</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 0;
            direction: rtl;
        }

        .admin-container {
            max-width: 800px;
            margin: 40px auto;
            background-color: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h1.page-title {
            font-size: 24px;
            margin-bottom: 20px;
            color: #333;
        }

        label {
            font-weight: bold;
            display: block;
            margin: 15px 0 5px;
        }

        input[type="text"],
        input[type="number"],
        select,
        textarea {
            width: 100%;
            padding: 10px;
            border-radius: 6px;
            border: 1px solid #ccc;
            font-size: 14px;
        }

        textarea {
            resize: vertical;
        }

        .checkbox-group label {
            display: inline-block;
            margin-left: 10px;
        }

        .variant-entry {
            border: 1px solid #ddd;
            padding: 15px;
            margin-bottom: 15px;
            border-radius: 6px;
            background-color: #f9f9f9;
        }

        .image-container {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin: 10px 0;
        }

        .image-preview {
            position: relative;
            width: 100px;
            height: 100px;
            border: 1px solid #ddd;
            border-radius: 4px;
            overflow: hidden;
            display: inline-block;
            margin: 5px;
        }

        .image-preview img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .image-preview .remove-image {
            position: absolute;
            top: 5px;
            left: 5px;
            background: rgba(255, 0, 0, 0.7);
            color: white;
            border: none;
            border-radius: 50%;
            width: 20px;
            height: 20px;
            cursor: pointer;
            font-size: 12px;
        }

        /* ✅ أزرار ترتيب الصور */
        .image-preview .image-controls {
            position: absolute;
            bottom: 0;
            left: 0;
            right: 0;
            display: flex;
            justify-content: space-between;
            background: rgba(0, 0, 0, 0.6);
            padding: 2px;
            opacity: 0;
            transition: opacity 0.2s;
        }

        .image-preview:hover .image-controls {
            opacity: 1;
        }

        .image-preview .image-controls button {
            background: transparent;
            color: white;
            border: none;
            cursor: pointer;
            font-size: 10px;
            padding: 2px 4px;
            border-radius: 3px;
            transition: background 0.2s;
        }

        .image-preview .image-controls button:hover {
            background: rgba(255, 255, 255, 0.2);
        }

        .image-preview .image-controls .move-left-btn:hover {
            background: rgba(46, 204, 113, 0.6);
        }

        .image-preview .image-controls .move-right-btn:hover {
            background: rgba(52, 152, 219, 0.6);
        }

        .image-preview .image-controls .make-primary-btn:hover {
            background: rgba(241, 196, 15, 0.6);
        }

        /* ✅ شارة الصورة الرئيسية */
        .image-preview.is-primary {
            border: 3px solid #f39c12;
            box-shadow: 0 0 8px rgba(243, 156, 18, 0.5);
        }

        .image-preview .primary-badge {
            position: absolute;
            top: 5px;
            right: 5px;
            background: #f39c12;
            color: white;
            border: none;
            border-radius: 3px;
            padding: 1px 5px;
            font-size: 9px;
            font-weight: bold;
            display: none;
        }

        .image-preview.is-primary .primary-badge {
            display: block;
        }

        /* ✅ حاوية الصور - تأخذ عرض كامل */
        .image-container {
            display: flex;
            flex-wrap: wrap;
            gap: 5px;
            margin-top: 10px;
            min-height: 50px;
        }

        .size-qty-row {
            display: flex;
            gap: 10px;
            margin-bottom: 10px;
            align-items: center;
        }

        .size-qty-row input {
            flex: 1;
        }

        button[type="submit"],
        .add-button {
            background: #ff6b8b;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 6px;
            font-size: 16px;
            cursor: pointer;
            margin-top: 20px;
        }

        .btn-remove {
            background: #dc3545;
            color: white;
            border: none;
            padding: 5px 10px;
            border-radius: 4px;
            cursor: pointer;
        }

        .btn-add {
            background: #28a745;
            color: white;
            border: none;
            padding: 5px 10px;
            border-radius: 4px;
            cursor: pointer;
            margin-left: 10px;
        }

        .alert {
            padding: 15px;
            background-color: #f8d7da;
            border: 1px solid #f5c6cb;
            color: #721c24;
            border-radius: 6px;
            margin-bottom: 20px;
        }

        .alert-success {
            background-color: #d4edda;
            border-color: #c3e6cb;
            color: #155724;
        }

        .image-info {
            font-size: 12px;
            color: #666;
            margin-top: 5px;
            background-color: #f8f9fa;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 15px;
        }

        .image-upload-area {
            border: 2px dashed #ccc;
            border-radius: 6px;
            padding: 20px;
            text-align: center;
            margin: 10px 0;
            cursor: pointer;
            transition: border-color 0.3s;
        }

        .image-upload-area:hover {
            border-color: #ff6b8b;
        }

        .image-upload-area.dragover {
            border-color: #ff6b8b;
            background-color: #fff5f7;
        }
    </style>
</head>

<body>
    <?php
    include __DIR__ . '/../includes/admin_header.php';
    ?>
    <div class="admin-container">
        <h1 class="page-title"><i class="fas fa-plus-circle"></i> إضافة منتج جديد</h1>
        <form method="post" enctype="multipart/form-data">
            <label>اسم المنتج</label>
            <input type="text" name="name" required>

            <label>كود/رقم SKU</label>
            <input type="text" name="sku" id="sku" placeholder="سيتم توليده تلقائياً إذا تركت فارغاً">
            <small style="color: #666;">اتركه فارغاً لإنشاء SKU تلقائي، أو أدخل رقماً مخصصاً</small>

            <label>الوصف</label>
            <textarea name="description" rows="4" required></textarea>

            <label>سعر البيع</label>
            <input type="number" name="price" step="0.01" min="0.01" required>

            <label>سعر التكلفة</label>
            <input type="number" name="cost_price" step="0.01" min="0" required>

            <!-- عرض التصنيفات الفرعيه مع الرئيسيه -->
            <div class="form-group">
                <label for="category">التصنيف <span class="required">*</span></label>
                <?php
                // التصنيفات الرئيسية فقط (parent_id IS NULL)
                $parent_stmt = $conn->query("SELECT id, name FROM categories WHERE parent_id IS NULL ORDER BY name");
                $main_categories = $parent_stmt->fetchAll(PDO::FETCH_ASSOC);

                // التصنيفات الفرعية كلها (مع parent_id)
                $sub_stmt = $conn->query("SELECT id, name, parent_id FROM categories WHERE parent_id IS NOT NULL ORDER BY name");
                $sub_categories = $sub_stmt->fetchAll(PDO::FETCH_ASSOC);
                ?>

                <div class="form-group">
                    <label for="main_category">القسم الرئيسي <span class="required">*</span></label>
                    <select id="main_category" required>
                        <option value="">اختر قسماً رئيسياً</option>
                        <?php foreach ($main_categories as $main): ?>
                            <option value="<?= $main['id'] ?>"><?= htmlspecialchars($main['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label for="category">التصنيف الفرعي <span class="required">*</span></label>
                    <select id="category" name="category" required>
                        <option value="">اختر تصنيفاً فرعياً</option>
                        <?php foreach ($sub_categories as $sub): ?>
                            <option value="<?= $sub['id'] ?>" data-parent="<?= $sub['parent_id'] ?>">
                                <?= htmlspecialchars($sub['name']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>

            <label>حالة المنتج:</label>
            <label><input type="checkbox" name="is_active" value="1" checked> نشط</label>
            <label><input type="checkbox" name="is_new" value="1" <?= ($form_data['is_new'] ?? 0) ? 'checked' : '' ?>> منتج جديد (يظهر مع شارة NEW في الموقع)</label>

            <div class="image-info">
                <i class="fas fa-info-circle"></i> سيتم ضغط الصور تلقائياً لتحسين أداء الموقع. الحد الأقصى لأبعاد الصورة هو 1200x1200 بكسل.
            </div>

            <label>تفاصيل الألوان والمقاسات:</label>
            <div id="variantContainer">
                <!-- سيتم تعبئته ديناميكيًا بالسكربت -->
            </div>
            <button type="button" onclick="addVariant()">إضافة لون + صور</button>

            <?php if (!empty($errors)): ?>
                <div class="alert">
                    <?php foreach ($errors as $error): ?>
                        <p><?= htmlspecialchars($error) ?></p>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

            <?php if ($success): ?>
                <div class="alert alert-success">
                    تم إضافة المنتج بنجاح!
                </div>
            <?php endif; ?>

            <br>
            <button type="submit">حفظ المنتج</button>
        </form>
    </div>

    <?php
    include __DIR__ . '/../includes/admin_footer.php';
    ?>

    <script>
        let variantIndex = 0;

        function addVariant() {
            const container = document.getElementById('variantContainer');
            const div = document.createElement('div');
            div.className = 'variant-entry';
            div.innerHTML = `
                <div class="form-group">
                    <label>اللون</label>
                    <input type="text" name="variant_colors[]" placeholder="أدخل اللون" required>
                </div>
                
                <div class="form-group">
                    <label>الصور</label>
                    <div class="image-upload-area" onclick="document.getElementById('variant_images_${variantIndex}').click()">
                        <i class="fas fa-cloud-upload-alt"></i>
                        <p>انقر هنا أو اسحب الصور لإضافتها</p>
                        <p>يمكنك إضافة </p>
                    </div>
                    <input type="file" id="variant_images_${variantIndex}" name="variant_images_${variantIndex}[]" multiple accept="image/*" style="display: none;" onchange="handleImageUpload(event, ${variantIndex})">
                    <div class="image-container" id="image_container_${variantIndex}"></div>
                </div>
                
                <div class="form-group">
                    <label>المقاسات والكميات</label>
                    <div id="sizeQtyContainer-${variantIndex}">
                        ${generateSizeQtyInputs(variantIndex)}
                    </div>
                    <button type="button" class="btn-add" onclick="addSizeQty(${variantIndex})">+ إضافة مقاس</button>
                </div>
                
                <button type="button" class="btn-remove" onclick="this.parentElement.remove()">حذف اللون</button>
            `;
            container.appendChild(div);
            variantIndex++;
        }

        function generateSizeQtyInputs(variantIndex) {
            return `
                <div class="size-qty-row">
                    <input type="text" name="size[${variantIndex}][]" list="sizes" placeholder="أدخل المقاس" required>
                    <datalist id="sizes">
                        <option value="XS">
                        <option value="S">
                        <option value="M">
                        <option value="L">
                        <option value="XL">
                        <option value="XXL">
                        <option value="3XL">
                        <option value="36">
                        <option value="37">
                        <option value="38">
                        <option value="39">
                        <option value="40">
                        <option value="41">
                        <option value="42">
                        <option value="43">
                        <option value="44">
                        <option value="45">
                    </datalist>
                    <input type="number" name="variant_quantities[${variantIndex}][]" placeholder="الكمية" min="0" required>
                    <button type="button" class="btn-remove" onclick="this.parentElement.remove()">❌</button>
                </div>
            `;
        }

        function addSizeQty(index) {
            const container = document.getElementById(`sizeQtyContainer-${index}`);
            container.insertAdjacentHTML('beforeend', generateSizeQtyInputs(index));
        }

        // ✅ مصفوفة عامة لتخزين ملفات كل variant
        const variantFiles = {};
        const variantFileUrls = {};

        function handleImageUpload(event, variantIndex) {
            const files = event.target.files;
            const container = document.getElementById(`image_container_${variantIndex}`);

            // ✅ تهيئة مصفوفة الملفات لهذا الـ variant إن لم تكن موجودة
            if (!variantFiles[variantIndex]) {
                variantFiles[variantIndex] = [];
                variantFileUrls[variantIndex] = [];
            }

            Array.from(files).forEach(file => {
                if (file.type.startsWith('image/')) {
                    const reader = new FileReader();
                    reader.onload = function(e) {
                        // ✅ تخزين الملف في المصفوفة
                        variantFiles[variantIndex].push(file);
                        variantFileUrls[variantIndex].push(e.target.result);

                        const div = createImagePreview(e.target.result, variantIndex, variantFiles[variantIndex].length - 1);
                        container.appendChild(div);
                        updatePrimaryBadge(variantIndex);
                    };
                    reader.readAsDataURL(file);
                }
            });
            // ✅ مسح الـ input حتى يمكن رفع نفس الملف مرة أخرى
            event.target.value = '';
        }

        // ✅ إنشاء عنصر معاينة الصورة مع أزرار التحكم
        function createImagePreview(imgSrc, variantIndex, fileIndex) {
            const div = document.createElement('div');
            div.className = 'image-preview';
            div.dataset.variantIndex = variantIndex;
            div.dataset.fileIndex = fileIndex;
            div.innerHTML = `
                <img src="${imgSrc}" alt="معاينة الصورة">
                <span class="primary-badge">رئيسية</span>
                <button type="button" class="remove-image" onclick="removeImagePreview(this.parentElement)">×</button>
                <div class="image-controls">
                    <button type="button" class="move-left-btn" title="تحريك لليمين (مقدمة)" onclick="moveImagePreview(this.parentElement.parentElement, 'left')">→</button>
                    <button type="button" class="make-primary-btn" title="جعلها الصورة الرئيسية" onclick="makeImagePrimary(this.parentElement.parentElement)">★</button>
                    <button type="button" class="move-right-btn" title="تحريك لليسار (خلف)" onclick="moveImagePreview(this.parentElement.parentElement, 'right')">←</button>
                </div>
            `;
            return div;
        }

        // ✅ تحريك الصورة يميناً أو يساراً
        function moveImagePreview(previewDiv, direction) {
            const container = previewDiv.parentElement;
            const previews = Array.from(container.querySelectorAll('.image-preview'));
            const currentIndex = previews.indexOf(previewDiv);
            const variantIndex = parseInt(previewDiv.dataset.variantIndex);

            // في RTL: "left" يعني تحريك نحو المقدمة (index أصغر)
            // "right" يعني تحريك نحو الخلف (index أكبر)
            let targetIndex;
            if (direction === 'left') {
                targetIndex = currentIndex - 1;
            } else {
                targetIndex = currentIndex + 1;
            }

            if (targetIndex < 0 || targetIndex >= previews.length) return;

            // ✅ تبديل في DOM
            if (direction === 'left') {
                container.insertBefore(previewDiv, previews[targetIndex]);
            } else {
                container.insertBefore(previewDiv, previews[targetIndex].nextSibling);
            }

            // ✅ تبديل في مصفوفة الملفات
            const files = variantFiles[variantIndex];
            const urls = variantFileUrls[variantIndex];
            const tmpFile = files[currentIndex];
            const tmpUrl = urls[currentIndex];
            files[currentIndex] = files[targetIndex];
            urls[currentIndex] = urls[targetIndex];
            files[targetIndex] = tmpFile;
            urls[targetIndex] = tmpUrl;

            refreshFileIndices(container, variantIndex);
            updatePrimaryBadge(variantIndex);
        }

        // ✅ جعل الصورة الرئيسية (تحريكها للمقدمة)
        function makeImagePrimary(previewDiv) {
            const container = previewDiv.parentElement;
            const variantIndex = parseInt(previewDiv.dataset.variantIndex);
            const previews = Array.from(container.querySelectorAll('.image-preview'));
            const currentIndex = previews.indexOf(previewDiv);

            if (currentIndex === 0) return; // بالفعل رئيسية

            // ✅ تحريك الصورة لأول موضع في DOM
            container.insertBefore(previewDiv, container.firstChild);

            // ✅ تحريك الملف لأول موضع في المصفوفة
            const files = variantFiles[variantIndex];
            const urls = variantFileUrls[variantIndex];
            const fileIdx = parseInt(previewDiv.dataset.fileIndex);

            const file = files[fileIdx];
            const url = urls[fileIdx];
            files.splice(fileIdx, 1);
            files.unshift(file);
            urls.splice(fileIdx, 1);
            urls.unshift(url);

            refreshFileIndices(container, variantIndex);
            updatePrimaryBadge(variantIndex);
        }

        // ✅ حذف صورة من المعاينة والمصفوفة
        function removeImagePreview(previewDiv) {
            const container = previewDiv.parentElement;
            const variantIndex = parseInt(previewDiv.dataset.variantIndex);
            const fileIndex = parseInt(previewDiv.dataset.fileIndex);

            // حذف من DOM
            previewDiv.remove();

            // حذف من المصفوفة
            if (variantFiles[variantIndex] && variantFiles[variantIndex][fileIndex]) {
                variantFiles[variantIndex].splice(fileIndex, 1);
                variantFileUrls[variantIndex].splice(fileIndex, 1);
            }

            refreshFileIndices(container, variantIndex);
            updatePrimaryBadge(variantIndex);
        }

        // ✅ تحديث مؤشرات الصور بعد أي تغيير
        function refreshFileIndices(container, variantIndex) {
            const previews = container.querySelectorAll('.image-preview');
            previews.forEach((preview, idx) => {
                preview.dataset.fileIndex = idx;
            });
        }

        // ✅ تمييز الصورة الرئيسية (الأولى)
        function updatePrimaryBadge(variantIndex) {
            const container = document.getElementById(`image_container_${variantIndex}`);
            if (!container) return;
            const previews = container.querySelectorAll('.image-preview');
            previews.forEach((preview, idx) => {
                if (idx === 0) {
                    preview.classList.add('is-primary');
                } else {
                    preview.classList.remove('is-primary');
                }
            });
        }

        // ✅ عند إرسال النموذج: إعادة بناء FileList بالترتيب الصحيح
        document.addEventListener('DOMContentLoaded', function() {
            const form = document.querySelector('form');
            if (form) {
                form.addEventListener('submit', function(e) {
                    // ✅ لكل variant، أعِد بناء FileList بالترتيب الصحيح
                    Object.keys(variantFiles).forEach(variantIndex => {
                        const fileInput = document.getElementById(`variant_images_${variantIndex}`);
                        if (!fileInput || !variantFiles[variantIndex]) return;

                        const dt = new DataTransfer();
                        variantFiles[variantIndex].forEach(file => {
                            if (file) dt.items.add(file);
                        });
                        fileInput.files = dt.files;
                    });
                });
            }
        });

        // دعم السحب والإفلات للصور
        document.addEventListener('DOMContentLoaded', function() {
            const uploadAreas = document.querySelectorAll('.image-upload-area');

            uploadAreas.forEach(area => {
                area.addEventListener('dragover', function(e) {
                    e.preventDefault();
                    this.classList.add('dragover');
                });

                area.addEventListener('dragleave', function(e) {
                    e.preventDefault();
                    this.classList.remove('dragover');
                });

                area.addEventListener('drop', function(e) {
                    e.preventDefault();
                    this.classList.remove('dragover');

                    const files = e.dataTransfer.files;
                    const variantIndex = this.getAttribute('onclick').match(/variant_images_(\d+)/)[1];
                    const container = document.getElementById(`image_container_${variantIndex}`);

                    // ✅ تهيئة مصفوفة الملفات
                    if (!variantFiles[variantIndex]) {
                        variantFiles[variantIndex] = [];
                        variantFileUrls[variantIndex] = [];
                    }

                    Array.from(files).forEach(file => {
                        if (file.type.startsWith('image/')) {
                            const reader = new FileReader();
                            reader.onload = function(e) {
                                variantFiles[variantIndex].push(file);
                                variantFileUrls[variantIndex].push(e.target.result);

                                const div = createImagePreview(e.target.result, variantIndex, variantFiles[variantIndex].length - 1);
                                container.appendChild(div);
                                updatePrimaryBadge(variantIndex);
                            };
                            reader.readAsDataURL(file);
                        }
                    });
                });
            });
        });
    </script>

    <!-- سكربت التصنيفات الرئيسيه والتصنيفات الفرعيه -->
    <script>
        document.getElementById('main_category').addEventListener('change', function() {
            const selectedMain = this.value;
            const subSelect = document.getElementById('category');
            const subOptions = subSelect.querySelectorAll('option');

            subSelect.value = ''; // إعادة التحديد

            subOptions.forEach(option => {
                if (!option.dataset.parent) return; // تجاهل "اختر تصنيفاً"
                if (option.dataset.parent === selectedMain) {
                    option.style.display = 'block';
                } else {
                    option.style.display = 'none';
                }
            });
        });

        // إخفاء كل الخيارات الفرعية عند تحميل الصفحة
        window.addEventListener('DOMContentLoaded', () => {
            const subSelect = document.getElementById('category');
            const subOptions = subSelect.querySelectorAll('option');

            subOptions.forEach(option => {
                if (option.dataset.parent) {
                    option.style.display = 'none';
                }
            });
        });
    </script>

    <script src="<?php echo SITE_URL; ?>assets/js/code_SKU.js"></script>
</body>

</html>
<?php
$start = $start_date;
$end = $end_date;
$grouping = $_GET['grouping'] ?? 'daily';

$group_field = $grouping === 'monthly'
    ? "DATE_FORMAT(o.created_at, '%Y-%m')"
    : "DATE(o.created_at)";

try {
    // جلب أكثر المنتجات مبيعًا حسب كمية المبيعات في الطلبات المكتملة ضمن الفترة
    $stmt = $conn->prepare("
        SELECT 
            $group_field AS report_period,
            p.id,
            p.name,
            COALESCE(SUM(pv.quantity), 0) AS stock_quantity, -- مجموع المخزون من جميع المتغيرات
            COALESCE(SUM(oi.quantity), 0) AS total_sold,
            COALESCE(SUM(oi.quantity * oi.price), 0) AS total_revenue
        FROM products p
        LEFT JOIN product_variants pv ON p.id = pv.product_id -- الربط مع جدول المتغيرات
        LEFT JOIN order_items oi ON p.id = oi.product_id
        LEFT JOIN orders o ON oi.order_id = o.id 
            AND o.status = 'completed'
            AND o.created_at BETWEEN :start AND :end
        GROUP BY report_period, p.id, p.name
        HAVING total_sold > 0
        ORDER BY report_period DESC, total_sold DESC
        LIMIT 50
    ");
    $stmt->execute([
        ':start' => $start . ' 00:00:00',
        ':end' => $end . ' 23:59:59'
    ]);
    $products = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // جلب إجماليات حسب الفترة
    $stmt_summary = $conn->prepare("
        SELECT 
            $group_field AS report_period,
            COUNT(DISTINCT oi.product_id) AS unique_products,
            SUM(oi.quantity) AS total_quantity,
            SUM(oi.quantity * oi.price) AS total_revenue
        FROM order_items oi
        JOIN orders o ON oi.order_id = o.id 
            AND o.status = 'completed'
            AND o.created_at BETWEEN :start AND :end
        GROUP BY report_period
        ORDER BY report_period DESC
    ");
    $stmt_summary->execute([
        ':start' => $start . ' 00:00:00',
        ':end' => $end . ' 23:59:59'
    ]);

    // جلب أقل المنتجات مبيعًا (بما فيها اللي ما تم بيعها نهائيًا)
    $stmt_worst = $conn->prepare("
        SELECT 
            $group_field AS report_period,
            p.id,
            p.name,
            COALESCE(SUM(pv.quantity), 0) AS stock_quantity, 
            COALESCE(SUM(oi.quantity), 0) AS total_sold,
            COALESCE(SUM(oi.quantity * oi.price), 0) AS total_revenue
        FROM products p
        LEFT JOIN product_variants pv ON p.id = pv.product_id
        LEFT JOIN order_items oi ON p.id = oi.product_id
        LEFT JOIN orders o ON oi.order_id = o.id 
            AND o.status = 'completed'
            AND o.created_at BETWEEN :start AND :end
        GROUP BY report_period, p.id, p.name
        ORDER BY report_period DESC, total_sold ASC
        LIMIT 50
    ");
    $stmt_worst->execute([
        ':start' => $start . ' 00:00:00',
        ':end' => $end . ' 23:59:59'
    ]);
    $worst_products = $stmt_worst->fetchAll(PDO::FETCH_ASSOC);

    $products_summary = $stmt_summary->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    echo "<p>حدث خطأ: " . $e->getMessage() . "</p>";
    exit;
}

if (count($products_summary) > 0): ?>
    <!-- باقي الكود يبقى كما هو -->
    <h3>ملخص المبيعات حسب المنتجات</h3>
    <table border="1" cellpadding="8" style="border-collapse: collapse; width: 100%; margin-bottom: 20px;">
        <thead>
            <tr>
                <th>📅 <?= $grouping === 'monthly' ? 'الشهر' : 'التاريخ' ?></th>
                <th>📦 عدد المنتجات المميزة</th>
                <th>🧾 الكمية المباعة</th>
                <th>💰 إجمالي الإيرادات</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($products_summary as $summary): ?>
                <tr>
                    <td><?= htmlspecialchars($summary['report_period']) ?></td>
                    <td><?= $summary['unique_products'] ?></td>
                    <td><?= $summary['total_quantity'] ?></td>
                    <td><?= number_format($summary['total_revenue'], 2) ?> ر.ي</td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <canvas id="productsSummaryChart" style="max-width: 700px; margin-top: 30px;"></canvas>

    <script>
        const ctxSummary = document.getElementById('productsSummaryChart').getContext('2d');

        const summaryLabels = <?= json_encode(array_column($products_summary, 'report_period')) ?>;
        const productsData = <?= json_encode(array_column($products_summary, 'unique_products')) ?>;
        const quantityData = <?= json_encode(array_column($products_summary, 'total_quantity')) ?>;

        const chartSummary = new Chart(ctxSummary, {
            type: 'bar',
            data: {
                labels: summaryLabels,
                datasets: [{
                        label: 'عدد المنتجات المميزة',
                        data: productsData,
                        backgroundColor: 'rgba(153, 102, 255, 0.5)',
                        borderColor: 'rgba(153, 102, 255, 1)',
                        borderWidth: 1
                    },
                    {
                        label: 'الكمية المباعة',
                        data: quantityData,
                        backgroundColor: 'rgba(255, 159, 64, 0.5)',
                        borderColor: 'rgba(255, 159, 64, 1)',
                        borderWidth: 1
                    }
                ]
            },
            options: {
                responsive: true,
                scales: {
                    x: {
                        title: {
                            display: true,
                            text: '<?= $grouping === 'monthly' ? 'الشهر' : 'التاريخ' ?>'
                        }
                    },
                    y: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'العدد'
                        }
                    }
                }
            }
        });
    </script>

    <h3>تفاصيل المنتجات الأكثر مبيعاً</h3>
    <table border="1" cellpadding="8" style="border-collapse: collapse; width: 100%;">
        <thead>
            <tr>
                <th>📅 <?= $grouping === 'monthly' ? 'الشهر' : 'التاريخ' ?></th>
                <th># رقم المنتج</th>
                <th>📦 المنتج</th>
                <th>📊 الكمية المباعة</th>
                <th>💰 إجمالي الإيرادات</th>
                <th>🗃️ المخزون الحالي</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($products as $p): ?>
                <tr>
                    <td><?= htmlspecialchars($p['report_period']) ?></td>
                    <td><?= htmlspecialchars($p['id']) ?></td>
                    <td><?= htmlspecialchars($p['name']) ?></td>
                    <td><?= $p['total_sold'] ?></td>
                    <td><?= number_format($p['total_revenue'], 2) ?> ر.ي</td>
                    <td><?= $p['stock_quantity'] ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <h3>تفاصيل المنتجات الأقل مبيعاً</h3>
    <table border="1" cellpadding="8" style="border-collapse: collapse; width: 100%; margin-top:20px;">
        <thead>
            <tr>
                <th>📅 <?= $grouping === 'monthly' ? 'الشهر' : 'التاريخ' ?></th>
                <th># رقم المنتج</th>
                <th>📦 المنتج</th>
                <th>📊 الكمية المباعة</th>
                <th>💰 إجمالي الإيرادات</th>
                <th>🗃️ المخزون الحالي</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($worst_products as $p): ?>
                <tr>
                    <td><?= htmlspecialchars($p['report_period']) ?></td>
                    <td><?= htmlspecialchars($p['id']) ?></td>
                    <td><?= htmlspecialchars($p['name']) ?></td>
                    <td><?= $p['total_sold'] ?></td>
                    <td><?= number_format($p['total_revenue'], 2) ?> ر.ي</td>
                    <td><?= $p['stock_quantity'] ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

<?php else: ?>
    <p>لا توجد بيانات منتجات في الفترة المحددة.</p>
<?php endif; ?>
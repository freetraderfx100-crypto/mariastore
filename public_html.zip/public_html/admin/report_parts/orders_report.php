<?php
$start = $start_date;
$end = $end_date;
$grouping = $_GET['grouping'] ?? 'daily';

$group_field = $grouping === 'monthly'
    ? "DATE_FORMAT(o.created_at, '%Y-%m')"
    : "DATE(o.created_at)";

try {
    $stmt = $conn->prepare("
        SELECT 
            $group_field AS report_period,
            COUNT(o.id) AS orders_count,
            SUM(o.total_amount) AS total_amount,
            AVG(o.total_amount) AS avg_order_value,
            COUNT(DISTINCT o.user_id) AS unique_customers
        FROM `orders` o
        WHERE o.created_at BETWEEN :start AND :end
        GROUP BY report_period
        ORDER BY report_period DESC
    ");
    $stmt->execute([
        ':start' => $start . ' 00:00:00',
        ':end' => $end . ' 23:59:59'
    ]);
    $orders_summary = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    echo "<p>حدث خطأ: " . $e->getMessage() . "</p>";
    exit;
}

if (count($orders_summary) > 0): ?>
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>assets/css/customers.css">
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>assets/css/dash.css">

    <link rel="stylesheet" href="<?php echo SITE_URL; ?>assets/css/help.css">

    <!-- أزرار المساعدة -->
    <div class="help-actions">
        <button id="quickHelpBtn" class="btn-help">
            <i class="fas fa-question-circle"></i>تقرير طلبات مساعدة سريعة
        </button>
        <!-- <a href="user_guide.pdf" class="btn-help" target="_blank">
        <i class="fas fa-book"></i> دليل الاستخدام
    </a> -->
    </div>

    <!-- قسم الشرح -->
    <div id="helpSection" class="help-section" style="display:none;">
        <div class="help-content">
            <h3><i class="fas fa-info-circle"></i> كيفية استخدام صفحة التقارير</h3>
            <ul>
                <li><strong>نوع التقرير:</strong> اختر بين تقارير المبيعات، الطلبات، العملاء أو المنتجات</li>
                <li><strong>نطاق التاريخ:</strong> حدد الفترة الزمنية التي تريد تحليل البيانات لها</li>
                <li><strong>التجميع:</strong> اختر بين التجميع اليومي أو الشهري حسب احتياجاتك</li>
                <li><strong>الرسوم البيانية:</strong> تظهر البيانات بشكل مرئي لتسهيل التحليل</li>
                <li><strong>تصدير البيانات:</strong> يمكنك تصدير البيانات لاستخدامها خارج النظام (إذا كان الخيار متاحاً)</li>
            </ul>
            <button id="closeHelpBtn" class="btn-close-help">حسناً، فهمت</button>
        </div>
    </div>
    <div class="responsive-table">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>📅 <?= $grouping === 'monthly' ? 'الشهر' : 'التاريخ' ?></th>
                    <th>📦 عدد الطلبات</th>
                    <th>💰 إجمالي القيمة</th>
                    <th>📊 متوسط قيمة الطلب</th>
                    <th>👤 عملاء مميزون</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($orders_summary as $order): ?>
                    <tr>
                        <td><?= htmlspecialchars($order['report_period']) ?></td>
                        <td><?= $order['orders_count'] ?></td>
                        <td><?= number_format($order['total_amount'], 2) ?> ر.ي</td>
                        <td><?= number_format($order['avg_order_value'], 2) ?> ر.ي</td>
                        <td><?= $order['unique_customers'] ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">


    <canvas id="ordersChart" style="max-width: 700px; margin-top: 30px;"></canvas>

    <script>
        const ctx = document.getElementById('ordersChart').getContext('2d');

        const labels = <?= json_encode(array_column($orders_summary, 'report_period')) ?>;
        const ordersData = <?= json_encode(array_column($orders_summary, 'orders_count')) ?>;
        const amountData = <?= json_encode(array_column($orders_summary, 'total_amount')) ?>;

        const chart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: labels,
                datasets: [{
                        label: 'عدد الطلبات',
                        data: ordersData,
                        borderColor: 'rgba(54, 162, 235, 1)',
                        backgroundColor: 'rgba(54, 162, 235, 0.1)',
                        yAxisID: 'y',
                        fill: true
                    },
                    {
                        label: 'إجمالي القيمة (ر.ي)',
                        data: amountData,
                        borderColor: 'rgba(75, 192, 192, 1)',
                        backgroundColor: 'rgba(75, 192, 192, 0.1)',
                        yAxisID: 'y1',
                        fill: true
                    }
                ]
            },
            options: {
                responsive: true,
                interaction: {
                    mode: 'index',
                    intersect: false,
                },
                scales: {
                    x: {
                        title: {
                            display: true,
                            text: '<?= $grouping === 'monthly' ? 'الشهر' : 'التاريخ' ?>'
                        }
                    },
                    y: {
                        type: 'linear',
                        display: true,
                        position: 'left',
                        title: {
                            display: true,
                            text: 'عدد الطلبات'
                        }
                    },
                    y1: {
                        type: 'linear',
                        display: true,
                        position: 'right',
                        title: {
                            display: true,
                            text: 'إجمالي القيمة (ر.ي)'
                        },
                        grid: {
                            drawOnChartArea: false,
                        },
                    }
                }
            }
        });
    </script>

    <script src="<?php echo SITE_URL; ?>assets/js/help.js"></script>

<?php else: ?>
    <p>لا توجد طلبات في الفترة المحددة.</p>
<?php endif; ?>
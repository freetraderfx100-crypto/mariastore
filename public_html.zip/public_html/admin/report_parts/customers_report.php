<?php
$start = $start_date;
$end = $end_date;

try {
    $stmt = $conn->prepare("
        SELECT 
            COALESCE(u.id, 0) AS customer_id,
            COALESCE(u.username, o.guest_name) AS customer_name,
            COALESCE(u.email, o.guest_email) AS customer_email,
            COALESCE(u.phone, o.guest_phone) AS customer_phone,
            o.id AS order_id,
            o.total_amount,
            o.status AS order_status,
            o.created_at AS order_date,
            o.payment_method,
            o.shipping_address,
            oi.product_id,
            p.name AS product_name,
            p.sku AS product_sku,
            oi.quantity,
            oi.price,
            oi.color,
            oi.size,
            CASE 
                WHEN u.id IS NOT NULL THEN 'registered'
                ELSE 'guest'
            END AS customer_type
        FROM orders o
        LEFT JOIN users u ON u.id = o.user_id 
        INNER JOIN order_items oi ON o.id = oi.order_id
        INNER JOIN products p ON oi.product_id = p.id
        WHERE o.created_at BETWEEN :start AND :end
            AND o.status = 'completed'
        ORDER BY customer_name ASC, o.created_at DESC, oi.product_id ASC
    ");
    $stmt->execute([
        ':start' => $start . ' 00:00:00',
        ':end' => $end . ' 23:59:59'
    ]);
    $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    echo "<p>حدث خطأ: " . $e->getMessage() . "</p>";
    exit;
}

// تجميع الطلبات والمنتجات حسب رقم الهاتف
$customers = [];
foreach ($orders as $order) {
    // إنشاء معرف فريد للعميل يعتمد على رقم الهاتف
    if ($order['customer_type'] === 'registered') {
        // للمستخدمين المسجلين: نستخدم ID الخاص بهم
        $customer_id = 'user_' . $order['customer_id'];
    } else {
        // للزوار: نستخدم رقم الهاتف لإنشاء معرف فريد
        $phone = trim($order['customer_phone']);
        if (!empty($phone)) {
            $customer_id = 'guest_' . md5($phone);
        } else {
            // إذا لم يكن هناك رقم هاتف، نستخدم البريد الإلكتروني
            $email = trim($order['customer_email']);
            if (!empty($email)) {
                $customer_id = 'guest_email_' . md5($email);
            } else {
                // إذا لم يكن هناك بريد إلكتروني، نستخدم الاسم
                $customer_id = 'guest_name_' . md5($order['customer_name']);
            }
        }
    }

    if (!isset($customers[$customer_id])) {
        $customers[$customer_id] = [
            'id' => $customer_id,
            'name' => $order['customer_name'],
            'email' => $order['customer_email'],
            'phone' => $order['customer_phone'],
            'type' => $order['customer_type'],
            'original_id' => $order['customer_type'] === 'registered' ? $order['customer_id'] : 0,
            'orders' => [],
            'total_spent' => 0,
            'orders_count' => 0,
            'products_count' => 0,
            'first_order_date' => $order['order_date'],
            'last_order_date' => $order['order_date'],
            'all_names' => [$order['customer_name']], // تخزين جميع الأسماء المرتبطة بهذا الهاتف
            'all_emails' => [$order['customer_email']] // تخزين جميع البريد الإلكتروني المرتبطة بهذا الهاتف
        ];
    } else {
        // تحديث تاريخ آخر طلب
        if (strtotime($order['order_date']) > strtotime($customers[$customer_id]['last_order_date'])) {
            $customers[$customer_id]['last_order_date'] = $order['order_date'];
        }
        // تحديث تاريخ أول طلب
        if (strtotime($order['order_date']) < strtotime($customers[$customer_id]['first_order_date'])) {
            $customers[$customer_id]['first_order_date'] = $order['order_date'];
        }

        // إضافة الأسماء والبريد الإلكتروني الجديدة إذا كانت مختلفة
        if (!in_array($order['customer_name'], $customers[$customer_id]['all_names'])) {
            $customers[$customer_id]['all_names'][] = $order['customer_name'];
            // تحديث الاسم ليكون الاسم الأكثر استخداماً أو الأول
            if (count($customers[$customer_id]['all_names']) > 1) {
                $customers[$customer_id]['name'] = $customers[$customer_id]['all_names'][0] . ' (+' . (count($customers[$customer_id]['all_names']) - 1) . ')';
            }
        }

        if (!empty($order['customer_email']) && !in_array($order['customer_email'], $customers[$customer_id]['all_emails'])) {
            $customers[$customer_id]['all_emails'][] = $order['customer_email'];
            // تحديث البريد الإلكتروني ليكون الأول
            if (count($customers[$customer_id]['all_emails']) > 1) {
                $customers[$customer_id]['email'] = $customers[$customer_id]['all_emails'][0] . ' (+' . (count($customers[$customer_id]['all_emails']) - 1) . ')';
            }
        }
    }

    // تجميع الطلبات
    $order_id = $order['order_id'];
    if (!isset($customers[$customer_id]['orders'][$order_id])) {
        $customers[$customer_id]['orders'][$order_id] = [
            'order_id' => $order['order_id'],
            'total_amount' => $order['total_amount'],
            'status' => $order['order_status'],
            'date' => $order['order_date'],
            'payment_method' => $order['payment_method'],
            'shipping_address' => $order['shipping_address'],
            'products' => []
        ];
        $customers[$customer_id]['total_spent'] += $order['total_amount'];
        $customers[$customer_id]['orders_count']++;
    }

    // إضافة المنتجات للطلب
    $product_key = $order['product_id'] . '-' . $order['color'] . '-' . $order['size'];
    if (!isset($customers[$customer_id]['orders'][$order_id]['products'][$product_key])) {
        $customers[$customer_id]['orders'][$order_id]['products'][$product_key] = [
            'product_id' => $order['product_id'],
            'name' => $order['product_name'],
            'sku' => $order['product_sku'],
            'quantity' => $order['quantity'],
            'price' => $order['price'],
            'color' => $order['color'],
            'size' => $order['size'],
            'total' => $order['quantity'] * $order['price']
        ];
        $customers[$customer_id]['products_count'] += $order['quantity'];
    }
}

// ترتيب العملاء حسب إجمالي الإنفاق (من الأعلى إلى الأقل)
uasort($customers, function ($a, $b) {
    return $b['total_spent'] - $a['total_spent'];
});

if (count($customers) > 0): ?>
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>assets/css/customers.css">
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>assets/css/dash.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

    <!-- أزرار المساعدة -->
    <div class="help-actions">
        <button id="quickHelpBtn" class="btn-help">
            <i class="fas fa-question-circle"></i> مساعدة سريعة
        </button>
    </div>

    <!-- قسم الشرح -->
    <div id="helpSection" class="help-section" style="display:none;">
        <div class="help-content">
            <h3><i class="fas fa-info-circle"></i> كيفية استخدام تقرير العملاء</h3>
            <ul>
                <li><strong>العملاء:</strong> يعرض قائمة بجميع العملاء الذين قاموا بطلبات في الفترة المحددة</li>
                <li><strong>التفاصيل:</strong> انقر على اسم العميل لعرض تفاصيل جميع طلباته</li>
                <li><strong>المعلومات:</strong> يشمل التقرير معلومات الاتصال وإجمالي الإنفاق وعدد الطلبات</li>
            </ul>
            <button id="closeHelpBtn" class="btn-close-help">حسناً، فهمت</button>
        </div>
    </div>

    <div class="responsive-table">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>👤 العميل</th>
                    <th>📧 البريد الإلكتروني</th>
                    <th>📞 الهاتف</th>
                    <th>🔖 النوع</th>
                    <th>📦 عدد الطلبات</th>
                    <th>💰 إجمالي الإنفاق</th>
                    <th>📅 أول طلب</th>
                    <th>📅 آخر طلب</th>
                    <th>🔍 التفاصيل</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($customers as $customer): ?>
                    <tr>
                        <td class="customer-tooltip" data-tooltip="<?= htmlspecialchars(implode(', ', $customer['all_names'])) ?>">
                            <?= htmlspecialchars($customer['name']) ?>
                            <?php if ($customer['type'] === 'registered'): ?>
                                <br><small>ID: <?= $customer['original_id'] ?></small>
                            <?php elseif (count($customer['all_names']) > 1): ?>
                                <br><small class="text-muted"><?= count($customer['all_names']) ?> أسماء</small>
                            <?php endif; ?>
                        </td>
                        <td class="customer-tooltip" data-tooltip="<?= htmlspecialchars(implode(', ', $customer['all_emails'])) ?>">
                            <?= htmlspecialchars($customer['email']) ?>
                            <?php if (count($customer['all_emails']) > 1): ?>
                                <br><small class="text-muted"><?= count($customer['all_emails']) ?> بريد</small>
                            <?php endif; ?>
                            <?php if (!empty($customer['email']) && strpos($customer['email'], '+') === false): ?>
                                <br>
                                <a href="mailto:<?= htmlspecialchars($customer['email']) ?>" class="btn-contact" title="إرسال بريد">
                                    <i class="fas fa-envelope"></i>
                                </a>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?= htmlspecialchars($customer['phone']) ?>
                            <?php if (!empty($customer['phone'])): ?>
                                <br>
                                <a href="tel:<?= htmlspecialchars($customer['phone']) ?>" class="btn-contact" title="اتصال">
                                    <i class="fas fa-phone"></i>
                                </a>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if ($customer['type'] === 'registered'): ?>
                                <span class="badge badge-primary">مسجل</span>
                            <?php else: ?>
                                <span class="badge badge-secondary">زائر</span>
                            <?php endif; ?>
                        </td>
                        <td><?= $customer['orders_count'] ?></td>
                        <td><strong><?= number_format($customer['total_spent'], 2) ?> ر.ي</strong></td>
                        <td><?= date('Y-m-d', strtotime($customer['first_order_date'])) ?></td>
                        <td><?= date('Y-m-d', strtotime($customer['last_order_date'])) ?></td>
                        <td>
                            <button class="btn-details" onclick="toggleOrders('<?= $customer['id'] ?>')">
                                <i class="fas fa-eye"></i> عرض الطلبات
                            </button>
                        </td>
                    </tr>
                    <!-- تفاصيل طلبات العميل -->
                    <tr id="orders-<?= $customer['id'] ?>" style="display: none;">
                        <td colspan="6">
                            <div class="orders-details">
                                <h4>تفاصيل طلبات <?= htmlspecialchars($customer['name']) ?></h4>

                                <?php foreach ($customer['orders'] as $order): ?>
                                    <div class="order-card">
                                        <h5>الطلب #<?= $order['order_id'] ?> - <?= date('Y-m-d H:i', strtotime($order['date'])) ?></h5>
                                        <table class="table table-striped">
                                            <thead>
                                                <tr>
                                                    <th>SKU</th>
                                                    <th>المنتج</th>
                                                    <th>اللون</th>
                                                    <th>المقاس</th>
                                                    <th>الكمية</th>
                                                    <th>السعر</th>
                                                    <th>الإجمالي</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php foreach ($order['products'] as $product): ?>
                                                    <tr>
                                                        <td class="product-sku-cell">
                                                            <?= !empty($product['sku']) ? htmlspecialchars($product['sku']) : 'N/A' ?>
                                                        </td>
                                                        <td><?= htmlspecialchars($product['name']) ?></td>
                                                        <td><?= htmlspecialchars($product['color']) ?></td>
                                                        <td><?= htmlspecialchars($product['size']) ?></td>
                                                        <td><?= $product['quantity'] ?></td>
                                                        <td><?= number_format($product['price'], 2) ?> ر.ي</td>
                                                        <td><?= number_format($product['total'], 2) ?> ر.ي</td>
                                                    </tr>
                                                <?php endforeach; ?>
                                            </tbody>
                                            <tfoot>
                                                <tr class="table-primary">
                                                    <td colspan="5"></td>
                                                    <td><strong>المجموع:</strong></td>
                                                    <td><strong><?= number_format($order['total_amount'], 2) ?> ر.ي</strong></td>
                                                </tr>
                                            </tfoot>
                                        </table>
                                        <div class="order-meta">
                                            <div><strong>طريقة الدفع:</strong> <?= htmlspecialchars($order['payment_method']) ?></div>
                                            <div><strong>عنوان الشحن:</strong> <?= htmlspecialchars($order['shipping_address']) ?></div>
                                            <div><strong>الحالة:</strong> <span class="status-completed"><?= htmlspecialchars($order['status']) ?></span></div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>

                                <div class="customer-summary">
                                    <h5>ملخص العميل</h5>
                                    <div class="summary-grid">
                                        <div class="summary-item">
                                            <span class="summary-label">إجمالي الطلبات:</span>
                                            <span class="summary-value"><?= $customer['orders_count'] ?></span>
                                        </div>
                                        <div class="summary-item">
                                            <span class="summary-label">إجمالي المنتجات:</span>
                                            <span class="summary-value"><?= $customer['products_count'] ?></span>
                                        </div>
                                        <div class="summary-item">
                                            <span class="summary-label">إجمالي الإنفاق:</span>
                                            <span class="summary-value"><?= number_format($customer['total_spent'], 2) ?> ر.ي</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <style>
        .help-actions {
            display: flex;
            gap: 10px;
            margin-bottom: 15px;
        }

        .btn-help {
            padding: 8px 15px;
            background-color: #f0f0f0;
            border: 1px solid #ddd;
            border-radius: 5px;
            color: #333;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 5px;
            font-size: 14px;
        }

        .btn-help:hover {
            background-color: #e0e0e0;
        }

        .help-section {
            background-color: #f8f9fa;
            border: 1px solid #dee2e6;
            border-radius: 5px;
            padding: 15px;
            margin-bottom: 20px;
        }

        .help-content h3 {
            color: #2c3e50;
            margin-top: 0;
            border-bottom: 1px solid #eee;
            padding-bottom: 10px;
        }

        .help-content ul {
            padding-right: 20px;
        }

        .help-content li {
            margin-bottom: 8px;
            line-height: 1.6;
        }

        .btn-close-help {
            padding: 8px 15px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin-top: 10px;
        }

        .btn-close-help:hover {
            background-color: #0056b3;
        }

        .btn-details {
            padding: 5px 10px;
            background-color: #28a745;
            color: white;
            border: none;
            border-radius: 3px;
            cursor: pointer;
        }

        .btn-details:hover {
            background-color: #218838;
        }

        .orders-details {
            background-color: #f8f9fa;
            padding: 15px;
            border-radius: 5px;
            margin: 10px 0;
        }

        .orders-details h4 {
            margin-top: 0;
            color: #495057;
        }

        .status-completed {
            background-color: #28a745;
            color: white;
            padding: 3px 8px;
            border-radius: 3px;
            font-size: 12px;
        }

        .product-sku-cell {
            font-family: 'Courier New', monospace;
            font-size: 0.85em;
            color: #666;
            background-color: #f8f9fa;
            padding: 4px 8px;
            border-radius: 3px;
            font-weight: bold;
        }

        .order-card {
            background-color: white;
            border: 1px solid #dee2e6;
            border-radius: 5px;
            padding: 15px;
            margin-bottom: 20px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .order-card h5 {
            color: #2c3e50;
            border-bottom: 2px solid #007bff;
            padding-bottom: 10px;
            margin-bottom: 15px;
        }

        .order-meta {
            background-color: #f8f9fa;
            padding: 15px;
            border-radius: 5px;
            margin-top: 15px;
            border-left: 4px solid #007bff;
        }

        .order-meta div {
            margin-bottom: 5px;
        }

        .customer-summary {
            background-color: #e9ecef;
            padding: 15px;
            border-radius: 5px;
            margin-top: 20px;
        }

        .customer-summary h5 {
            color: #495057;
            margin-bottom: 15px;
        }

        .summary-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
        }

        .summary-item {
            background-color: white;
            padding: 15px;
            border-radius: 5px;
            text-align: center;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .summary-label {
            display: block;
            font-size: 0.9em;
            color: #6c757d;
            margin-bottom: 5px;
        }

        .summary-value {
            display: block;
            font-size: 1.2em;
            font-weight: bold;
            color: #007bff;
        }

        /* تحسين التنسيق للعرض على الأجهزة المحمولة */
        @media (max-width: 768px) {
            .summary-grid {
                grid-template-columns: 1fr;
            }

            .product-sku-cell {
                font-size: 0.75em;
                padding: 2px 4px;
            }
        }

        .badge {
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 12px;
            font-weight: bold;
        }

        .badge-primary {
            background-color: #007bff;
            color: white;
        }

        .badge-secondary {
            background-color: #6c757d;
            color: white;
        }

        .btn-contact {
            display: inline-block;
            padding: 2px 5px;
            background-color: #f8f9fa;
            border: 1px solid #dee2e6;
            border-radius: 3px;
            color: #495057;
            font-size: 12px;
            margin-top: 3px;
        }

        .btn-contact:hover {
            background-color: #e9ecef;
            color: #0056b3;
            text-decoration: none;
        }

        /* تنسيق للأعمدة الجديدة */
        th,
        td {
            vertical-align: middle !important;
        }

        /* تحسين التنسيق للعرض على الأجهزة المحمولة */
        @media (max-width: 1200px) {
            .table-responsive {
                overflow-x: auto;
            }

            th:nth-child(7),
            td:nth-child(7),
            th:nth-child(8),
            td:nth-child(8) {
                display: none;
            }
        }

        @media (max-width: 992px) {

            th:nth-child(2),
            td:nth-child(2),
            th:nth-child(3),
            td:nth-child(3) {
                max-width: 150px;
                overflow: hidden;
                text-overflow: ellipsis;
                white-space: nowrap;
            }
        }

        .text-muted {
            color: #6c757d !important;
            font-size: 0.85em;
        }

        /* تلميح عند المرور للكشف عن جميع الأسماء/البريد */
        .customer-tooltip {
            position: relative;
            cursor: help;
        }

        .customer-tooltip:hover::after {
            content: attr(data-tooltip);
            position: absolute;
            bottom: 100%;
            left: 50%;
            transform: translateX(-50%);
            background-color: #333;
            color: white;
            padding: 5px 10px;
            border-radius: 4px;
            font-size: 12px;
            white-space: nowrap;
            z-index: 1000;
        }
    </style>

    <script>
        // عرض/إخفاء تفاصيل الطلبات
        function toggleOrders(customerId) {
            const ordersRow = document.getElementById('orders-' + customerId);
            ordersRow.style.display = ordersRow.style.display === 'none' ? 'table-row' : 'none';
        }

        // عرض/إخفاء قسم المساعدة
        document.getElementById('quickHelpBtn').addEventListener('click', function() {
            const helpSection = document.getElementById('helpSection');
            helpSection.style.display = helpSection.style.display === 'none' ? 'block' : 'none';
        });

        document.getElementById('closeHelpBtn').addEventListener('click', function() {
            document.getElementById('helpSection').style.display = 'none';
        });

        // فتح المساعدة تلقائياً لأول زيارة
        window.addEventListener('DOMContentLoaded', function() {
            const firstVisit = localStorage.getItem('customersHelpSeen');
            if (!firstVisit) {
                document.getElementById('helpSection').style.display = 'block';
                localStorage.setItem('customersHelpSeen', 'true');
            }
        });
    </script>
    <script>
        // إضافة مستمع حدث لنسخ SKU
        document.addEventListener('DOMContentLoaded', function() {
            const skuCells = document.querySelectorAll('.product-sku-cell');

            skuCells.forEach(cell => {
                cell.addEventListener('click', function() {
                    const sku = this.textContent.trim();
                    if (sku !== 'N/A') {
                        navigator.clipboard.writeText(sku).then(() => {
                            const originalText = this.innerHTML;
                            this.innerHTML = '✓ تم النسخ!';

                            setTimeout(() => {
                                this.innerHTML = originalText;
                            }, 1500);
                        });
                    }
                });

                if (cell.textContent.trim() !== 'N/A') {
                    cell.style.cursor = 'pointer';
                    cell.title = 'انقر لنسخ SKU';
                }
            });
        });
    </script>
<?php else: ?>
    <p>لا يوجد عملاء لديهم طلبات في الفترة المحددة.</p>
<?php endif; ?>
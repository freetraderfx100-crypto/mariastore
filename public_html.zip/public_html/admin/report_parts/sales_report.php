<?php
$start = $start_date;
$end = $end_date;
$grouping = $_GET['grouping'] ?? 'daily';

$group_field = $grouping === 'monthly'
    ? "DATE_FORMAT(o.`created_at`, '%Y-%m')"
    : "DATE(o.`created_at`)";

try {
    // استعلام مبسط وأكثر كفاءة
    $stmt = $conn->prepare("
        SELECT 
            $group_field AS report_period,
            SUM(o.`total_amount`) AS total_sales,
            SUM(o.`subtotal`) AS products_value,
            SUM(o.`shipping_cost`) AS shipping_cost,
            COUNT(o.`id`) AS total_orders
        FROM `orders` o
        WHERE o.`created_at` BETWEEN :start AND :end
          AND o.`status` = 'completed'
        GROUP BY report_period
        ORDER BY report_period DESC
    ");
    $stmt->execute([
        ':start' => $start . ' 00:00:00',
        ':end' => $end . ' 23:59:59'
    ]);
    $sales = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // حساب الإجماليات
    $total_sales = 0;
    $total_products_value = 0;
    $total_shipping_cost = 0;
    $total_orders = 0;

    foreach ($sales as $row) {
        $total_sales += $row['total_sales'];
        $total_products_value += $row['products_value'];
        $total_shipping_cost += $row['shipping_cost'];
        $total_orders += $row['total_orders'];
    }
} catch (PDOException $e) {
    echo "<p>حدث خطأ: " . $e->getMessage() . "</p>";
    exit;
}

if (count($sales) > 0): ?>
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>assets/css/customers.css">
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>assets/css/dash.css">
    <style>
        .summary-cards {
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
            margin-bottom: 20px;
        }

        .summary-card {
            flex: 1;
            min-width: 200px;
            background: white;
            border-radius: 8px;
            padding: 15px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            text-align: center;
            border-top: 4px solid;
        }

        .summary-card.sales {
            border-color: #4a6cf7;
        }

        .summary-card.products {
            border-color: #28a745;
        }

        .summary-card.shipping {
            border-color: #ffc107;
        }

        .summary-card.orders {
            border-color: #17a2b8;
        }

        .summary-card h3 {
            font-size: 14px;
            margin-bottom: 10px;
            color: #666;
        }

        .summary-card .value {
            font-size: 20px;
            font-weight: bold;
            color: #333;
        }

        .progress-bar {
            height: 20px;
            background: #f0f0f0;
            border-radius: 4px;
            overflow: hidden;
            margin-top: 5px;
        }

        .progress-fill {
            height: 100%;
            background: #4a6cf7;
        }
    </style>

    <!-- بطاقات الملخص -->
    <div class="summary-cards">
        <div class="summary-card sales">
            <h3><i class="fas fa-money-bill-wave"></i> إجمالي المبيعات</h3>
            <div class="value"><?= number_format($total_sales, 2) ?> ر.ي</div>
        </div>

        <div class="summary-card products">
            <h3><i class="fas fa-shopping-bag"></i> قيمة المنتجات</h3>
            <div class="value"><?= number_format($total_products_value, 2) ?> ر.ي</div>
        </div>

        <div class="summary-card shipping">
            <h3><i class="fas fa-truck"></i> تكاليف الشحن</h3>
            <div class="value"><?= number_format($total_shipping_cost, 2) ?> ر.ي</div>
        </div>

        <div class="summary-card orders">
            <h3><i class="fas fa-shopping-cart"></i> عدد الطلبات</h3>
            <div class="value"><?= $total_orders ?></div>
        </div>
    </div>

    <div class="responsive-table">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>📅 <?= $grouping === 'monthly' ? 'الشهر' : 'التاريخ' ?></th>
                    <th>💰 إجمالي المبيعات</th>
                    <th>🛍️ قيمة المنتجات</th>
                    <th>🚚 تكاليف الشحن</th>
                    <th>📦 عدد الطلبات</th>
                    <th>📊 نسبة الشحن (%)</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($sales as $row):
                    $shipping_ratio = $row['total_sales'] > 0 ? ($row['shipping_cost'] / $row['total_sales']) * 100 : 0;
                ?>
                    <tr>
                        <td><?= htmlspecialchars($row['report_period']) ?></td>
                        <td><?= number_format($row['total_sales'], 2) ?> ر.ي</td>
                        <td><?= number_format($row['products_value'], 2) ?> ر.ي</td>
                        <td><?= number_format($row['shipping_cost'], 2) ?> ر.ي</td>
                        <td><?= $row['total_orders'] ?></td>
                        <td>
                            <div class="progress-bar">
                                <div class="progress-fill" style="width: <?= $shipping_ratio ?>%"></div>
                            </div>
                            <?= number_format($shipping_ratio, 2) ?>%
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
            <tfoot>
                <tr style="background-color: #f8f9fa; font-weight: bold;">
                    <td>الإجمالي</td>
                    <td><?= number_format($total_sales, 2) ?> ر.ي</td>
                    <td><?= number_format($total_products_value, 2) ?> ر.ي</td>
                    <td><?= number_format($total_shipping_cost, 2) ?> ر.ي</td>
                    <td><?= $total_orders ?></td>
                    <td>
                        <?php
                        $total_shipping_ratio = $total_sales > 0 ? ($total_shipping_cost / $total_sales) * 100 : 0;
                        echo number_format($total_shipping_ratio, 2) . '%';
                        ?>
                    </td>
                </tr>
            </tfoot>
        </table>
    </div>

    <?php if (count($sales) > 0): ?>
        <div style="display: flex; flex-wrap: wrap; gap: 20px; margin-top: 30px;">
            <div style="flex: 1; min-width: 300px;">
                <canvas id="salesChart" style="max-width: 100%;"></canvas>
            </div>
            <div style="flex: 1; min-width: 300px;">
                <canvas id="breakdownChart" style="max-width: 100%;"></canvas>
            </div>
        </div>

        <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
        <script>
            const ctx = document.getElementById('salesChart').getContext('2d');
            const breakdownCtx = document.getElementById('breakdownChart').getContext('2d');

            const labels = <?= json_encode(array_column($sales, 'report_period')) ?>;
            const salesData = <?= json_encode(array_map(function ($row) {
                                    return (float)$row['total_sales'];
                                }, $sales)) ?>;

            const productsData = <?= json_encode(array_map(function ($row) {
                                        return (float)$row['products_value'];
                                    }, $sales)) ?>;

            const shippingData = <?= json_encode(array_map(function ($row) {
                                        return (float)$row['shipping_cost'];
                                    }, $sales)) ?>;

            // مخطط المبيعات
            const salesChart = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: labels,
                    datasets: [{
                        label: 'إجمالي المبيعات (ر.ي)',
                        data: salesData,
                        borderColor: 'rgba(75, 192, 192, 1)',
                        backgroundColor: 'rgba(75, 192, 192, 0.2)',
                        fill: true,
                        tension: 0.3
                    }]
                },
                options: {
                    responsive: true,
                    scales: {
                        x: {
                            title: {
                                display: true,
                                text: 'التاريخ'
                            }
                        },
                        y: {
                            beginAtZero: true,
                            title: {
                                display: true,
                                text: 'المبيعات (ر.ي)'
                            }
                        }
                    },
                    plugins: {
                        legend: {
                            display: true,
                            position: 'top'
                        },
                        tooltip: {
                            mode: 'index',
                            intersect: false
                        }
                    }
                }
            });

            // مخطط تفصيلي للمبيعات
            const breakdownChart = new Chart(breakdownCtx, {
                type: 'bar',
                data: {
                    labels: labels,
                    datasets: [{
                            label: 'قيمة المنتجات',
                            data: productsData,
                            backgroundColor: 'rgba(40, 167, 69, 0.7)',
                            borderColor: 'rgba(40, 167, 69, 1)',
                            borderWidth: 1
                        },
                        {
                            label: 'تكاليف الشحن',
                            data: shippingData,
                            backgroundColor: 'rgba(255, 193, 7, 0.7)',
                            borderColor: 'rgba(255, 193, 7, 1)',
                            borderWidth: 1
                        }
                    ]
                },
                options: {
                    responsive: true,
                    scales: {
                        x: {
                            title: {
                                display: true,
                                text: 'التاريخ'
                            }
                        },
                        y: {
                            beginAtZero: true,
                            title: {
                                display: true,
                                text: 'القيمة (ر.ي)'
                            }
                        }
                    },
                    plugins: {
                        legend: {
                            display: true,
                            position: 'top'
                        },
                        tooltip: {
                            mode: 'index',
                            intersect: false
                        }
                    }
                }
            });
        </script>
    <?php endif; ?>

<?php else: ?>
    <p>لا توجد مبيعات في الفترة المحددة.</p>
<?php endif; ?>
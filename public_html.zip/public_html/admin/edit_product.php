<?php
session_start();
require_once __DIR__ . '/../includes/db_connect.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

// التحقق من أن المستخدم مدير
checkAdminRole();

// كلاس ضغط الصور (نفس الكلاس المستخدم في إضافة المنتج)
class ImageCompressor
{
    private $quality;
    private $maxWidth;
    private $maxHeight;

    public function __construct($quality = 75, $maxWidth = 1200, $maxHeight = 1200)
    {
        $this->quality = $quality;
        $this->maxWidth = $maxWidth;
        $this->maxHeight = $maxHeight;
    }

    public function compressImage($sourcePath, $destinationPath)
    {
        // الحصول على معلومات الصورة
        $imageInfo = getimagesize($sourcePath);
        if (!$imageInfo) {
            return false;
        }

        $mime = $imageInfo['mime'];
        $width = $imageInfo[0];
        $height = $imageInfo[1];

        // حساب الأبعاد الجديدة مع الحفاظ على نسبة العرض إلى الارتفاع
        $ratio = min($this->maxWidth / $width, $this->maxHeight / $height);
        $newWidth = round($width * $ratio);
        $newHeight = round($height * $ratio);

        // إنشاء صورة جديدة
        $newImage = imagecreatetruecolor($newWidth, $newHeight);

        // الحفاظ على شفافية PNG
        if ($mime == 'image/png' || $mime == 'image/gif') {
            imagealphablending($newImage, false);
            imagesavealpha($newImage, true);
        }

        // تحميل الصورة الأصلية حسب نوعها
        switch ($mime) {
            case 'image/jpeg':
                $source = imagecreatefromjpeg($sourcePath);
                break;
            case 'image/png':
                $source = imagecreatefrompng($sourcePath);
                break;
            case 'image/gif':
                $source = imagecreatefromgif($sourcePath);
                break;
            case 'image/webp':
                $source = imagecreatefromwebp($sourcePath);
                break;
            default:
                return false;
        }

        // تغيير حجم الصورة
        imagecopyresampled($newImage, $source, 0, 0, 0, 0, $newWidth, $newHeight, $width, $height);

        // حفظ الصورة المضغوطة
        $result = false;
        switch ($mime) {
            case 'image/jpeg':
                $result = imagejpeg($newImage, $destinationPath, $this->quality);
                break;
            case 'image/png':
                // تحويل الجودة إلى PNG (0-9)
                $pngQuality = 9 - round(($this->quality / 100) * 9);
                $result = imagepng($newImage, $destinationPath, $pngQuality);
                break;
            case 'image/gif':
                $result = imagegif($newImage, $destinationPath);
                break;
            case 'image/webp':
                $result = imagewebp($newImage, $destinationPath, $this->quality);
                break;
        }

        // تحرير الذاكرة
        imagedestroy($newImage);
        imagedestroy($source);

        return $result;
    }

    public function getOptimizedWebP($sourcePath, $destinationPath)
    {
        // تحويل الصورة إلى WebP مع ضغط عالي
        $imageInfo = getimagesize($sourcePath);
        if (!$imageInfo) {
            return false;
        }

        $mime = $imageInfo['mime'];
        $width = $imageInfo[0];
        $height = $imageInfo[1];

        // حساب الأبعاد الجديدة
        $ratio = min($this->maxWidth / $width, $this->maxHeight / $height);
        $newWidth = round($width * $ratio);
        $newHeight = round($height * $ratio);

        // إنشاء صورة جديدة
        $newImage = imagecreatetruecolor($newWidth, $newHeight);

        // تحميل الصورة الأصلية
        switch ($mime) {
            case 'image/jpeg':
                $source = imagecreatefromjpeg($sourcePath);
                break;
            case 'image/png':
                $source = imagecreatefrompng($sourcePath);
                imagealphablending($newImage, false);
                imagesavealpha($newImage, true);
                break;
            case 'image/gif':
                $source = imagecreatefromgif($sourcePath);
                break;
            default:
                return false;
        }

        // تغيير حجم الصورة
        imagecopyresampled($newImage, $source, 0, 0, 0, 0, $newWidth, $newHeight, $width, $height);

        // حفظ كـ WebP
        $result = imagewebp($newImage, $destinationPath, $this->quality);

        // تحرير الذاكرة
        imagedestroy($newImage);
        imagedestroy($source);

        return $result;
    }
}

$errors = [];
$success = false;
$product_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// التحقق من وجود المنتج
if ($product_id <= 0) {
    $errors[] = "معرف المنتج غير صالح";
    header("Location: products.php");
    exit;
}

// جلب بيانات المنتج
$stmt = $conn->prepare("SELECT * FROM products WHERE id = ?");
$stmt->execute([$product_id]);
$product = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$product) {
    $errors[] = "المنتج غير موجود";
    header("Location: products.php");
    exit;
}

// جلب متغيرات المنتج
$variants_stmt = $conn->prepare("SELECT * FROM product_variants WHERE product_id = ? ORDER BY color, size");
$variants_stmt->execute([$product_id]);
$variants = $variants_stmt->fetchAll(PDO::FETCH_ASSOC);

// تنظيم المتغيرات حسب اللون
$variants_by_color = [];
foreach ($variants as $variant) {
    $color = $variant['color'];
    if (!isset($variants_by_color[$color])) {
        $variants_by_color[$color] = [
            'sizes' => [],
            'quantities' => [],
            'image_urls' => json_decode($variant['image_urls'], true) ?: []
        ];
    }
    $variants_by_color[$color]['sizes'][] = $variant['size'];
    $variants_by_color[$color]['quantities'][] = $variant['quantity'];
}

// جلب التصنيفات
$cat_stmt = $conn->query("SELECT id, name, parent_id FROM categories ORDER BY name");
$all_categories = $cat_stmt->fetchAll(PDO::FETCH_ASSOC);

$main_categories = [];
$sub_categories = [];
foreach ($all_categories as $category) {
    if ($category['parent_id'] === null) {
        $main_categories[] = $category;
    } else {
        $sub_categories[] = $category;
    }
}

// جلب التصنيف الرئيسي للمنتج
$category_id = $product['category_id'];
$main_category_id = null;
foreach ($sub_categories as $sub) {
    if ($sub['id'] == $category_id) {
        $main_category_id = $sub['parent_id'];
        break;
    }
}

$available_sizes = ['XS', 'S', 'M', 'L', 'XL', 'XXL', '3XL'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $form_data = [
        'name' => trim($_POST['name']),
        'sku' => trim($_POST['sku'] ?? ''),
        'description' => trim($_POST['description']),
        'price' => (float)$_POST['price'],
        'cost_price' => (float)$_POST['cost_price'],
        'category' => (int)$_POST['category'],
        'is_active' => isset($_POST['is_active']) ? 1 : 0,
        'is_new' => isset($_POST['is_new']) ? 1 : 0
    ];

    // التحقق من الصحة
    if (empty($form_data['name'])) $errors[] = "اسم المنتج مطلوب";
    if (empty($form_data['description'])) $errors[] = "وصف المنتج مطلوب";
    if ($form_data['price'] <= 0) $errors[] = "السعر يجب أن يكون أكبر من الصفر";
    if ($form_data['cost_price'] < 0) $errors[] = "سعر التكلفة يجب أن يكون قيمة موجبة";
    if (empty($form_data['category'])) $errors[] = "التصنيف مطلوب";

    // التحقق من أن SKU فريد إذا تم تغييره
    if (!empty($form_data['sku']) && $form_data['sku'] != $product['sku']) {
        $check_sku = $conn->prepare("SELECT id FROM products WHERE sku = ? AND id != ?");
        $check_sku->execute([$form_data['sku'], $product_id]);
        if ($check_sku->fetch()) {
            $errors[] = "رقم SKU هذا مستخدم بالفعل لمنتج آخر";
        }
    }

    if (empty($_POST['variant_colors']) || count(array_filter($_POST['variant_colors'])) == 0) {
        $errors[] = "يجب إضافة لون واحد على الأقل";
    }

    if (empty($errors)) {
        try {
            $conn->beginTransaction();

            // تحديث بيانات المنتج الأساسية
            $stmt = $conn->prepare("UPDATE products SET name = ?, sku = ?, description = ?, price = ?, cost_price = ?, category_id = ?, is_active = ?, is_new = ? WHERE id = ?");
            $stmt->execute([
                $form_data['name'],
                $form_data['sku'],
                $form_data['description'],
                $form_data['price'],
                $form_data['cost_price'],
                $form_data['category'],
                $form_data['is_active'],
                $form_data['is_new'],
                $product_id
            ]);

            // حذف المتغيرات القديمة
            $delete_variants = $conn->prepare("DELETE FROM product_variants WHERE product_id = ?");
            $delete_variants->execute([$product_id]);

            // إضافة المتغيرات الجديدة
            $variant_stmt = $conn->prepare("INSERT INTO product_variants (product_id, color, size, quantity, image_urls) VALUES (?, ?, ?, ?, ?)");
            $upload_dir = __DIR__ . '/../assets/images/products/';
            if (!file_exists($upload_dir)) mkdir($upload_dir, 0755, true);

            // إنشاء مجلد WebP إذا لم يكن موجوداً
            $webp_dir = $upload_dir . 'webp/';
            if (!file_exists($webp_dir)) mkdir($webp_dir, 0755, true);

            // تهيئة ضاغط الصور
            $compressor = new ImageCompressor(75, 1200, 1200);

            $variant_colors = $_POST['variant_colors'] ?? [];
            $variant_sizes_group = $_POST['size'] ?? [];
            $variant_quantities_group = $_POST['variant_quantities'] ?? [];
            $existing_images = $_POST['existing_images'] ?? [];

            $used_colors = [];

            for ($i = 0; $i < count($variant_colors); $i++) {
                $color = trim($variant_colors[$i]);
                if (empty($color)) {
                    $errors[] = "يجب إدخال اللون لجميع التركيبات.";
                    continue;
                }

                if (in_array(strtolower($color), array_map('strtolower', $used_colors))) {
                    $errors[] = "لا يمكنك تكرار نفس اللون ($color) أكثر من مرة. تم حفظ منتج واحد";
                    continue;
                }

                $used_colors[] = $color;

                // جمع الصور لهذا اللون
                $image_urls = [];

                // إضافة الصور الموجودة مسبقاً إذا تم تحديدها
                if (isset($existing_images[$i]) && is_array($existing_images[$i])) {
                    $image_urls = $existing_images[$i];
                }

                // معالجة الصور الجديدة
                $image_key = 'variant_images_' . $i;
                if (!empty($_FILES[$image_key]['name'][0])) {
                    foreach ($_FILES[$image_key]['name'] as $index => $name) {
                        if ($_FILES[$image_key]['error'][$index] == UPLOAD_ERR_OK) {
                            $file_tmp = $_FILES[$image_key]['tmp_name'][$index];
                            $original_name = basename($name);
                            $file_name = uniqid() . '_' . $original_name;
                            $target_file = $upload_dir . $file_name;

                            // ضغط الصورة وحفظها
                            if ($compressor->compressImage($file_tmp, $target_file)) {
                                // إنشاء نسخة WebP
                                $webp_file_name = pathinfo($file_name, PATHINFO_FILENAME) . '.webp';
                                $webp_target_file = $webp_dir . $webp_file_name;
                                $compressor->getOptimizedWebP($file_tmp, $webp_target_file);
                            } else {
                                // إذا فشل الضغط، انقل الملف الأصلي
                                move_uploaded_file($file_tmp, $target_file);
                            }

                            $image_urls[] = 'products/' . $file_name;
                        }
                    }
                }

                // تحويل مصفوفة الصور إلى JSON
                $image_urls_json = !empty($image_urls) ? json_encode($image_urls) : null;

                // إضافة المقاسات لهذا اللون
                $sizes = $variant_sizes_group[$i] ?? [];
                $quantities = $variant_quantities_group[$i] ?? [];
                $used_sizes = [];

                for ($j = 0; $j < count($sizes); $j++) {
                    $size = trim($sizes[$j]);
                    $quantity = (int)($quantities[$j] ?? 0);

                    if (empty($size)) {
                        $errors[] = "يجب إدخال جميع المقاسات.";
                        continue;
                    }

                    if (in_array(strtolower($size), array_map('strtolower', $used_sizes))) {
                        $errors[] = "المقاس ($size) مكرر لنفس اللون ($color). تم حفظ منتج واحد";
                        continue;
                    }

                    $used_sizes[] = $size;
                    $variant_stmt->execute([$product_id, $color, $size, $quantity, $image_urls_json]);
                }
            }

            $conn->commit();
            $success = true;

            // تحديث بيانات المنتج بعد التعديل
            $stmt = $conn->prepare("SELECT * FROM products WHERE id = ?");
            $stmt->execute([$product_id]);
            $product = $stmt->fetch(PDO::FETCH_ASSOC);

            // جلب المتغيرات المحدثة
            $variants_stmt = $conn->prepare("SELECT * FROM product_variants WHERE product_id = ? ORDER BY color, size");
            $variants_stmt->execute([$product_id]);
            $variants = $variants_stmt->fetchAll(PDO::FETCH_ASSOC);

            // تنظيم المتغيرات حسب اللون
            $variants_by_color = [];
            foreach ($variants as $variant) {
                $color = $variant['color'];
                if (!isset($variants_by_color[$color])) {
                    $variants_by_color[$color] = [
                        'sizes' => [],
                        'quantities' => [],
                        'image_urls' => json_decode($variant['image_urls'], true) ?: []
                    ];
                }
                $variants_by_color[$color]['sizes'][] = $variant['size'];
                $variants_by_color[$color]['quantities'][] = $variant['quantity'];
            }
        } catch (PDOException $e) {
            $conn->rollBack();
            $errors[] = "خطأ في تحديث المنتج: " . $e->getMessage();
        }
    }
}
?>
<!-- HTML يبدأ من هنا -->
<!DOCTYPE html>
<html lang="ar" dir="rtl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تعديل المنتج</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 0;
            direction: rtl;
        }

        .admin-container {
            max-width: 800px;
            margin: 40px auto;
            background-color: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h1.page-title {
            font-size: 24px;
            margin-bottom: 20px;
            color: #333;
        }

        label {
            font-weight: bold;
            display: block;
            margin: 15px 0 5px;
        }

        input[type="text"],
        input[type="number"],
        select,
        textarea {
            width: 100%;
            padding: 10px;
            border-radius: 6px;
            border: 1px solid #ccc;
            font-size: 14px;
        }

        textarea {
            resize: vertical;
        }

        .checkbox-group label {
            display: inline-block;
            margin-left: 10px;
        }

        .variant-entry {
            border: 1px solid #ddd;
            padding: 15px;
            margin-bottom: 15px;
            border-radius: 6px;
            background-color: #f9f9f9;
        }

        .image-container {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin: 10px 0;
        }

        .image-preview {
            position: relative;
            width: 100px;
            height: 100px;
            border: 1px solid #ddd;
            border-radius: 4px;
            overflow: hidden;
        }

        .image-preview img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .image-preview .remove-image {
            position: absolute;
            top: 5px;
            left: 5px;
            background: rgba(255, 0, 0, 0.7);
            color: white;
            border: none;
            border-radius: 50%;
            width: 20px;
            height: 20px;
            cursor: pointer;
            font-size: 12px;
        }

        .size-qty-row {
            display: flex;
            gap: 10px;
            margin-bottom: 10px;
            align-items: center;
        }

        .size-qty-row input {
            flex: 1;
        }

        button[type="submit"],
        .add-button {
            background: #ff6b8b;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 6px;
            font-size: 16px;
            cursor: pointer;
            margin-top: 20px;
        }

        .btn-remove {
            background: #dc3545;
            color: white;
            border: none;
            padding: 5px 10px;
            border-radius: 4px;
            cursor: pointer;
        }

        .btn-add {
            background: #28a745;
            color: white;
            border: none;
            padding: 5px 10px;
            border-radius: 4px;
            cursor: pointer;
            margin-left: 10px;
        }

        .alert {
            padding: 15px;
            background-color: #f8d7da;
            border: 1px solid #f5c6cb;
            color: #721c24;
            border-radius: 6px;
            margin-bottom: 20px;
        }

        .alert-success {
            background-color: #d4edda;
            border-color: #c3e6cb;
            color: #155724;
        }

        .image-info {
            font-size: 12px;
            color: #666;
            margin-top: 5px;
            background-color: #f8f9fa;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 15px;
        }

        .image-upload-area {
            border: 2px dashed #ccc;
            border-radius: 6px;
            padding: 20px;
            text-align: center;
            margin: 10px 0;
            cursor: pointer;
            transition: border-color 0.3s;
        }

        .image-upload-area:hover {
            border-color: #ff6b8b;
        }

        .image-upload-area.dragover {
            border-color: #ff6b8b;
            background-color: #fff5f7;
        }

        .existing-images {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin: 10px 0;
        }

        .existing-image {
            position: relative;
            width: 100px;
            height: 100px;
            border: 1px solid #ddd;
            border-radius: 4px;
            overflow: hidden;
        }

        .existing-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .existing-image .keep-image {
            position: absolute;
            top: 5px;
            left: 5px;
            background: rgba(0, 128, 0, 0.7);
            color: white;
            border: none;
            border-radius: 50%;
            width: 20px;
            height: 20px;
            cursor: pointer;
            font-size: 12px;
        }

        .existing-image .remove-existing-image {
            position: absolute;
            top: 5px;
            right: 5px;
            background: rgba(255, 0, 0, 0.7);
            color: white;
            border: none;
            border-radius: 50%;
            width: 20px;
            height: 20px;
            cursor: pointer;
            font-size: 12px;
        }

        .existing-image {
            position: relative;
            width: 100px;
            height: 100px;
            border: 1px solid #ddd;
            border-radius: 4px;
            overflow: hidden;
            margin: 5px;
        }

        .existing-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .remove-existing-image {
            position: absolute;
            top: 5px;
            right: 5px;
            background: rgba(255, 0, 0, 0.7);
            color: white;
            border: none;
            border-radius: 50%;
            width: 20px;
            height: 20px;
            cursor: pointer;
            font-size: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .remove-existing-image:hover {
            background: rgba(255, 0, 0, 0.9);
        }
    </style>
</head>

<body>
    <?php
    include __DIR__ . '/../includes/admin_header.php';
    ?>
    <div class="admin-container">
        <h1 class="page-title"><i class="fas fa-edit"></i> تعديل المنتج: <?= htmlspecialchars($product['name']) ?></h1>
        <form method="post" enctype="multipart/form-data">
            <label>اسم المنتج</label>
            <input type="text" name="name" value="<?= htmlspecialchars($product['name']) ?>" required>

            <label>كود/رقم SKU</label>
            <input type="text" name="sku" id="sku" value="<?= htmlspecialchars($product['sku']) ?>" required>

            <label>الوصف</label>
            <textarea name="description" rows="4" required><?= htmlspecialchars($product['description']) ?></textarea>

            <label>سعر البيع</label>
            <input type="number" name="price" step="0.01" min="0.01" value="<?= htmlspecialchars($product['price']) ?>" required>

            <label>سعر التكلفة</label>
            <input type="number" name="cost_price" step="0.01" min="0" value="<?= htmlspecialchars($product['cost_price']) ?>" required>

            <!-- عرض التصنيفات الفرعيه مع الرئيسيه -->
            <div class="form-group">
                <label for="category">التصنيف <span class="required">*</span></label>
                <div class="form-group">
                    <label for="main_category">القسم الرئيسي <span class="required">*</span></label>
                    <select id="main_category" required>
                        <option value="">اختر قسماً رئيسياً</option>
                        <?php foreach ($main_categories as $main): ?>
                            <option value="<?= $main['id'] ?>" <?= $main['id'] == $main_category_id ? 'selected' : '' ?>>
                                <?= htmlspecialchars($main['name']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="category">التصنيف الفرعي <span class="required">*</span></label>
                    <select id="category" name="category" required>
                        <option value="">اختر تصنيفاً فرعياً</option>
                        <?php foreach ($sub_categories as $sub): ?>
                            <option value="<?= $sub['id'] ?>" data-parent="<?= $sub['parent_id'] ?>" <?= $sub['id'] == $category_id ? 'selected' : '' ?>>
                                <?= htmlspecialchars($sub['name']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>

            <label>حالة المنتج:</label>
            <label><input type="checkbox" name="is_active" value="1" <?= $product['is_active'] ? 'checked' : '' ?>> نشط</label>
            <label><input type="checkbox" name="is_new" value="1" <?= (isset($product['is_new']) && $product['is_new']) ? 'checked' : '' ?>> منتج جديد (يظهر مع شارة NEW في الموقع)</label>

            <div class="image-info">
                <i class="fas fa-info-circle"></i> سيتم ضغط الصور تلقائياً لتحسين أداء الموقع. الحد الأقصى لأبعاد الصورة هو 1200x1200 بكسل.
            </div>

            <label>تفاصيل الألوان والمقاسات:</label>
            <div id="variantContainer">
                <?php
                $variantIndex = 0;
                foreach ($variants_by_color as $color => $data):
                    $sizes = $data['sizes'];
                    $quantities = $data['quantities'];
                    $image_urls = $data['image_urls'];
                ?>
                    <div class="variant-entry">
                        <div class="form-group">
                            <label>اللون</label>
                            <input type="text" name="variant_colors[]" value="<?= htmlspecialchars($color) ?>" placeholder="أدخل اللون" required>
                        </div>

                        <div class="form-group">
                            <label>الصور الموجودة</label>
                            <div class="existing-images" id="existing_images_<?= $variantIndex ?>">
                                <?php foreach ($image_urls as $index => $url): ?>
                                    <div class="existing-image">
                                        <img src="<?= SITE_URL . 'assets/images/' . $url ?>" alt="صورة المنتج">
                                        <input type="hidden" name="existing_images[<?= $variantIndex ?>][]" value="<?= $url ?>">
                                        <button type="button" class="remove-existing-image" onclick="removeExistingImage(this)">×</button>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>

                        <div class="form-group">
                            <label>صور جديدة</label>
                            <div class="image-upload-area" onclick="document.getElementById('variant_images_<?= $variantIndex ?>').click()">
                                <i class="fas fa-cloud-upload-alt"></i>
                                <p>انقر هنا أو اسحب الصور لإضافتها</p>
                                <p>يمكنك إضافة </p>
                            </div>
                            <input type="file" id="variant_images_<?= $variantIndex ?>" name="variant_images_<?= $variantIndex ?>[]" multiple accept="image/*" style="display: none;" onchange="handleImageUpload(event, <?= $variantIndex ?>)">
                            <div class="image-container" id="image_container_<?= $variantIndex ?>"></div>
                        </div>

                        <div class="form-group">
                            <label>المقاسات والكميات</label>
                            <div id="sizeQtyContainer-<?= $variantIndex ?>">
                                <?php for ($j = 0; $j < count($sizes); $j++): ?>
                                    <div class="size-qty-row">
                                        <input type="text" name="size[<?= $variantIndex ?>][]" list="sizes" value="<?= htmlspecialchars($sizes[$j]) ?>" placeholder="أدخل المقاس" required>
                                        <datalist id="sizes">
                                            <option value="XS">
                                            <option value="S">
                                            <option value="M">
                                            <option value="L">
                                            <option value="XL">
                                            <option value="XXL">
                                            <option value="3XL">
                                            <option value="36">
                                            <option value="37">
                                            <option value="38">
                                            <option value="39">
                                            <option value="40">
                                            <option value="41">
                                            <option value="42">
                                            <option value="43">
                                            <option value="44">
                                            <option value="45">
                                        </datalist>
                                        <input type="number" name="variant_quantities[<?= $variantIndex ?>][]" value="<?= htmlspecialchars($quantities[$j]) ?>" placeholder="الكمية" min="0" required>
                                        <button type="button" class="btn-remove" onclick="this.parentElement.remove()">❌</button>
                                    </div>
                                <?php endfor; ?>
                            </div>
                            <button type="button" class="btn-add" onclick="addSizeQty(<?= $variantIndex ?>)">+ إضافة مقاس</button>
                        </div>

                        <button type="button" class="btn-remove" onclick="this.parentElement.remove()">حذف اللون</button>
                    </div>
                <?php
                    $variantIndex++;
                endforeach;
                ?>
            </div>
            <button type="button" onclick="addVariant()">إضافة لون + صور</button>

            <?php if (!empty($errors)): ?>
                <div class="alert">
                    <?php foreach ($errors as $error): ?>
                        <p><?= htmlspecialchars($error) ?></p>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

            <?php if ($success): ?>
                <div class="alert alert-success">
                    تم تحديث المنتج بنجاح!
                </div>
            <?php endif; ?>

            <br>
            <button type="submit">حفظ التغييرات</button>
        </form>
    </div>
    <?php
    include __DIR__ . '/../includes/admin_footer.php';
    ?>
    <script>
        let variantIndex = <?= $variantIndex ?>;

        function addVariant() {
            const container = document.getElementById('variantContainer');
            const div = document.createElement('div');
            div.className = 'variant-entry';
            div.innerHTML = `
                <div class="form-group">
                    <label>اللون</label>
                    <input type="text" name="variant_colors[]" placeholder="أدخل اللون" required>
                </div>
                
                <div class="form-group">
                    <label>الصور</label>
                    <div class="image-upload-area" onclick="document.getElementById('variant_images_${variantIndex}').click()">
                        <i class="fas fa-cloud-upload-alt"></i>
                        <p>انقر هنا أو اسحب الصور لإضافتها</p>
                        <p>يمكنك إضافة </p>
                    </div>
                    <input type="file" id="variant_images_${variantIndex}" name="variant_images_${variantIndex}[]" multiple accept="image/*" style="display: none;" onchange="handleImageUpload(event, ${variantIndex})">
                    <div class="image-container" id="image_container_${variantIndex}"></div>
                </div>
                
                <div class="form-group">
                    <label>المقاسات والكميات</label>
                    <div id="sizeQtyContainer-${variantIndex}">
                        ${generateSizeQtyInputs(variantIndex)}
                    </div>
                    <button type="button" class="btn-add" onclick="addSizeQty(${variantIndex})">+ إضافة مقاس</button>
                </div>
                
                <button type="button" class="btn-remove" onclick="this.parentElement.remove()">حذف اللون</button>
            `;
            container.appendChild(div);
            variantIndex++;
        }

        function generateSizeQtyInputs(variantIndex) {
            return `
                <div class="size-qty-row">
                    <input type="text" name="size[${variantIndex}][]" list="sizes" placeholder="أدخل المقاس" required>
                    <datalist id="sizes">
                        <option value="XS">
                        <option value="S">
                        <option value="M">
                        <option value="L">
                        <option value="XL">
                        <option value="XXL">
                        <option value="3XL">
                        <option value="36">
                        <option value="37">
                        <option value="38">
                        <option value="39">
                        <option value="40">
                        <option value="41">
                        <option value="42">
                        <option value="43">
                        <option value="44">
                        <option value="45">
                    </datalist>
                    <input type="number" name="variant_quantities[${variantIndex}][]" placeholder="الكمية" min="0" required>
                    <button type="button" class="btn-remove" onclick="this.parentElement.remove()">❌</button>
                </div>
            `;
        }

        function addSizeQty(index) {
            const container = document.getElementById(`sizeQtyContainer-${index}`);
            container.insertAdjacentHTML('beforeend', generateSizeQtyInputs(index));
        }

        function handleImageUpload(event, variantIndex) {
            const files = event.target.files;
            const container = document.getElementById(`image_container_${variantIndex}`);
            Array.from(files).forEach(file => {
                if (file.type.startsWith('image/')) {
                    const reader = new FileReader();
                    reader.onload = function(e) {
                        const div = document.createElement('div');
                        div.className = 'image-preview';
                        div.innerHTML = `
                            <img src="${e.target.result}" alt="معاينة الصورة">
                            <button type="button" class="remove-image" onclick="this.parentElement.remove()">×</button>
                        `;
                        container.appendChild(div);
                    };
                    reader.readAsDataURL(file);
                }
            });
        }

        function removeExistingImage(button) {
            // الحصول على مسار الصورة
            const imageContainer = button.parentElement;
            const hiddenInput = imageContainer.querySelector('input[type="hidden"]');
            const imagePath = hiddenInput.value;

            // إرسال طلب لحذف الصورة من الخادم
            if (imagePath) {
                // تعطيل الزر مؤقتاً لمنع النقرات المتعددة
                button.disabled = true;
                button.innerHTML = '...';

                fetch('delete_image.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded',
                        },
                        body: 'image_path=' + encodeURIComponent(imagePath)
                    })
                    .then(response => {
                        if (!response.ok) {
                            throw new Error('Network response was not ok');
                        }
                        return response.json();
                    })
                    .then(data => {
                        if (data.success) {
                            // إخفاء الصورة عند الضغط على زر الحذف
                            imageContainer.style.display = 'none';
                            // إزالة قيمة الصورة من الحقل المخفي
                            hiddenInput.name = ''; // إفراغ الاسم لمنع إرسال القيمة
                        } else {
                            alert('فشل حذف الصورة: ' + data.message);
                            // إعادة تفعيل الزر
                            button.disabled = false;
                            button.innerHTML = '×';
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        alert('حدث خطأ أثناء حذف الصورة');
                        // إعادة تفعيل الزر
                        button.disabled = false;
                        button.innerHTML = '×';
                    });
            }
        }

        // دعم السحب والإفلات للصور
        document.addEventListener('DOMContentLoaded', function() {
            const uploadAreas = document.querySelectorAll('.image-upload-area');
            uploadAreas.forEach(area => {
                area.addEventListener('dragover', function(e) {
                    e.preventDefault();
                    this.classList.add('dragover');
                });
                area.addEventListener('dragleave', function(e) {
                    e.preventDefault();
                    this.classList.remove('dragover');
                });
                area.addEventListener('drop', function(e) {
                    e.preventDefault();
                    this.classList.remove('dragover');
                    const files = e.dataTransfer.files;
                    const variantIndex = this.getAttribute('onclick').match(/variant_images_(\d+)/)[1];
                    const container = document.getElementById(`image_container_${variantIndex}`);
                    const fileInput = document.getElementById(`variant_images_${variantIndex}`);
                    // تحديث قائمة الملفات في حقل الإدخال
                    fileInput.files = files;
                    Array.from(files).forEach(file => {
                        if (file.type.startsWith('image/')) {
                            const reader = new FileReader();
                            reader.onload = function(e) {
                                const div = document.createElement('div');
                                div.className = 'image-preview';
                                div.innerHTML = `
                                    <img src="${e.target.result}" alt="معاينة الصورة">
                                    <button type="button" class="remove-image" onclick="this.parentElement.remove()">×</button>
                                `;
                                container.appendChild(div);
                            };
                            reader.readAsDataURL(file);
                        }
                    });
                });
            });
        });
    </script>
    <!-- سكربت التصنيفات الرئيسيه والتصنيفات الفرعيه -->
    <script>
        document.getElementById('main_category').addEventListener('change', function() {
            const selectedMain = this.value;
            const subSelect = document.getElementById('category');
            const subOptions = subSelect.querySelectorAll('option');
            subSelect.value = ''; // إعادة التحديد
            subOptions.forEach(option => {
                if (!option.dataset.parent) return; // تجاهل "اختر تصنيفاً"
                if (option.dataset.parent === selectedMain) {
                    option.style.display = 'block';
                } else {
                    option.style.display = 'none';
                }
            });
        });

        // إخفاء كل الخيارات الفرعية عند تحميل الصفحة
        window.addEventListener('DOMContentLoaded', () => {
            const subSelect = document.getElementById('category');
            const subOptions = subSelect.querySelectorAll('option');
            subOptions.forEach(option => {
                if (option.dataset.parent) {
                    option.style.display = 'none';
                }
            });

            // إظهار التصنيفات الفرعية التابعة للتصنيف الرئيسي المحدد
            const mainCategorySelect = document.getElementById('main_category');
            const selectedMain = mainCategorySelect.value;
            if (selectedMain) {
                subOptions.forEach(option => {
                    if (option.dataset.parent === selectedMain) {
                        option.style.display = 'block';
                    }
                });
            }
        });
    </script>
    <script src="<?php echo SITE_URL; ?>assets/js/code_SKU.js"></script>
</body>

</html>
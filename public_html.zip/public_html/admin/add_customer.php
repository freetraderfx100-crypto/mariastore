<?php
require_once __DIR__ . '/../includes/db_connect.php';
require_once __DIR__ . '/../includes/auth.php';
// require_once __DIR__ . '/../includes/session_config.php';

// التحقق من أن المستخدم مدير
checkAdminRole();

$errors = [];
$success = false;

// عند إرسال النموذج
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $role = $_POST['role'];
    $avatar = null;

    // التحقق من الحقول
    if (empty($username) || empty($email) || empty($password) || empty($role)) {
        $errors[] = "جميع الحقول مطلوبة.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "البريد الإلكتروني غير صالح.";
    }

    // رفع الصورة
    if (isset($_FILES['avatar']) && $_FILES['avatar']['error'] === UPLOAD_ERR_OK) {
        $fileTmp = $_FILES['avatar']['tmp_name'];
        $fileName = time() . '_' . basename($_FILES['avatar']['name']);
        $uploadPath = __DIR__ . '/../assets/images/users/avatars/' . $fileName;

        // التحقق من نوع الملف
        $allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
        $fileType = mime_content_type($fileTmp);

        if (!in_array($fileType, $allowedTypes)) {
            $errors[] = "نوع الملف غير مسموح به. يرجى رفع صورة (JPEG, PNG, GIF, WebP).";
        } elseif ($_FILES['avatar']['size'] > 5 * 1024 * 1024) { // 5MB كحد أقصى
            $errors[] = "حجم الصورة كبير جداً. الحد الأقصى هو 5MB.";
        } elseif (move_uploaded_file($fileTmp, $uploadPath)) {
            $avatar = $fileName;
        } else {
            $errors[] = "فشل في رفع الصورة.";
        }
    }

    // إذا لا يوجد أخطاء، أضف المستخدم
    if (empty($errors)) {
        // التحقق من عدم وجود مستخدم بنفس البريد الإلكتروني
        $checkStmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
        $checkStmt->execute([$email]);

        if ($checkStmt->fetch()) {
            $errors[] = "البريد الإلكتروني مسجل مسبقاً.";
        } else {
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

            $stmt = $conn->prepare("INSERT INTO users (username, email, password, role, avatar, created_at, updated_at) VALUES (?, ?, ?, ?, ?, NOW(), NOW())");
            $stmt->execute([$username, $email, $hashedPassword, $role, $avatar]);

            $success = true;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إضافة عميل جديد</title>
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>assets/css/customers.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

</head>

<body>
    <div class="container">
        <div class="header">
            <h2><i class="fas fa-user-plus"></i> إضافة عميل جديد</h2>
            <a href="<?php echo SITE_URL; ?>admin/customers.php" class="back-btn"><i class="fas fa-arrow-right"></i> العودة إلى العملاء</a>
        </div>

        <div class="form-container">
            <?php if ($success): ?>
                <div class="alert success">
                    <i class="fas fa-check-circle"></i>
                    <span>✅ تم إضافة العميل بنجاح</span>
                </div>

                <div class="success-actions">
                    <a href="<?php echo SITE_URL; ?>admin/customers.php" class="success-btn"><i class="fas fa-users"></i> العودة للعملاء</a>
                    <a href="<?php echo SITE_URL; ?>admin/add_customer.php" class="success-btn add-another"><i class="fas fa-plus"></i> إضافة عميل آخر</a>
                </div>
            <?php elseif (!empty($errors)): ?>
                <div class="alert error">
                    <?php foreach ($errors as $error): ?>
                        <p><i class="fas fa-exclamation-circle"></i> <?= htmlspecialchars($error) ?></p>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

            <?php if (!$success): ?>
                <form method="POST" enctype="multipart/form-data" id="customerForm">
                    <div class="form-grid">
                        <div class="form-group">
                            <label for="username"><i class="fas fa-user"></i> اسم المستخدم</label>
                            <input type="text" name="username" id="username" required value="<?= isset($_POST['username']) ? htmlspecialchars($_POST['username']) : '' ?>">
                        </div>

                        <div class="form-group">
                            <label for="email"><i class="fas fa-envelope"></i> البريد الإلكتروني</label>
                            <input type="email" name="email" id="email" required value="<?= isset($_POST['email']) ? htmlspecialchars($_POST['email']) : '' ?>">
                        </div>

                        <div class="form-group">
                            <label for="password"><i class="fas fa-lock"></i> كلمة المرور</label>
                            <input type="password" name="password" id="password" required>
                        </div>

                        <div class="form-group">
                            <label for="role"><i class="fas fa-user-tag"></i> الدور</label>
                            <select name="role" id="role" required>
                                <option value="user" <?= (isset($_POST['role']) && $_POST['role'] == 'user') ? 'selected' : '' ?>>مستخدم</option>
                                <option value="admin" <?= (isset($_POST['role']) && $_POST['role'] == 'admin') ? 'selected' : '' ?>>مدير</option>
                            </select>
                        </div>

                        <div class="form-group full-width">
                            <label>صورة الملف الشخصي (اختياري)</label>
                            <div class="file-input-container">
                                <label class="file-input-label" for="avatar">
                                    <i class="fas fa-cloud-upload-alt"></i>
                                    <span>انقر أو اسحب الصورة هنا</span>
                                    <small>الحجم الأقصى: 5MB (JPEG, PNG, GIF, WebP)</small>
                                </label>
                                <input type="file" class="file-input" name="avatar" id="avatar" accept="image/*">
                            </div>
                            <div class="preview-container" id="previewContainer">
                                <img src="" class="preview-image" id="previewImage">
                                <div><small>معاينة الصورة</small></div>
                            </div>
                        </div>
                    </div>

                    <button type="submit"><i class="fas fa-plus"></i> إضافة العميل</button>
                </form>
            <?php endif; ?>
        </div>
    </div>

    <script>
        // معاينة الصورة قبل الرفع
        document.getElementById('avatar').addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    const previewImage = document.getElementById('previewImage');
                    const previewContainer = document.getElementById('previewContainer');

                    previewImage.src = e.target.result;
                    previewContainer.style.display = 'block';
                }
                reader.readAsDataURL(file);
            }
        });

        // إظهار رسالة النجاح بشكل متحرك
        document.addEventListener('DOMContentLoaded', () => {
            const successAlert = document.querySelector('.alert.success');
            if (successAlert) {
                setTimeout(() => {
                    successAlert.style.opacity = '0';
                    successAlert.style.transition = 'opacity 1s';
                }, 5000);
            }
        });

        // التحقق من صحة النموذج قبل الإرسال
        document.getElementById('customerForm').addEventListener('submit', function(e) {
            const password = document.getElementById('password').value;
            if (password.length < 6) {
                e.preventDefault();
                alert('كلمة المرور يجب أن تحتوي على الأقل 6 أحرف');
                return false;
            }
        });
    </script>
</body>

</html>
<?php
require_once __DIR__ . '/../includes/db_connect.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

// session_start();

// التحقق من أن المستخدم مدير
checkAdminRole();

// تصفية التاريخ
$start_date = $_GET['start_date'] ?? date('Y-m-01');
$end_date = $_GET['end_date'] ?? date('Y-m-d');
$type = $_GET['type'] ?? 'sales';
$grouping = $_GET['grouping'] ?? 'daily'; // التجميع الافتراضي لجميع التقارير

// تعيين عنوان الصفحة
$page_title = "إدارة التقارير";
?>
<!DOCTYPE html>
<html lang="ar">

<head>
    <meta charset="UTF-8">
    <title>تقارير المتجر</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>assets/css/customers.css">


</head>

<body>
    <?php include __DIR__ . '/../includes/admin_header.php'; ?>

    <h2>📊 التقارير</h2>

    <?php
    $start_date = isset($_GET['start_date']) && $_GET['start_date'] !== '' ? $_GET['start_date'] : date('Y-m-01');
    $end_date = isset($_GET['end_date']) && $_GET['end_date'] !== '' ? $_GET['end_date'] : date('Y-m-d');
    $type = $_GET['type'] ?? 'sales';
    $grouping = $_GET['grouping'] ?? 'daily';
    ?>

    <form method="get">
        <label>من: <input type="date" name="start_date" value="<?= htmlspecialchars($start_date) ?>"></label>
        <label>إلى: <input type="date" name="end_date" value="<?= htmlspecialchars($end_date) ?>"></label>

        <select name="type">
            <option value="sales" <?= $type == 'sales' ? 'selected' : '' ?>>🛒 تقرير المبيعات</option>
            <option value="orders" <?= $type == 'orders' ? 'selected' : '' ?>>📦 تقرير الطلبات</option>
            <option value="customers" <?= $type == 'customers' ? 'selected' : '' ?>>👤 تقرير العملاء</option>
            <option value="products" <?= $type == 'products' ? 'selected' : '' ?>>🧾 تقرير المنتجات</option>
        </select>

        <select name="grouping">
            <option value="daily" <?= $grouping == 'daily' ? 'selected' : '' ?>>تجميع يومي</option>
            <option value="monthly" <?= $grouping == 'monthly' ? 'selected' : '' ?>>تجميع شهري</option>
        </select>

        <button type="submit">عرض التقرير</button>
    </form>
    </br>

    <div class="report-section">
        <?php
        switch ($type) {
            case 'sales':
                include 'report_parts/sales_report.php';
                break;
            case 'orders':
                include 'report_parts/orders_report.php';
                break;
            case 'customers':
                include 'report_parts/customers_report.php';
                break;
            case 'products':
                include 'report_parts/products_report.php';
                break;
        }
        ?>
    </div>
    <?php include __DIR__ . '/../includes/admin_footer.php'; ?>

</body>

</html>
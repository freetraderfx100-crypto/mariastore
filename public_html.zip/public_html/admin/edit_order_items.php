<?php
session_start();
require_once __DIR__ . '/../includes/db_connect.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';
// التحقق من أن المستخدم مدير
checkAdminRole();
// التحقق من وجود معرف الطلب
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: " . SITE_URL . "admin/orders.php");
    exit;
}
$order_id = (int)$_GET['id'];
// جلب بيانات الطلب الأساسية
$stmt = $conn->prepare("SELECT id, status FROM orders WHERE id = ?");
$stmt->execute([$order_id]);
$order = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$order) {
    header("Location: " . SITE_URL . "admin/orders.php");
    exit;
}
// جلب عناصر الطلب
// جلب عناصر الطلب
$items_stmt = $conn->prepare("
    SELECT 
        oi.*, 
        p.name,
        p.sku,
        pv.color,
        pv.size
    FROM order_items oi
    JOIN products p ON oi.product_id = p.id
    JOIN product_variants pv ON oi.product_id = pv.product_id 
        AND oi.color = pv.color 
        AND oi.size = pv.size
    WHERE oi.order_id = ?
");
$items_stmt->execute([$order_id]);
$order_items = $items_stmt->fetchAll(PDO::FETCH_ASSOC);
// معالجة حذف العنصر
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_item_id'])) {
    $delete_id = (int)$_POST['delete_item_id'];
    // بدء المعاملة
    $conn->beginTransaction();
    try {
        // جلب بيانات العنصر قبل الحذف
        $stmt = $conn->prepare("
            SELECT product_id, quantity, price, order_id 
            FROM order_items 
            WHERE id = ?
        ");
        $stmt->execute([$delete_id]);
        $item = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($item) {
            // إعادة الكمية للمنتج
            $return_stmt = $conn->prepare("
                UPDATE product_variants 
                SET quantity = quantity + ? 
                WHERE product_id = ?
            ");
            $return_stmt->execute([$item['quantity'], $item['product_id']]);
            // تسجيل في سجل المخزون
            $log_stmt = $conn->prepare("
                INSERT INTO stock_logs (order_id, product_id, quantity, action_type, description)
                VALUES (?, ?, ?, 'return', ?)
            ");
            $log_desc = "حذف عنصر من الطلب #{$item['order_id']} وإعادة الكمية للمخزون";
            $log_stmt->execute([
                $item['order_id'],
                $item['product_id'],
                $item['quantity'],
                $log_desc
            ]);
        }
        // حذف العنصر من الطلب
        $stmt = $conn->prepare("DELETE FROM order_items WHERE id = ?");
        $stmt->execute([$delete_id]);
        // تحديث السعر الإجمالي للطلب
        $total_stmt = $conn->prepare("
            UPDATE orders o
            JOIN (
                SELECT SUM(oi.price * oi.quantity) AS subtotal
                FROM order_items oi
                WHERE oi.order_id = ?
            ) items ON 1=1
            SET o.subtotal = items.subtotal,
                o.total_amount = items.subtotal + o.shipping_cost
            WHERE o.id = ?
        ");
        $total_stmt->execute([$order_id, $order_id]);
        $conn->commit();
        $_SESSION['success'] = "تم حذف العنصر بنجاح وإعادة الكمية للمخزون.";
    } catch (Exception $e) {
        $conn->rollBack();
        $_SESSION['error'] = "حدث خطأ أثناء حذف العنصر: " . $e->getMessage();
    }
    header("Location: " . SITE_URL . "admin/edit_order_items.php?id=" . $order_id);
    exit;
}
// معالجة تحديث العناصر
// في قسم معالجة تحديث العناصر
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_items']) && isset($_POST['items'])) {
    $conn->beginTransaction();
    try {
        foreach ($_POST['items'] as $item_id => $data) {
            $additional_quantity = (int)$data['quantity'];
            $final_quantity = (int)$data['final_quantity'];
            // جلب البيانات الحالية
            $stmt = $conn->prepare("
                SELECT oi.quantity, oi.price, oi.product_id, oi.color, oi.size 
                FROM order_items oi 
                WHERE oi.id = ?
            ");
            $stmt->execute([$item_id]);
            $current_item = $stmt->fetch();
            if ($current_item) {
                $difference = $final_quantity - $current_item['quantity'];
                // تحديث المخزون إذا كانت هناك تغييرات
                if ($difference != 0) {
                    $update_stmt = $conn->prepare("
                        UPDATE product_variants 
                        SET quantity = quantity - ? 
                        WHERE product_id = ? AND color = ? AND size = ?
                    ");
                    $update_stmt->execute([
                        $difference,
                        $current_item['product_id'],
                        $current_item['color'],
                        $current_item['size']
                    ]);
                }
                // تحديث كمية الطلب
                $update_order_stmt = $conn->prepare("
                    UPDATE order_items 
                    SET quantity = ? 
                    WHERE id = ?
                ");
                $update_order_stmt->execute([$final_quantity, $item_id]);
                // تسجيل في سجل التغييرات
                if ($difference != 0) {
                    $action = $difference > 0 ? 'increase' : 'decrease';
                    $log_stmt = $conn->prepare("
                        INSERT INTO stock_logs 
                        (order_id, product_id, quantity, action_type, description) 
                        VALUES (?, ?, ?, ?, ?)
                    ");
                    $log_desc = $difference > 0 ?
                        "زيادة كمية المنتج في الطلب #$order_id من {$current_item['quantity']} إلى $final_quantity" :
                        "تقليل كمية المنتج في الطلب #$order_id من {$current_item['quantity']} إلى $final_quantity";
                    $log_stmt->execute([
                        $order_id,
                        $current_item['product_id'],
                        abs($difference),
                        $action,
                        $log_desc
                    ]);
                }
            }
        }
        // تحديث السعر الإجمالي للطلب
        $total_stmt = $conn->prepare("
            UPDATE orders o
            JOIN (
                SELECT SUM(oi.price * oi.quantity) AS subtotal
                FROM order_items oi
                WHERE oi.order_id = ?
            ) items ON 1=1
            SET o.subtotal = items.subtotal,
                o.total_amount = items.subtotal + o.shipping_cost
            WHERE o.id = ?
        ");
        $total_stmt->execute([$order_id, $order_id]);
        $conn->commit();
        $_SESSION['success'] = "تم تحديث الطلب بنجاح";
    } catch (Exception $e) {
        $conn->rollBack();
        $_SESSION['error'] = "حدث خطأ أثناء تحديث الطلب: " . $e->getMessage();
    }
    header("Location: " . SITE_URL . "admin/order_details.php?id=" . $order_id);
    exit;
}
// تعيين عنوان الصفحة
$page_title = "تعديل عناصر الطلب #" . $order['id'];
?>
<?php include __DIR__ . '/../includes/admin_header.php'; ?>
<link rel="stylesheet" href="<?php echo SITE_URL; ?>assets/css/order_style.css">
<div class="admin-container">
    <div class="order-details-header">
        <h1 class="page-title">
            <i class="fas fa-edit"></i> تعديل عناصر الطلب #<?= $order['id'] ?>
        </h1>
        <div class="order-actions">
            <a href="<?php echo SITE_URL; ?>admin/order_details.php?id=<?= $order_id ?>" class="btn btn-outline">
                <i class="fas fa-arrow-left"></i> العودة إلى تفاصيل الطلب
            </a>
            <a href="<?php echo SITE_URL; ?>admin/add_order_item.php?id=<?= $order_id ?>" class="btn btn-blue">
                <i class="fas fa-plus"></i> إضافة منتج
            </a>
        </div>
    </div>
    <div class="order-items-section">
        <div class="order-items-table">
            <form method="post">
                <table>
                    <thead>
                        <tr>
                            <th>كود المنتج</th>
                            <th>الصورة</th>
                            <th>المنتج</th>
                            <th>السعر</th>
                            <th>الكمية</th>
                            <th>الإجمالي</th>
                            <th>حذف</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($order_items)): ?>
                            <?php foreach ($order_items as $item): ?>
                                <tr>
                                    <td class="product-sku"> <!-- الخلية الجديدة -->
                                        <?= !empty($item['sku']) ? htmlspecialchars($item['sku']) : '<span style="color: #999; font-style: italic;">N/A</span>' ?>
                                    </td>
                                    <td class="product-image">
                                        <?php if (!empty($item['image_url'])): ?>
                                            <img src="<?php echo SITE_URL; ?>assets/images/<?= htmlspecialchars($item['image_url']) ?>" alt="<?= htmlspecialchars($item['name']) ?>">
                                        <?php else: ?>
                                            <div class="no-image"><i class="fas fa-box-open"></i></div>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <small>اللون: <?= htmlspecialchars($item['color']) ?></small><br>
                                        <small>المقاس: <?= htmlspecialchars($item['size']) ?></small>
                                    </td>
                                    <td data-price="<?= $item['price'] ?>"><?= number_format($item['price'], 2) ?> ر.ي</td>
                                    <td>
                                        <div class="quantity-controls">
                                            <input type="number"
                                                name="items[<?= $item['id'] ?>][quantity]"
                                                value="0"
                                                min="-<?= $item['quantity'] ?>"
                                                max="<?= getAvailableQuantity($conn, $item['product_id'], $item['color'], $item['size']) ?>"
                                                class="order-quantity"
                                                data-current="<?= $item['quantity'] ?>"
                                                data-max="<?= getAvailableQuantity($conn, $item['product_id'], $item['color'], $item['size']) ?>"
                                                onchange="updateOrderQuantity(this)">
                                            <div class="quantity-info">
                                                <div class="order-qty">
                                                    <span class="info-label">الكمية الحالية:</span>
                                                    <span class="qty-value current-quantity"><?= $item['quantity'] ?></span>
                                                </div>
                                                <div class="new-qty">
                                                    <span class="info-label">الزيادة الجديدة:</span>
                                                    <span class="qty-value new-quantity">0</span>
                                                </div>
                                                <div class="available-qty">
                                                    <span class="info-label">المتاح في المخزن:</span>
                                                    <span class="qty-value available-quantity"><?= getAvailableQuantity($conn, $item['product_id'], $item['color'], $item['size']) ?></span>
                                                </div>
                                                <div class="total-qty" style="margin-top:5px; border-top:1px dashed #ccc; padding-top:5px;">
                                                    <span class="info-label">الإجمالي بعد التعديل:</span>
                                                    <span class="qty-value total-quantity"><?= $item['quantity'] ?></span>
                                                </div>
                                            </div>
                                            <input type="hidden" name="items[<?= $item['id'] ?>][final_quantity]" value="<?= $item['quantity'] ?>">
                                        </div>
                                    </td>
                                    <td><?= number_format($item['price'] * $item['quantity'], 2) ?> ر.ي</td>
                                    <td>
                                        <button type="submit" name="delete_item_id" value="<?= $item['id'] ?>" class="btn-delete" onclick="return confirm('هل تريد حذف هذا العنصر؟')">
                                            <i class="fas fa-trash-alt"></i>
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="6" class="text-center">لا توجد عناصر في هذا الطلب</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
                <?php if (!empty($order_items)): ?>
                    <div style="margin-top: 20px; text-align: left;">
                        <button type="submit" name="update_items" class="btn btn-pink">
                            <i class="fas fa-save"></i> حفظ التعديلات
                        </button>
                    </div>
                <?php endif; ?>
            </form>
        </div>
    </div>
</div>
<script>
    // دالة للتحقق من عدم تجاوز الكمية المتاحة
    function validateQuantity(input) {
        const max = parseInt(input.dataset.max);
        const requested = parseInt(input.value);
        const row = input.closest('tr');
        if (requested > max) {
            alert('الكمية المطلوبة (' + requested + ') تتجاوز الكمية المتاحة (' + max + ')!');
            input.value = max;
            updateQuantityDisplay(row, max);
            return false;
        }
        if (requested < 1) {
            alert('الكمية يجب أن تكون على الأقل 1!');
            input.value = 1;
            updateQuantityDisplay(row, 1);
            return false;
        }
        updateQuantityDisplay(row, requested);
        return true;
    }
    // تحديث عرض الكمية
    function updateQuantityDisplay(row, qty) {
        const qtyDisplay = row.querySelector('.order-qty .qty-value');
        if (qtyDisplay) {
            qtyDisplay.textContent = qty;
        }
    }
    // تعديل الحد الأقصى للكمية عند تغيير المقاس أو اللون
    document.querySelectorAll('.color-select, .size-select').forEach(select => {
        select.addEventListener('change', function() {
            const row = this.closest('tr');
            const quantityInput = row.querySelector('.order-quantity');
            const color = row.querySelector('.color-select').value;
            const size = row.querySelector('.size-select').value;
            const productId = row.querySelector('.color-select').dataset.product;
            const availableQtyDisplay = row.querySelector('.available-qty .qty-value');
            if (color && size) {
                fetch(`<?php echo SITE_URL; ?>admin/get_product_quantity.php?product_id=${productId}&color=${color}&size=${size}`)
                    .then(response => response.json())
                    .then(data => {
                        availableQtyDisplay.textContent = data.quantity;
                        quantityInput.dataset.max = data.quantity;
                        // إذا كانت الكمية الحالية أكبر من المتاح، تصحيحها
                        if (parseInt(quantityInput.value) > data.quantity) {
                            quantityInput.value = data.quantity;
                            updateQuantityDisplay(row, data.quantity);
                        }
                    });
            }
        });
    });
    // كود الكميه في الجدول 
    function updateOrderQuantity(input) {
        const row = input.closest('tr');
        const currentQty = parseInt(input.dataset.current);
        const newQty = parseInt(input.value) || 0; // تأكد من أن القيمة رقم
        const maxAvailable = parseInt(input.dataset.max);
        const minAllowed = -currentQty;

        // التحقق من القيم المدخلة
        if (newQty < minAllowed) {
            alert(`لا يمكن تقليل الكمية بأكثر من ${currentQty}`);
            input.value = minAllowed;
            updateQuantityDisplays(row, minAllowed, currentQty);
            return;
        }
        if (newQty > maxAvailable) {
            alert(`الكمية المطلوبة (${newQty}) تتجاوز الكمية المتاحة (${maxAvailable})!`);
            input.value = maxAvailable;
            updateQuantityDisplays(row, maxAvailable, currentQty);
            return;
        }
        updateQuantityDisplays(row, newQty, currentQty);
    }

    function updateQuantityDisplays(row, newQty, currentQty) {
        // تحديث عرض الكمية الجديدة
        const newQtyDisplay = row.querySelector('.new-quantity');
        newQtyDisplay.textContent = newQty;

        // حساب الكمية الإجمالية الجديدة
        const totalQty = currentQty + newQty;
        row.querySelector('.total-quantity').textContent = totalQty;

        // تحديث الحقل المخفي للكمية النهائية
        row.querySelector('input[name*="[final_quantity]"]').value = totalQty;

        // تحديث السعر الإجمالي
        updateTotalPrice(row, totalQty);

        // تلوين الكمية السالبة باللون الأحمر
        if (newQty < 0) {
            newQtyDisplay.classList.add('negative-qty');
        } else {
            newQtyDisplay.classList.remove('negative-qty');
        }
    }

    function updateTotalPrice(row, totalQty) {
        const priceCell = row.querySelector('td[data-price]');
        const price = parseFloat(priceCell.dataset.price);
        const totalPrice = (price * totalQty).toFixed(2);
        const totalCell = row.querySelector('td:nth-child(6)'); // العمود السادس هو عمود الإجمالي
        totalCell.textContent = totalPrice + ' ر.ي';
    }
</script>
<script src="<?php echo SITE_URL; ?>assets/js/coby_code_SKU.js"></script>
<?php
// دالة مساعدة للحصول على الكمية المتاحة
function getAvailableQuantity($conn, $product_id, $color, $size)
{
    $stmt = $conn->prepare("
        SELECT quantity 
        FROM product_variants 
        WHERE product_id = ? AND color = ? AND size = ?
    ");
    $stmt->execute([$product_id, $color, $size]);
    $quantity = $stmt->fetchColumn();
    return $quantity !== false ? $quantity : 0;
}
include __DIR__ . '/../includes/admin_footer.php'; ?>
<?php
require_once __DIR__ . '/../includes/db_connect.php';
require_once __DIR__ . '/../includes/auth.php';

// ✅ حماية: يجب أن يكون مديراً
checkAdminRole();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['method_name'];
    $account = $_POST['account_number'];

    $stmt = $conn->prepare("INSERT INTO payment_methods (method_name, account_number) VALUES (?, ?)");
    $stmt->execute([$name, $account]);

    header("Location: payment_methods.php");
    exit;
}

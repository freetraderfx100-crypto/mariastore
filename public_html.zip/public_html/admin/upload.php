<?php
session_start();
require_once '../includes/db_connect.php';
require_once __DIR__ . '/../includes/auth.php';

// التحقق من أن المستخدم مدير
checkAdminRole();

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['product_image'])) {
    $target_dir = "../assets/images/products/";
    $target_file = $target_dir . basename($_FILES["product_image"]["name"]);
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    // تحقق إذا كانت الصورة حقيقية
    $check = getimagesize($_FILES["product_image"]["tmp_name"]);
    if ($check === false) {
        echo "الملف ليس صورة.";
        $uploadOk = 0;
    }

    // تحقق من حجم الملف
    if ($_FILES["product_image"]["size"] > 500000) {
        echo "حجم الصورة كبير جداً.";
        $uploadOk = 0;
    }

    // السماح بأنواع معينة من الملفات
    if ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg") {
        echo "فقط ملفات JPG, JPEG, PNG مسموحة.";
        $uploadOk = 0;
    }

    if ($uploadOk == 1) {
        if (move_uploaded_file($_FILES["product_image"]["tmp_name"], $target_file)) {
            echo "تم رفع الملف: " . htmlspecialchars(basename($_FILES["product_image"]["name"]));

            // هنا يمكنك إضافة المنتج إلى قاعدة البيانات
            // $stmt = $conn->prepare("INSERT INTO products (...) VALUES (...)");
            // $stmt->execute([...]);
        } else {
            echo "عذراً، حدث خطأ أثناء رفع الملف.";
        }
    }
}

<?php
session_start();
require_once __DIR__ . '/../includes/db_connect.php';
require_once __DIR__ . '/../includes/functions.php';

// جلب الإحصائيات
try {
    // عدد المنتجات
    $products_stmt = $conn->query("SELECT COUNT(*) as total FROM products");
    $products_count = $products_stmt->fetch(PDO::FETCH_ASSOC)['total'];

    // عدد الطلبات
    $orders_stmt = $conn->query("SELECT COUNT(*) as total FROM orders");
    $orders_count = $orders_stmt->fetch(PDO::FETCH_ASSOC)['total'];

    // عدد العملاء
    $customers_stmt = $conn->query("SELECT COUNT(*) as total FROM users WHERE role = 'user'");
    $customers_count = $customers_stmt->fetch(PDO::FETCH_ASSOC)['total'];

    // إجمالي المبيعات
    $sales_stmt = $conn->query("SELECT SUM(total_amount) as total FROM orders WHERE status = 'completed'");
    $sales_total = $sales_stmt->fetch(PDO::FETCH_ASSOC)['total'] ?? 0;

    // إجمالي التكلفة للمبيعات المكتملة
    $cost_stmt = $conn->query("
        SELECT SUM(p.cost_price * oi.quantity) as total_cost 
        FROM order_items oi 
        JOIN products p ON oi.product_id = p.id 
        JOIN orders o ON oi.order_id = o.id 
        WHERE o.status = 'completed'
    ");
    $total_cost = $cost_stmt->fetch(PDO::FETCH_ASSOC)['total_cost'] ?? 0;

    // إجمالي تكلفة الشحن للمبيعات المكتملة
    $shipping_cost_stmt = $conn->query("
        SELECT SUM(shipping_cost) as total_shipping 
        FROM orders 
        WHERE status = 'completed'
    ");
    $total_shipping = $shipping_cost_stmt->fetch(PDO::FETCH_ASSOC)['total_shipping'] ?? 0;

    // حساب الربح الصافي (المبيعات - تكلفة المنتجات - تكلفة الشحن)
    $net_profit = $sales_total - $total_cost - $total_shipping;

    // أحدث الطلبات
    $recent_orders = $conn->query("SELECT o.*, u.username 
                                  FROM orders o
                                  JOIN users u ON o.user_id = u.id
                                  ORDER BY o.created_at DESC LIMIT 5")->fetchAll(PDO::FETCH_ASSOC);

    // المنتجات الأكثر مبيعاً
    $best_sellers = $conn->query("
    SELECT 
        p.name, 
        pi.image_url, 
        SUM(oi.quantity) AS total_sold
    FROM order_items oi
    JOIN products p ON oi.product_id = p.id
    JOIN orders o ON oi.order_id = o.id
    LEFT JOIN product_variants pi ON pi.product_id = p.id
        AND pi.id = (
            SELECT MIN(id) 
            FROM product_variants 
            WHERE product_id = p.id
        )
    WHERE o.status = 'completed'
    GROUP BY p.id, p.name, pi.image_url
    ORDER BY total_sold DESC
    LIMIT 5
")->fetchAll(PDO::FETCH_ASSOC);

    // المنتجات الأقل مبيعاً
    $worst_sellers = $conn->query("
    SELECT 
        p.name, 
        pi.image_url, 
        COALESCE(SUM(oi.quantity), 0) AS total_sold
    FROM products p
    LEFT JOIN order_items oi ON oi.product_id = p.id
    LEFT JOIN orders o ON oi.order_id = o.id AND o.status = 'completed'
    LEFT JOIN product_variants pi ON pi.product_id = p.id
        AND pi.id = (
            SELECT MIN(id) 
            FROM product_variants 
            WHERE product_id = p.id
        )
    GROUP BY p.id, p.name, pi.image_url
    ORDER BY total_sold ASC
    LIMIT 6
")->fetchAll(PDO::FETCH_ASSOC);


    // المنتجات القاربة على الانتهاء (الكمية أقل من أو تساوي 10)
    $low_stock_products = $conn->query("
    SELECT 
        p.name as product_name,
        pv.color,
        pv.size,
        pv.quantity,
        pv.image_url
    FROM product_variants pv
    JOIN products p ON pv.product_id = p.id
    WHERE pv.quantity <= 10
    ORDER BY pv.quantity ASC, p.name
    LIMIT 10
")->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("خطأ في قاعدة البيانات: " . $e->getMessage());
}

// تعيين عنوان الصفحة
$page_title = "لوحة التحكم";
?>

<?php include __DIR__ . '/../includes/admin_header.php'; ?>


<link rel="stylesheet" href="<?php echo SITE_URL; ?>assets/css/dash.css">



<div class="dashboard-container">
    <div class="dashboard-header">
        <h1><i class="fas fa-tachometer-alt"></i> لوحة التحكم</h1>
        <!-- <p>مرحباً <?= htmlspecialchars($_SESSION['user_name']) ?>، هذه نظرة عامة على متجرك</p> -->
    </div>

    <!-- بطاقات الإحصائيات -->
    <div class="stats-cards">
        <!-- البطاقات الحالية -->
        <div class="stat-card">
            <div class="stat-icon" style="background-color: #ff6b81;">
                <i class="fas fa-box-open"></i>
            </div>
            <div class="stat-info">
                <h3>المنتجات</h3>
                <span><?= number_format($products_count) ?></span>
                <a href="<?php echo SITE_URL; ?>admin/manage_products.php">عرض الكل <i class="fas fa-arrow-left"></i></a>
            </div>
        </div>

        <div class="stat-card">
            <div class="stat-icon" style="background-color: #2ed573;">
                <i class="fas fa-shopping-cart"></i>
            </div>
            <div class="stat-info">
                <h3>الطلبات</h3>
                <span><?= number_format($orders_count) ?></span>
                <a href="<?php echo SITE_URL; ?>admin/orders.php">عرض الكل <i class="fas fa-arrow-left"></i></a>
            </div>
        </div>

        <div class="stat-card">
            <div class="stat-icon" style="background-color: #1e90ff;">
                <i class="fas fa-users"></i>
            </div>
            <div class="stat-info">
                <h3>العملاء</h3>
                <span><?= number_format($customers_count) ?></span>
                <a href="<?php echo SITE_URL; ?>admin/customers.php">عرض الكل <i class="fas fa-arrow-left"></i></a>
            </div>
        </div>

        <div class="stat-card">
            <div class="stat-icon" style="background-color: #ffa502;">
                <i class="fas fa-money-bill-wave"></i>
            </div>
            <div class="stat-info">
                <h3>إجمالي المبيعات</h3>
                <span><?= number_format($sales_total, 2) ?> ر.ي</span>
                <a href="<?php echo SITE_URL; ?>admin/reports.php">عرض التقارير <i class="fas fa-arrow-left"></i></a>
            </div>
        </div>

        <!-- بطاقة الربح الصافي الجديدة -->
        <div class="stat-card">
            <div class="stat-icon" style="background-color: <?= $net_profit >= 0 ? '#28a745' : '#dc3545' ?>;">
                <i class="fas fa-chart-line"></i>
            </div>
            <div class="stat-info">
                <h3>الربح الصافي</h3>
                <span class="<?= $net_profit >= 0 ? 'positive-profit' : 'negative-profit' ?>">
                    <?= number_format($net_profit, 2) ?> ر.ي
                </span>
                <a href="<?php echo SITE_URL; ?>admin/reports.php">عرض التفاصيل <i class="fas fa-arrow-left"></i></a>
            </div>
        </div>
    </div>

    <!-- قسم الطلبات الحديثة والمنتجات الأكثر مبيعاً والاقل مبيعا-->
    <div class="dashboard-sections">
        <!-- قسم تفاصيل الربح -->
        <div class="dashboard-section">
            <div class="section-header">
                <h3><i class="fas fa-chart-pie"></i> تحليل الربحية</h3>
            </div>
            <div class="section-content">
                <div class="profit-analysis">
                    <div class="profit-item">
                        <span class="profit-label">إجمالي المبيعات:</span>
                        <span class="profit-value"><?= number_format($sales_total, 2) ?> ر.ي</span>
                    </div>
                    <div class="profit-item">
                        <span class="profit-label">تكلفة المنتجات:</span>
                        <span class="profit-value">-<?= number_format($total_cost, 2) ?> ر.ي</span>
                    </div>
                    <div class="profit-item">
                        <span class="profit-label">تكلفة الشحن:</span>
                        <span class="profit-value">-<?= number_format($total_shipping, 2) ?> ر.ي</span>
                    </div>
                    <div class="profit-item total-profit">
                        <span class="profit-label">الربح الصافي:</span>
                        <span class="profit-value <?= $net_profit >= 0 ? 'positive-profit' : 'negative-profit' ?>">
                            <?= number_format($net_profit, 2) ?> ر.ي
                        </span>
                    </div>
                    <?php if ($sales_total > 0): ?>
                        <div class="profit-item">
                            <span class="profit-label">هامش الربح:</span>
                            <span class="profit-value">
                                <?= number_format(($net_profit / $sales_total) * 100, 2) ?>%
                            </span>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="best-sellers-section">
            <h3><i class="fas fa-star"></i> المنتجات الأكثر مبيعاً</h3>
            <?php if (!empty($best_sellers)): ?>
                <div class="best-sellers-list">
                    <?php foreach ($best_sellers as $product): ?>
                        <div class="best-seller-item">
                            <div class="product-image">
                                <?php if (!empty($product['image_url'])): ?>
                                    <img src="<?php echo SITE_URL; ?>assets/images/<?= htmlspecialchars($product['image_url']) ?>"
                                        alt="<?= htmlspecialchars($product['name']) ?>">
                                <?php else: ?>
                                    <div class="no-image">
                                        <i class="fas fa-box-open"></i>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <div class="product-info">
                                <h4><?= htmlspecialchars($product['name']) ?></h4>
                                <p>تم بيع <strong><?= $product['total_sold'] ?></strong> قطعة</p>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <p>لا توجد بيانات عن المنتجات الأكثر مبيعاً.</p>
            <?php endif; ?>
        </div>
        <div class="worst-sellers-section">
            <h3><i class="fas fa-arrow-down"></i> المنتجات الأقل مبيعاً</h3>
            <?php if (!empty($worst_sellers)): ?>
                <div class="best-sellers-list">
                    <?php foreach ($worst_sellers as $product): ?>
                        <div class="best-seller-item">
                            <div class="product-image">
                                <?php if (!empty($product['image_url'])): ?>
                                    <img src="<?php echo SITE_URL; ?>assets/images/<?= htmlspecialchars($product['image_url']) ?>"
                                        alt="<?= htmlspecialchars($product['name']) ?>">
                                <?php else: ?>
                                    <div class="no-image">
                                        <i class="fas fa-box-open"></i>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <div class="product-info">
                                <h4><?= htmlspecialchars($product['name']) ?></h4>
                                <p>تم بيع <strong><?= $product['total_sold'] ?></strong> قطعة</p>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <p>لا توجد بيانات عن المنتجات الأقل مبيعاً.</p>
            <?php endif; ?>
        </div>


    </div>

    <!-- قسم جديد للمنتجات القاربة على الانتهاء -->
    <div class="dashboard-section low-stock-section">
        <div class="section-header">
            <h3><i class="fas fa-exclamation-triangle"></i> المنتجات القاربة على النفاذ</h3>
            <a href="<?php echo SITE_URL; ?>admin/manage_products.php" class="btn btn-outline">إدارة المنتجات</a>
        </div>
        <div class="section-content">
            <?php if (!empty($low_stock_products)): ?>
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>الصورة</th>
                            <th>اسم المنتج</th>
                            <th>اللون</th>
                            <th>المقاس</th>
                            <th>الكمية المتبقية</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($low_stock_products as $product): ?>
                            <tr class="<?= $product['quantity'] == 0 ? 'out-of-stock' : ($product['quantity'] <= 5 ? 'very-low-stock' : 'low-stock') ?>">
                                <td>
                                    <?php if (!empty($product['image_url'])): ?>
                                        <img src="<?php echo SITE_URL; ?>assets/images/<?= htmlspecialchars($product['image_url']) ?>"
                                            alt="<?= htmlspecialchars($product['product_name']) ?>"
                                            class="product-thumbnail">
                                    <?php else: ?>
                                        <div class="no-image-thumbnail">
                                            <i class="fas fa-box-open"></i>
                                        </div>
                                    <?php endif; ?>
                                </td>
                                <td><?= htmlspecialchars($product['product_name']) ?></td>
                                <td><?= !empty($product['color']) ? htmlspecialchars($product['color']) : '---' ?></td>
                                <td><?= !empty($product['size']) ? htmlspecialchars($product['size']) : '---' ?></td>
                                <td>
                                    <span class="quantity-badge <?= $product['quantity'] == 0 ? 'out-of-stock' : ($product['quantity'] <= 5 ? 'very-low' : 'low') ?>">
                                        <?= $product['quantity'] == 0 ? 'نفذ' : $product['quantity'] ?>
                                    </span>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div class="empty-state">
                    <i class="fas fa-check-circle fa-2x"></i>
                    <p>لا توجد منتجات قاربة على النفاذ</p>
                </div>
            <?php endif; ?>
        </div>
    </div>


</div>

<?php include __DIR__ . '/../includes/admin_footer.php'; ?>
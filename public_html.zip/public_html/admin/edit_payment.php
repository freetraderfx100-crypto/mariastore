<?php
require_once __DIR__ . '/../includes/db_connect.php';
require_once __DIR__ . '/../includes/auth.php';

// ✅ حماية: يجب أن يكون مديراً
checkAdminRole();

$id = $_GET['id'] ?? null;

if (!$id) {
    header("Location: payment_methods.php");
    exit;
}

// جلب الوسيلة
$stmt = $conn->prepare("SELECT * FROM payment_methods WHERE id=?");
$stmt->execute([$id]);
$method = $stmt->fetch();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['method_name'];
    $account = $_POST['account_number'];
    $status = isset($_POST['is_active']) ? 1 : 0;

    $stmt = $conn->prepare("UPDATE payment_methods SET method_name=?, account_number=?, is_active=? WHERE id=?");
    $stmt->execute([$name, $account, $status, $id]);

    header("Location: payment_methods.php");
    exit;
}
include __DIR__ . '/../includes/admin_header.php';

?>
<form method="post">
    <input type="text" name="method_name" value="<?= htmlspecialchars($method['method_name']) ?>" required>
    <input type="text" name="account_number" value="<?= htmlspecialchars($method['account_number']) ?>" required>
    <label><input type="checkbox" name="is_active" <?= $method['is_active'] ? 'checked' : '' ?>> مفعل</label>
    <button type="submit">حفظ التعديلات</button>
</form>
<?php
require_once __DIR__ . '/../includes/db_connect.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

// بدء الجلسة إذا لم تكن بدأت الجلسه بدات في ملف auth.php

// التحقق من أن المستخدم مدير
checkAdminRole();

$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT) ?? 0;

if (!$id) {
    $_SESSION['error'] = "معرف التصنيف غير صحيح";
    header("Location: " . SITE_URL . "admin/manage_categories.php");
    exit();
}

try {
    // جلب معلومات التصنيف لمعرفة إذا كان لديه صورة
    $stmt = $conn->prepare("SELECT image FROM categories WHERE id = ?");
    $stmt->execute([$id]);
    $category = $stmt->fetch();

    if (!$category) {
        $_SESSION['error'] = "التصنيف غير موجود";
        header("Location: " . SITE_URL . "admin/manage_categories.php");
        exit();
    }

    // التحقق من وجود منتجات مرتبطة بالقسم الرئيسي أو الفرعي
    $stmt = $conn->prepare("SELECT COUNT(*) FROM products WHERE category_id = ? OR category_id IN (SELECT id FROM categories WHERE parent_id = ?)");
    $stmt->execute([$id, $id]);
    $has_products = $stmt->fetchColumn();

    if ($has_products) {
        $_SESSION['error'] = "لا يمكن حذف هذا التصنيف لأنه أو أحد تصنيفاته الفرعية مرتبط بمنتجات";
        header("Location: " . SITE_URL . "admin/manage_categories.php");
        exit();
    }

    // جلب جميع التصنيفات الفرعية لمعرفة إذا كان لديهم صور
    $stmt = $conn->prepare("SELECT id, image FROM categories WHERE parent_id = ?");
    $stmt->execute([$id]);
    $sub_categories = $stmt->fetchAll();

    // بدء المعاملة
    $conn->beginTransaction();

    // حذف صور التصنيفات الفرعية أولاً
    foreach ($sub_categories as $sub_category) {
        if (!empty($sub_category['image'])) {
            $image_path = __DIR__ . '/../assets/images/uploads/categories/' . $sub_category['image'];
            if (file_exists($image_path)) {
                unlink($image_path);
            }
        }
    }

    // حذف الأقسام الفرعية
    $stmt = $conn->prepare("DELETE FROM categories WHERE parent_id = ?");
    $stmt->execute([$id]);

    // حذف صورة التصنيف الرئيسي إذا كانت موجودة
    if (!empty($category['image'])) {
        $image_path = __DIR__ . '/../assets/images/uploads/categories/' . $category['image'];
        if (file_exists($image_path)) {
            unlink($image_path);
        }
    }

    // حذف القسم الرئيسي
    $stmt = $conn->prepare("DELETE FROM categories WHERE id = ?");
    $stmt->execute([$id]);

    $conn->commit();

    $_SESSION['success'] = "تم حذف القسم الرئيسي وأقسامه الفرعية بنجاح";
} catch (PDOException $e) {
    if (isset($conn) && $conn->inTransaction()) {
        $conn->rollBack();
    }
    $_SESSION['error'] = "خطأ في الحذف: " . $e->getMessage();
} catch (Exception $e) {
    if (isset($conn) && $conn->inTransaction()) {
        $conn->rollBack();
    }
    $_SESSION['error'] = "خطأ في حذف الصور: " . $e->getMessage();
}

header("Location: " . SITE_URL . "admin/manage_categories.php");
exit();

<?php
session_start();
require_once __DIR__ . '/../includes/db_connect.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

// التحقق من أن المستخدم مدير
checkAdminRole();

$errors = [];
$success = false;

// بعد نجاح إضافة تصنيف جديد
if ($success && isset($_GET['return_to'])) {
    echo "<script>
        if (window.opener && !window.opener.closed) {
            window.opener.location.reload();
            window.close();
        }
    </script>";
    exit;
}

// جلب جميع التصنيفات
try {
    $stmt = $conn->query("SELECT c.*, COUNT(p.id) as products_count 
                         FROM categories c
                         LEFT JOIN products p ON c.id = p.category_id
                         GROUP BY c.id
                         ORDER BY c.name");
    $categories = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("خطأ في جلب التصنيفات: " . $e->getMessage());
}

// معالجة إضافة تصنيف جديد
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_category'])) {
    $name = trim(filter_input(INPUT_POST, 'name', FILTER_SANITIZE_FULL_SPECIAL_CHARS));
    $description = trim(filter_input(INPUT_POST, 'description', FILTER_SANITIZE_FULL_SPECIAL_CHARS));
    $slug = toSlug($name);

    if (empty($name)) {
        $errors[] = "اسم التصنيف مطلوب";
    }

    if (empty($errors)) {
        try {
            // التحقق من عدم تكرار اسم التصنيف
            $check_stmt = $conn->prepare("SELECT COUNT(*) FROM categories WHERE name = ? OR slug = ?");
            $check_stmt->execute([$name, $slug]);
            $exists = $check_stmt->fetchColumn();

            if ($exists) {
                $errors[] = "هذا التصنيف موجود بالفعل";
            } else {
                $stmt = $conn->prepare("INSERT INTO categories (name, slug, description, created_at, updated_at) 
                                      VALUES (?, ?, ?, NOW(), NOW())");
                $stmt->execute([$name, $slug, $description]);
                $success = "تم إضافة التصنيف بنجاح";

                // إعادة تحميل التصنيفات
                $stmt = $conn->query("SELECT c.*, COUNT(p.id) as products_count 
                                     FROM categories c
                                     LEFT JOIN products p ON c.id = p.category_id
                                     GROUP BY c.id
                                     ORDER BY c.name");
                $categories = $stmt->fetchAll(PDO::FETCH_ASSOC);
            }
        } catch (PDOException $e) {
            if ($e->getCode() == 23000) {
                $errors[] = "هذا التصنيف موجود بالفعل";
            } else {
                $errors[] = "خطأ في إضافة التصنيف: " . $e->getMessage();
            }
        }
    }
}

// معالجة تحديث التصنيف
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_category'])) {
    $id = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);
    $name = trim(filter_input(INPUT_POST, 'name', FILTER_SANITIZE_FULL_SPECIAL_CHARS));
    $description = trim(filter_input(INPUT_POST, 'description', FILTER_SANITIZE_FULL_SPECIAL_CHARS));

    if (empty($name)) {
        $errors[] = "اسم التصنيف مطلوب";
    }

    if (empty($errors)) {
        try {
            // التحقق من عدم تكرار اسم التصنيف
            $check_stmt = $conn->prepare("SELECT COUNT(*) FROM categories WHERE (name = ? OR slug = ?) AND id != ?");
            $slug = toSlug($name);
            $check_stmt->execute([$name, $slug, $id]);
            $exists = $check_stmt->fetchColumn();

            if ($exists) {
                $errors[] = "هذا التصنيف موجود بالفعل";
            } else {
                $stmt = $conn->prepare("UPDATE categories SET 
                                      name = ?, 
                                      description = ?,
                                      slug = ?,
                                      updated_at = NOW()
                                      WHERE id = ?");
                $stmt->execute([$name, $description, $slug, $id]);
                $success = "تم تحديث التصنيف بنجاح";

                // إعادة تحميل التصنيفات
                $stmt = $conn->query("SELECT c.*, COUNT(p.id) as products_count 
                                     FROM categories c
                                     LEFT JOIN products p ON c.id = p.category_id
                                     GROUP BY c.id
                                     ORDER BY c.name");
                $categories = $stmt->fetchAll(PDO::FETCH_ASSOC);
            }
        } catch (PDOException $e) {
            $errors[] = "خطأ في تحديث التصنيف: " . $e->getMessage();
        }
    }
}

// معالجة حذف التصنيف
if (isset($_GET['delete'])) {
    $id = filter_input(INPUT_GET, 'delete', FILTER_VALIDATE_INT);

    try {
        // التحقق من عدم وجود منتجات مرتبطة بهذا التصنيف
        $stmt = $conn->prepare("SELECT COUNT(*) FROM products WHERE category_id = ?");
        $stmt->execute([$id]);
        $product_count = $stmt->fetchColumn();

        if ($product_count > 0) {
            $errors[] = "لا يمكن حذف التصنيف لأنه مرتبط بمنتجات موجودة";
        } else {
            $stmt = $conn->prepare("DELETE FROM categories WHERE id = ?");
            $stmt->execute([$id]);
            $success = "تم حذف التصنيف بنجاح";

            // إعادة تحميل التصنيفات
            $stmt = $conn->query("SELECT c.*, COUNT(p.id) as products_count 
                                 FROM categories c
                                 LEFT JOIN products p ON c.id = p.category_id
                                 GROUP BY c.id
                                 ORDER BY c.name");
            $categories = $stmt->fetchAll(PDO::FETCH_ASSOC);
        }
    } catch (PDOException $e) {
        $errors[] = "خطأ في حذف التصنيف: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إدارة التصنيفات | متجرنا</title>
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>assets/css/admin.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
        }

        .modal-content {
            background-color: #fff;
            margin: 5% auto;
            padding: 20px;
            border-radius: 5px;
            width: 60%;
            max-width: 600px;
        }

        .close-modal {
            float: left;
            font-size: 24px;
            cursor: pointer;
        }

        .category-actions {
            white-space: nowrap;
        }

        .slug-display {
            color: #666;
            font-size: 12px;
            direction: ltr;
        }

        .products-count {
            background: #ff6b81;
            color: white;
            padding: 2px 6px;
            border-radius: 10px;
            font-size: 12px;
        }
    </style>
</head>

<body>
    <?php include __DIR__ . '/../includes/admin_header.php'; ?>

    <div class="admin-container">
        <h1 class="page-title"><i class="fas fa-tags"></i> إدارة التصنيفات</h1>

        <?php if ($success): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i> <?= $success ?>
            </div>
        <?php endif; ?>

        <?php if (!empty($errors)): ?>
            <div class="alert alert-danger">
                <h4><i class="fas fa-exclamation-triangle"></i> حدثت الأخطاء التالية:</h4>
                <ul>
                    <?php foreach ($errors as $error): ?>
                        <li><?= $error ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <div class="card">
            <h2><i class="fas fa-plus-circle"></i> إضافة تصنيف جديد</h2>
            <form method="post" class="category-form">
                <div class="form-row">
                    <div class="form-group">
                        <label for="name">اسم التصنيف <span class="required">*</span></label>
                        <input type="text" id="name" name="name" required>
                    </div>

                    <div class="form-group">
                        <label for="description">وصف التصنيف</label>
                        <textarea id="description" name="description" rows="2"></textarea>
                    </div>

                    <div class="form-group">
                        <button type="submit" name="add_category" class="btn btn-pink">
                            <i class="fas fa-save"></i> إضافة تصنيف
                        </button>
                    </div>
                </div>
            </form>
        </div>

        <div class="card">
            <h2><i class="fas fa-list"></i> قائمة التصنيفات</h2>

            <?php if (empty($categories)): ?>
                <p>لا توجد تصنيفات مضافة</p>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>اسم التصنيف</th>
                                <th>الوصف</th>
                                <th>عدد المنتجات</th>
                                <th>تاريخ الإنشاء</th>
                                <th>آخر تحديث</th>
                                <th>الإجراءات</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($categories as $category): ?>
                                <tr>
                                    <td><?= $category['id'] ?></td>
                                    <td>
                                        <?= htmlspecialchars($category['name']) ?>
                                        <div class="slug-display"><?= $category['slug'] ?></div>
                                    </td>
                                    <td><?= htmlspecialchars($category['description']) ?: '-' ?></td>
                                    <td class="text-center">
                                        <span class="products-count"><?= $category['products_count'] ?></span>
                                    </td>
                                    <td><?= date('Y-m-d H:i', strtotime($category['created_at'])) ?></td>
                                    <td><?= date('Y-m-d H:i', strtotime($category['updated_at'])) ?></td>
                                    <td class="category-actions">
                                        <button class="btn-action btn-edit" onclick="openEditModal(
                                            <?= $category['id'] ?>, 
                                            '<?= htmlspecialchars($category['name'], ENT_QUOTES) ?>',
                                            '<?= htmlspecialchars($category['description'], ENT_QUOTES) ?>'
                                        )">
                                            <i class="fas fa-edit"></i> تعديل
                                        </button>
                                        <?php if ($category['products_count'] == 0): ?>
                                            <a href="<?php echo SITE_URL; ?>admin/categories.php?delete=<?= $category['id'] ?>" class="btn-action btn-delete" onclick="return confirm('هل أنت متأكد من حذف هذا التصنيف؟')">
                                                <i class="fas fa-trash-alt"></i> حذف
                                            </a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Modal لتعديل التصنيف -->
    <div id="editModal" class="modal">
        <div class="modal-content">
            <span class="close-modal" onclick="closeEditModal()">&times;</span>
            <h2><i class="fas fa-edit"></i> تعديل التصنيف</h2>
            <form method="post" id="editForm">
                <input type="hidden" name="id" id="edit_id">

                <div class="form-group">
                    <label for="edit_name">اسم التصنيف <span class="required">*</span></label>
                    <input type="text" id="edit_name" name="name" required>
                </div>

                <div class="form-group">
                    <label for="edit_description">وصف التصنيف</label>
                    <textarea id="edit_description" name="description" rows="3"></textarea>
                </div>

                <div class="form-actions">
                    <button type="submit" name="update_category" class="btn btn-pink">
                        <i class="fas fa-save"></i> حفظ التعديلات
                    </button>
                    <button type="button" class="btn btn-outline" onclick="closeEditModal()">
                        <i class="fas fa-times"></i> إلغاء
                    </button>
                </div>
            </form>
        </div>
    </div>

    <?php include __DIR__ . '/../includes/admin_footer.php'; ?>

    <script>
        // فتح نافذة التعديل
        function openEditModal(id, name, description) {
            document.getElementById('edit_id').value = id;
            document.getElementById('edit_name').value = name;
            document.getElementById('edit_description').value = description || '';
            document.getElementById('editModal').style.display = 'block';
        }

        // إغلاق نافذة التعديل
        function closeEditModal() {
            document.getElementById('editModal').style.display = 'none';
        }

        // إغلاق النافذة عند النقر خارجها
        window.onclick = function(event) {
            const modal = document.getElementById('editModal');
            if (event.target == modal) {
                closeEditModal();
            }
        }
    </script>
</body>

</html>
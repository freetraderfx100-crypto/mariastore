<?php
require_once __DIR__ . '/../includes/db_connect.php';
require_once __DIR__ . '/../vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\IOFactory;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['excel_file'])) {
    $file = $_FILES['excel_file']['tmp_name'];

    try {
        $spreadsheet = IOFactory::load($file);
        $sheet = $spreadsheet->getActiveSheet();
        $rows = $sheet->toArray();

        // تخطي السطر الأول (العناوين)
        for ($i = 1; $i < count($rows); $i++) {
            list(
                $name,
                $description,
                $price,
                $quantity,
                $main_category_id,
                $sub_category_id,
                $sizes,
                $colors,
                $images
            ) = $rows[$i];

            // التحقق من البيانات الأساسية
            if (empty($name) || empty($price) || empty($quantity) || empty($main_category_id)) {
                continue; // تجاهل الصف إذا كانت البيانات ناقصة
            }

            // إدخال المنتج
            $stmt = $conn->prepare("INSERT INTO products (name, description, price, stock_quantity, category_id, created_at, is_active)
                                   VALUES (?, ?, ?, ?, ?, NOW(), 1)");
            $stmt->execute([
                $name,
                $description,
                $price,
                $quantity,
                $sub_category_id ?: $main_category_id,
            ]);

            $product_id = $conn->lastInsertId();

            // إدخال الصور
            $image_list = array_map('trim', explode(',', $images));
            $color_list = array_map('trim', explode(',', $colors));

            foreach ($image_list as $index => $image_name) {
                // if (!file_exists(__DIR__ . '/../assets/images/products/' . $image_name)) {
                //     continue; // تجاهل الصور غير الموجودة
                // }
                $color = $color_list[$index] ?? null;
                $is_main = $index === 0 ? 1 : 0;

                $stmt_img = $conn->prepare("INSERT INTO product_images (product_id, image_url, is_main, created_at, color)
                                            VALUES (?, ?, ?, NOW(), ?)");
                $stmt_img->execute([$product_id, $image_name, $is_main, $color]);
            }

            // إدخال المقاسات
            $size_list = array_map('trim', explode(',', $sizes));
            foreach ($size_list as $size) {
                if (!empty($size)) {
                    $stmt_size = $conn->prepare("INSERT INTO product_sizes (product_id, size) VALUES (?, ?)");
                    $stmt_size->execute([$product_id, $size]);
                }
            }
        }

        echo "<p style='color:green'>تم استيراد المنتجات بنجاح.</p>";
    } catch (Exception $e) {
        echo "<p style='color:red'>حدث خطأ أثناء الاستيراد: " . $e->getMessage() . "</p>";
    }
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">

<head>
    <meta charset="UTF-8">
    <title>استيراد المنتجات</title>
</head>

<body>
    <h2>رفع ملف Excel</h2>
    <form method="post" enctype="multipart/form-data">
        <input type="file" name="excel_file" accept=".xlsx, .xls" required>
        <button type="submit">استيراد</button>
    </form>
</body>

</html>
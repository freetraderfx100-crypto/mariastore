<?php
/**
 * admin/diagnose_push.php
 * --------------------------------------------------------------------
 * صفحة تشخيص شاملة لنظام Web Push
 *
 * ✅ محمية بـ checkAdminRole() - فقط المدير يمكنه الوصول
 *
 * تتحقق من:
 *   1. إعدادات Web Push (VAPID keys, web_push_enabled)
 *   2. عدد الاشتراكات النشطة
 *   3. حالة الإشعارات المعلّقة (is_sent=0)
 *   4. آخر سجلات cron (push_notifications.log)
 *   5. اختبار إرسال فعلي لإشعار تجريبي
 *   6. فحص ملفات النظام (push_web.php, sw.js, notifications.js)
 * --------------------------------------------------------------------
 */

require_once __DIR__ . '/../includes/db_connect.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/notifications.php';

checkAdminRole();

$diag_results = [];
$test_notif_id = null;

// ============================================================
// 1. إعدادات Web Push
// ============================================================
$diag_results['settings'] = [
    'title' => 'إعدادات Web Push',
    'items' => [],
];

try {
    $notifMgr = new NotificationsManager($conn);

    $web_push_enabled = $notifMgr->getSetting('web_push_enabled', '0');
    $vapid_public = $notifMgr->getSetting('vapid_public_key', '');
    $vapid_private = $notifMgr->getSetting('vapid_private_key', '');
    $vapid_subject = $notifMgr->getSetting('vapid_subject', '');

    $diag_results['settings']['items'][] = [
        'label' => 'Web Push مفعّل',
        'value' => $web_push_enabled === '1' ? '✅ نعم' : '❌ لا',
        'ok' => $web_push_enabled === '1',
        'hint' => $web_push_enabled !== '1' ? 'فعّل Web Push من الإعدادات' : '',
    ];

    $diag_results['settings']['items'][] = [
        'label' => 'VAPID Public Key',
        'value' => strlen($vapid_public) . ' حرف (المطلوب: 87)',
        'ok' => strlen($vapid_public) === 87,
        'hint' => strlen($vapid_public) !== 87 ? 'المفتاح غير صحيح. أعد توليده' : '',
    ];

    $diag_results['settings']['items'][] = [
        'label' => 'VAPID Private Key',
        'value' => strlen($vapid_private) . ' حرف (المطلوب: 43)',
        'ok' => strlen($vapid_private) === 43,
        'hint' => strlen($vapid_private) !== 43 ? 'المفتاح غير صحيح. أعد توليده' : '',
    ];

    $diag_results['settings']['items'][] = [
        'label' => 'VAPID Subject',
        'value' => $vapid_subject ?: '❌ فارغ',
        'ok' => !empty($vapid_subject),
        'hint' => empty($vapid_subject) ? 'أضف mailto:admin@mariastore1.com' : '',
    ];

} catch (Exception $e) {
    $diag_results['settings']['items'][] = [
        'label' => 'خطأ',
        'value' => $e->getMessage(),
        'ok' => false,
    ];
}

// ============================================================
// 2. الاشتراكات
// ============================================================
$diag_results['subscriptions'] = [
    'title' => 'الاشتراكات (push_subscriptions)',
    'items' => [],
];

try {
    $total_subs = $conn->query("SELECT COUNT(*) FROM push_subscriptions")->fetchColumn();
    $active_subs = $conn->query("SELECT COUNT(*) FROM push_subscriptions WHERE is_active = 1")->fetchColumn();
    $inactive_subs = $total_subs - $active_subs;
    $recent_subs = $conn->query("SELECT COUNT(*) FROM push_subscriptions WHERE created_at > DATE_SUB(NOW(), INTERVAL 7 DAY)")->fetchColumn();

    $diag_results['subscriptions']['items'][] = [
        'label' => 'إجمالي الاشتراكات',
        'value' => $total_subs,
        'ok' => $total_subs > 0,
    ];

    $diag_results['subscriptions']['items'][] = [
        'label' => 'اشتراكات نشطة',
        'value' => $active_subs,
        'ok' => $active_subs > 0,
        'hint' => $active_subs == 0 ? '⚠️ لا يوجد مشتركين نشطين! افتح الموقع من هاتفك وفعّل الإشعارات' : '',
    ];

    $diag_results['subscriptions']['items'][] = [
        'label' => 'اشتراكات معطّلة',
        'value' => $inactive_subs,
        'ok' => true,
    ];

    $diag_results['subscriptions']['items'][] = [
        'label' => 'اشتراكات آخر 7 أيام',
        'value' => $recent_subs,
        'ok' => $recent_subs > 0,
        'hint' => $recent_subs == 0 ? '⚠️ لا اشتراكات جديدة! ربما زر "تفعيل الإشعارات" لا يعمل' : '',
    ];

    // آخر 5 اشتراكات
    $recent = $conn->query("SELECT id, user_id, LEFT(endpoint, 50) as ep, is_active, created_at, last_used_at FROM push_subscriptions ORDER BY id DESC LIMIT 5")->fetchAll(PDO::FETCH_ASSOC);

    $diag_results['subscriptions']['recent'] = $recent;

} catch (Exception $e) {
    $diag_results['subscriptions']['items'][] = [
        'label' => 'خطأ',
        'value' => $e->getMessage(),
        'ok' => false,
    ];
}

// ============================================================
// 3. حالة الإشعارات
// ============================================================
$diag_results['notifications'] = [
    'title' => 'حالة الإشعارات',
    'items' => [],
];

try {
    $total_notifs = $conn->query("SELECT COUNT(*) FROM notifications")->fetchColumn();
    $pending = $conn->query("SELECT COUNT(*) FROM notifications WHERE is_sent = 0")->fetchColumn();
    $sent = $conn->query("SELECT COUNT(*) FROM notifications WHERE is_sent = 1")->fetchColumn();
    $last_24h_pending = $conn->query("SELECT COUNT(*) FROM notifications WHERE is_sent = 0 AND created_at > DATE_SUB(NOW(), INTERVAL 24 HOUR)")->fetchColumn();

    $diag_results['notifications']['items'][] = [
        'label' => 'إجمالي الإشعارات',
        'value' => $total_notifs,
        'ok' => true,
    ];

    $diag_results['notifications']['items'][] = [
        'label' => 'إشعارات مرسلة (is_sent=1)',
        'value' => $sent,
        'ok' => true,
    ];

    $diag_results['notifications']['items'][] = [
        'label' => 'إشعارات معلّقة (is_sent=0)',
        'value' => $pending,
        'ok' => $pending == 0,
        'hint' => $pending > 0 ? "⚠️ {$pending} إشعار بانتظار cron. لو >0 دائماً = cron لا يعمل!" : '',
    ];

    $diag_results['notifications']['items'][] = [
        'label' => 'معلّقة آخر 24 ساعة',
        'value' => $last_24h_pending,
        'ok' => $last_24h_pending == 0,
        'hint' => $last_24h_pending > 0 ? '⚠️ cron لم يعالج هذه الإشعارات!' : '',
    ];

    // آخر 5 إشعارات مع حالتها
    $recent_notifs = $conn->query("SELECT id, type, title, is_sent, created_at FROM notifications ORDER BY id DESC LIMIT 5")->fetchAll(PDO::FETCH_ASSOC);
    $diag_results['notifications']['recent'] = $recent_notifs;

} catch (Exception $e) {
    $diag_results['notifications']['items'][] = [
        'label' => 'خطأ',
        'value' => $e->getMessage(),
        'ok' => false,
    ];
}

// ============================================================
// 4. فحص ملفات النظام
// ============================================================
$diag_results['files'] = [
    'title' => 'فحص ملفات النظام',
    'items' => [],
];

$required_files = [
    'includes/push_web.php' => 'دوال Web Push (تشفير + VAPID JWT)',
    'includes/notifications.php' => 'NotificationsManager class',
    'api/notifications.php' => 'REST API للإشعارات',
    'assets/js/notifications.js' => 'عميل الإشعارات (JS)',
    'sw.js' => 'Service Worker',
    'cron/send_push_notifications.php' => 'cron job لإرسال Push',
    'assets/icons/icon-192.png' => 'أيقونة الإشعار 192x192',
    'assets/icons/badge-72.png' => 'أيقونة شريط الحالة 72x72',
];

foreach ($required_files as $file => $desc) {
    $full_path = __DIR__ . '/../' . $file;
    $exists = file_exists($full_path);
    $size = $exists ? filesize($full_path) : 0;

    $diag_results['files']['items'][] = [
        'label' => $file,
        'value' => $exists ? "{$size} bytes ✓" : '❌ مفقود',
        'ok' => $exists,
        'hint' => !$exists ? "⚠️ {$desc}" : '',
    ];
}

// ============================================================
// 5. سجل cron (آخر 20 سطر)
// ============================================================
$diag_results['cron_log'] = [
    'title' => 'سجل cron (آخر 20 سطر)',
    'log_exists' => false,
    'lines' => [],
];

$cron_log_path = __DIR__ . '/../cron/push_notifications.log';
if (file_exists($cron_log_path)) {
    $diag_results['cron_log']['log_exists'] = true;
    $diag_results['cron_log']['size'] = filesize($cron_log_path);
    $diag_results['cron_log']['modified'] = date('Y-m-d H:i:s', filemtime($cron_log_path));

    // قراءة آخر 20 سطر
    $lines = file($cron_log_path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    $diag_results['cron_log']['lines'] = array_slice($lines, -20);

    // هل الـ log حديث (آخر ساعة)؟
    $last_modified = filemtime($cron_log_path);
    $is_recent = (time() - $last_modified) < 3600;
    $diag_results['cron_log']['is_recent'] = $is_recent;
    $diag_results['cron_log']['hint'] = $is_recent
        ? '✅ cron يعمل (آخر تحديث خلال ساعة)'
        : '⚠️ cron لا يعمل! آخر تحديث: ' . date('Y-m-d H:i:s', $last_modified);
} else {
    $diag_results['cron_log']['hint'] = '❌ ملف log غير موجود = cron لم يعمل أبداً!';
}

// ============================================================
// 6. اختبار إرسال فعلي (لو طُلب)
// ============================================================
if (isset($_GET['test_send']) && $_GET['test_send'] == '1') {
    try {
        $notifMgr = new NotificationsManager($conn);

        // ✅ v2.5: نوع الإشعار يكون new_product (مثل add_product.php تماماً)
        // حتى نختبر نفس المسار الذي يستخدمه الموقع فعلياً
        $test_notif_id = $notifMgr->create([
            'type' => 'new_product',
            'title' => '🎉 منتج جديد!',
            'body' => 'تمت إضافة منتج جديد: اختبار من diagnose_push.php في ' . date('H:i:s'),
            'url' => SITE_URL,
            'icon' => 'fa-box',
            'target_audience' => 'all',
            'send_push' => false,
        ]);

        // ✅ إرسال مباشر للاشتراكات النشطة
        $subscriptions = $notifMgr->getActiveSubscriptions();
        $test_results = [
            'notif_id' => $test_notif_id,
            'subscriptions_count' => count($subscriptions),
            'sent' => 0,
            'failed' => 0,
            'errors' => [],
        ];

        if (count($subscriptions) > 0) {
            require_once __DIR__ . '/../includes/push_web.php';

            foreach ($subscriptions as $sub) {
                $result = sendWebPushNotification($sub, $test_notif_id, $conn);
                if ($result === true) {
                    $test_results['sent']++;
                } else {
                    $test_results['failed']++;
                    // ✅ v2.3: رسالة الخطأ المفصّلة من FCM
                    $err_msg = is_string($result) ? $result : 'Unknown error';
                    $test_results['errors'][] = "sub#{$sub['id']} (user=" . ($sub['user_id'] ?? 'NULL') . "): {$err_msg}";
                }
            }

            // ✅ فقط حدّث is_sent=1 لو نجح واحد على الأقل
            if ($test_results['sent'] > 0) {
                $stmt = $conn->prepare("UPDATE notifications SET is_sent = 1 WHERE id = ?");
                $stmt->execute([$test_notif_id]);
            }
        }

        $diag_results['test_send'] = $test_results;

    } catch (Exception $e) {
        $diag_results['test_send'] = ['error' => $e->getMessage()];
    }
}

// ============================================================
// 6.2. اختبار شامل: إنشاء + إرسال فعلي + عرض النتيجة (لو طُلب)
// ============================================================
if (isset($_GET['full_test']) && $_GET['full_test'] == '1') {
    try {
        $notifMgr = new NotificationsManager($conn);

        // 1. إنشاء إشعار جديد (نوع new_product)
        $test_notif_id = $notifMgr->create([
            'type' => 'new_product',
            'title' => '🎉 منتج جديد!',
            'body' => 'اختبار شامل: ' . date('H:i:s'),
            'url' => SITE_URL,
            'icon' => 'fa-box',
            'target_audience' => 'all',
            'send_push' => false,
        ]);

        // 2. إرسال فعلي مباشر (بدون انتظار cron)
        require_once __DIR__ . '/../includes/push_web.php';
        $subscriptions = $notifMgr->getActiveSubscriptions();
        $sent = 0;
        $failed = 0;
        $details = [];

        foreach ($subscriptions as $sub) {
            $result = sendWebPushNotification($sub, $test_notif_id, $conn);
            if ($result === true) {
                $sent++;
                $details[] = "✅ sub#{$sub['id']} (user=" . ($sub['user_id'] ?? 'NULL') . ")";
            } else {
                $failed++;
                $err_msg = is_string($result) ? $result : 'Unknown';
                $details[] = "❌ sub#{$sub['id']} (user=" . ($sub['user_id'] ?? 'NULL') . "): {$err_msg}";
            }
        }

        // 3. تحديث is_sent لو نجح واحد على الأقل
        if ($sent > 0) {
            $stmt = $conn->prepare("UPDATE notifications SET is_sent = 1 WHERE id = ?");
            $stmt->execute([$test_notif_id]);
        }

        $diag_results['full_test'] = [
            'notif_id' => $test_notif_id,
            'subscriptions_count' => count($subscriptions),
            'sent' => $sent,
            'failed' => $failed,
            'details' => $details,
            'hint' => $sent > 0
                ? "✅ نجح إرسال {$sent} إشعار! تحقق من جهازك (Chrome مفتوح أو في System Tray)"
                : "❌ فشل كل الإرسالات. راجع التفاصيل أعلاه.",
        ];

    } catch (Exception $e) {
        $diag_results['full_test'] = ['error' => $e->getMessage()];
    }
}

// ============================================================
// 6.5. تشغيل cron يدوياً (لو طُلب)
// ============================================================
if (isset($_GET['run_cron']) && $_GET['run_cron'] == '1') {
    try {
        // ✅ استدعاء cron_runner.php داخلياً (بدون HTTP)
        $cron_file = __DIR__ . '/../cron/send_push_notifications.php';
        if (file_exists($cron_file)) {
            // تعريف الثوابت المطلوبة لـ cron
            $isCli = php_sapi_name() === 'cli';
            // تجاوز فحص الـ key لأننا من admin
            $_GET['key'] = 'ADMIN_INTERNAL_CALL';

            // capture output
            ob_start();
            // تنفيذ الكرون مباشرة
            $cron_results = [
                'started_at' => date('Y-m-d H:i:s'),
                'output' => '',
                'success' => false,
            ];

            // بدلاً من include (قد يسبب مشاكل)، نستخدم file_get_contents عبر HTTP
            $cron_url = SITE_URL . 'cron/cron_runner.php?key=' . urlencode(env('CRON_SECRET_KEY', ''));
            $context = stream_context_create([
                'http' => [
                    'timeout' => 120,
                    'method' => 'GET',
                ]
            ]);
            $response = @file_get_contents($cron_url, false, $context);

            if ($response !== false) {
                $decoded = json_decode($response, true);
                $cron_results['response'] = $decoded;
                $cron_results['success'] = isset($decoded['success']) && $decoded['success'];
                $cron_results['raw_response'] = substr($response, 0, 2000);
            } else {
                $cron_results['error'] = 'فشل الاتصال بـ cron_runner.php';
                $cron_results['hint'] = 'تأكد أن CRON_SECRET_KEY مضبوط في .env';
                $last_error = error_get_last();
                if ($last_error) {
                    $cron_results['php_error'] = $last_error['message'];
                }
            }

            ob_end_clean();
            $diag_results['run_cron'] = $cron_results;
        }
    } catch (Exception $e) {
        $diag_results['run_cron'] = ['error' => $e->getMessage()];
    }
}

// ============================================================
// 7. إعدادات الخادم
// ============================================================
$diag_results['server'] = [
    'title' => 'إعدادات الخادم',
    'items' => [],
];

$diag_results['server']['items'][] = [
    'label' => 'PHP Version',
    'value' => PHP_VERSION,
    'ok' => version_compare(PHP_VERSION, '7.4.0', '>='),
];

$diag_results['server']['items'][] = [
    'label' => 'OpenSSL Extension',
    'value' => extension_loaded('openssl') ? '✅ متوفر' : '❌ غير متوفر',
    'ok' => extension_loaded('openssl'),
    'hint' => !extension_loaded('openssl') ? 'مطلوب لتشفير AES128GCM' : '',
];

$diag_results['server']['items'][] = [
    'label' => 'cURL Extension',
    'value' => extension_loaded('curl') ? '✅ متوفر' : '❌ غير متوفر',
    'ok' => extension_loaded('curl'),
    'hint' => !extension_loaded('curl') ? 'مطلوب لإرسال طلبات HTTP لـ FCM' : '',
];

$diag_results['server']['items'][] = [
    'label' => 'HTTPS',
    'value' => (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || ($_SERVER['SERVER_PORT'] ?? '') == 443 ? '✅ مفعّل' : '❌ غير مفعّل',
    'ok' => (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || ($_SERVER['SERVER_PORT'] ?? '') == 443,
    'hint' => '⚠️ Web Push يتطلب HTTPS إلزامياً' ,
];

$diag_results['server']['items'][] = [
    'label' => 'SITE_URL',
    'value' => SITE_URL,
    'ok' => true,
];

// ============================================================
// عرض الصفحة
// ============================================================
include __DIR__ . '/../includes/admin_header.php';
?>

<div class="content-wrapper">
    <div class="container-fluid">
        <h2 class="mt-4 mb-4">
            <i class="fas fa-stethoscope text-primary"></i>
            تشخيص شامل لنظام Web Push
        </h2>

        <?php if (isset($diag_results['test_send'])): ?>
            <div class="alert alert-info">
                <h5><i class="fas fa-flask"></i> نتيجة اختبار الإرسال المباشر</h5>
                <?php if (isset($diag_results['test_send']['error'])): ?>
                    <div class="text-danger">❌ خطأ: <?= htmlspecialchars($diag_results['test_send']['error']) ?></div>
                <?php else: ?>
                    <ul class="mb-0">
                        <li>إشعار ID: <strong>#<?= $diag_results['test_send']['notif_id'] ?></strong></li>
                        <li>عدد الاشتراكات النشطة: <strong><?= $diag_results['test_send']['subscriptions_count'] ?></strong></li>
                        <li class="text-success">✅ تم الإرسال: <strong><?= $diag_results['test_send']['sent'] ?></strong></li>
                        <li class="text-danger">❌ فشل: <strong><?= $diag_results['test_send']['failed'] ?></strong></li>
                    </ul>
                    <?php if (!empty($diag_results['test_send']['errors'])): ?>
                        <details class="mt-2">
                            <summary>تفاصيل الأخطاء</summary>
                            <pre class="small"><?php foreach ($diag_results['test_send']['errors'] as $err) echo htmlspecialchars($err) . "\n"; ?></pre>
                        </details>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <?php if (isset($diag_results['run_cron'])): ?>
            <div class="alert alert-warning">
                <h5><i class="fas fa-cogs"></i> نتيجة تشغيل cron يدوياً</h5>
                <?php if (isset($diag_results['run_cron']['error'])): ?>
                    <div class="text-danger">❌ خطأ: <?= htmlspecialchars($diag_results['run_cron']['error']) ?></div>
                <?php elseif (isset($diag_results['run_cron']['success']) && $diag_results['run_cron']['success']): ?>
                    <ul class="mb-0">
                        <li class="text-success">✅ تم تشغيل cron بنجاح</li>
                        <?php if (isset($diag_results['run_cron']['response']['summary'])): ?>
                            <?php $s = $diag_results['run_cron']['response']['summary']; ?>
                            <li>الإشعارات المعلّقة: <strong><?= $s['pending_count'] ?></strong></li>
                            <li>الاشتراكات النشطة: <strong><?= $s['subscriptions_count'] ?></strong></li>
                            <li class="text-success">✅ تم إرسال: <strong><?= $s['sent'] ?></strong></li>
                            <li class="text-danger">❌ فشل: <strong><?= $s['failed'] ?></strong></li>
                            <li>تخطي (>6h): <strong><?= $s['skipped'] ?></strong></li>
                            <li>المدة: <strong><?= $diag_results['run_cron']['response']['duration_seconds'] ?> ثانية</strong></li>
                        <?php endif; ?>
                    </ul>
                    <?php if (!empty($diag_results['run_cron']['response']['results'])): ?>
                        <details class="mt-2">
                            <summary>تفاصيل كل إشعار</summary>
                            <pre class="small bg-light p-2"><?php
                                foreach ($diag_results['run_cron']['response']['results'] as $r) {
                                    echo "Notif #{$r['notif_id']}: {$r['status']} (sent: {$r['sent_to']}, failed: {$r['failed']})\n";
                                    if (!empty($r['errors'])) {
                                        foreach (array_slice($r['errors'], 0, 2) as $err) {
                                            echo "  └─ $err\n";
                                        }
                                    }
                                }
                            ?></pre>
                        </details>
                    <?php endif; ?>
                <?php else: ?>
                    <div class="text-danger">❌ فشل تشغيل cron</div>
                    <?php if (!empty($diag_results['run_cron']['error'])): ?>
                        <div>خطأ: <?= htmlspecialchars($diag_results['run_cron']['error']) ?></div>
                    <?php endif; ?>
                    <?php if (!empty($diag_results['run_cron']['php_error'])): ?>
                        <div class="small">PHP Error: <?= htmlspecialchars($diag_results['run_cron']['php_error']) ?></div>
                    <?php endif; ?>
                    <?php if (!empty($diag_results['run_cron']['hint'])): ?>
                        <div class="small text-muted">💡 <?= htmlspecialchars($diag_results['run_cron']['hint']) ?></div>
                    <?php endif; ?>
                    <?php if (!empty($diag_results['run_cron']['raw_response'])): ?>
                        <details class="mt-2">
                            <summary>الإجابة الخام</summary>
                            <pre class="small"><?= htmlspecialchars($diag_results['run_cron']['raw_response']) ?></pre>
                        </details>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <?php if (isset($diag_results['full_test'])): ?>
            <div class="alert alert-success">
                <h5><i class="fas fa-vial"></i> 🎯 نتيجة الاختبار الشامل (إرسال فوري بدون انتظار cron)</h5>
                <?php if (isset($diag_results['full_test']['error'])): ?>
                    <div class="text-danger">❌ خطأ: <?= htmlspecialchars($diag_results['full_test']['error']) ?></div>
                <?php else: ?>
                    <ul class="mb-0">
                        <li>إشعار ID: <strong>#<?= $diag_results['full_test']['notif_id'] ?></strong></li>
                        <li>عدد الاشتراكات النشطة: <strong><?= $diag_results['full_test']['subscriptions_count'] ?></strong></li>
                        <li class="text-success">✅ تم الإرسال: <strong><?= $diag_results['full_test']['sent'] ?></strong></li>
                        <li class="text-danger">❌ فشل: <strong><?= $diag_results['full_test']['failed'] ?></strong></li>
                        <li><strong><?= $diag_results['full_test']['hint'] ?></strong></li>
                    </ul>
                    <?php if (!empty($diag_results['full_test']['details'])): ?>
                        <details class="mt-2">
                            <summary>تفاصيل كل اشتراك</summary>
                            <pre class="small bg-light p-2"><?php
                                foreach ($diag_results['full_test']['details'] as $line) {
                                    echo htmlspecialchars($line) . "\n";
                                }
                            ?></pre>
                        </details>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <!-- أزرار الاختبار -->
        <div class="mb-4 d-flex gap-2 flex-wrap">
            <a href="?full_test=1" class="btn btn-primary btn-lg" onclick="return confirm('🚀 سيتم إنشاء إشعار منتج جديد وإرساله فوراً لكل المشتركين بدون انتظار cron. متابعة؟')">
                <i class="fas fa-rocket"></i> 🎯 اختبار شامل فوري (منتج جديد)
            </a>
            <a href="?test_send=1" class="btn btn-success" onclick="return confirm('سيتم إرسال إشعار تجريبي لكل المشتركين النشطين. متابعة؟')">
                <i class="fas fa-paper-plane"></i> إرسال إشعار تجريبي مباشر
            </a>
            <a href="?run_cron=1" class="btn btn-warning" onclick="return confirm('سيتم تشغيل cron يدوياً لإرسال كل الإشعارات المعلّقة. قد يستغرق عدة ثوان. متابعة؟')">
                <i class="fas fa-cogs"></i> تشغيل cron يدوياً الآن
            </a>
        </div>

        <?php foreach ($diag_results as $section_key => $section): ?>
            <div class="card mb-4">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0">
                        <i class="fas fa-<?= $section_key === 'settings' ? 'cog' : ($section_key === 'subscriptions' ? 'users' : ($section_key === 'notifications' ? 'bell' : ($section_key === 'files' ? 'file-code' : ($section_key === 'cron_log' ? 'history' : 'server')))) ?>"></i>
                        <?= $section['title'] ?>
                    </h5>
                </div>
                <div class="card-body">
                    <?php if ($section_key === 'cron_log'): ?>
                        <?php if ($section['log_exists']): ?>
                            <p>
                                <strong>حجم الملف:</strong> <?= number_format($section['size']) ?> bytes |
                                <strong>آخر تحديث:</strong> <?= $section['modified'] ?>
                            </p>
                            <p class="<?= strpos($section['hint'], '✅') !== false ? 'text-success' : 'text-warning' ?>">
                                <?= $section['hint'] ?>
                            </p>
                            <pre class="bg-dark text-light p-3" style="max-height: 300px; overflow-y: auto; direction: ltr; text-align: left;"><?php
                                foreach ($section['lines'] as $line) {
                                    echo htmlspecialchars($line) . "\n";
                                }
                            ?></pre>
                        <?php else: ?>
                            <div class="alert alert-danger mb-0"><?= $section['hint'] ?></div>
                        <?php endif; ?>
                    <?php elseif (isset($section['recent'])): ?>
                        <table class="table table-sm table-striped">
                            <tbody>
                                <?php foreach ($section['items'] as $item): ?>
                                    <tr>
                                        <td style="width: 50%"><?= htmlspecialchars($item['label']) ?></td>
                                        <td class="<?= $item['ok'] ? 'text-success' : 'text-danger' ?>">
                                            <?= $item['value'] ?>
                                            <?php if (!empty($item['hint'])): ?>
                                                <br><small class="text-warning"><?= $item['hint'] ?></small>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>

                        <?php if ($section_key === 'subscriptions' && !empty($section['recent'])): ?>
                            <h6 class="mt-3">آخر 5 اشتراكات:</h6>
                            <div class="table-responsive">
                                <table class="table table-sm">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>User</th>
                                            <th>Endpoint</th>
                                            <th>Active</th>
                                            <th>Created</th>
                                            <th>Last Used</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($section['recent'] as $s): ?>
                                            <tr>
                                                <td><?= $s['id'] ?></td>
                                                <td><?= $s['user_id'] ?? 'NULL' ?></td>
                                                <td dir="ltr" style="font-size: 10px;"><?= htmlspecialchars($s['ep']) ?>...</td>
                                                <td><?= $s['is_active'] ? '✅' : '❌' ?></td>
                                                <td><?= $s['created_at'] ?></td>
                                                <td><?= $s['last_used_at'] ?? 'NULL' ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php elseif ($section_key === 'notifications' && !empty($section['recent'])): ?>
                            <h6 class="mt-3">آخر 5 إشعارات:</h6>
                            <div class="table-responsive">
                                <table class="table table-sm">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Type</th>
                                            <th>Title</th>
                                            <th>Sent</th>
                                            <th>Created</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($section['recent'] as $n): ?>
                                            <tr>
                                                <td><?= $n['id'] ?></td>
                                                <td><span class="badge badge-info"><?= htmlspecialchars($n['type']) ?></span></td>
                                                <td><?= htmlspecialchars(mb_substr($n['title'], 0, 40)) ?></td>
                                                <td><?= $n['is_sent'] ? '✅' : '⏳' ?></td>
                                                <td><?= $n['created_at'] ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php endif; ?>
                    <?php else: ?>
                        <table class="table table-sm table-striped mb-0">
                            <tbody>
                                <?php foreach ($section['items'] as $item): ?>
                                    <tr>
                                        <td style="width: 50%"><?= htmlspecialchars($item['label']) ?></td>
                                        <td class="<?= $item['ok'] ? 'text-success' : 'text-danger' ?>">
                                            <?= $item['value'] ?>
                                            <?php if (!empty($item['hint'])): ?>
                                                <br><small class="text-warning"><?= $item['hint'] ?></small>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; ?>

        <!-- دليل إعداد cron على Hostinger -->
        <div class="card mb-4">
            <div class="card-header bg-danger text-white">
                <h5 class="mb-0"><i class="fas fa-exclamation-triangle"></i> ⚠️ خطوة مطلوبة: إعداد cron job على Hostinger</h5>
            </div>
            <div class="card-body">
                <p class="alert alert-warning">
                    <strong>الحالة الحالية:</strong> cron لا يعمل على استضافتك!
                    بدون cron، Web Push لن يصل والمتصفح مغلق.
                    لديك <strong><?= $diag_results['notifications']['items'][2]['value'] ?? '?' ?> إشعار</strong> بانتظار المعالجة.
                </p>

                <h6 class="mt-3">📋 الطريقة 1: Hostinger hPanel (موصى به)</h6>
                <ol>
                    <li>سجّل دخول لـ <a href="https://hpanel.hostinger.com" target="_blank">hPanel Hostinger</a></li>
                    <li>اذهب إلى: <strong>Hosting → الإدارة → متقدم → Cron Jobs</strong></li>
                    <li>اضغط <strong>"Create Cron Job"</strong></li>
                    <li>اختر <strong>"Custom"</strong> في الخيارات</li>
                    <li>في حقل <strong>Command</strong>، الصق:
                        <pre class="bg-dark text-light p-2" dir="ltr">php /home/u905256684/public_html/cron/send_push_notifications.php</pre>
                    </li>
                    <li>في <strong>Schedule</strong>، اختر: <strong>"Every 5 minutes"</strong></li>
                    <li>اضغط <strong>"Save"</strong></li>
                </ol>

                <h6 class="mt-3">📋 الطريقة 2: HTTP cron (للباقات التي لا تدعم CLI cron)</h6>
                <p>استخدم خدمة cron خارجية مجانية:</p>
                <ol>
                    <li>سجّل في <a href="https://cron-job.org" target="_blank">cron-job.org</a> (مجاني)</li>
                    <li>أضف cron job جديد:</li>
                    <li>في حقل <strong>URL</strong>، الصق:
                        <pre class="bg-dark text-light p-2" dir="ltr">https://mariastore1.com/cron/cron_runner.php?key=MariaStore_Cron_2026_SecretKey_a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6</pre>
                    </li>
                    <li>في <strong>Schedule</strong>، اختر: <strong>"Every 5 minutes"</strong></li>
                    <li>احفظ. سيقوم الموقع بإرسال الإشعارات تلقائياً.</li>
                </ol>

                <h6 class="mt-3">📋 الطريقة 3: استخدام زر "تشغيل cron يدوياً"</h6>
                <p>كحل مؤقت، يمكنك الضغط على الزر أعلاه كلما أردت إرسال الإشعارات المعلّقة.
                لكن هذا ليس حلاً دائماً - يجب إعداد cron للعمل التلقائي.</p>

                <div class="alert alert-info mt-3">
                    <strong>💡 ملاحظة:</strong> بعد إعداد cron، ارجع لهذه الصفحة بعد 10 دقائق.
                    يجب أن تجد أن "آخر تحديث" لسجل cron أصبح حديثاً (خلال آخر ساعة).
                </div>
            </div>
        </div>

        <!-- دليل الحلول الشائعة -->
        <div class="card mb-4">
            <div class="card-header bg-warning">
                <h5 class="mb-0"><i class="fas fa-lightbulb"></i> دليل الحلول الشائعة</h5>
            </div>
            <div class="card-body">
                <h6>⚠️ لو Web Push لا يصل والمتصفح مغلق:</h6>
                <ol>
                    <li><strong>تأكد أن cron job مفعّل</strong> - اتبع الخطوات في القسم الأحمر أعلاه</li>
                    <li><strong>تأكد أن Web Push مفعّل</strong> من <a href="notification_settings.php">صفحة الإعدادات</a></li>
                    <li><strong>تأكد أن لديك اشتراكات نشطة</strong> (الأعلى = 0؟ افتح الموقع من هاتفك وفعّل الإشعارات)</li>
                    <li><strong>تأكد أن VAPID keys صحيحة</strong> (Public=87 حرف، Private=43 حرف)</li>
                    <li><strong>تأكد أن الموقع HTTPS</strong> (Web Push يتطلب HTTPS إلزامياً)</li>
                </ol>

                <h6 class="mt-3">⚠️ قيود Web Push (لا يمكن تجاوزها):</h6>
                <ul>
                    <li><strong>iOS Safari:</strong> لا يدعم Web Push (إلا في PWA mode بعد iOS 16.4)</li>
                    <li><strong>متصفح مغلق تماماً على موبايل:</strong> الـ OS قد يمنع إيقاظ المتصفح</li>
                    <li><strong>كمبيوتر في وضع Sleep:</strong> لا يمكن استقبال الإشعارات</li>
                    <li><strong>متصفح في وضع Incognito:</strong> Service Worker لا يعمل</li>
                </ul>

                <h6 class="mt-3">📋 خطوات اختبار سريعة:</h6>
                <ol>
                    <li>افتح الموقع من <strong>Chrome على ديسكتوب</strong></li>
                    <li>اضغط على أيقونة الجرس 🔔 → اسمح بالإشعارات</li>
                    <li>تأكد أن الاشتراك ظهر في جدول <code>push_subscriptions</code></li>
                    <li>اضغط زر "إرسال إشعار تجريبي مباشر" أعلى هذه الصفحة</li>
                    <li>يجب أن يظهر الإشعار فوراً (حتى لو المتصفح في تبويب آخر)</li>
                    <li>أغلق المتصفح بالكامل → انتظر 5 دقائق → يجب أن يصل الإشعار كـ System Notification</li>
                </ol>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>

<?php
// upload_excel.php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_FILES['excel_file']) && $_FILES['excel_file']['error'] === UPLOAD_ERR_OK) {
        $uploadDir = __DIR__ . '/../uploads/';
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }

        $fileTmpPath = $_FILES['excel_file']['tmp_name'];
        $fileName = 'products.xlsx'; // نستخدم اسمًا ثابتًا ليسهل قراءته لاحقًا
        $destPath = $uploadDir . $fileName;

        if (move_uploaded_file($fileTmpPath, $destPath)) {
            header("Location: " . SITE_URL . "admin/import_products.php?success=1");
            exit;
        } else {
            $error = "فشل في رفع الملف.";
        }
    } else {
        $error = "يرجى اختيار ملف Excel صالح.";
    }
}
?>
<!-- 
<!DOCTYPE html>
<html lang="ar" dir="rtl">

<head>
    <meta charset="UTF-8">
    <title>رفع ملف Excel</title>
    <style>
        body {
            font-family: Arial;
            padding: 20px;
            background: #f2f2f2;
        }

        form {
            background: white;
            padding: 20px;
            border-radius: 10px;
            width: 400px;
            margin: auto;
        }

        input[type="file"] {
            margin-bottom: 15px;
        }

        .success {
            color: green;
            margin-top: 15px;
        }

        .error {
            color: red;
            margin-top: 15px;
        }
    </style>
</head>

<body>
    <form action="" method="post" enctype="multipart/form-data">
        <h3>رفع ملف المنتجات (Excel)</h3>
        <input type="file" name="excel_file" accept=".xls,.xlsx" required>
        <br>
        <button type="submit">رفع الملف واستيراده</button>

        <?php if (isset($_GET['success'])): ?>
            <p class="success">✅ تم رفع الملف بنجاح! جاري الاستيراد...</p>
        <?php elseif (isset($error)): ?>
            <p class="error">❌ <?= $error ?></p>
        <?php endif; ?>
    </form>
</body>

</html> -->

<h1 style="text-align: center;">Soon</h1>
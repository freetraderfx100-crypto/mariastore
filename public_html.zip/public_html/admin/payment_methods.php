<?php
session_start();
require_once __DIR__ . '/../includes/db_connect.php';
require_once __DIR__ . '/../includes/auth.php';

checkAdminRole();

// جلب الوسائل من قاعدة البيانات
$stmt = $conn->query("SELECT * FROM payment_methods ORDER BY id DESC");
$methods = $stmt->fetchAll(PDO::FETCH_ASSOC);
include __DIR__ . '/../includes/admin_header.php';

?>

<!DOCTYPE html>
<html lang="ar">

<head>
    <meta charset="UTF-8">
    <title>إدارة وسائل الدفع</title>
    <!-- <link rel="stylesheet" href="<?php echo SITE_URL; ?>assets/css/admin.css"> -->
     
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>assets/css/customers.css">

    <style>
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }

        th,
        td {
            border: 1px solid #ccc;
            padding: 10px;
            text-align: center;
        }

        form {
            margin: 20px 0;
        }

        input[type=text] {
            padding: 5px;
            width: 200px;
        }

        button {
            padding: 6px 12px;
            cursor: pointer;
        }
    </style>
</head>

<body>
    <h2>إدارة وسائل الدفع</h2>

    <!-- نموذج إضافة -->
    <form method="post" action="save_payment.php">
        <input type="text" name="method_name" placeholder="اسم المحفظة / البنك" required>
        <input type="text" name="account_number" placeholder="رقم الحساب" required>
        <button type="submit">إضافة</button>
    </form>

    <!-- عرض الوسائل -->
    <table>
        <tr>
            <th>الاسم</th>
            <th>رقم الحساب</th>
            <th>الحالة</th>
            <th>إجراءات</th>
        </tr>
        <?php foreach ($methods as $m): ?>
            <tr>
                <td><?= htmlspecialchars($m['method_name']) ?></td>
                <td><?= htmlspecialchars($m['account_number']) ?></td>
                <td><?= $m['is_active'] ? 'مفعل' : 'معطل' ?></td>
                <td>
                    <a href="edit_payment.php?id=<?= $m['id'] ?>">تعديل</a>

                </td>
            </tr>
        <?php endforeach; ?>
    </table>
</body>

</html>
<?php
// require_once __DIR__ . '/../../includes/db_connect.php';

// header('Content-Type: application/json');

// if (!isset($_GET['product_id']) || !isset($_GET['color'])) {
//     echo json_encode(['sizes' => []]);
//     exit;
// }

// $product_id = (int)$_GET['product_id'];
// $color = $_GET['color'];

// $stmt = $conn->prepare("
//     SELECT DISTINCT size 
//     FROM product_variants 
//     WHERE product_id = ? AND color = ?
//     ORDER BY size
// ");
// $stmt->execute([$product_id, $color]);
// $sizes = $stmt->fetchAll(PDO::FETCH_COLUMN);

// echo json_encode(['sizes' => $sizes]);
// ملغي للتاكد

<?php
require_once __DIR__ . '/../includes/db_connect.php';

$search = $_GET['search'] ?? '';
$role = $_GET['role'] ?? '';

$sql = "SELECT id, username, email, role, avatar, is_active, created_at FROM users WHERE 1=1";
$params = [];

if (!empty($search)) {
    $sql .= " AND (username LIKE ? OR email LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

if (!empty($role)) {
    $sql .= " AND role = ?";
    $params[] = $role;
}

$sql .= " ORDER BY id DESC";

$stmt = $conn->prepare($sql);
$stmt->execute($params);
$customers = $stmt->fetchAll(PDO::FETCH_ASSOC);

foreach ($customers as $user): ?>
    <tr>
        <td>
            <?php if (!empty($user['avatar'])): ?>
                <img src="<?php echo SITE_URL; ?>assets/images/users/avatars/<?= htmlspecialchars($user['avatar']) ?>" alt="avatar" class="product-thumbnail">
            <?php else: ?>
                <img src="<?php echo SITE_URL; ?>assets/images/default-avatar.png" alt="default" class="product-thumbnail">
            <?php endif; ?>
        </td>
        <td><?= htmlspecialchars($user['username']) ?></td>
        <td><?= htmlspecialchars($user['email']) ?></td>
        <td><?= htmlspecialchars($user['role']) ?></td>
        <td><?= $user['is_active'] ? '✅ مفعل' : '⛔ غير مفعل' ?></td>
        <td><?= htmlspecialchars($user['created_at']) ?></td>
        <td class="actions">
            <a href="<?php echo SITE_URL; ?>admin/edit_customer.php?id=<?= $user['id'] ?>" class="edit">تعديل</a>
            <a href="<?php echo SITE_URL; ?>admin/delete_customer.php?id=<?= $user['id'] ?>" class="delete" onclick="return confirm('هل أنت متأكد من حذف هذا العميل؟');">حذف</a>
            <?php if ($user['is_active']): ?>
                <a href="<?php echo SITE_URL; ?>admin/toggle_status.php?id=<?= $user['id'] ?>&action=deactivate" class="delete">تعطيل</a>
            <?php else: ?>
                <a href="<?php echo SITE_URL; ?>admin/toggle_status.php?id=<?= $user['id'] ?>&action=activate" class="edit">تفعيل</a>
            <?php endif; ?>
        </td>
    </tr>
<?php endforeach; ?>
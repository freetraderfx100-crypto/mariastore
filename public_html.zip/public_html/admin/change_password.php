<?php
require_once '../includes/db_connect.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

// ✅ حماية: يجب أن يكون مديراً
checkAdminRole();

$user_id = $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $current_password = $_POST['current_password'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];

    // التحقق من كلمة المرور الحالية
    $stmt = $conn->prepare("SELECT password FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch();

    if (!password_verify($current_password, $user['password'])) {
        $_SESSION['error_message'] = "كلمة المرور الحالية غير صحيحة";
    } elseif ($new_password !== $confirm_password) {
        $_SESSION['error_message'] = "كلمة المرور الجديدة غير متطابقة";
    } else {
        // تحديث كلمة المرور
        $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
        $stmt = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
        if ($stmt->execute([$hashed_password, $user_id])) {
            $_SESSION['success_message'] = "تم تغيير كلمة المرور بنجاح";
            header("Location: " . SITE_URL . "admin/profile.php");
            ob_end_flush(); // إفراغ buffer وإرسال headers
            exit();
        }
    }
}
ob_end_clean(); // تنظيف buffer بدون إرسال المحتوى
require_once '../includes/admin_header.php';

?>

<style>
    /* تنسيقات الملف الشخصي */
    .avatar-upload {
        margin-bottom: 20px;
    }

    .avatar-preview {
        width: 150px;
        height: 150px;
        margin: 0 auto;
        border-radius: 50%;
        overflow: hidden;
        border: 3px solid #ddd;
    }

    .avatar-preview img {
        width: 100%;
        height: 100%;
        object-fit: cover;
    }

    .card {
        box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
        border: none;
    }

    .card-header {
        border-bottom: none;
    }

    .alert {
        margin-top: 20px;
    }
</style>

<div class="content-wrapper">
    <div class="container-fluid">
        <!-- رسائل التنبيه -->
        <?php if (isset($_SESSION['success_message'])): ?>
            <div class="alert alert-success">
                <?= $_SESSION['success_message'];
                unset($_SESSION['success_message']); ?>
            </div>
        <?php endif; ?>

        <?php if (isset($_SESSION['error_message'])): ?>
            <div class="alert alert-danger">
                <?= $_SESSION['error_message'];
                unset($_SESSION['error_message']); ?>
            </div>
        <?php endif; ?>

        <div class="row">
            <div class="col-md-6 mx-auto">
                <div class="card">
                    <div class="card-header bg-primary text-white">
                        <h4><i class="fas fa-lock"></i> تغيير كلمة المرور</h4>
                    </div>
                    <div class="card-body">
                        <form action="" method="post">
                            <div class="form-group">
                                <label for="current_password">كلمة المرور الحالية</label>
                                <input type="password" class="form-control" id="current_password" name="current_password" required>
                            </div>
                            <div class="form-group">
                                <label for="new_password">كلمة المرور الجديدة</label>
                                <input type="password" class="form-control" id="new_password" name="new_password" required>
                            </div>
                            <div class="form-group">
                                <label for="confirm_password">تأكيد كلمة المرور الجديدة</label>
                                <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                            </div>
                            <div class="form-group mt-4">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-save"></i> حفظ التغييرات
                                </button>
                                <a href="<?php echo SITE_URL; ?>admin/profile.php" class="btn btn-secondary">
                                    <i class="fas fa-times"></i> إلغاء
                                </a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once '../includes/admin_footer.php'; ?>
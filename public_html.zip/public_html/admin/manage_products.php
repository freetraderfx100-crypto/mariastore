<?php
session_start();
require_once __DIR__ . '/../includes/db_connect.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';
// استخدم هذا الاستعلام لجلب التصنيفات الفرعية فقط:
$categories_stmt = $conn->query("
    SELECT c.id, CONCAT(c.name, ' (', p.name, ')') as name 
    FROM categories c
    JOIN categories p ON c.parent_id = p.id
");
$categories = $categories_stmt->fetchAll(PDO::FETCH_KEY_PAIR);

// التحقق من أن المستخدم مدير
checkAdminRole();
// جلب معايير التصفية من GET
$category_filter = isset($_GET['category']) ? (int)$_GET['category'] : '';
$status_filter = isset($_GET['status']) ? $_GET['status'] : '';
$stock_filter = isset($_GET['stock']) ? $_GET['stock'] : '';
$search_query = isset($_GET['search']) ? trim($_GET['search']) : '';
// جلب جميع المنتجات مع أول صورة من جدول product_variants
// جلب جميع المنتجات مع التصفية
$products = [];
try {
    // تغيير الاستعلام ليشمل حقل cost_price
    $query = "SELECT p.id, p.name, p.sku, p.description, p.price, p.cost_price, p.category_id, p.is_active, p.created_at,
    (SELECT image_urls FROM product_variants WHERE product_id = p.id LIMIT 1) AS image_urls,
    (SELECT COUNT(*) FROM product_variants pv WHERE pv.product_id = p.id AND pv.quantity = 0) as out_of_stock_variants,
    (SELECT COUNT(*) FROM product_variants pv WHERE pv.product_id = p.id) as total_variants
    FROM products p
    WHERE 1=1";
    $params = [];
    // تصفية حسب التصنيف
    if (!empty($category_filter)) {
        $query .= " AND p.category_id = :category_id";
        $params[':category_id'] = $category_filter;
    }
    // تصفية حسب الحالة
    if ($status_filter === 'active') {
        $query .= " AND p.is_active = 1";
    } elseif ($status_filter === 'inactive') {
        $query .= " AND p.is_active = 0";
    }
    // تصفية حسب البحث (يشمل الآن اسم المنتج وSKU)
    if (!empty($search_query)) {
        $query .= " AND (p.name LIKE :search OR p.sku LIKE :search)";
        $params[':search'] = "%$search_query%";
    }
    $query .= " ORDER BY p.created_at DESC";
    $stmt = $conn->prepare($query);
    $stmt->execute($params);
    $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
    // جلب المتغيرات لكل منتج
    foreach ($products as &$product) {
        $stmt = $conn->prepare("SELECT size, quantity FROM product_variants WHERE product_id = ?");
        $stmt->execute([$product['id']]);
        $product['variants'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
        // حساب الكمية الإجمالية
        $product['stock_quantity'] = array_sum(array_column($product['variants'], 'quantity'));

        // استخراج الصور من JSON
        $image_urls = json_decode($product['image_urls'], true);
        $product['first_image'] = !empty($image_urls) && is_array($image_urls) ? $image_urls[0] : null;
    }
    unset($product); // كسر المرجع
    // تصفية حسب المخزون بعد جلب البيانات
    if (!empty($stock_filter)) {
        $products = array_filter($products, function ($product) use ($stock_filter) {
            if ($stock_filter === 'in_stock') {
                // منتجات متوفرة بالكامل (لا يوجد أي متغير منتهي)
                return $product['out_of_stock_variants'] == 0;
            } elseif ($stock_filter === 'out_of_stock') {
                // منتجات لديها على الأقل متغير واحد منتهي
                return $product['out_of_stock_variants'] > 0;
            }
            return true;
        });
    }
} catch (PDOException $e) {
    $error = "خطأ في جلب المنتجات: " . $e->getMessage();
}
// معالجة حذف المنتج
if (isset($_GET['delete_id'])) {
    $product_id = (int)$_GET['delete_id'];
    try {
        // تحقق أولاً: هل المنتج مرتبط بطلبات؟
        $stmt = $conn->prepare("SELECT COUNT(*) FROM order_items WHERE product_id = ?");
        $stmt->execute([$product_id]);
        $orderItemCount = $stmt->fetchColumn();
        if ($orderItemCount > 0) {
            // لا يمكن الحذف – أعد التوجيه مع رسالة خطأ للمستخدم
            header("Location: " . SITE_URL . "admin/manage_products.php?error=" . urlencode("لا يمكن حذف المنتج لأنه مرتبط بطلبات سابقة يمكنك الغاء تنشيطها بدلا من ذالك"));
            exit;
        }
        // لم يتم ربطه – يمكن الحذف بأمان
        $conn->beginTransaction();
        // جلب الصور المرتبطة
        $stmt = $conn->prepare("SELECT image_urls FROM product_variants WHERE product_id = ?");
        $stmt->execute([$product_id]);
        $image_data = $stmt->fetchAll(PDO::FETCH_COLUMN);

        // حذف الصور من النظام
        foreach ($image_data as $image_json) {
            $image_urls = json_decode($image_json, true);
            if (is_array($image_urls)) {
                foreach ($image_urls as $image_url) {
                    $file_path = __DIR__ . '/../assets/images/' . $image_url;
                    if (file_exists($file_path)) {
                        unlink($file_path);
                    }

                    // حذف نسخة WebP إذا كانت موجودة
                    $webp_path = __DIR__ . '/../assets/images/products/webp/' . pathinfo($image_url, PATHINFO_FILENAME) . '.webp';
                    if (file_exists($webp_path)) {
                        unlink($webp_path);
                    }
                }
            }
        }

        // حذف المتغيرات
        $stmt = $conn->prepare("DELETE FROM product_variants WHERE product_id = ?");
        $stmt->execute([$product_id]);

        // حذف المنتج
        $stmt = $conn->prepare("DELETE FROM products WHERE id = ?");
        $stmt->execute([$product_id]);

        $conn->commit();
        header("Location: " . SITE_URL . "admin/manage_products.php?success=" . urlencode("تم حذف المنتج بنجاح."));
        exit;
    } catch (PDOException $e) {
        $conn->rollBack();
        $error = "حدث خطأ أثناء الحذف: " . $e->getMessage();
    }
}
// تعيين عنوان الصفحة
$page_title = "إدارة المنتجات";
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إدارة المنتجات | ماريا</title>
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>assets/css/admin.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="<?php echo SITE_URL; ?>assets/js/sweetalert2.min.js"></script>

    <style>
        .stock-details {
            margin-bottom: 5px;
        }

        .variant-item {
            display: flex;
            justify-content: space-between;
            margin-bottom: 3px;
            font-size: 0.9em;
        }

        .variant-size {
            font-weight: bold;
        }

        .variant-quantity {
            padding: 2px 5px;
            border-radius: 3px;
        }

        .variant-quantity.in-stock {
            color: #28a745;
        }

        .variant-quantity.out-of-stock {
            color: #dc3545;
        }

        .total-stock {
            margin-top: 5px;
            padding-top: 5px;
            border-top: 1px dashed #ddd;
            font-weight: bold;
            display: flex;
            justify-content: space-between;
        }

        /* ستايل مربع البحث */
        .filters-container {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
        }

        .filter-form {
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
            align-items: flex-end;
        }

        .filter-group {
            display: flex;
            flex-direction: column;
        }

        .filter-group label {
            margin-bottom: 5px;
            font-weight: bold;
        }

        .filter-group input,
        .filter-group select {
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }

        .btn-filter {
            background-color: #4e73df;
            color: white;
            padding: 8px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .btn-reset {
            background-color: #e74a3b;
            color: white;
            padding: 8px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            text-decoration: none;
        }

        .btn-filter:hover {
            background-color: #2e59d9;
        }

        .btn-reset:hover {
            background-color: #d52a1a;
        }

        .partial-stock {
            background-color: #fff3cd !important;
            color: #856404;
        }

        .product-stock.partial-stock .total-stock span {
            color: #856404;
            font-weight: bold;
        }

        .product-sku {
            font-family: 'Courier New', monospace;
            font-size: 0.9em;
            color: #666;
            background-color: #f8f9fa;
            padding: 8px;
            text-align: center;
        }

        .product-sku:hover {
            background-color: #e9ecef;
        }

        /* تعديل عرض الأعمدة لاستيعاب العمود الجديد */
        .products-table th:nth-child(2),
        .products-table td:nth-child(2) {
            width: 120px;
        }

        /* تعديل عرض الأعمدة الأخرى */
        .products-table th:nth-child(3),
        .products-table td:nth-child(3) {
            width: auto;
        }

        /* داخل قسم الـ style */
        .product-cost-price {
            font-weight: bold;
            color: #6c757d;
        }

        .product-profit {
            font-weight: bold;
        }

        .profit-amount.positive-profit {
            color: #28a745;
        }

        .profit-amount.negative-profit {
            color: #dc3545;
        }

        .profit-amount.zero-profit {
            color: #6c757d;
        }

        .profit-margin.positive-profit {
            color: #20c997;
            font-size: 0.85em;
        }

        .profit-margin.negative-profit {
            color: #e4606d;
            font-size: 0.85em;
        }

        .profit-margin.zero-profit {
            color: #6c757d;
            font-size: 0.85em;
        }

        /* تعديل عرض الأعمدة لاستيعاب الأعمدة الجديدة */
        .products-table th:nth-child(4),
        .products-table td:nth-child(4) {
            width: 100px;
        }

        .products-table th:nth-child(5),
        .products-table td:nth-child(5) {
            width: 100px;
        }

        .products-table th:nth-child(6),
        .products-table td:nth-child(6) {
            width: 120px;
        }

        /* تنسيق الصورة في الجدول */
        .product-thumbnail {
            width: 60px;
            height: 60px;
            object-fit: cover;
            border-radius: 4px;
            border: 1px solid #ddd;
        }

        .no-image {
            width: 60px;
            height: 60px;
            display: flex;
            align-items: center;
            justify-content: center;
            background-color: #f8f9fa;
            border-radius: 4px;
            border: 1px dashed #ddd;
            color: #6c757d;
        }
    </style>
</head>

<body>
    <?php include __DIR__ . '/../includes/admin_header.php'; ?>
    <div class="admin-container">
        <div class="admin-actions">
            <a href="<?php echo SITE_URL; ?>admin/add_product.php" class="btn btn-pink">
                <i class="fas fa-plus"></i> إضافة منتج جديد
            </a>
        </div>
        <div class="admin-actions">
            <a href="<?php echo SITE_URL; ?>admin/manage_categories.php" class="btn btn-pink">
                <i class="fas fa-plus"></i> تعديل التصنيفات في الصفحة
            </a>
        </div>
        <h1 class="page-title"><i class="fas fa-box-open"></i> إدارة المنتجات</h1>
        <div class="filters-container">
            <form method="get" class="filter-form">
                <div class="filter-group">
                    <label for="search">بحث:</label>
                    <input type="text" name="search" id="search" value="<?= htmlspecialchars($search_query) ?>" placeholder="ابحث باسم المنتج">
                </div>
                <div class="filter-group">
                    <label for="category">التصنيف:</label>
                    <select name="category" id="category">
                        <option value="">جميع التصنيفات</option>
                        <?php foreach ($categories as $id => $name): ?>
                            <option value="<?= $id ?>" <?= $category_filter == $id ? 'selected' : '' ?>>
                                <?= htmlspecialchars($name) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="filter-group">
                    <label for="status">الحالة:</label>
                    <select name="status" id="status">
                        <option value="">الكل</option>
                        <option value="active" <?= $status_filter === 'active' ? 'selected' : '' ?>>نشط</option>
                        <option value="inactive" <?= $status_filter === 'inactive' ? 'selected' : '' ?>>غير نشط</option>
                    </select>
                </div>
                <div class="filter-group">
                    <label for="stock">المخزون:</label>
                    <select name="stock" id="stock">
                        <option value="">الكل</option>
                        <option value="in_stock" <?= $stock_filter === 'in_stock' ? 'selected' : '' ?>>متوفر</option>
                        <option value="out_of_stock" <?= $stock_filter === 'out_of_stock' ? 'selected' : '' ?>>نفذ</option>
                    </select>
                </div>
                <button type="submit" class="btn btn-filter">تصفية</button>
                <a href="<?php echo SITE_URL; ?>admin/manage_products.php" class="btn btn-reset">إعادة تعيين</a>
            </form>
        </div>
        <?php if (isset($error)): ?>
            <div class="alert alert-danger">
                <?php echo $error; ?>
            </div>
        <?php endif; ?>
        <?php if (isset($_GET['success'])): ?>
            <div class="alert alert-success">
                <?php echo htmlspecialchars($_GET['success']); ?>
            </div>
        <?php endif; ?>
        <?php if (isset($_GET['error'])): ?>
            <div class="alert alert-danger">
                <?= htmlspecialchars($_GET['error']) ?>
            </div>
        <?php endif; ?>

        <div class="products-grid">
            <?php if (empty($products)): ?>
                <div class="empty-state">
                    <i class="fas fa-box-open fa-3x"></i>
                    <p>لا توجد منتجات متاحة</p>
                </div>
            <?php else: ?>
                <div class="responsive-table">
                    <table class="products-table">
                        <thead>
                            <tr>
                                <th>الصورة</th>
                                <th>SKU</th>
                                <th>اسم المنتج</th>
                                <th>سعر التكلفة</th> <!-- العمود الجديد -->
                                <th>سعر البيع</th>
                                <th>الربح</th> <!-- عمود جديد لحساب الربح -->
                                <th>الكمية</th>
                                <th>الحالة</th>
                                <th>الإجراءات</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($products as $product): ?>
                                <tr>
                                    <td class="product-image-cell">
                                        <?php if (!empty($product['first_image'])): ?>
                                            <img src="<?php echo SITE_URL; ?>assets/images/<?= htmlspecialchars($product['first_image']) ?>"
                                                alt="<?= htmlspecialchars($product['name']) ?>"
                                                class="product-thumbnail">
                                        <?php else: ?>
                                            <div class="no-image">
                                                <i class="fas fa-image"></i>
                                            </div>
                                        <?php endif; ?>
                                    </td>
                                    <td class="product-sku"> <!-- الخلية الجديدة -->
                                        <?= !empty($product['sku']) ? htmlspecialchars($product['sku']) : '<span style="color: #999;">N/A</span>' ?>
                                    </td>
                                    <td class="product-name">
                                        <?= htmlspecialchars($product['name']) ?>
                                        <span class="product-category">
                                            <?= htmlspecialchars($categories[$product['category_id']] ?? 'غير مصنف') ?>
                                        </span>
                                    </td>
                                    <td class="product-cost-price">
                                        <?= number_format($product['cost_price'], 2) ?> ر.ي
                                    </td>
                                    <td class="product-price">
                                        <?= number_format($product['price'], 2) ?> ر.ي
                                    </td>
                                    <td class="product-profit">
                                        <?php
                                        $profit = $product['price'] - $product['cost_price'];
                                        $profit_margin = $product['cost_price'] > 0 ? ($profit / $product['cost_price']) * 100 : 0;
                                        $profit_class = $profit > 0 ? 'positive-profit' : ($profit < 0 ? 'negative-profit' : 'zero-profit');
                                        ?>
                                        <span class="profit-amount <?= $profit_class ?>">
                                            <?= number_format($profit, 2) ?> ر.ي
                                        </span>
                                        <br>
                                        <span class="profit-margin <?= $profit_class ?>">
                                            (<?= number_format($profit_margin, 1) ?>%)
                                        </span>
                                    </td>
                                    <!-- داخل الجدول، نعدل خلية الكمية لتظهر الأحجام والكميات -->
                                    <td class="product-stock <?= $product['out_of_stock_variants'] > 0 ? ($product['out_of_stock_variants'] == $product['total_variants'] ? 'out-of-stock' : 'partial-stock') : 'in-stock' ?>">
                                        <div class="stock-details">
                                            <?php if (!empty($product['variants'])): ?>
                                                <?php foreach ($product['variants'] as $variant): ?>
                                                    <div class="variant-item">
                                                        <span class="variant-size"><?= htmlspecialchars($variant['size']) ?>:</span>
                                                        <span class="variant-quantity <?= $variant['quantity'] > 0 ? 'in-stock' : 'out-of-stock' ?>">
                                                            <?= $variant['quantity'] ?>
                                                        </span>
                                                    </div>
                                                <?php endforeach; ?>
                                            <?php else: ?>
                                                <span>لا توجد متغيرات</span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="total-stock">
                                            الإجمالي: <?= $product['stock_quantity'] ?>
                                            <span>
                                                <?php if ($product['out_of_stock_variants'] == 0): ?>
                                                    متوفر
                                                <?php elseif ($product['out_of_stock_variants'] == $product['total_variants']): ?>
                                                    نفذ
                                                <?php else: ?>
                                                    متوفر جزئياً
                                                <?php endif; ?>
                                            </span>
                                        </div>
                                    </td>
                                    <td class="product-status">
                                        <span class="status-badge <?= $product['is_active'] ? 'active' : 'inactive' ?>">
                                            <?= $product['is_active'] ? 'نشط' : 'غير نشط' ?>
                                        </span>
                                    </td>
                                    <td class="product-actions">
                                        <a href="<?php echo SITE_URL; ?>admin/edit_product.php?id=<?= $product['id'] ?>"
                                            class="btn-action btn-edit" title="تعديل">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <a href="<?php echo SITE_URL; ?>admin/manage_products.php?delete_id=<?= $product['id'] ?>"
                                            class="btn-action btn-delete" title="حذف">
                                            <i class="fas fa-trash-alt"></i>
                                        </a>
                                        <a href="<?php echo SITE_URL; ?>pages/details_product.php?id=<?= $product['id'] ?>"
                                            class="btn-action btn-view" title="معاينة" target="_blank">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
    <?php include __DIR__ . '/../includes/admin_footer.php'; ?>

    <script>
        <?php if (isset($_GET['success'])): ?>
            Swal.fire({
                icon: 'success',
                title: 'نجاح',
                text: '<?= htmlspecialchars($_GET['success']) ?>',
                confirmButtonText: 'حسنًا'
            });
        <?php elseif (isset($_GET['error'])): ?>
            Swal.fire({
                icon: 'error',
                title: 'خطأ',
                text: '<?= htmlspecialchars($_GET['error']) ?>',
                confirmButtonText: 'فهمت'
            });
        <?php endif; ?>
    </script>
    <script>
        // دالة تأكيد الحذف
        function confirmDelete(event) {
            event.preventDefault(); // منع التنفيذ المباشر للرابط
            const deleteUrl = event.currentTarget.getAttribute('href');
            Swal.fire({
                title: 'هل أنت متأكد؟',
                text: "لن تتمكن من استعادة هذا المنتج بعد الحذف!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'نعم، احذفه!',
                cancelButtonText: 'إلغاء',
                reverseButtons: true
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = deleteUrl;
                }
            });
        }
        // إضافة مستمع الأحداث لأزرار الحذف عند تحميل الصفحة
        document.addEventListener('DOMContentLoaded', function() {
            const deleteButtons = document.querySelectorAll('.btn-delete');
            deleteButtons.forEach(button => {
                button.addEventListener('click', confirmDelete);
            });
            <?php if (isset($_GET['success'])): ?>
                Swal.fire({
                    icon: 'success',
                    title: 'نجاح',
                    text: '<?= htmlspecialchars($_GET['success']) ?>',
                    confirmButtonText: 'حسنًا'
                });
            <?php elseif (isset($_GET['error'])): ?>
                Swal.fire({
                    icon: 'error',
                    title: 'خطأ',
                    text: '<?= htmlspecialchars($_GET['error']) ?>',
                    confirmButtonText: 'فهمت'
                });
            <?php endif; ?>
        });
    </script>
    <script src="<?php echo SITE_URL; ?>assets/js/coby_code_SKU.js"></script>

</body>

</html>
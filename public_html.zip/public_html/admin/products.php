<!-- manage_categories.php هاذي الصفحه ملغيه استبدل بدلها  -->

<!-- <?php
        // session_start();
        // require_once __DIR__ . '/../includes/db_connect.php';
        // require_once __DIR__ . '/../includes/functions.php';

        // // التحقق من صلاحيات المدير
        // if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] != 'admin') {
        //     header("Location: " . SITE_URL . "admin/login.php");
        //     exit;
        // }

        // // جلب جميع المنتجات
        // $products = [];
        // try {
        //     $stmt = $conn->query("SELECT p.*, pi.image_url 
        //                          FROM products p
        //                          LEFT JOIN (
        //                              SELECT product_id, image_url 
        //                              FROM product_images 
        //                              WHERE is_main = 1
        //                              GROUP BY product_id
        //                          ) pi ON p.id = pi.product_id
        //                          ORDER BY p.created_at DESC");
        //     $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
        // } catch (PDOException $e) {
        //     $error = "خطأ في جلب المنتجات: " . $e->getMessage();
        // }

        // // معالجة حذف المنتج
        // if (isset($_GET['delete_id'])) {
        //     $product_id = (int)$_GET['delete_id'];

        //     try {
        //         $conn->beginTransaction();

        //         // 1. حذف صور المنتج أولاً
        //         $stmt = $conn->prepare("DELETE FROM product_images WHERE product_id = ?");
        //         $stmt->execute([$product_id]);

        //         // 2. حذف المنتج
        //         $stmt = $conn->prepare("DELETE FROM products WHERE id = ?");
        //         $stmt->execute([$product_id]);

        //         $conn->commit();

        //         header("Location: " . SITE_URL . "admin/products.php?success=تم حذف المنتج بنجاح");
        //         exit;
        //     } catch (PDOException $e) {
        //         $conn->rollBack();
        //         $error = "خطأ في حذف المنتج: " . $e->getMessage();
        //     }
        // }
        ?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إدارة المنتجات | ماريا</title>
    <link rel="stylesheet" href="/online_store/assets/css/admin.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>

<body>
    <?php include __DIR__ . '/../includes/admin_header.php'; ?>

    <div class="admin-container">
        <div class="admin-actions">
            <a href="/online_store/admin/add_product.php" class="btn btn-pink">
                <i class="fas fa-plus"></i> إضافة منتج جديد
            </a>
        </div>

        <h1 class="page-title"><i class="fas fa-box-open"></i> إدارة المنتجات</h1>

        <?php if (isset($error)): ?>
            <div class="alert alert-danger">
                <?php echo $error; ?>
            </div>
        <?php endif; ?>

        <?php if (isset($_GET['success'])): ?>
            <div class="alert alert-success">
                <?php echo htmlspecialchars($_GET['success']); ?>
            </div>
        <?php endif; ?>

        <div class="products-grid">
            <?php if (empty($products)): ?>
                <div class="empty-state">
                    <i class="fas fa-box-open fa-3x"></i>
                    <p>لا توجد منتجات متاحة</p>
                </div>
            <?php else: ?>
                <div class="responsive-table">
                    <table class="products-table">
                        <thead>
                            <tr>
                                <th>الصورة</th>
                                <th>اسم المنتج</th>
                                <th>السعر</th>
                                <th>الكمية</th>
                                <th>الحالة</th>
                                <th>الإجراءات</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($products as $product): ?>
                                <tr>
                                    <td class="product-image-cell">
                                        <?php if (!empty($product['image_url'])): ?>
                                            <img src="/online_store/assets/images/<?= htmlspecialchars($product['image_url']) ?>"
                                                alt="<?= htmlspecialchars($product['name']) ?>"
                                                class="product-thumbnail">
                                        <?php else: ?>
                                            <div class="no-image">
                                                <i class="fas fa-image"></i>
                                            </div>
                                        <?php endif; ?>
                                    </td>
                                    <td class="product-name">
                                        <?= htmlspecialchars($product['name']) ?>
                                        <span class="product-category">
                                            <?= htmlspecialchars($product['category']) ?>
                                        </span>
                                    </td>
                                    <td class="product-price">
                                        <?= number_format($product['price'], 2) ?> ر.ي
                                    </td>
                                    <td class="product-stock <?= $product['stock_quantity'] > 0 ? 'in-stock' : 'out-of-stock' ?>">
                                        <?= $product['stock_quantity'] ?>
                                        <span><?= $product['stock_quantity'] > 0 ? 'متوفر' : 'نفذ' ?></span>
                                    </td>
                                    <td class="product-status">
                                        <span class="status-badge <?= $product['is_active'] ? 'active' : 'inactive' ?>">
                                            <?= $product['is_active'] ? 'نشط' : 'غير نشط' ?>
                                        </span>
                                    </td>
                                    <td class="product-actions">
                                        <a href="/online_store/admin/edit_product.php?id=<?= $product['id'] ?>"
                                            class="btn-action btn-edit" title="تعديل">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <a href="products.php?delete_id=<?= $product['id'] ?>"
                                            class="btn-action btn-delete"
                                            title="حذف"
                                            onclick="return confirm('هل أنت متأكد من حذف هذا المنتج؟ لن يمكنك استرجاعه لاحقاً')">
                                            <i class="fas fa-trash-alt"></i>
                                        </a>
                                        <a href="/online_store/pages/details_product.php?id=<?= $product['id'] ?>"
                                            class="btn-action btn-view" title="معاينة" target="_blank">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <?php include __DIR__ . '/../includes/admin_footer.php'; ?>

    <script>
        // تأكيد الحذف
        document.querySelectorAll('.btn-delete').forEach(btn => {
            btn.addEventListener('click', function(e) {
                if (!confirm('هل أنت متأكد من حذف هذا المنتج؟ لن يمكنك استرجاعه لاحقاً')) {
                    e.preventDefault();
                }
            });
        });
    </script>
</body>

</html> -->
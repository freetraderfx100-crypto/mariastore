<?php
require_once __DIR__ . '/../includes/db_connect.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/notifications.php';
// التحقق من صلاحيات المسؤول
checkAdminRole();
// استدعاء الدالة عند تحميل الصفحة
checkExpiredDiscounts($conn);
// معالجة البحث باستخدام SKU
$search_sku = '';
$where_clause = '';
$search_params = [];
if (isset($_GET['search_sku']) && !empty($_GET['search_sku'])) {
    $search_sku = trim($_GET['search_sku']);
    $where_clause = "WHERE p.sku LIKE :sku";
    $search_params[':sku'] = '%' . $search_sku . '%';
}
// معالجة تحديث الخصومات
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_discounts'])) {
    // ✅ فحص نوع التحديث: "selected" (المحدد فقط) أو "all" (الكل)
    $apply_mode = $_POST['apply_mode'] ?? 'all';
    $selected_products = $_POST['selected_products'] ?? [];

    // ✅ جلب قيم الخصم العامة (لو磨利صة "تطبيق على المحدد")
    $bulk_percentage = !empty($_POST['bulk_percentage']) ? (float)$_POST['bulk_percentage'] : null;
    $bulk_end_date = !empty($_POST['bulk_end_date']) ? $_POST['bulk_end_date'] : null;

    if ($apply_mode === 'selected' && !empty($selected_products)) {
        // ✅ وضع "تطبيق على المنتجات المحددة فقط"
        // أولاً: تصفير خصم جميع المنتجات (إلغاء أي خصم سابق)
        $stmt_clear = $conn->prepare("UPDATE products SET discount_percentage = 0, discount_end_date = NULL");
        $stmt_clear->execute();

        // ثانياً: تطبيق الخصم على المنتجات المحددة فقط
        foreach ($selected_products as $product_id) {
            $product_id = (int)$product_id;
            // لو القيم من الحقول الفردية موجودة، نستخدمها
            if (isset($_POST['discounts'][$product_id])) {
                $discount_percentage = (float)($_POST['discounts'][$product_id]['percentage'] ?? 0);
                $discount_end_date = !empty($_POST['discounts'][$product_id]['end_date']) ? $_POST['discounts'][$product_id]['end_date'] : null;
            } else {
                // لو لا، نستخدم القيم العامة
                $discount_percentage = $bulk_percentage ?? 0;
                $discount_end_date = $bulk_end_date;
            }

            if ($discount_percentage > 0) {
                $stmt = $conn->prepare("
                    UPDATE products
                    SET discount_percentage = ?,
                        discount_end_date = ?
                    WHERE id = ?
                ");
                $stmt->execute([$discount_percentage, $discount_end_date, $product_id]);
            }
        }
        $_SESSION['success_message'] = "تم تطبيق الخصم على " . count($selected_products) . " منتج محدد بنجاح";
        
        // ✅ إطلاق إشعار "خصم جديد" لكل منتج تم خصمه
        try {
            $notifManager = new NotificationsManager($conn);
            foreach ($selected_products as $product_id) {
                $product_id = (int)$product_id;
                if (isset($_POST['discounts'][$product_id])) {
                    $discount_percentage = (float)($_POST['discounts'][$product_id]['percentage'] ?? 0);
                } else {
                    $discount_percentage = $bulk_percentage ?? 0;
                }
                
                if ($discount_percentage >= 5) { // حد أدنى للإشعار
                    // جلب بيانات المنتج
                    $pstmt = $conn->prepare("SELECT name, price, (SELECT image_urls FROM product_variants WHERE product_id = p.id LIMIT 1) as image_urls FROM products p WHERE id = ?");
                    $pstmt->execute([$product_id]);
                    $product = $pstmt->fetch(PDO::FETCH_ASSOC);
                    
                    if ($product) {
                        $old_price = $product['price'];
                        $new_price = $old_price * (1 - $discount_percentage / 100);
                        
                        // استخراج أول صورة
                        $first_image = null;
                        if (!empty($product['image_urls'])) {
                            $imgs = json_decode($product['image_urls'], true);
                            if (is_array($imgs) && !empty($imgs)) {
                                $first_image = $imgs[0];
                            }
                        }
                        
                        $notifManager->notifyNewDiscount(
                            $product_id,
                            $product['name'],
                            $discount_percentage,
                            $old_price,
                            $new_price,
                            $first_image
                        );
                        
                    }
                }
            }
        } catch (Exception $e) {
            error_log("Notification error (new discount): " . $e->getMessage());
        }
    } else {
        // ✅ وضع "تحديث كل المنتجات" (السلوك القديم)
        foreach ($_POST['discounts'] as $product_id => $discount_data) {
            $discount_percentage = (float)$discount_data['percentage'];
            $discount_end_date = !empty($discount_data['end_date']) ? $discount_data['end_date'] : null;
            $stmt = $conn->prepare("
                UPDATE products
                SET discount_percentage = ?,
                    discount_end_date = ?
                WHERE id = ?
            ");
            $stmt->execute([$discount_percentage, $discount_end_date, $product_id]);
        }
        $_SESSION['success_message'] = "تم تحديث خصومات جميع المنتجات بنجاح";
        
        // ✅ إطلاق إشعار "خصم جديد" لكل منتج له خصم جديد
        try {
            $notifManager = new NotificationsManager($conn);
            foreach ($_POST['discounts'] as $product_id => $discount_data) {
                $discount_percentage = (float)$discount_data['percentage'];
                
                if ($discount_percentage >= 5) {
                    $pstmt = $conn->prepare("SELECT name, price, discount_percentage as old_discount, (SELECT image_urls FROM product_variants WHERE product_id = p.id LIMIT 1) as image_urls FROM products p WHERE id = ?");
                    $pstmt->execute([$product_id]);
                    $product = $pstmt->fetch(PDO::FETCH_ASSOC);
                    
                    if ($product && $product['old_discount'] < $discount_percentage) {
                        $old_price = $product['price'];
                        $new_price = $old_price * (1 - $discount_percentage / 100);
                        
                        $first_image = null;
                        if (!empty($product['image_urls'])) {
                            $imgs = json_decode($product['image_urls'], true);
                            if (is_array($imgs) && !empty($imgs)) {
                                $first_image = $imgs[0];
                            }
                        }
                        
                        $notifManager->notifyNewDiscount(
                            $product_id,
                            $product['name'],
                            $discount_percentage,
                            $old_price,
                            $new_price,
                            $first_image
                        );
                        
                    }
                }
            }
        } catch (Exception $e) {
            error_log("Notification error (new discount all): " . $e->getMessage());
        }
    }
    header("Location: " . SITE_URL . "admin/manage_discounts.php" . (!empty($search_sku) ? "?search_sku=" . urlencode($search_sku) : ""));
    exit();
}
// جلب جميع المنتجات مع معلومات الخصم
$sql = "
    SELECT p.id, p.name, p.sku, p.price, p.discount_percentage, p.discount_end_date,
           (SELECT pv.image_urls FROM product_variants pv WHERE pv.product_id = p.id LIMIT 1) as image_urls
    FROM products p
    $where_clause
    ORDER BY p.discount_percentage DESC, p.name
";
$stmt = $conn->prepare($sql);
foreach ($search_params as $key => $value) {
    $stmt->bindValue($key, $value);
}
$stmt->execute();
$products = $stmt->fetchAll(PDO::FETCH_ASSOC);
// دالة لاستخراج أول صورة من JSON
function getFirstImage($image_urls_json)
{
    if (empty($image_urls_json)) {
        return 'default-product-image.jpg';
    }

    $images = json_decode($image_urls_json, true);
    if (is_array($images) && !empty($images)) {
        return $images[0];
    }

    return 'default-product-image.jpg';
}
$pageTitle = "إدارة الخصومات";
include __DIR__ . '/../includes/admin_header.php';
?>
<!-- <link rel="stylesheet" href="<?php echo SITE_URL; ?>assets/css/dash.css"> -->
<link rel="stylesheet" href="<?php echo SITE_URL; ?>assets/css/customers.css">

<div class="container py-5">
    <h1 class="mb-4">إدارة الخصومات</h1>
    <?php if (isset($_SESSION['success_message'])): ?>
        <div class="alert alert-success"><?= $_SESSION['success_message'];
                                            unset($_SESSION['success_message']); ?></div>
    <?php endif; ?>
    <!-- نموذج البحث باستخدام SKU -->
    <div class="card mb-4">
        <div class="card-header">
            <h5 class="mb-0">بحث المنتجات باستخدام SKU</h5>
        </div>
        <div class="card-body">
            <form method="get" class="row g-3 align-items-end">
                <div class="col-md-8">
                    <label for="search_sku" class="form-label">رقم SKU</label>
                    <input type="text" class="form-control" id="search_sku" name="search_sku"
                        value="<?= htmlspecialchars($search_sku) ?>"
                        placeholder="أدخل رقم SKU للبحث...">
                </div>
                <div class="col-md-2">
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="fas fa-search"></i> بحث
                    </button>
                </div>
                <div class="col-md-2">
                    <a href="<?php echo SITE_URL; ?>admin/manage_discounts.php" class="btn btn-secondary w-100">
                        <i class="fas fa-times"></i> إلغاء
                    </a>
                </div>
            </form>
        </div>
    </div>
    <?php if (!empty($search_sku)): ?>
        <div class="alert alert-info mb-4">
            <i class="fas fa-info-circle"></i>
            عرض <?= count($products) ?> منتج(منتجات) للبحث: "<strong><?= htmlspecialchars($search_sku) ?></strong>"
            <a href="<?php echo SITE_URL; ?>admin/manage_discounts.php" class="float-end">
                عرض جميع المنتجات
            </a>
        </div>
    <?php endif; ?>
    <form method="post" id="discountsForm" class="bg-light p-4 rounded mb-5">
        <!-- ✅ إخفاء حقل نوع التطبيق -->
        <input type="hidden" name="apply_mode" id="apply_mode" value="all">
        <!-- ✅ حقل مخفي لإثبات أن النموذج مُرسل (لأن JS submit لا يرسل أزرار submit) -->
        <input type="hidden" name="update_discounts" value="1">

        <!-- ✅ شريط أدوات: تطبيق على المحدد + تحديد الكل -->
        <div class="card mb-4" style="background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%); border: 1px solid #dee2e6;">
            <div class="card-body">
                <h5 class="mb-3"><i class="fas fa-bolt text-warning"></i> تطبيق سريع للخصم</h5>
                <div class="row g-3 align-items-end">
                    <div class="col-md-2">
                        <label class="form-label small">نسبة الخصم %</label>
                        <input type="number" name="bulk_percentage" id="bulk_percentage"
                            class="form-control" min="0" max="100" step="1"
                            placeholder="مثال: 20">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label small">تاريخ انتهاء الخصم</label>
                        <input type="date" name="bulk_end_date" id="bulk_end_date" class="form-control">
                    </div>
                    <div class="col-md-4">
                        <button type="button" class="btn btn-outline-primary w-100" onclick="applyBulkToSelected()">
                            <i class="fas fa-check-circle"></i> تطبيق على المحدد (مع تصفير الباقي)
                        </button>
                    </div>
                    <div class="col-md-3">
                        <div class="form-check">
                            <input type="checkbox" class="form-check-input" id="select_all" onclick="toggleSelectAll(this)">
                            <label class="form-check-label fw-bold" for="select_all">تحديد الكل / إلغاء التحديد</label>
                        </div>
                    </div>
                </div>
                <div class="alert alert-info mt-3 mb-0 py-2 small">
                    <i class="fas fa-info-circle"></i>
                    <strong>طريقة الاستخدام:</strong>
                    1. حدد المنتجات بالـ checkboxes &nbsp;|&nbsp;
                    2. أدخل نسبة الخصم وتاريخ الانتهاء &nbsp;|&nbsp;
                    3. اضغط "تطبيق على المحدد" (سيلغي الخصومات السابقة على باقي المنتجات)
                    &nbsp;|&nbsp; أو اضبط لكل منتج على حدة ثم "حفظ التغييرات"
                </div>
            </div>
        </div>

        <div class="d-flex justify-content-between mb-4">
            <h3>تعديل خصومات المنتجات</h3>
            <button type="submit" name="update_discounts" class="btn btn-primary" onclick="setApplyMode('all')">
                <i class="fas fa-save"></i> حفظ التغييرات (كل المنتجات)
            </button>
        </div>
        <div class="responsive-table">
            <table class="table table-bordered">
                <thead class="table-dark">
                    <tr>
                        <th style="width: 40px;">تحديد</th>
                        <th>الصورة</th>
                        <th>اسم المنتج</th>
                        <th>SKU</th>
                        <th>السعر</th>
                        <th>نسبة الخصم %</th>
                        <th>تاريخ انتهاء الخصم</th>
                        <th>السعر بعد الخصم</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($products) > 0): ?>
                        <?php foreach ($products as $product): ?>
                            <?php
                            // استخراج أول صورة من JSON
                            $first_image = getFirstImage($product['image_urls']);

                            // التحقق من أن الخصم لم ينتهي صلاحيته
                            $is_discount_active = (!$product['discount_end_date'] || $product['discount_end_date'] >= date('Y-m-d'));
                            $discount_percentage = $is_discount_active ? $product['discount_percentage'] : 0;
                            $discounted_price = $product['price'] * (1 - $discount_percentage / 100);
                            ?>
                            <tr>
                                <td class="text-center">
                                    <input type="checkbox" name="selected_products[]"
                                        value="<?= $product['id'] ?>"
                                        class="form-check-input product-checkbox"
                                        style="transform: scale(1.3); cursor: pointer;">
                                </td>
                                <td>
                                    <img src="<?php echo SITE_URL; ?>assets/images/<?= htmlspecialchars($first_image) ?>"
                                        alt="<?= htmlspecialchars($product['name']) ?>"
                                        style="width: 60px; height: 60px; object-fit: cover; border-radius: 4px; border: 1px solid #ddd;">
                                </td>
                                <td><?= htmlspecialchars($product['name']) ?></td>
                                <td>
                                    <span class="badge bg-secondary"><?= htmlspecialchars($product['sku']) ?></span>
                                </td>
                                <td><?= number_format($product['price'], 2) ?> ر.ي</td>
                                <td>
                                    <input type="number" name="discounts[<?= $product['id'] ?>][percentage]"
                                        value="<?= $discount_percentage ?>"
                                        min="0" max="100" step="1"
                                        class="form-control" style="width: 80px;">
                                </td>
                                <td>
                                    <input type="date" name="discounts[<?= $product['id'] ?>][end_date]"
                                        value="<?= $is_discount_active ? $product['discount_end_date'] : '' ?>"
                                        class="form-control">
                                </td>
                                <td>
                                    <?= number_format($discounted_price, 2) ?> ر.ي
                                    <?php if ($is_discount_active && $discount_percentage > 0): ?>
                                        <span class="badge bg-danger">خصم <?= $discount_percentage ?>%</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="8" class="text-center py-4">
                                <?php if (!empty($search_sku)): ?>
                                    <div class="text-muted">
                                        <i class="fas fa-search fa-2x mb-3"></i>
                                        <h5>لا توجد نتائج للبحث</h5>
                                        <p>لم يتم العثور على أي منتج يحتوي على "<strong><?= htmlspecialchars($search_sku) ?></strong>" في رقم SKU</p>
                                        <a href="<?php echo SITE_URL; ?>admin/manage_discounts.php" class="btn btn-primary">
                                            عرض جميع المنتجات
                                        </a>
                                    </div>
                                <?php else: ?>
                                    <div class="text-muted">
                                        <i class="fas fa-box-open fa-2x mb-3"></i>
                                        <h5>لا توجد منتجات</h5>
                                        <p>لم يتم العثور على أي منتجات في النظام</p>
                                    </div>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php if (count($products) > 0): ?>
            <div class="text-center mt-3">
                <button type="submit" name="update_discounts" class="btn btn-primary btn-lg" onclick="setApplyMode('all')">
                    <i class="fas fa-save"></i> حفظ التغييرات (كل المنتجات)
                </button>
            </div>
        <?php endif; ?>
    </form>

    <script>
        // ✅ تعيين وضع التطبيق (all أو selected)
        function setApplyMode(mode) {
            document.getElementById('apply_mode').value = mode;
        }

        // ✅ تحديد/إلغاء تحديد كل المنتجات
        function toggleSelectAll(source) {
            const checkboxes = document.querySelectorAll('.product-checkbox');
            checkboxes.forEach(cb => cb.checked = source.checked);
        }

        // ✅ تطبيق الخصم العام على المنتجات المحددة فقط
        function applyBulkToSelected() {
            const selected = document.querySelectorAll('.product-checkbox:checked');
            const bulkPercentage = document.getElementById('bulk_percentage').value;
            const bulkEndDate = document.getElementById('bulk_end_date').value;

            if (selected.length === 0) {
                alert('⚠️ يرجى تحديد منتج واحد على الأقل');
                return;
            }

            if (!bulkPercentage || bulkPercentage <= 0) {
                alert('⚠️ يرجى إدخال نسبة خصم صحيحة');
                return;
            }

            // تأكيد العملية
            const confirmMsg = `سيتم تطبيق خصم ${bulkPercentage}% على ${selected.length} منتج محدد.\n` +
                (bulkEndDate ? `تاريخ الانتهاء: ${bulkEndDate}\n` : '') +
                `\n⚠️ سيتم تصفير خصم جميع المنتجات الأخرى. هل أنت متأكد؟`;

            if (!confirm(confirmMsg)) return;

            // تعيين الوضع "selected"
            setApplyMode('selected');

            // تطبيق القيمة على حقول المنتجات المحددة (لإرسالها مع النموذج)
            selected.forEach(checkbox => {
                const productId = checkbox.value;
                const row = checkbox.closest('tr');
                const percentageInput = row.querySelector(`input[name="discounts[${productId}][percentage]"]`);
                const dateInput = row.querySelector(`input[name="discounts[${productId}][end_date]"]`);
                if (percentageInput) percentageInput.value = bulkPercentage;
                if (dateInput && bulkEndDate) dateInput.value = bulkEndDate;
            });

            // ✅ إرسال النموذج عبر ID المحدد
            const form = document.getElementById('discountsForm');
            if (form) {
                form.submit();
            } else {
                console.error('Form not found!');
                alert('❌ خطأ: لم يتم العثور على النموذج');
            }
        }
    </script>
</div>
<?php include __DIR__ . '/../includes/admin_footer.php'; ?>
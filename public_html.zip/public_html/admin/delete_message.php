<?php
session_start();
require_once __DIR__ . '/../includes/db_connect.php';

require_once __DIR__ . '/../includes/auth.php';
// التحقق من أن المستخدم مدير
checkAdminRole();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id'])) {
    $id = intval($_POST['id']);

    try {
        $stmt = $conn->prepare("DELETE FROM contact_messages WHERE id = ?");
        $stmt->execute([$id]);
    } catch (PDOException $e) {
        die("خطأ أثناء الحذف: " . $e->getMessage());
    }
}

header("Location: " . SITE_URL . "admin/messages.php");
exit;

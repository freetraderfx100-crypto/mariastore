<?php
require_once __DIR__ . '/../includes/db_connect.php';
require_once __DIR__ . '/../includes/auth.php';
// require_once __DIR__ . '/includes/session_config.php';

// التحقق من أن المستخدم مدير
checkAdminRole();

// البحث عن العملاء
$search = $_GET['search'] ?? '';
if (!empty($search)) {
    $stmt = $conn->prepare("SELECT id, username, email, role, avatar, created_at, is_active FROM users WHERE username LIKE ? OR email LIKE ? ORDER BY id DESC");
    $stmt->execute(["%$search%", "%$search%"]);
} else {
    $stmt = $conn->prepare("SELECT id, username, email, role, avatar, created_at, is_active FROM users ORDER BY id DESC");
    $stmt->execute();
}

$customers = $stmt->fetchAll(PDO::FETCH_ASSOC);

// تعيين عنوان الصفحة
$page_title = "إدارة العملاء";
?>

<!DOCTYPE html>
<html lang="ar">

<head>
    <meta charset="UTF-8">
    <title>إدارة العملاء</title>
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>assets/css/customers.css">
    <!-- <style>
        .loading-spinner {
            border: 4px solid #f3f3f3;
            border-top: 4px solid #3498db;
            border-radius: 50%;
            width: 30px;
            height: 30px;
            animation: spin 1s linear infinite;
            margin: 0 auto;
        }

        @keyframes spin {
            0% {
                transform: rotate(0deg);
            }

            100% {
                transform: rotate(360deg);
            }
        }
    </style> -->
</head>

<body>
    <?php include __DIR__ . '/../includes/admin_header.php'; ?>

    <div style="text-align: center; margin-bottom: 20px;">
        <a href="<?php echo SITE_URL; ?>admin/add_customer.php" class="back-btn" style="padding: 10px 20px; background: #ffb8c6; color: white; text-decoration: none; border-radius: 6px;"><i class="fas fa-user-plus"></i> إضافة عميل جديد</a>
    </div>

    <div style="text-align: center; margin: 20px;">
        <input type="text" id="search" placeholder="ابحث بالاسم أو البريد" style="padding: 10px; width: 300px;">
        <select id="roleFilter" style="padding: 10px;">
            <option value="">الكل</option>
            <option value="admin">مدير</option>
            <option value="user">مستخدم</option>
        </select>
    </div>

    <h1>قائمة العملاء</h1>
    <div class="responsive-table">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>الصورة</th>
                    <th>الاسم</th>
                    <th>البريد الإلكتروني</th>
                    <th>الدور</th>
                    <th>الحالة</th>
                    <th>تاريخ الإنشاء</th>
                    <th>التحكم</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($customers as $user): ?>
                    <tr>
                        <td>
                            <?php if (!empty($user['avatar'])): ?>
                                <img src="<?php echo SITE_URL; ?>assets/images/users/avatars/<?= htmlspecialchars($user['avatar']) ?>" alt="avatar" class="product-thumbnail">
                            <?php else: ?>
                                <img src="<?php echo SITE_URL; ?>assets/images/default-avatar.png" alt="default" class="product-thumbnail">
                            <?php endif; ?>
                        </td>
                        <td><?= htmlspecialchars($user['username']) ?></td>
                        <td><?= htmlspecialchars($user['email']) ?></td>
                        <td><?= htmlspecialchars($user['role']) ?></td>
                        <td><?= $user['is_active'] ? '✅ مفعل' : '⛔ غير مفعل' ?></td>
                        <td><?= htmlspecialchars($user['created_at']) ?></td>
                        <td class="actions">
                            <a href="<?php echo SITE_URL; ?>admin/edit_customer.php?id=<?= $user['id'] ?>" class="edit">تعديل</a>
                            <a href="<?php echo SITE_URL; ?>admin/delete_customer.php?id=<?= $user['id'] ?>" class="delete" onclick="return confirm('هل أنت متأكد من حذف هذا العميل؟');">حذف</a>
                            <?php if ($user['is_active']): ?>
                                <a href="<?php echo SITE_URL; ?>admin/toggle_status.php?id=<?= $user['id'] ?>&action=deactivate" class="delete">تعطيل</a>
                            <?php else: ?>
                                <a href="<?php echo SITE_URL; ?>admin/toggle_status.php?id=<?= $user['id'] ?>&action=activate" class="edit">تفعيل</a>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php include __DIR__ . '/../includes/admin_footer.php'; ?>

    <script>
        // تعريف المتغيرات مرة واحدة فقط
        const searchInput = document.getElementById("search");
        const tableBody = document.querySelector("tbody");
        const roleFilter = document.getElementById("roleFilter");

        function showLoading() {
            tableBody.innerHTML = `
                <tr>
                    <td colspan="7" style="text-align: center;">
                        <div class="loading-spinner"></div>
                        <p>جاري التحميل...</p>
                    </td>
                </tr>
            `;
        }

        function loadFilteredResults() {
            showLoading();

            const query = searchInput.value.trim();
            const role = roleFilter.value;

            fetch(`search_customers.php?search=${encodeURIComponent(query)}&role=${encodeURIComponent(role)}`)
                .then(res => res.text())
                .then(data => {
                    tableBody.innerHTML = data;
                })
                .catch(error => {
                    tableBody.innerHTML = `
                        <tr>
                            <td colspan="7" style="text-align: center; color: red;">
                                حدث خطأ أثناء جلب البيانات
                            </td>
                        </tr>
                    `;
                    console.error('Error:', error);
                });
        }

        // إضافة مستمعي الأحداث مرة واحدة
        searchInput.addEventListener("keyup", loadFilteredResults);
        roleFilter.addEventListener("change", loadFilteredResults);
    </script>
</body>

</html>
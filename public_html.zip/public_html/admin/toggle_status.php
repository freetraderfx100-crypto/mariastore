<?php
require_once __DIR__ . '/../includes/db_connect.php';
require_once __DIR__ . '/../includes/auth.php';

session_start();

// التحقق من أن المستخدم مدير
checkAdminRole();

if (!isset($_GET['id'], $_GET['action'])) {
    header("Location: " . SITE_URL . "admin/customers.php");
    exit;
}

$id = intval($_GET['id']);
$action = $_GET['action'];

if ($action === 'activate') {
    $stmt = $conn->prepare("UPDATE users SET is_active = 1 WHERE id = ?");
} elseif ($action === 'deactivate') {
    $stmt = $conn->prepare("UPDATE users SET is_active = 0 WHERE id = ?");
} else {
    header("Location: " . SITE_URL . "admin/customers.php");
    exit;
}

$stmt->execute([$id]);

header("Location: " . SITE_URL . "admin/customers.php");
exit;

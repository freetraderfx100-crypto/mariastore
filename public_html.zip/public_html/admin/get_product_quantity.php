<?php
require_once __DIR__ . '/../../includes/db_connect.php';

header('Content-Type: application/json');

if (!isset($_GET['product_id']) || !isset($_GET['color']) || !isset($_GET['size'])) {
    echo json_encode(['quantity' => 0]);
    exit;
}

$product_id = (int)$_GET['product_id'];
$color = $_GET['color'];
$size = $_GET['size'];

$stmt = $conn->prepare("
    SELECT quantity 
    FROM product_variants 
    WHERE product_id = ? AND color = ? AND size = ?
");
$stmt->execute([$product_id, $color, $size]);
$quantity = $stmt->fetchColumn() ?? 0;

echo json_encode(['quantity' => $quantity]);
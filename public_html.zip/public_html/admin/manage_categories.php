<?php
require_once __DIR__ . '/../includes/db_connect.php';

// جلب الأقسام الرئيسية والتصنيفات الفرعية
$main_categories = $conn->query("SELECT * FROM categories WHERE parent_id IS NULL ORDER BY name")->fetchAll();
$sub_categories = $conn->query("SELECT * FROM categories WHERE parent_id IS NOT NULL ORDER BY parent_id, name")->fetchAll();

// جلب عدد المنتجات لكل تصنيف
$products_count = [];
$stmt = $conn->query("SELECT category_id, COUNT(*) as count FROM products GROUP BY category_id");
foreach ($stmt->fetchAll() as $row) {
    $products_count[$row['category_id']] = $row['count'];
}

// تعيين عنوان الصفحة
$page_title = "إدارة التصنيفات";

include __DIR__ . '/../includes/admin_header.php';
?>

<div class="admin-container">
    <h1>إدارة الأقسام والتصنيفات</h1>

    <!-- إضافة قسم رئيسي -->
    <div class="card mb-4">
        <div class="card-header">
            <h3>إضافة قسم رئيسي</h3>
        </div>
        <div class="card-body">
            <form id="addMainCategoryForm" action="add_category.php" method="post" enctype="multipart/form-data">
                <input type="hidden" name="type" value="main">
                <div class="form-group">
                    <label>اسم القسم</label>
                    <input type="text" name="name" class="form-control" required>
                </div>
                <div class="form-group">
                    <label>الرابط (Slug)</label>
                    <input type="text" name="slug" class="form-control" required>
                </div>
                <div class="form-group">
                    <label>الوصف</label>
                    <textarea name="description" class="form-control"></textarea>
                </div>
                <div class="form-group">
                    <label>صورة القسم</label>
                    <input type="file" name="image" class="form-control" accept="image/*">
                </div>
                <button type="submit" class="btn btn-primary" id="saveMainCategoryBtn">حفظ القسم</button>
            </form>
        </div>
    </div>

    <!-- إضافة تصنيف فرعي -->
    <div class="card mb-4">
        <div class="card-header">
            <h3>إضافة تصنيف فرعي</h3>
        </div>
        <div class="card-body">
            <form id="addSubCategoryForm" action="add_category.php" method="post" enctype="multipart/form-data">
                <input type="hidden" name="type" value="sub">
                <div class="form-group">
                    <label>القسم الرئيسي</label>
                    <select name="parent_id" class="form-control" required>
                        <?php foreach ($main_categories as $cat): ?>
                            <option value="<?= $cat['id'] ?>"><?= $cat['name'] ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>اسم التصنيف</label>
                    <input type="text" name="name" class="form-control" required>
                </div>
                <div class="form-group">
                    <label>الرابط (Slug)</label>
                    <input type="text" name="slug" class="form-control" required>
                </div>
                <div class="form-group">
                    <label>صورة التصنيف</label>
                    <input type="file" name="image" class="form-control" accept="image/*">
                </div>
                <button type="submit" class="btn btn-primary" id="saveSubCategoryBtn">حفظ التصنيف</button>
            </form>
        </div>
    </div>


    <!-- عرض التصنيفات -->
    <div class="card">
        <div class="card-header">
            <h3>الأقسام والتصنيفات</h3>
        </div>
        <div class="card-body">
            <div class="responsive-table">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>الاسم</th>
                            <th>النوع</th>
                            <th>الرابط</th>
                            <th>عدد المنتجات</th>
                            <th>الإجراءات</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($main_categories as $main): ?>
                            <tr class="table-primary">
                                <td><strong><?= $main['name'] ?></strong></td>
                                <td>قسم رئيسي</td>
                                <td><?= $main['slug'] ?></td>
                                <td><?= $products_count[$main['id']] ?? 0 ?></td>
                                <td>
                                    <a href="<?php echo SITE_URL; ?>admin/edit_category.php?id=<?= $main['id'] ?>" class="btn btn-sm btn-warning">تعديل</a>
                                    <a href="<?php echo SITE_URL; ?>admin/delete_category.php?id=<?= $main['id'] ?>" class="btn btn-sm btn-danger delete-btn" data-id="<?= $main['id'] ?>" data-is-main="true">حذف</a>
                                </td>
                            </tr>
                            <?php foreach ($sub_categories as $sub): ?>
                                <?php if ($sub['parent_id'] == $main['id']): ?>
                                    <tr>
                                        <td class="ps-4">↳ <?= $sub['name'] ?></td>
                                        <td>تصنيف فرعي</td>
                                        <td><?= $sub['slug'] ?></td>
                                        <td><?= $products_count[$sub['id']] ?? 0 ?></td>
                                        <td>
                                            <a href="<?php echo SITE_URL; ?>admin/edit_category.php?id=<?= $sub['id'] ?>" class="btn btn-sm btn-warning">تعديل</a>
                                            <a href="<?php echo SITE_URL; ?>admin/delete_category.php?id=<?= $sub['id'] ?>" class="btn btn-sm btn-danger delete-btn" data-id="<?= $sub['id'] ?>" data-is-main="false">حذف</a>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        // SweetAlert2 لأزرار الحذف (الكود السابق)

        // SweetAlert2 عند حفظ التصنيف الرئيسي
        const mainCategoryForm = document.getElementById('addMainCategoryForm');
        if (mainCategoryForm) {
            mainCategoryForm.addEventListener('submit', function(e) {
                e.preventDefault();

                Swal.fire({
                    title: 'جاري حفظ القسم الرئيسي',
                    text: 'يرجى الانتظار بينما نقوم بحفظ البيانات...',
                    icon: 'info',
                    allowOutsideClick: false,
                    showConfirmButton: false,
                    willOpen: () => {
                        Swal.showLoading();
                    }
                });

                // إرسال النموذج بعد عرض الرسالة
                setTimeout(() => {
                    mainCategoryForm.submit();
                }, 500);
            });
        }

        // SweetAlert2 عند حفظ التصنيف الفرعي
        const subCategoryForm = document.getElementById('addSubCategoryForm');
        if (subCategoryForm) {
            subCategoryForm.addEventListener('submit', function(e) {
                e.preventDefault();

                Swal.fire({
                    title: 'جاري حفظ التصنيف الفرعي',
                    text: 'يرجى الانتظار بينما نقوم بحفظ البيانات...',
                    icon: 'info',
                    allowOutsideClick: false,
                    showConfirmButton: false,
                    willOpen: () => {
                        Swal.showLoading();
                    }
                });

                // إرسال النموذج بعد عرض الرسالة
                setTimeout(() => {
                    subCategoryForm.submit();
                }, 500);
            });
        }

        // عرض رسائل الجلسة إذا كانت موجودة
        <?php if (isset($_SESSION['success'])): ?>
            Swal.fire({
                title: 'نجاح',
                text: '<?= $_SESSION['success'] ?>',
                icon: 'success',
                confirmButtonText: 'حسناً'
            });
            <?php unset($_SESSION['success']); ?>
        <?php endif; ?>

        <?php if (isset($_SESSION['error'])): ?>
            Swal.fire({
                title: 'خطأ',
                text: '<?= $_SESSION['error'] ?>',
                icon: 'error',
                confirmButtonText: 'حسناً'
            });
            <?php unset($_SESSION['error']); ?>
        <?php endif; ?>
    });
</script>

<?php include __DIR__ . '/../includes/admin_footer.php'; ?>
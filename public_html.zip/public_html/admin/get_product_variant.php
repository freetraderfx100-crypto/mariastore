<?php
// require_once __DIR__ . '/../../includes/db_connect.php';

// if (!isset($_GET['product_id']) || !isset($_GET['color']) || !isset($_GET['size'])) {
//     echo json_encode(null);
//     exit;
// }

// $product_id = (int)$_GET['product_id'];
// $color = $_GET['color'];
// $size = $_GET['size'];

// $stmt = $conn->prepare("
//     SELECT pv.*, p.name AS product_name 
//     FROM product_variants pv
//     JOIN products p ON pv.product_id = p.id
//     WHERE pv.product_id = ? AND pv.color = ? AND pv.size = ?
// ");
// $stmt->execute([$product_id, $color, $size]);
// $variant = $stmt->fetch(PDO::FETCH_ASSOC);

// header('Content-Type: application/json');
// echo json_encode($variant ?: null);
?>
<!-- ملغي للتاكد -->

class SearchSuggestions {
    constructor() {
        this.searchInput = document.getElementById('search-input');
        this.searchSuggestions = document.getElementById('search-suggestions');
        this.debounceTimer = null;
        this.init();
    }

    init() {
        if (!this.searchInput || !this.searchSuggestions) return;

        this.setupEventListeners();
    }

    setupEventListeners() {
        // عرض المنتجات المميزة عند التركيز
        this.searchInput.addEventListener('focus', () => {
            if (this.searchInput.value.trim() === '') {
                this.fetchFeaturedProducts();
            }
        });

        // الاقتراحات التلقائية أثناء الكتابة
        this.searchInput.addEventListener('input', () => {
            this.handleInput();
        });

        // إغلاق الاقتراحات عند النقر خارجها
        document.addEventListener('click', (e) => {
            if (!this.searchInput.contains(e.target) && !this.searchSuggestions.contains(e.target)) {
                this.hideSuggestions();
            }
        });

        // إرسال النموذج عند الضغط على Enter
        this.searchInput.addEventListener('keydown', (e) => {
            if (e.key === 'Enter') {
                this.hideSuggestions();
            }
        });
    }

    handleInput() {
        clearTimeout(this.debounceTimer);
        const query = this.searchInput.value.trim();

        if (query.length < 2) {
            this.hideSuggestions();
            return;
        }

        this.debounceTimer = setTimeout(() => {
            this.fetchSuggestions(query);
        }, 300);
    }

    async fetchSuggestions(query) {
        try {
            const response = await fetch(`${SITE_URL}includes/autocomplete.php?q=${encodeURIComponent(query)}`);
            const data = await response.json();

            if (data.length > 0) {
                this.renderSuggestions(data, 'نتائج البحث');
            } else {
                this.hideSuggestions();
            }
        } catch (error) {
            console.error('Error fetching suggestions:', error);
            this.hideSuggestions();
        }
    }

    async fetchFeaturedProducts() {
        try {
            const response = await fetch(`${SITE_URL}includes/featured_products.php`);
            const data = await response.json();

            if (data.length > 0) {
                this.renderSuggestions(data, 'منتجات مميزة');
            }
        } catch (error) {
            console.error('Error fetching featured products:', error);
        }
    }

    renderSuggestions(items, title) {
        this.searchSuggestions.innerHTML = `
            <div class="suggestions-header">
                <span>${title}</span>
            </div>
        `;

        items.forEach(item => {
            const suggestion = document.createElement('div');
            suggestion.className = 'search-suggestion';

            // استخدام صورة افتراضية إذا لم توجد صورة
            const imageUrl = item.image ?
                `${SITE_URL}assets/images/${item.image}` :
                `${SITE_URL}assets/images/default-product-image.jpg`;

            suggestion.innerHTML = `
                <img src="${imageUrl}" alt="${item.name}" onerror="this.src='${SITE_URL}assets/images/default-product-image.jpg'">
                <div class="product-info">
                    <div class="product-name">${item.name}</div>
                    <div class="product-price">${item.price} ر.ي</div>
                    ${item.category ? `<div class="product-category">${item.category}</div>` : ''}
                </div>
            `;

            suggestion.addEventListener('click', () => {
                if (title === 'منتجات مميزة') {
                    window.location.href = `${SITE_URL}pages/details_product.php?id=${item.id}`;
                } else {
                    this.searchInput.value = item.name;
                    this.hideSuggestions();
                    this.searchInput.closest('form').submit();
                }
            });

            this.searchSuggestions.appendChild(suggestion);
        });

        this.showSuggestions();
    }

    showSuggestions() {
        this.searchSuggestions.style.display = 'block';
    }

    hideSuggestions() {
        this.searchSuggestions.style.display = 'none';
    }
}

// تهيئة النظام عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', function () {
    new SearchSuggestions();
});
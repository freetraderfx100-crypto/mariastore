// عرض/إخفاء قسم المساعدة
document.getElementById('quickHelpBtn').addEventListener('click', function() {
    const helpSection = document.getElementById('helpSection');
    helpSection.style.display = helpSection.style.display === 'none' ? 'block' : 'none';
});

document.getElementById('closeHelpBtn').addEventListener('click', function() {
    document.getElementById('helpSection').style.display = 'none';
});

// فتح المساعدة تلقائياً لأول زيارة
window.addEventListener('DOMContentLoaded', function() {
    const firstVisit = localStorage.getItem('reportsHelpSeen');
    if (!firstVisit) {
        document.getElementById('helpSection').style.display = 'block';
        localStorage.setItem('reportsHelpSeen', 'true');
    }
});
// هذا الكود لسلايد المنتجات و وسلايد الفئات في الصفحه الرئيسيه
    function slideProduct(sliderElement, direction) {
            const slidesContainer = sliderElement.querySelector('.product-slides');
    const slides = slidesContainer.querySelectorAll('.product-slide');
            let activeIndex = Array.from(slides).findIndex(slide => slide.classList.contains('active'));

    slides[activeIndex].classList.remove('active');

    let newIndex = activeIndex + direction;
    if (newIndex < 0) {
        newIndex = slides.length - 1;
            } else if (newIndex >= slides.length) {
        newIndex = 0;
            }

    slides[newIndex].classList.add('active');
        }

    // كود أزرار التمرير للفئات
    document.addEventListener('DOMContentLoaded', function() {
            const wrapper = document.getElementById('categoriesWrapper');
    const scrollLeftBtn = document.getElementById('scrollLeft');
    const scrollRightBtn = document.getElementById('scrollRight');

    if (wrapper && scrollLeftBtn && scrollRightBtn) {
                // مقدار التمرير (يمكن تعديله حسب الحاجة)
                const scrollAmount = 300;

    // زر التمرير لليسار
    scrollLeftBtn.addEventListener('click', function() {
        wrapper.scrollBy({
            left: scrollAmount,
            behavior: 'smooth'
        });
                });

    // زر التمرير لليمين
    scrollRightBtn.addEventListener('click', function() {
        wrapper.scrollBy({
            left: -scrollAmount,
            behavior: 'smooth'
        });
                });

    // تفعيل التحقق الأولي
    wrapper.dispatchEvent(new Event('scroll'));
            }
        });

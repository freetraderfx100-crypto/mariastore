/**
 * lazy-loader.js
 * --------------------------------------------------------------------
 * سكربت بسيط وفعّال لتحميل الصور الكسول (Lazy Loading).
 *
 * المشكلة التي يحلها:
 *   - في ملف index.php ودالة displayProduct()، تُكتب وسوم <img> بصيغة:
 *       <img class="lazy" data-src="..." src="data:image/gif;base64,...">
 *   - لكن لا يوجد أي سكربت في المشروع يحوّل data-src إلى src فعلياً.
 *   - النتيجة: الصور في الصفحة الرئيسية تظهر فارغة (مربع أبيض) رغم
 *     وجود المسارات الصحيحة.
 *
 * ما يفعله هذا السكربت:
 *   1) يبحث عن كل عنصر <img> يحمل class="lazy" أو سمة data-src.
 *   2) يستخدم IntersectionObserver لمراقبة دخول الصورة إلى منطقة الرؤية.
 *   3) عند الاقتراب (rootMargin 200px) ينقل القيمة من data-src إلى src.
 *   4) يدعم أيضاً عناصر <picture> و<source data-srcset> وsrcset على <img>.
 *   5) يعيد مراقبة العناصر الجديدة التي تُحقن عبر AJAX (تحميل المزيد
 *      من المنتجات تلقائياً) باستخدام MutationObserver.
 *   6) يعمل بدون أي مكتبة خارجية، ويعود بسرعة إلى تحميل فوري لو فشل
 *      IntersectionObserver (متصفحات قديمة جداً).
 * --------------------------------------------------------------------
 */

(function () {
    'use strict';

    const LAZY_CLASS = 'lazy';
    const DATA_SRC = 'data-src';
    const DATA_SRCSET = 'data-srcset';
    const ROOT_MARGIN = '300px 0px'; // ابدأ التحميل قبل ظهور الصورة بـ 300px
    const THRESHOLD = 0.01;

    /**
     * تحميل صورة واحدة: نقل data-src إلى src.
     */
    function loadImage(img) {
        // src عادي
        const dataSrc = img.getAttribute(DATA_SRC);
        if (dataSrc) {
            img.src = dataSrc;
            img.removeAttribute(DATA_SRC);
        }

        // srcset (لو موجود)
        const dataSrcset = img.getAttribute(DATA_SRCSET);
        if (dataSrcset) {
            img.srcset = dataSrcset;
            img.removeAttribute(DATA_SRCSET);
        }

        // إزالة class="lazy" لتفادي إعادة معالجته
        img.classList.remove(LAZY_CLASS);
        img.classList.add('lazy-loaded');
    }

    /**
     * إنشاء IntersectionObserver لمتابعة الصور.
     */
    function createObserver() {
        if (!('IntersectionObserver' in window)) {
            // متصفح قديم: حمّل كل الصور دفعة واحدة
            document.querySelectorAll('img.' + LAZY_CLASS + ',img[' + DATA_SRC + ']').forEach(loadImage);
            return null;
        }

        const observer = new IntersectionObserver(function (entries, obs) {
            entries.forEach(function (entry) {
                if (entry.isIntersecting) {
                    loadImage(entry.target);
                    obs.unobserve(entry.target);
                }
            });
        }, {
            root: null,
            rootMargin: ROOT_MARGIN,
            threshold: THRESHOLD
        });

        return observer;
    }

    /**
     * تسجيل مجموعة من الصور الجديدة لمراقبتها.
     */
    function observeImages(observer, scope) {
        if (!observer) return;
        const imgs = (scope || document).querySelectorAll(
            'img.' + LAZY_CLASS + ',img[' + DATA_SRC + ']'
        );
        imgs.forEach(function (img) {
            // تجاهل ما هو قيد المراقبة فعلاً
            if (!img.__lazyObserved) {
                img.__lazyObserved = true;
                observer.observe(img);
            }
        });
    }

    /**
     * تهيئة السكربت: مراقبة الصور الموجودة + المتغيرة عبر AJAX.
     */
    function init() {
        const observer = createObserver();
        if (observer) {
            observeImages(observer, document);

            // مراقبة DOM لتطبيق lazy-loading على الصور التي تُحقن
            // لاحقاً (مثل التحميل اللانهائي للمنتجات في index.php).
            if ('MutationObserver' in window) {
                const mo = new MutationObserver(function (mutations) {
                    mutations.forEach(function (m) {
                        m.addedNodes.forEach(function (node) {
                            if (node.nodeType !== 1) return;
                            // إن كان عنصر <img> جديد
                            if (node.tagName === 'IMG') {
                                if (node.classList.contains(LAZY_CLASS) || node.hasAttribute(DATA_SRC)) {
                                    observeImages(observer, node);
                                }
                            }
                            // أو حاوية تحتوي على صور
                            if (node.querySelectorAll) {
                                observeImages(observer, node);
                            }
                        });
                    });
                });
                mo.observe(document.body, { childList: true, subtree: true });
            }
        }
    }

    // شغّل عند جاهزية DOM
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();

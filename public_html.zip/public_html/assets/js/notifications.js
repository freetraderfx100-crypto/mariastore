/**
 * assets/js/notifications.js
 * --------------------------------------------------------------------
 * عميل نظام الإشعارات لمتجر ماريا
 * 
 * الميزات:
 *   - جلب الإشعارات من API
 *   - عرض الناقوس (bell) مع عداد غير المقروء
 *   - عرض الإشعارات في dropdown
 *   - دعم Web Push (لو مفعّل)
 *   - دعم Browser Notifications API
 *   - فحص دوري كل 30 ثانية
 * --------------------------------------------------------------------
 */

(function() {
    'use strict';

    const NOTIFICATIONS_API = (window.SITE_URL || '/') + 'api/notifications.php';
    const POLL_INTERVAL = 30000; // 30 ثانية
    // ✅ إصلاح: sw.js يجب أن يكون في جذر الموقع ليتمكن من التحكم في النطاق بالكامل
    const SW_PATH = (window.SITE_URL || '/') + 'sw.js';

    class NotificationsClient {
        constructor() {
            this.unreadCount = 0;
            this.notifications = [];
            this.lastFetchTime = 0;
            this.isDropdownOpen = false;
            this.lastSeenId = this.getLastSeenId();
            this.soundEnabled = true;
            this.autoDismissSeconds = 8;
            // ✅ v2.0: visitor_session من localStorage (يستمر عبر الجلسات والأجهزة)
            this.visitorSession = this.getOrCreateVisitorSession();
            // ✅ v2.0: CSRF token من meta tag (يحمي طلبات POST)
            this.csrfToken = this.getCsrfToken();
            this.init();
        }

        /**
         * ✅ v2.0: توليد/قراءة visitor_session من localStorage
         *
         * المشكلة السابقة: كان يُولّد في session (PHP) ويتغير عند كل جلسة جديدة
         *   → الإشعارات تظهر "غير مقروءة" بعد إغلاق المتصفح
         *
         * الحل: نولّده مرة واحدة في localStorage ويستمر للأبد على نفس المتصفح
         */
        getOrCreateVisitorSession() {
            try {
                let vs = localStorage.getItem('visitor_session');
                // تحقق من الصيغة: vs_ + 32 hex char
                if (!vs || !/^vs_[a-f0-9]{32}$/.test(vs)) {
                    vs = 'vs_' + Array.from(crypto.getRandomValues(new Uint8Array(16)))
                        .map(b => b.toString(16).padStart(2, '0')).join('');
                    localStorage.setItem('visitor_session', vs);
                    console.log('[Notifications] Generated new visitor_session:', vs);
                }
                return vs;
            } catch (e) {
                // localStorage قد يكون معطّل (private mode) → نولّد مؤقتاً
                return 'vs_' + Math.random().toString(16).slice(2).padEnd(32, '0').slice(0, 32);
            }
        }

        /**
         * ✅ v2.0: قراءة CSRF token من meta tag
         * يُولّد من PHP ويُحقن في <meta name="csrf-token">
         */
        getCsrfToken() {
            const meta = document.querySelector('meta[name="csrf-token"]');
            return meta ? meta.content : '';
        }

        /**
         * ✅ v2.0: بناء headers موحدة لطلبات fetch
         */
        buildFetchHeaders(extra = {}) {
            const headers = {
                'X-Visitor-Session': this.visitorSession,
                ...extra,
            };
            if (this.csrfToken) {
                headers['X-CSRF-Token'] = this.csrfToken;
            }
            return headers;
        }

        async init() {
            // قراءة الإعدادات من meta tags (لو موجودة)
            const soundMeta = document.querySelector('meta[name="notify-sound"]');
            if (soundMeta) this.soundEnabled = soundMeta.content === '1';

            const dismissMeta = document.querySelector('meta[name="notify-auto-dismiss"]');
            if (dismissMeta) this.autoDismissSeconds = parseInt(dismissMeta.content, 10) || 8;

            // تسجيل Service Worker
            await this.registerServiceWorker();

            // طلب إذن الإشعارات
            await this.requestNotificationPermission();

            // إنشاء UI
            this.createBellUI();

            // جلب أولي
            await this.fetchNotifications();

            // بدء الفحص الدوري
            this.startPolling();

            // ربط الأحداث
            this.bindEvents();

            // ✅ الاشتراك التلقائي في Web Push لو الإذن granted
            if ('Notification' in window && Notification.permission === 'granted') {
                console.log('[Notifications] Permission already granted, attempting to subscribe...');
                setTimeout(() => this.subscribeToPush(), 2000);
            }

            console.log('[Notifications] Client initialized');
        }

        /**
         * تسجيل Service Worker
         */
        async registerServiceWorker() {
            if (!('serviceWorker' in navigator)) {
                console.warn('[Notifications] Service Worker not supported');
                return false;
            }

            try {
                // ✅ إضافة ?v= لإجبار المتصفح على تحميل أحدث نسخة من SW
                const swPathWithVersion = SW_PATH + '?v=' + Date.now();
                console.log('[Notifications] Registering SW from:', swPathWithVersion);
                const registration = await navigator.serviceWorker.register(swPathWithVersion, {
                    scope: '/',
                    updateViaCache: 'none',
                });
                console.log('[Notifications] ✅ SW registered successfully:', registration.scope);
                
                // انتظر حتى يصبح SW نشطاً
                if (registration.waiting) {
                    console.log('[Notifications] SW is waiting, activating...');
                    registration.waiting.postMessage({ type: 'SKIP_WAITING' });
                }
                if (registration.installing) {
                    console.log('[Notifications] SW is installing...');
                    await new Promise(resolve => {
                        if (registration.installing) {
                            registration.installing.addEventListener('statechange', (e) => {
                                if (e.target.state === 'activated') {
                                    console.log('[Notifications] SW activated');
                                    resolve();
                                }
                            });
                        } else {
                            resolve();
                        }
                    });
                }
                
                return true;
            } catch (err) {
                console.error('[Notifications] ❌ SW registration failed:', err.message);
                console.error('Full error:', err);
                return false;
            }
        }

        /**
         * طلب إذن الإشعارات
         */
        async requestNotificationPermission() {
            if (!('Notification' in window)) {
                console.warn('[Notifications] Notifications API not supported');
                return false;
            }

            if (Notification.permission === 'granted') {
                return true;
            }

            if (Notification.permission === 'denied') {
                return false;
            }

            // لا نطلب الإذن تلقائياً - ننتظر تفاعل المستخدم
            return false;
        }

        /**
         * طلب الإذن عند تفاعل المستخدم
         */
        async askPermission() {
            if (!('Notification' in window)) return false;
            
            if (Notification.permission === 'granted') return true;
            if (Notification.permission === 'denied') return false;

            try {
                const permission = await Notification.requestPermission();
                return permission === 'granted';
            } catch (e) {
                return false;
            }
        }

        /**
         * إنشاء واجهة الناقوس
         */
        createBellUI() {
            // التحقق من عدم وجوده مسبقاً
            if (document.getElementById('notificationsBell')) return;

            const bell = document.createElement('div');
            bell.id = 'notificationsBell';
            bell.className = 'notifications-bell';
            bell.innerHTML = `
                <button class="bell-button" aria-label="الإشعارات" title="الإشعارات">
                    <i class="fas fa-bell"></i>
                    <span class="bell-badge" id="bellBadge" style="display:none;">0</span>
                </button>
                <div class="notifications-dropdown" id="notificationsDropdown">
                    <div class="notifications-header">
                        <h3><i class="fas fa-bell"></i> الإشعارات</h3>
                        <div class="notifications-actions">
                            <button class="mark-all-read" id="markAllReadBtn" title="تعليم الكل كمقروء">
                                <i class="fas fa-check-double"></i>
                            </button>
                            <button class="enable-push-btn" id="enablePushBtn" title="تفعيل الإشعارات" style="display:none;">
                                <i class="fas fa-bell"></i>
                            </button>
                        </div>
                    </div>
                    <div class="notifications-list" id="notificationsList">
                        <div class="notifications-loading">
                            <i class="fas fa-spinner fa-spin"></i> جارٍ التحميل...
                        </div>
                    </div>
                    <div class="notifications-footer">
                        <a href="#" id="viewAllLink">عرض الكل</a>
                    </div>
                </div>
            `;

            // إضافة الأنماط (لو لم تُضاف مسبقاً)
            if (!document.getElementById('notificationsBellStyles')) {
                const styles = document.createElement('style');
                styles.id = 'notificationsBellStyles';
                styles.textContent = `
                    .notifications-bell {
                        position: fixed;
                        top: 20px;
                        left: 20px;
                        z-index: 9999;
                        font-family: 'Tajawal', 'Segoe UI', Tahoma, sans-serif;
                    }
                    .notifications-bell .bell-button {
                        position: relative;
                        width: 50px;
                        height: 50px;
                        border-radius: 50%;
                        border: none;
                        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                        color: white;
                        cursor: pointer;
                        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
                        transition: all 0.3s ease;
                        font-size: 20px;
                    }
                    .notifications-bell .bell-button:hover {
                        transform: scale(1.1);
                        box-shadow: 0 6px 16px rgba(0,0,0,0.2);
                    }
                    .notifications-bell .bell-badge {
                        position: absolute;
                        top: -5px;
                        right: -5px;
                        background: #dc3545;
                        color: white;
                        font-size: 11px;
                        font-weight: bold;
                        min-width: 20px;
                        height: 20px;
                        border-radius: 10px;
                        display: flex;
                        align-items: center;
                        justify-content: center;
                        padding: 0 5px;
                        border: 2px solid white;
                    }
                    .notifications-bell .bell-badge.pulse {
                        animation: pulse 2s infinite;
                    }
                    @keyframes pulse {
                        0% { transform: scale(1); }
                        50% { transform: scale(1.15); box-shadow: 0 0 0 8px rgba(220,53,69,0.2); }
                        100% { transform: scale(1); }
                    }
                    .notifications-dropdown {
                        position: absolute;
                        top: 60px;
                        left: 0;
                        width: 380px;
                        max-height: 500px;
                        background: white;
                        border-radius: 12px;
                        box-shadow: 0 10px 40px rgba(0,0,0,0.2);
                        display: none;
                        flex-direction: column;
                        overflow: hidden;
                        opacity: 0;
                        transform: translateY(-10px);
                        transition: all 0.2s ease;
                    }
                    .notifications-dropdown.show {
                        display: flex;
                        opacity: 1;
                        transform: translateY(0);
                    }
                    .notifications-header {
                        padding: 15px;
                        background: #f8f9fa;
                        border-bottom: 1px solid #e9ecef;
                        display: flex;
                        justify-content: space-between;
                        align-items: center;
                    }
                    .notifications-header h3 {
                        margin: 0;
                        font-size: 16px;
                        color: #333;
                    }
                    .notifications-actions {
                        display: flex;
                        gap: 8px;
                    }
                    .notifications-actions button {
                        background: none;
                        border: none;
                        cursor: pointer;
                        color: #666;
                        font-size: 14px;
                        padding: 5px;
                        border-radius: 4px;
                        transition: all 0.2s;
                    }
                    .notifications-actions button:hover {
                        background: #e9ecef;
                        color: #333;
                    }
                    .notifications-list {
                        flex: 1;
                        overflow-y: auto;
                        max-height: 380px;
                    }
                    .notifications-list::-webkit-scrollbar {
                        width: 6px;
                    }
                    .notifications-list::-webkit-scrollbar-thumb {
                        background: #ccc;
                        border-radius: 3px;
                    }
                    .notification-item {
                        padding: 12px 15px;
                        border-bottom: 1px solid #f0f0f0;
                        cursor: pointer;
                        transition: background 0.2s;
                        display: flex;
                        gap: 10px;
                        align-items: flex-start;
                        text-decoration: none;
                        color: inherit;
                    }
                    .notification-item:hover {
                        background: #f8f9fa;
                    }
                    .notification-item.unread {
                        background: #e3f2fd;
                        border-right: 3px solid #2196f3;
                    }
                    .notification-item.unread:hover {
                        background: #e1f0fe;
                    }
                    .notification-icon {
                        width: 40px;
                        height: 40px;
                        border-radius: 50%;
                        background: #e9ecef;
                        display: flex;
                        align-items: center;
                        justify-content: center;
                        flex-shrink: 0;
                        font-size: 16px;
                        color: #666;
                    }
                    .notification-item.unread .notification-icon {
                        background: #2196f3;
                        color: white;
                    }
                    .notification-content {
                        flex: 1;
                        min-width: 0;
                    }
                    .notification-title {
                        font-weight: bold;
                        font-size: 14px;
                        color: #333;
                        margin-bottom: 3px;
                    }
                    .notification-body {
                        font-size: 13px;
                        color: #666;
                        line-height: 1.4;
                        overflow: hidden;
                        display: -webkit-box;
                        -webkit-line-clamp: 2;
                        -webkit-box-orient: vertical;
                    }
                    .notification-time {
                        font-size: 11px;
                        color: #999;
                        margin-top: 4px;
                    }
                    .notifications-loading, .notifications-empty {
                        padding: 40px 20px;
                        text-align: center;
                        color: #999;
                        font-size: 14px;
                    }
                    .notifications-footer {
                        padding: 10px;
                        background: #f8f9fa;
                        border-top: 1px solid #e9ecef;
                        text-align: center;
                    }
                    .notifications-footer a {
                        color: #2196f3;
                        text-decoration: none;
                        font-size: 13px;
                        font-weight: bold;
                    }
                    .toast-notification {
                        position: fixed;
                        top: 20px;
                        right: 20px;
                        background: white;
                        border-radius: 12px;
                        box-shadow: 0 10px 40px rgba(0,0,0,0.2);
                        padding: 15px;
                        max-width: 350px;
                        z-index: 10000;
                        display: flex;
                        gap: 12px;
                        align-items: flex-start;
                        cursor: pointer;
                        animation: slideInRight 0.3s ease;
                        border-right: 4px solid #2196f3;
                    }
                    @keyframes slideInRight {
                        from { transform: translateX(400px); opacity: 0; }
                        to { transform: translateX(0); opacity: 1; }
                    }
                    .toast-notification.removing {
                        animation: slideOutRight 0.3s ease forwards;
                    }
                    @keyframes slideOutRight {
                        from { transform: translateX(0); opacity: 1; }
                        to { transform: translateX(400px); opacity: 0; }
                    }
                    @media (max-width: 768px) {
                        .notifications-bell {
                            top: 15px;
                            left: 15px;
                        }
                        .notifications-bell .bell-button {
                            width: 42px;
                            height: 42px;
                            font-size: 16px;
                        }
                        .notifications-dropdown {
                            width: calc(100vw - 30px);
                            max-width: 380px;
                        }
                    }
                `;
                document.head.appendChild(styles);
            }

            document.body.appendChild(bell);
        }

        /**
         * ربط الأحداث
         */
        bindEvents() {
            const bell = document.getElementById('notificationsBell');
            if (!bell) return;

            const button = bell.querySelector('.bell-button');
            const dropdown = document.getElementById('notificationsDropdown');
            const markAllBtn = document.getElementById('markAllReadBtn');
            const enablePushBtn = document.getElementById('enablePushBtn');

            // النقر على الناقوس
            button.addEventListener('click', async (e) => {
                e.stopPropagation();
                this.toggleDropdown();

                // ✅ إصلاح: الاشتراك في Web Push تلقائياً لو الإذن مُعطى
                if (Notification.permission === 'default') {
                    await this.askPermission();
                }
                // لو الإذن granted (سواء كان من قبل أو تم إعطاؤه الآن)، اشترك
                if (Notification.permission === 'granted') {
                    await this.subscribeToPush();
                }
            });

            // النقر خارج الـ dropdown لإغلاقه
            document.addEventListener('click', (e) => {
                if (!bell.contains(e.target)) {
                    this.closeDropdown();
                }
            });

            // تعليم الكل كمقروء
            if (markAllBtn) {
                markAllBtn.addEventListener('click', (e) => {
                    e.stopPropagation();
                    this.markAllAsRead();
                });
            }

            // تفعيل Web Push
            if (enablePushBtn) {
                enablePushBtn.addEventListener('click', async (e) => {
                    e.stopPropagation();
                    const granted = await this.askPermission();
                    if (granted) {
                        await this.subscribeToPush();
                        enablePushBtn.style.display = 'none';
                    }
                });
            }
        }

        /**
         * فتح/إغلاق القائمة
         */
        toggleDropdown() {
            const dropdown = document.getElementById('notificationsDropdown');
            if (!dropdown) return;
            this.isDropdownOpen = !this.isDropdownOpen;
            dropdown.classList.toggle('show', this.isDropdownOpen);

            if (this.isDropdownOpen) {
                this.fetchNotifications();
            }
        }

        closeDropdown() {
            const dropdown = document.getElementById('notificationsDropdown');
            if (dropdown) dropdown.classList.remove('show');
            this.isDropdownOpen = false;
        }

        /**
         * جلب الإشعارات من API
         */
        async fetchNotifications() {
            try {
                const response = await fetch(`${NOTIFICATIONS_API}?action=list&limit=20`, {
                    credentials: 'same-origin',
                    cache: 'no-cache',
                    headers: this.buildFetchHeaders(),
                });
                
                if (!response.ok) throw new Error('HTTP ' + response.status);
                
                const data = await response.json();
                if (!data.success) throw new Error(data.error || 'Unknown error');

                const newNotifications = data.data || [];
                
                // اكتشاف الإشعارات الجديدة
                const newOnes = newNotifications.filter(n => 
                    !this.notifications.find(old => old.id === n.id)
                );

                this.notifications = newNotifications;
                this.unreadCount = newNotifications.filter(n => !n.is_read).length;
                
                this.updateBellBadge();
                this.renderNotificationsList();

                // ✅ v2.5 إصلاح جذري: عرض Toast فقط للإشعارات الجديدة فعلياً
                // نستخدم lastNotifId (محفوظ في localStorage) كمرجع وحيد
                // Toast يظهر فقط للإشعارات التي id > lastNotifId
                const lastSeenId = this.getLastSeenId();

                const trulyNew = newNotifications.filter(n =>
                    parseInt(n.id, 10) > lastSeenId && !n.is_read
                );

                trulyNew.forEach(n => {
                    this.showToastNotification(n);
                });

                // تحديث lastNotifId فوراً (حتى لو المتصفح أُغلق، لن تظهر مجدداً)
                if (newNotifications.length > 0) {
                    const maxId = Math.max(...newNotifications.map(n => parseInt(n.id, 10)));
                    if (maxId > lastSeenId) {
                        this.saveLastSeenId(maxId);
                    }
                }

                this.lastFetchTime = Date.now();
                this.saveLastSeenId();

            } catch (err) {
                console.error('[Notifications] Fetch error:', err);
                const list = document.getElementById('notificationsList');
                if (list) {
                    list.innerHTML = '<div class="notifications-empty">تعذّر تحميل الإشعارات</div>';
                }
            }
        }

        /**
         * تحديث عداد الناقوس
         */
        updateBellBadge() {
            const badge = document.getElementById('bellBadge');
            if (!badge) return;

            if (this.unreadCount > 0) {
                badge.textContent = this.unreadCount > 99 ? '99+' : this.unreadCount;
                badge.style.display = 'flex';
                badge.classList.add('pulse');
            } else {
                badge.style.display = 'none';
                badge.classList.remove('pulse');
            }
        }

        /**
         * عرض قائمة الإشعارات
         */
        renderNotificationsList() {
            const list = document.getElementById('notificationsList');
            if (!list) return;

            if (this.notifications.length === 0) {
                list.innerHTML = `
                    <div class="notifications-empty">
                        <i class="fas fa-bell-slash" style="font-size:30px;color:#ccc;margin-bottom:10px;"></i>
                        <div>لا توجد إشعارات</div>
                    </div>
                `;
                return;
            }

            list.innerHTML = this.notifications.map(n => {
                // ✅ عرض صورة المنتج لو موجودة
                let iconHtml;
                if (n.image_url) {
                    iconHtml = `<div class="notification-icon" style="background:transparent;padding:0;overflow:hidden;">
                        <img src="${this.escapeHtml(n.image_url)}" 
                             alt="صورة" 
                             style="width:100%;height:100%;object-fit:cover;border-radius:50%;"
                             onerror="this.style.display='none';this.parentElement.innerHTML='<i class=\\'fas ${this.escapeHtml(n.icon || 'fa-bell')}\\'></i>';">
                    </div>`;
                } else {
                    iconHtml = `<div class="notification-icon">
                        <i class="fas ${this.escapeHtml(n.icon || 'fa-bell')}"></i>
                    </div>`;
                }
                
                return `
                <div class="notification-item ${n.is_read ? '' : 'unread'}" data-id="${n.id}" data-url="${this.escapeHtml(n.url || '')}">
                    ${iconHtml}
                    <div class="notification-content">
                        <div class="notification-title">${this.escapeHtml(n.title)}</div>
                        <div class="notification-body">${this.escapeHtml(n.body)}</div>
                        <div class="notification-time">${this.formatTime(n.created_at)}</div>
                    </div>
                </div>`;
            }).join('');

            // ربط النقر
            list.querySelectorAll('.notification-item').forEach(item => {
                item.addEventListener('click', () => {
                    const id = item.dataset.id;
                    const url = item.dataset.url;
                    
                    if (id) this.markAsRead(id);
                    
                    if (url) {
                        window.location.href = url;
                    }
                });
            });
        }

        /**
         * عرض إشعار toast
         */
        showToastNotification(notification) {
            const toast = document.createElement('div');
            toast.className = 'toast-notification';
            
            // ✅ عرض صورة المنتج لو موجودة، وإلا أيقونة Font Awesome
            let iconHtml;
            if (notification.image_url) {
                // عرض صورة المنتج
                iconHtml = `<div class="notification-icon" style="background:transparent;padding:0;overflow:hidden;width:50px;height:50px;">
                    <img src="${this.escapeHtml(notification.image_url)}" 
                         alt="صورة المنتج" 
                         style="width:100%;height:100%;object-fit:cover;border-radius:50%;"
                         onerror="this.style.display='none';this.parentElement.innerHTML='<i class=\\'fas fa-bell\\' style=\\'font-size:20px;\\'></i>';this.parentElement.style.background='#2196f3';this.parentElement.style.color='white';">
                </div>`;
            } else {
                // عرض أيقونة Font Awesome
                iconHtml = `<div class="notification-icon" style="background:#2196f3;color:white;">
                    <i class="fas ${this.escapeHtml(notification.icon || 'fa-bell')}"></i>
                </div>`;
            }
            
            toast.innerHTML = `
                ${iconHtml}
                <div class="notification-content" style="flex:1;">
                    <div class="notification-title">${this.escapeHtml(notification.title)}</div>
                    <div class="notification-body">${this.escapeHtml(notification.body)}</div>
                </div>
                <button style="background:none;border:none;font-size:18px;color:#999;cursor:pointer;" onclick="this.parentElement.classList.add('removing');setTimeout(()=>this.parentElement.remove(),300);">&times;</button>
            `;

            toast.onclick = (e) => {
                if (e.target.tagName === 'BUTTON') return;
                if (notification.id) this.markAsRead(notification.id);
                if (notification.url) window.location.href = notification.url;
            };

            document.body.appendChild(toast);

            // تشغيل صوت
            if (this.soundEnabled) {
                this.playSound();
            }

            // ✅ v2.1: إشعار النظام مع صورة المنتج
            if (Notification.permission === 'granted' && 'serviceWorker' in navigator) {
                navigator.serviceWorker.ready.then(registration => {
                    // ✅ استخدام صورة المنتج كأيقونة رئيسية (لو موجودة)
                    // مع fallback للأيقونة الافتراضية
                    const notifIcon = notification.image_url
                        || ((window.SITE_URL || '/') + 'assets/icons/icon-192.png');
                    const notifBadge = (window.SITE_URL || '/') + 'assets/icons/badge-72.png';

                    const notifOptions = {
                        body: notification.body,
                        icon: notifIcon,
                        badge: notifBadge,
                        dir: 'rtl',
                        lang: 'ar',
                        tag: `notif-${notification.id}`,
                        data: {
                            url: notification.url || '/',
                            notification_id: notification.id,
                        },
                        vibrate: [200, 100, 200],
                    };

                    // ✅ صورة كبيرة (Chrome Desktop فقط) - تستخدم صورة المنتج
                    if (notification.image_url) {
                        notifOptions.image = notification.image_url;
                    }

                    registration.showNotification(notification.title, notifOptions);
                });
            }

            // إزالة تلقائية
            setTimeout(() => {
                toast.classList.add('removing');
                setTimeout(() => toast.remove(), 300);
            }, this.autoDismissSeconds * 1000);
        }

        /**
         * تشغيل صوت الإشعار
         */
        playSound() {
            try {
                const audio = new Audio((window.SITE_URL || '/') + 'assets/sounds/notification.mp3');
                audio.volume = 0.5;
                audio.play().catch(() => {});
            } catch (e) {}
        }

        /**
         * تعليم إشعار كمقروء
         */
        async markAsRead(id) {
            try {
                const formData = new FormData();
                formData.append('action', 'mark_read');
                formData.append('id', id);

                await fetch(`${NOTIFICATIONS_API}?action=mark_read`, {
                    method: 'POST',
                    body: formData,
                    credentials: 'same-origin',
                    headers: this.buildFetchHeaders(),
                });

                // تحديث محلي
                const notif = this.notifications.find(n => n.id == id);
                if (notif) {
                    notif.is_read = 1;
                    this.unreadCount = Math.max(0, this.unreadCount - 1);
                    this.updateBellBadge();
                    this.renderNotificationsList();
                }
            } catch (err) {
                console.error('[Notifications] markAsRead error:', err);
            }
        }

        /**
         * تعليم الكل كمقروء
         */
        async markAllAsRead() {
            try {
                await fetch(`${NOTIFICATIONS_API}?action=mark_all_read`, {
                    method: 'POST',
                    credentials: 'same-origin',
                    headers: this.buildFetchHeaders(),
                });

                this.notifications.forEach(n => n.is_read = 1);
                this.unreadCount = 0;
                this.updateBellBadge();
                this.renderNotificationsList();
            } catch (err) {
                console.error('[Notifications] markAllAsRead error:', err);
            }
        }

        /**
         * الاشتراك في Web Push
         */
        async subscribeToPush() {
            if (!('serviceWorker' in navigator) || !('PushManager' in window)) {
                console.warn('[Notifications] Push not supported');
                return false;
            }

            try {
                console.log('[Notifications] Subscribing to push...');

                // جلب المفتاح العمومي
                const response = await fetch(`${NOTIFICATIONS_API}?action=vapid_public_key`, {
                    credentials: 'same-origin',
                    headers: this.buildFetchHeaders(),
                });
                const data = await response.json();
                console.log('[Notifications] VAPID response:', data);

                if (!data.success || !data.public_key) {
                    console.warn('[Notifications] VAPID key not configured');
                    return false;
                }

                if (!data.web_push_enabled) {
                    console.warn('[Notifications] Web Push is disabled in settings');
                    return false;
                }

                const registration = await navigator.serviceWorker.ready;
                console.log('[Notifications] SW ready:', registration.scope);
                
                // التحقق من اشتراك موجود
                let subscription = await registration.pushManager.getSubscription();
                console.log('[Notifications] Existing subscription:', subscription ? subscription.endpoint : 'none');
                
                // ✅ تتبع ما إذا كان هذا اشتراكاً جديداً أم موجوداً
                let isNewSubscription = false;
                
                if (!subscription) {
                    const publicKey = this.urlBase64ToUint8Array(data.public_key);
                    console.log('[Notifications] Creating new subscription...');
                    subscription = await registration.pushManager.subscribe({
                        userVisibleOnly: true,
                        applicationServerKey: publicKey,
                    });
                    console.log('[Notifications] New subscription created:', subscription.endpoint);
                    isNewSubscription = true;  // ✅ هذا اشتراك جديد
                }

                // إرسال لـ API
                console.log('[Notifications] Sending subscription to API...');
                const apiResponse = await fetch(`${NOTIFICATIONS_API}?action=subscribe`, {
                    method: 'POST',
                    headers: this.buildFetchHeaders({ 'Content-Type': 'application/json' }),
                    body: JSON.stringify({ subscription }),
                    credentials: 'same-origin',
                });
                
                const apiResult = await apiResponse.json();
                console.log('[Notifications] API subscribe response:', apiResult);
                
                if (apiResult.success) {
                    console.log('[Notifications] ✅ Push subscribed successfully!');
                    // ✅ إظهار رسالة النجاح فقط عند إنشاء اشتراك جديد (وليس في كل تحديث صفحة)
                    if (isNewSubscription) {
                        this.showSubscriptionSuccess();
                    }
                } else {
                    console.error('[Notifications] API subscribe failed:', apiResult);
                }
                
                return apiResult.success;

            } catch (err) {
                console.error('[Notifications] Subscribe error:', err);
                return false;
            }
        }

        /**
         * إظهار رسالة نجاح الاشتراك
         */
        showSubscriptionSuccess() {
            const toast = document.createElement('div');
            toast.className = 'toast-notification';
            toast.style.borderRightColor = '#28a745';
            toast.innerHTML = `
                <div class="notification-icon" style="background:#28a745;color:white;">
                    <i class="fas fa-check"></i>
                </div>
                <div class="notification-content" style="flex:1;">
                    <div class="notification-title">تم تفعيل الإشعارات</div>
                    <div class="notification-body">ستصلك الإشعارات حتى لو كان المتصفح مغلقاً</div>
                </div>
                <button style="background:none;border:none;font-size:18px;color:#999;cursor:pointer;" onclick="this.parentElement.classList.add('removing');setTimeout(()=>this.parentElement.remove(),300);">&times;</button>
            `;
            document.body.appendChild(toast);
            
            setTimeout(() => {
                toast.classList.add('removing');
                setTimeout(() => toast.remove(), 300);
            }, 5000);
        }

        /**
         * ✅ دوال localStorage لتتبع الإشعارات المعروضة
         */
        getShownToasts() {
            try {
                return JSON.parse(localStorage.getItem('shown_toasts') || '[]');
            } catch (e) {
                return [];
            }
        }

        markToastAsShown(notifId) {
            try {
                const shown = this.getShownToasts();
                if (!shown.includes(notifId)) {
                    shown.push(notifId);
                    // الاحتفاظ بآخر 20 إشعار فقط لتجنب تضخم localStorage
                    const trimmed = shown.slice(-20);
                    localStorage.setItem('shown_toasts', JSON.stringify(trimmed));
                }
            } catch (e) {}
        }

        getLatestUnreadId() {
            const unread = this.notifications.filter(n => !n.is_read);
            if (unread.length === 0) return null;
            // الإشعارات مرتبة تنازلياً (الأحدث أولاً)
            return unread[0].id;
        }

        /**
         * بدء الفحص الدوري
         */
        startPolling() {
            setInterval(() => this.fetchNotifications(), POLL_INTERVAL);

            // فحص عند العودة للمتابعة
            document.addEventListener('visibilitychange', () => {
                if (!document.hidden) {
                    this.fetchNotifications();
                }
            });
        }

        /**
         * حفظ/قراءة آخر إشعار شوهد
         */
        getLastSeenId() {
            try {
                return parseInt(localStorage.getItem('lastNotifId') || '0', 10);
            } catch (e) {
                return 0;
            }
        }

        saveLastSeenId(explicitId) {
            try {
                let idToSave;
                if (typeof explicitId === 'number') {
                    idToSave = explicitId;
                } else if (this.notifications.length > 0) {
                    idToSave = Math.max(...this.notifications.map(n => parseInt(n.id, 10)));
                } else {
                    return;
                }
                // v2.5: تأكد أن القيمة أكبر من المحفوظة (لا نرجع للوراء)
                const current = parseInt(localStorage.getItem('lastNotifId') || '0', 10);
                if (idToSave > current) {
                    localStorage.setItem('lastNotifId', String(idToSave));
                }
            } catch (e) {}
        }

        /**
         * دوال مساعدة
         */
        escapeHtml(str) {
            if (str == null) return '';
            return String(str)
                .replace(/&/g, '&amp;')
                .replace(/</g, '&lt;')
                .replace(/>/g, '&gt;')
                .replace(/"/g, '&quot;')
                .replace(/'/g, '&#039;');
        }

        formatTime(dateStr) {
            try {
                const date = new Date(dateStr.replace(' ', 'T'));
                const now = new Date();
                const diff = (now - date) / 1000; // ثواني
                
                if (diff < 60) return 'الآن';
                if (diff < 3600) return Math.floor(diff / 60) + ' دقيقة';
                if (diff < 86400) return Math.floor(diff / 3600) + ' ساعة';
                if (diff < 604800) return Math.floor(diff / 86400) + ' يوم';
                
                return date.toLocaleDateString('ar-EG');
            } catch (e) {
                return dateStr;
            }
        }

        urlBase64ToUint8Array(base64String) {
            const padding = '='.repeat((4 - base64String.length % 4) % 4);
            const base64 = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/');
            const rawData = window.atob(base64);
            const outputArray = new Uint8Array(rawData.length);
            for (let i = 0; i < rawData.length; ++i) {
                outputArray[i] = rawData.charCodeAt(i);
            }
            return outputArray;
        }
    }

    // بدء تلقائي عند تحميل الصفحة
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => new NotificationsClient());
    } else {
        new NotificationsClient();
    }

    // إتاحة عالمياً
    window.NotificationsClient = NotificationsClient;
})();

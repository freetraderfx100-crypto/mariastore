/**
 * assets/js/pwa-install.js
 * --------------------------------------------------------------------
 * ✅ v1.0 - تشجيع المستخدمين على تثبيت الموقع كـ PWA
 *
 * الفائدة:
 *   - على Mobile: الإشعارات تصل حتى لو Chrome مغلق تماماً
 *   - على Desktop: اختصار على سطح المكتب + إشعارات أقوى
 *   - على iOS: يدعم Web Push (الذي لا يدعمه Safari عادة)
 *
 * يظهر زر "تثبيت التطبيق" عند توفر beforeinstallprompt event
 * --------------------------------------------------------------------
 */

(function() {
    'use strict';

    let deferredPrompt = null;

    class PWAInstaller {
        constructor() {
            this.installButton = null;
            this.hasShownPrompt = false;
            this.init();
        }

        init() {
            // الاستماع لحدث beforeinstallprompt
            window.addEventListener('beforeinstallprompt', (e) => {
                console.log('[PWA] beforeinstallprompt fired');
                // منع ظهور الـ prompt التلقائي
                e.preventDefault();
                // حفظ الحدث لاستخدامه لاحقاً
                deferredPrompt = e;
                // إظهار زر التثبيت
                this.showInstallButton();
            });

            // الاستماع لحدث appinstalled
            window.addEventListener('appinstalled', (evt) => {
                console.log('[PWA] App installed successfully');
                this.hideInstallButton();
                // إظهار رسالة شكر
                this.showThankYouMessage();
                // إخفاء الزر نهائياً
                localStorage.setItem('pwa_installed', '1');
            });

            // لو المثبت بالفعل، لا تظهر الزر
            if (this.isStandalone() || localStorage.getItem('pwa_installed') === '1') {
                console.log('[PWA] Already installed/standalone mode');
                return;
            }

            // على iOS، نعرض تعليمات خاصة
            if (this.isIOS() && !this.isInStandaloneMode()) {
                this.showIOSInstructions();
            }
        }

        /**
         * هل الموقع يعمل كـ PWA (standalone mode)؟
         */
        isStandalone() {
            return window.matchMedia('(display-mode: standalone)').matches
                || window.navigator.standalone === true
                || document.referrer.startsWith('android-app://');
        }

        /**
         * هل الموقع على iOS؟
         */
        isIOS() {
            const ua = window.navigator.userAgent;
            const iOS = /iPad|iPhone|iPod/.test(ua);
            const iPadOS = navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1;
            return iOS || iPadOS;
        }

        /**
         * إنشاء زر التثبيت
         */
        showInstallButton() {
            if (this.installButton) return;

            const btn = document.createElement('div');
            btn.id = 'pwa-install-btn';
            btn.style.cssText = `
                position: fixed;
                bottom: 20px;
                right: 20px;
                z-index: 10000;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: white;
                padding: 12px 20px;
                border-radius: 30px;
                cursor: pointer;
                box-shadow: 0 4px 20px rgba(102, 126, 234, 0.4);
                font-family: 'Tajawal', sans-serif;
                font-size: 14px;
                font-weight: 600;
                display: flex;
                align-items: center;
                gap: 8px;
                transition: all 0.3s ease;
                animation: pwaSlideIn 0.4s ease;
            `;

            btn.innerHTML = `
                <i class="fas fa-download" style="font-size: 16px;"></i>
                <span>تثبيت التطبيق</span>
                <button style="background: none; border: none; color: rgba(255,255,255,0.7); cursor: pointer; padding: 0 4px; font-size: 18px;" onclick="event.stopPropagation(); this.parentElement.remove();">&times;</button>
            `;

            btn.addEventListener('click', (e) => {
                if (e.target.tagName === 'BUTTON') return;
                this.promptInstall();
            });

            // إضافة animation
            const style = document.createElement('style');
            style.textContent = `
                @keyframes pwaSlideIn {
                    from { transform: translateY(100px); opacity: 0; }
                    to { transform: translateY(0); opacity: 1; }
                }
                #pwa-install-btn:hover {
                    transform: translateY(-2px);
                    box-shadow: 0 6px 25px rgba(102, 126, 234, 0.5);
                }
            `;
            document.head.appendChild(style);

            document.body.appendChild(btn);
            this.installButton = btn;

            // إخفاء تلقائي بعد 15 ثانية لو لم يُضغط
            setTimeout(() => {
                if (this.installButton && !this.hasShownPrompt) {
                    this.hideInstallButton();
                }
            }, 15000);
        }

        /**
         * إظهار prompt التثبيت
         */
        async promptInstall() {
            if (!deferredPrompt) {
                console.log('[PWA] No deferred prompt available');
                return;
            }

            this.hasShownPrompt = true;

            // إظهار الـ prompt
            deferredPrompt.prompt();

            // انتظار اختيار المستخدم
            const { outcome } = await deferredPrompt.userChoice;
            console.log(`[PWA] User response: ${outcome}`);

            // الـ prompt لا يمكن إعادة استخدامه
            deferredPrompt = null;
            this.hideInstallButton();

            if (outcome === 'accepted') {
                localStorage.setItem('pwa_installed', '1');
            }
        }

        /**
         * إخفاء زر التثبيت
         */
        hideInstallButton() {
            if (this.installButton) {
                this.installButton.style.animation = 'pwaSlideOut 0.3s ease';
                setTimeout(() => {
                    if (this.installButton) {
                        this.installButton.remove();
                        this.installButton = null;
                    }
                }, 300);
            }
        }

        /**
         * رسالة شكر بعد التثبيت
         */
        showThankYouMessage() {
            const msg = document.createElement('div');
            msg.style.cssText = `
                position: fixed;
                top: 20px;
                left: 50%;
                transform: translateX(-50%);
                background: #28a745;
                color: white;
                padding: 15px 25px;
                border-radius: 8px;
                z-index: 10001;
                font-family: 'Tajawal', sans-serif;
                box-shadow: 0 4px 20px rgba(40, 167, 69, 0.4);
                animation: pwaSlideDown 0.4s ease;
            `;
            msg.innerHTML = `
                <i class="fas fa-check-circle"></i>
                تم تثبيت التطبيق! الإشعارات ستعمل بشكل أفضل الآن.
            `;
            document.body.appendChild(msg);
            setTimeout(() => msg.remove(), 5000);
        }

        /**
         * تعليمات خاصة بـ iOS
         */
        showIOSInstructions() {
            // ننتظر 3 ثوانٍ بعد تحميل الصفحة
            setTimeout(() => {
                if (localStorage.getItem('ios_instructions_shown') === '1') return;

                const banner = document.createElement('div');
                banner.style.cssText = `
                    position: fixed;
                    bottom: 20px;
                    left: 20px;
                    right: 20px;
                    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                    color: white;
                    padding: 15px;
                    border-radius: 12px;
                    z-index: 10000;
                    font-family: 'Tajawal', sans-serif;
                    box-shadow: 0 4px 20px rgba(0,0,0,0.2);
                    animation: pwaSlideIn 0.4s ease;
                `;
                banner.innerHTML = `
                    <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 8px;">
                        <i class="fas fa-mobile-alt" style="font-size: 24px;"></i>
                        <strong style="font-size: 16px;">ثبّت ماريا كتطبيق!</strong>
                        <button style="background: none; border: none; color: rgba(255,255,255,0.7); cursor: pointer; margin-right: auto; font-size: 22px;" onclick="this.parentElement.parentElement.remove(); localStorage.setItem('ios_instructions_shown', '1');">&times;</button>
                    </div>
                    <div style="font-size: 13px; line-height: 1.6;">
                        لتصلك الإشعارات حتى لو المتصفح مغلق:<br>
                        1. اضغط زر المشاركة <i class="fas fa-share" style="font-size: 12px;"></i> في Safari<br>
                        2. اختر "Add to Home Screen" <i class="fas fa-plus-square" style="font-size: 12px;"></i><br>
                        3. افتح التطبيق من الشاشة الرئيسية
                    </div>
                `;
                document.body.appendChild(banner);

                // إخفاء تلقائي بعد 20 ثانية
                setTimeout(() => {
                    if (banner.parentElement) {
                        banner.remove();
                        localStorage.setItem('ios_instructions_shown', '1');
                    }
                }, 20000);
            }, 3000);
        }
    }

    // بدء تلقائي
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => new PWAInstaller());
    } else {
        new PWAInstaller();
    }

    window.PWAInstaller = PWAInstaller;
})();

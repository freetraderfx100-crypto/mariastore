        // دالة لتحريك السلايدر
        function slideProduct(slider, direction) {
            const slidesContainer = slider.querySelector('.product-slides');
            const slides = slider.querySelectorAll('.product-slide');
            const activeSlide = slider.querySelector('.product-slide.active');
            
            let currentIndex = activeSlide ? parseInt(activeSlide.dataset.index) : 0;
            let newIndex = currentIndex + direction;
            
            // التدوير عند الوصول إلى النهايات
            if (newIndex < 0) newIndex = slides.length - 1;
            if (newIndex >= slides.length) newIndex = 0;
            
            // تحديث الصورة النشطة
            slides.forEach(slide => {
                slide.classList.remove('active');
                if (parseInt(slide.dataset.index) === newIndex) {
                    slide.classList.add('active');
                }
            });
            
            // تحريك السلايدر
            slidesContainer.style.transform = `translateX(-${newIndex * 100}%)`;
        }

        // التمرير التلقائي
        document.addEventListener('DOMContentLoaded', function() {
            const sliders = document.querySelectorAll('.product-slider');
            
            sliders.forEach(slider => {
                const slides = slider.querySelectorAll('.product-slide');
                if (slides.length <= 1) return;
                
                // تعيين الصورة الأولى كنشطة
                slides[0].classList.add('active');
                
                // التمرير التلقائي
                let interval = setInterval(() => {
                    const activeSlide = slider.querySelector('.product-slide.active');
                    let currentIndex = parseInt(activeSlide.dataset.index);
                    slideProduct(slider.parentElement, 1);
                }, 5000);
                
                // إيقاف التمرير التلقائي عند التوقف
                slider.addEventListener('mouseenter', () => clearInterval(interval));
                slider.addEventListener('mouseleave', () => {
                    interval = setInterval(() => {
                        slideProduct(slider.parentElement, 1);
                    }, 5000);
                });
            });
        });
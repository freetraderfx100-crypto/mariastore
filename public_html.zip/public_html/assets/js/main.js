// تفعيل قائمة الهاتف
document.addEventListener('DOMContentLoaded', function () {
    // تبديل القائمة
    const mobileToggle = document.querySelector('.mobile-nav-toggle');
    if (mobileToggle) {
        mobileToggle.addEventListener('click', function () {
            document.body.classList.toggle('mobile-nav-active');
        });
    }

    // إغلاق القائمة عند النقر خارجها
    document.addEventListener('click', function (e) {
        if (!e.target.closest('.mobile-nav') && !e.target.closest('.mobile-nav-toggle')) {
            document.body.classList.remove('mobile-nav-active');
        }
    });

    // القوائم المنسدلة
    const dropdownToggles = document.querySelectorAll('.dropdown-toggle');
    dropdownToggles.forEach(toggle => {
        toggle.addEventListener('click', function () {
            const dropdown = this.closest('.mobile-dropdown');
            dropdown.classList.toggle('active');
        });
    });

    // تفعيل شريط البحث
    const searchIcon = document.querySelector('.mobile-search-icon');
    const searchBar = document.querySelector('.mobile-search-bar');
    if (searchIcon && searchBar) {
        searchIcon.addEventListener('click', function () {
            searchBar.style.display = searchBar.style.display === 'block' ? 'none' : 'block';
            if (searchBar.style.display === 'block') {
                searchBar.querySelector('input').focus();
            }
        });
    }

    // تحديث عداد السلة
    // أضف هذه الدالة إذا لم تكن موجودة
    function updateCartCount() {
        // يمكنك تحديث هذا الكود ليتناسب مع طريقة عرض عداد السلة في موقعك
        const cartCountElement = document.querySelector('.cart-count');
        if (cartCountElement) {
            // يمكنك جلب عدد المنتجات من الخادم أو من localStorage
            fetch('<?php echo SITE_URL; ?>pages/get_cart_count.php')
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        cartCountElement.textContent = data.count;
                    }
                });
        }
    }

    // استدعاء الدالة عند تحميل الصفحة
    document.addEventListener('DOMContentLoaded', function () {
        updateCartCount();
    }); 

// إدارة الكمية في صفحة المنتج (تم نقلها داخل DOMContentLoaded)
document.addEventListener('DOMContentLoaded', function() {
    const minusBtn = document.querySelector('.quantity-btn.minus');
    const plusBtn = document.querySelector('.quantity-btn.plus');
    const quantityInput = document.getElementById('quantity');

    if (minusBtn && plusBtn && quantityInput) {
        minusBtn.addEventListener('click', function () {
            let value = parseInt(quantityInput.value);
            if (value > 1) {
                quantityInput.value = value - 1;
            }
        });

        plusBtn.addEventListener('click', function () {
            let value = parseInt(quantityInput.value);
            let max = parseInt(quantityInput.max);
            if (value < max) {
                quantityInput.value = value + 1;
            }
        });
    }
});
});

let offset = 8;
let loading = false;

function loadMoreProducts() {
    if (loading) return;
    loading = true;
    const loadingEl = document.getElementById('loading');
    const productsContainer = document.getElementById('productsContainer');
    if (!loadingEl) { loading = false; return; }
    loadingEl.style.display = 'block';

    fetch(`load_more_products.php?offset=${offset}`)
        .then(res => res.text())
        .then(html => {
            if (html.trim() === '') {
                loadingEl.innerHTML = 'تم عرض كل المنتجات';
            } else if (productsContainer) {
                productsContainer.insertAdjacentHTML('beforeend', html);
                offset += 8;
                loading = false;
            }
        });
}

window.addEventListener('scroll', () => {
    const { scrollTop, scrollHeight, clientHeight } = document.documentElement;
    if (scrollTop + clientHeight >= scrollHeight - 100) {
        loadMoreProducts();
    }
});

// كود صور العروض في الصفحه الرئيسيه


function updateSlider(index) {
    slides.forEach((slide, i) => {
        slide.classList.toggle("active", i === index);
    });

    document.querySelectorAll(".dots button").forEach((dot, i) => {
        dot.classList.toggle("active", i === index);
    });
}


// كود عرض الصور المنتج بشكل متحرك


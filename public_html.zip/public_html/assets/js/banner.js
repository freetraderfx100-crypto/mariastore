// ✅ انتظر تحميل DOM + فحص وجود العناصر قبل الاستخدام
document.addEventListener('DOMContentLoaded', function() {
    const slides = document.querySelectorAll('.slide');
    const prevBtn = document.querySelector('.prev');
    const nextBtn = document.querySelector('.next');
    const dots = document.querySelectorAll('.dots button');

    // لو لا توجد شرائح، لا تفعل شيئاً
    if (slides.length === 0) return;

    let currentIndex = 0;

    function showSlide(index) {
        slides.forEach((slide, i) => {
            slide.classList.toggle('active', i === index);
        });
        currentIndex = index;
    }

    // ✅ فحص وجود الأزرار قبل إضافة event listeners
    if (prevBtn) {
        prevBtn.addEventListener('click', () => {
            let index = currentIndex - 1;
            if (index < 0) index = slides.length - 1;
            showSlide(index);
        });
    }

    if (nextBtn) {
        nextBtn.addEventListener('click', () => {
            let index = currentIndex + 1;
            if (index >= slides.length) index = 0;
            showSlide(index);
        });
    }

    dots.forEach(dot => {
        dot.addEventListener('click', e => {
            const slideIndex = Number(e.target.getAttribute('data-slide'));
            showSlide(slideIndex);
        });
    });

    // تمرير تلقائي كل 5 ثواني
    setInterval(() => {
        let nextIndex = (currentIndex + 1) % slides.length;
        showSlide(nextIndex);
    }, 5000);
});

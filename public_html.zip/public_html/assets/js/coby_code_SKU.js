
// إضافة مستمع حدث لنسخ SKU
document.addEventListener('DOMContentLoaded', function () {
    const skuCells = document.querySelectorAll('.product-sku');

    skuCells.forEach(cell => {
        cell.addEventListener('click', function () {
            const sku = this.textContent.trim();
            if (sku !== 'N/A') {
                navigator.clipboard.writeText(sku).then(() => {
                    // عرض رسالة تأكيد
                    const originalText = this.innerHTML;
                    this.innerHTML = '✓ تم النسخ!';

                    setTimeout(() => {
                        this.innerHTML = originalText;
                    }, 1500);
                });
            }
        });

        // تغيير المؤشر عند التمرير
        if (cell.textContent.trim() !== 'N/A') {
            cell.style.cursor = 'pointer';
            cell.title = 'انقر لنسخ SKU';
        }
    });
});
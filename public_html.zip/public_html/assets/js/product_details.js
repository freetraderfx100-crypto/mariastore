// تغيير الصورة الرئيسية عند النقر على الصور المصغرة
document.querySelectorAll('.thumbnail img').forEach(thumb => {
    thumb.addEventListener('click', function() {
        const mainImage = document.getElementById('mainProductImage');
        mainImage.src = this.src;
        document.querySelectorAll('.thumbnail').forEach(t => t.classList.remove('active'));
        this.parentElement.classList.add('active');
    });
});

// إدارة الكمية
document.querySelector('.quantity-btn.minus')?.addEventListener('click', function() {
    const quantityInput = document.getElementById('quantity');
    let value = parseInt(quantityInput.value);
    if (value > 1) quantityInput.value = value - 1;
});

document.querySelector('.quantity-btn.plus')?.addEventListener('click', function() {
    const quantityInput = document.getElementById('quantity');
    let value = parseInt(quantityInput.value);
    let max = parseInt(quantityInput.max);
    if (value < max) quantityInput.value = value + 1;
});

// منع الإرسال قبل اختيار اللون/المقاس
document.querySelector('.add-to-cart-form')?.addEventListener('submit', function(e) {
    const color = document.getElementById('selectedColor').value;
    const size = document.getElementById('selectedSize').value;

    if (!color) {
        alert('يرجى اختيار اللون قبل إضافة المنتج إلى السلة.');
        e.preventDefault();
    }

    if (!size) {
        alert('يرجى اختيار المقاس قبل إضافة المنتج إلى السلة.');
        e.preventDefault();
    }
});

// إدارة المفضلة
document.addEventListener("DOMContentLoaded", function() {
    const wishlistButtonsDiv = document.getElementById("wishlistButtons");
    const messageDiv = document.getElementById("wishlistMessage");
    // ✅ إصلاح: استخدام متغير SITE_URL العام إن وُجد، وإلا استخدام المسار النسبي
    const SITE_URL = (typeof window.SITE_URL !== 'undefined') ? window.SITE_URL : '/';

    function addToWishlist(productId) {
        fetch(`${SITE_URL}pages/add_to_wishlist.php`, {
                method: "POST",
                headers: { "Content-Type": "application/x-www-form-urlencoded" },
                body: "product_id=" + encodeURIComponent(productId)
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    messageDiv.style.color = "green";
                    messageDiv.textContent = "تمت إضافة المنتج إلى المفضلة بنجاح.";
                    renderRemoveButton(productId);
                } else {
                    messageDiv.style.color = "red";
                    messageDiv.textContent = data.error || "حدث خطأ أثناء الإضافة.";
                }
            })
            .catch(() => {
                messageDiv.style.color = "red";
                messageDiv.textContent = "فشل الاتصال بالخادم.";
            });
    }

    function removeFromWishlist(productId) {
        fetch(`${SITE_URL}pages/remove_wishlist.php`, {
                method: "POST",
                headers: { "Content-Type": "application/x-www-form-urlencoded" },
                body: "product_id=" + encodeURIComponent(productId)
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    messageDiv.style.color = "green";
                    messageDiv.textContent = "تمت إزالة المنتج من المفضلة.";
                    renderAddButton(productId);
                } else {
                    messageDiv.style.color = "red";
                    messageDiv.textContent = data.error || "حدث خطأ أثناء الإزالة.";
                }
            })
            .catch(() => {
                messageDiv.style.color = "red";
                messageDiv.textContent = "فشل الاتصال بالخادم.";
            });
    }

    function renderAddButton(productId) {
        wishlistButtonsDiv.innerHTML = `
            <button id="addToWishlistBtn" data-product-id="${productId}" class="btn btn-outline-danger">
                ❤️ أضف إلى المفضلة
            </button>
        `;
        document.getElementById("addToWishlistBtn").addEventListener("click", function() {
            addToWishlist(productId);
        });
    }

    function renderRemoveButton(productId) {
        wishlistButtonsDiv.innerHTML = `
            <button id="removeFromWishlistBtn" data-product-id="${productId}" class="btn btn-danger">
                ❌ إزالة من المفضلة
            </button>
        `;
        document.getElementById("removeFromWishlistBtn").addEventListener("click", function() {
            removeFromWishlist(productId);
        });
    }

    // ربط الأحداث
    if (document.getElementById("addToWishlistBtn")) {
        document.getElementById("addToWishlistBtn").addEventListener("click", function() {
            addToWishlist(this.getAttribute("data-product-id"));
        });
    }

    if (document.getElementById("removeFromWishlistBtn")) {
        document.getElementById("removeFromWishlistBtn").addEventListener("click", function() {
            removeFromWishlist(this.getAttribute("data-product-id"));
        });
    }
});

// إدارة اللون والمقاس والكمية
document.addEventListener("DOMContentLoaded", function () {
    // ✅ إصلاح: كان هناك كود PHP داخل ملف JS (json_encode($product_variants))
    // الآن نعتمد على AJAX لجلب المقاسات المتاحة لكل لون
    const thumbnails = document.querySelectorAll('.thumbnail');
    const colorButtons = document.querySelectorAll('.color-btn');
    const sizeSelect = document.getElementById('size');
    const quantityInput = document.getElementById('quantity');
    const availabilityDiv = document.getElementById('variantAvailability');
    const hiddenColor = document.getElementById('selectedColor');
    const hiddenSize = document.getElementById('selectedSize');
    const hiddenImageUrl = document.getElementById('selectedImageUrl');
    // محاولة قراءة معرف المنتج من زر الإضافة للسلة أو من الحقل المخفي
    const addToCartForm = document.querySelector('.add-to-cart-form');
    const productIdInput = addToCartForm ? addToCartForm.querySelector('input[name="product_id"]') : null;
    const productId = productIdInput ? productIdInput.value : null;

    // استخدام متغير عام إن وجد (يمكن للصفحة تعريف window.SITE_URL)
    const SITE_URL = (typeof window.SITE_URL !== 'undefined') ? window.SITE_URL : '/';

    function updateSizesByColor(color) {
        if (!productId || !color) {
            sizeSelect.innerHTML = '<option value="">اختر مقاساً</option>';
            return;
        }
        // AJAX لجلب المقاسات المتاحة للون المختار
        fetch(`${SITE_URL}ajax/get_sizes_by_color.php?product_id=${encodeURIComponent(productId)}&color=${encodeURIComponent(color)}`)
            .then(r => r.json())
            .then(sizes => {
                sizeSelect.innerHTML = '<option value="">اختر مقاساً</option>';
                if (Array.isArray(sizes)) {
                    sizes.forEach(size => {
                        const option = document.createElement('option');
                        option.value = size;
                        option.textContent = size;
                        sizeSelect.appendChild(option);
                    });
                }
                hiddenSize.value = '';
                quantityInput.max = 1;
                availabilityDiv.innerHTML = `<i class="fas fa-info-circle"></i> <span>يرجى اختيار مقاساً</span>`;
            })
            .catch(() => {
                sizeSelect.innerHTML = '<option value="">اختر مقاساً</option>';
                availabilityDiv.innerHTML = `<i class="fas fa-exclamation-triangle"></i> <span>تعذّر تحميل المقاسات</span>`;
            });
    }

    function updateAvailability(color, size) {
        if (!color || !size) {
            availabilityDiv.innerHTML = `<i class="fas fa-info-circle"></i> <span>يرجى اختيار اللون والمقاس</span>`;
            quantityInput.max = 1;
            return;
        }
        // AJAX لجلب الكمية المتوفرة لهذه التركيبة
        fetch(`${SITE_URL}admin/get_product_quantity.php?product_id=${encodeURIComponent(productId)}&color=${encodeURIComponent(color)}&size=${encodeURIComponent(size)}`)
            .then(r => r.json())
            .then(data => {
                const qty = parseInt(data.quantity || 0, 10);
                if (qty > 0) {
                    availabilityDiv.innerHTML = `<i class="fas fa-check-circle"></i> <span>الكمية المتوفرة: ${qty}</span>`;
                    quantityInput.max = qty;
                } else {
                    availabilityDiv.innerHTML = `<i class="fas fa-times-circle"></i> <span>غير متوفر</span>`;
                    quantityInput.max = 0;
                }
            })
            .catch(() => {
                availabilityDiv.innerHTML = `<i class="fas fa-times-circle"></i> <span>تعذّر التحقق من التوفر</span>`;
                quantityInput.max = 1;
            });
    }

    thumbnails.forEach(thumb => {
        thumb.addEventListener('click', function () {
            const img = this.querySelector('img');
            if (!img) return;

            document.getElementById('mainProductImage').src = img.src;
            hiddenImageUrl.value = img.src.split('/').pop();

            const color = this.dataset.color;
            if (color) {
                hiddenColor.value = color;
                colorButtons.forEach(btn => {
                    btn.classList.remove('active');
                    if (btn.textContent.trim() === color) {
                        btn.classList.add('active');
                    }
                });
                
                updateSizesByColor(color);
            }

            thumbnails.forEach(t => t.classList.remove('active'));
            this.classList.add('active');
        });
    });

    colorButtons.forEach(button => {
        button.addEventListener('click', function() {
            const selectedColor = this.textContent.trim();
            hiddenColor.value = selectedColor;

            colorButtons.forEach(btn => btn.classList.remove('active'));
            this.classList.add('active');

            updateSizesByColor(selectedColor);

            let firstMatch = null;
            thumbnails.forEach(thumb => {
                thumb.classList.remove('active');
                if (thumb.dataset.color === selectedColor && !firstMatch) {
                    firstMatch = thumb;
                }
            });

            if (firstMatch) {
                firstMatch.classList.add('active');
                const img = firstMatch.querySelector('img');
                document.getElementById('mainProductImage').src = img.src;
                hiddenImageUrl.value = img.src.split('/').pop();
            }
        });
    });

    sizeSelect.addEventListener('change', function() {
        hiddenSize.value = this.value;
        updateAvailability(hiddenColor.value, this.value);
    });

    if (colorButtons.length === 1) {
        colorButtons[0].click();
    }
});
// هاذا الكود لتسجيل خروج المستخدم الغير نشط
        const logoutTime = 86400000; // يوم بالملي ثانيه
        const warningTime = 86400; // يوم بالثواني
        let inactivityTimer;
        let warningTimer;

        window.onload = function() {
            resetTimer();
            setupEventListeners();
        };

        function setupEventListeners() {
            ['mousemove', 'keypress', 'click', 'scroll', 'touchstart', 'mousedown'].forEach(evt => {
                window.addEventListener(evt, resetTimer);
            });
            // ✅ إصلاح: فحص وجود العنصر قبل إضافة الحدث
            // (السكريبت يُحمّل في كل الصفحات، لكن #email و #password موجودان فقط في صفحة الدخول)
            ['email', 'password'].forEach(id => {
                const el = document.getElementById(id);
                if (el) {
                    el.addEventListener('input', resetTimer);
                }
            });
        }

        function resetTimer() {
            // ✅ إصلاح: فحص وجود العناصر قبل التعديل
            const warning = document.getElementById('logoutWarning');
            const overlay = document.getElementById('overlay');
            const timer = document.getElementById('inactivityTimer');
            if (warning) warning.style.display = 'none';
            if (overlay) overlay.style.display = 'none';
            if (timer) timer.style.display = 'none';

            clearTimeout(inactivityTimer);
            clearInterval(warningTimer);

            updateCountdown(logoutTime / 1000);

            inactivityTimer = setTimeout(showWarning, logoutTime);
        }

        function showWarning() {
            // ✅ إصلاح: فحص وجود العناصر
            const warning = document.getElementById('logoutWarning');
            const overlay = document.getElementById('overlay');
            const timer = document.getElementById('inactivityTimer');
            if (warning) warning.style.display = 'block';
            if (overlay) overlay.style.display = 'block';
            if (timer) timer.style.display = 'none';

            let secondsLeft = warningTime / 1000;
            updateWarningCountdown(secondsLeft);

            warningTimer = setInterval(function() {
                secondsLeft--;
                if (secondsLeft <= 0) {
                    clearInterval(warningTimer);
                    logout();
                } else {
                    updateWarningCountdown(secondsLeft);
                }
            }, 1000);
        }

        function updateCountdown(seconds) {
            const minutes = Math.floor(seconds / 60);
            const remainingSeconds = Math.floor(seconds % 60);
            // ✅ إصلاح: فحص وجود العنصر
            const el = document.getElementById('countdown');
            if (el) el.textContent = `${minutes.toString().padStart(2,'0')}:${remainingSeconds.toString().padStart(2,'0')}`;
        }

        function updateWarningCountdown(seconds) {
            const minutes = Math.floor(seconds / 60);
            const remainingSeconds = Math.floor(seconds % 60);
            // ✅ إصلاح: فحص وجود العنصر
            const el = document.getElementById('warningCountdown');
            if (el) el.textContent = `${minutes.toString().padStart(2,'0')}:${remainingSeconds.toString().padStart(2,'0')}`;
        }

        function stayLoggedIn() {
            resetTimer();
        }

        function logout() {
            window.location.href = SITE_URL + 'includes/logout.php';
        }

        // ✅ إصلاح: فحص وجود العنصر قبل العرض
        setTimeout(function() {
            const timer = document.getElementById('inactivityTimer');
            if (timer) timer.style.display = 'block';
        }, 60000);

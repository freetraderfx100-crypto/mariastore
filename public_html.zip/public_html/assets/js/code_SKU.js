// معاينة SKU التلقائي عند كتابة اسم المنتج
document.querySelector('input[name="name"]').addEventListener('input', function () {
    const skuField = document.getElementById('sku');
    const categorySelect = document.getElementById('main_category');

    // إذا كان حقل SKU فارغاً، عرض معاينة
    if (skuField.value === '') {
        const productName = this.value;
        const categoryId = categorySelect.value;

        if (productName.length > 0) {
            // إجراء طلب AJAX لمعاينة SKU
            fetch('../includes/generate_sku_preview.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `product_name=${encodeURIComponent(productName)}&category_id=${categoryId}`
            })
                .then(response => response.text())
                .then(sku => {
                    skuField.placeholder = "معاينة: " + sku;
                });
        }
    }
});

// إعادة معاينة SKU عند تغيير التصنيف
document.getElementById('main_category').addEventListener('change', function () {
    const nameField = document.querySelector('input[name="name"]');
    const skuField = document.getElementById('sku');

    if (nameField.value.length > 0 && skuField.value === '') {
        nameField.dispatchEvent(new Event('input'));
    }
});

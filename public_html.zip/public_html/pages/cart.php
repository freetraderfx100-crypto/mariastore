<?php
// إعداد الجلسة
if (session_status() === PHP_SESSION_NONE) {
    session_start([
        'cookie_lifetime' => 86400,
        'cookie_secure' => true,
        'cookie_httponly' => true,
        'cookie_samesite' => 'Lax'
    ]);
}
require_once __DIR__ . '/../includes/db_connect.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/visitor_tracking.php';
// إنشاء كائن تتبع الزوار
$visitorTracker = new VisitorTracker($conn);
$visitorTracker->recordPageView($_SERVER['REQUEST_URI']);
// جلب إعدادات الشحن
$shipping_settings = getShippingSettings();
$free_shipping_threshold = $shipping_settings['free_shipping_threshold'];
$shipping_discount = $shipping_settings['shipping_discount_percentage'];
// التحقق من حالة المستخدم
$is_logged_in = isset($_SESSION['user_id']);
$is_guest = isset($_SESSION['guest_id']);
$user_id = $is_logged_in ? $_SESSION['user_id'] : null;
// تعريف المتغيرات الأساسية
$cart_id = null;
$errors = [];
$cart_items = [];
$subtotal = 0;
$shipping = 0;
$total = 0;
// إذا لم يكن المستخدم مسجلاً أو زائراً، إنشاء معرف زائر
if (!$is_logged_in && !$is_guest) {
    $_SESSION['guest_id'] = uniqid('guest_', true);
    $is_guest = true;
}
try {
    // للمستخدمين المسجلين: استخدام نظام السلة في قاعدة البيانات
    if ($is_logged_in) {
        // البحث عن سلة المستخدم أو إنشاؤها
        $stmt = $conn->prepare("SELECT id FROM carts WHERE user_id = ?");
        $stmt->execute([$user_id]);
        $cart = $stmt->fetch();
        if (!$cart) {
            $stmt = $conn->prepare("INSERT INTO carts (user_id) VALUES (?)");
            $stmt->execute([$user_id]);
            $cart_id = $conn->lastInsertId();
        } else {
            $cart_id = $cart['id'];
        }
        // جلب عناصر السلة مع التحقق من المخزون والخصم
        $stmt = $conn->prepare("
            SELECT
                ci.id,
                p.id as product_id,
                p.name,
                p.sku,
                ci.price,
                ci.quantity,
                ci.color,
                ci.size,
                ci.image_url,
                
                (SELECT pv.quantity 
                FROM product_variants pv 
                WHERE pv.product_id = ci.product_id 
                AND pv.color = ci.color 
                AND pv.size = ci.size 
                LIMIT 1) as stock_quantity,
                p.price as original_price, 
                p.discount_percentage,
                p.discount_end_date,
               
                CASE 
                    WHEN p.discount_percentage > 0 AND (p.discount_end_date IS NULL OR p.discount_end_date >= CURDATE()) 
                    THEN p.price * (1 - p.discount_percentage / 100)
                    ELSE p.price
                END as current_price
            FROM cart_items ci
            JOIN products p ON ci.product_id = p.id
            WHERE ci.cart_id = ?
        ");
        $stmt->execute([$cart_id]);
        $cart_items = $stmt->fetchAll();
        // تحديث أسعار العناصر في السلة إذا انتهت فترة الخصم
        foreach ($cart_items as &$item) {
            $is_discount_active = ($item['discount_percentage'] > 0 &&
                (!$item['discount_end_date'] || $item['discount_end_date'] >= date('Y-m-d')));
            $current_calculated_price = $is_discount_active ?
                $item['original_price'] * (1 - $item['discount_percentage'] / 100) :
                $item['original_price'];
            // إذا كان السعر المخزن مختلف عن السعر الحقيقي، قم بتحديثه
            if ($item['price'] != $current_calculated_price) {
                $item['price'] = $current_calculated_price;
                // تحديث في قاعدة البيانات
                $update_stmt = $conn->prepare("UPDATE cart_items SET price = ? WHERE id = ?");
                $update_stmt->execute([$current_calculated_price, $item['id']]);
            }
            // التأكد من وجود current_price في المصفوفة
            if (!isset($item['current_price'])) {
                $item['current_price'] = $current_calculated_price;
            }
        }
        unset($item); // كسر المرجع
    }
    // للزوار: استخدام سلة الجلسة
    elseif ($is_guest && isset($_SESSION['guest_cart'])) {
        foreach ($_SESSION['guest_cart'] as $key => $item) {
            // جلب معلومات المنتج من قاعدة البيانات
            $stmt = $conn->prepare("
                SELECT 
                    p.id as product_id,
                    p.name,
                    p.sku,
                    p.price as original_price,
                    p.discount_percentage,
                    p.discount_end_date,
                    pv.quantity as stock_quantity
                FROM products p
                LEFT JOIN product_variants pv ON 
                    pv.product_id = p.id AND 
                    pv.color = ? AND 
                    pv.size = ?
                WHERE p.id = ?
            ");
            $stmt->execute([$item['color'], $item['size'], $item['product_id']]);
            $product_info = $stmt->fetch();
            if ($product_info) {
                // حساب السعر الحالي مع مراعاة الخصم
                $is_discount_active = ($product_info['discount_percentage'] > 0 &&
                    (!$product_info['discount_end_date'] || $product_info['discount_end_date'] >= date('Y-m-d')));
                $current_price = $is_discount_active ?
                    $product_info['original_price'] * (1 - $product_info['discount_percentage'] / 100) :
                    $product_info['original_price'];
                // تحديث السعر في الجلسة إذا كان مختلفاً
                if ($item['price'] != $current_price) {
                    $_SESSION['guest_cart'][$key]['price'] = $current_price;
                    $item['price'] = $current_price;
                }
                $cart_items[] = [
                    'id' => $key,
                    'product_id' => $item['product_id'],
                    'name' => $product_info['name'],
                    'sku' => $product_info['sku'],
                    'price' => $current_price,
                    'quantity' => $item['quantity'],
                    'color' => $item['color'],
                    'size' => $item['size'],
                    'image_url' => $item['image_url'],
                    'stock_quantity' => $product_info['stock_quantity'],
                    'original_price' => $product_info['original_price'],
                    'discount_percentage' => $product_info['discount_percentage'],
                    'discount_end_date' => $product_info['discount_end_date'],
                    'current_price' => $current_price // إضافة current_price هنا
                ];
            }
        }
    }
    // معالجة إضافة منتج (للمستخدمين المسجلين فقط)
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_to_cart']) && $is_logged_in) {
        $product_id = (int)$_POST['product_id'];
        $quantity = (int)($_POST['quantity'] ?? 1);
        $color = $_POST['color'] ?? null;
        $size = $_POST['selected_size'] ?? null;
        $image_url = !empty($_POST['image_url']) ? $_POST['image_url'] : 'default-product.png';
        // حساب السعر النهائي مع الخصم
        $original_price = (float)$_POST['original_price'];
        $discount_percentage = (float)$_POST['discount_percentage'];
        $final_price = $discount_percentage > 0 ?
            $original_price * (1 - $discount_percentage / 100) :
            $original_price;
        $variant_stmt = $conn->prepare("SELECT id, quantity, image_url FROM product_variants WHERE product_id = ? AND color = ? AND size = ?");
        $variant_stmt->execute([$product_id, $color, $size]);
        $variant = $variant_stmt->fetch();
        if ($variant) {
            $stock_quantity = $variant['quantity'];
            $stmt = $conn->prepare("SELECT id, quantity FROM cart_items WHERE cart_id = ? AND product_id = ? AND color = ? AND size = ?");
            $stmt->execute([$cart_id, $product_id, $color, $size]);
            $existing_item = $stmt->fetch();
            if ($existing_item) {
                $new_quantity = $existing_item['quantity'] + $quantity;
                if ($new_quantity <= $stock_quantity) {
                    $stmt = $conn->prepare("UPDATE cart_items SET quantity = ?, price = ? WHERE id = ?");
                    $stmt->execute([$new_quantity, $final_price, $existing_item['id']]);
                } else {
                    $errors[] = "الكمية المطلوبة غير متوفرة في المخزن";
                }
            } else {
                if ($quantity <= $stock_quantity) {
                    $stmt = $conn->prepare("INSERT INTO cart_items (cart_id, product_id, quantity, color, size, image_url, price)
                    VALUES (?, ?, ?, ?, ?, ?, ?)");
                    $stmt->execute([$cart_id, $product_id, $quantity, $color, $size, $variant['image_url'], $final_price]);
                } else {
                    $errors[] = "الكمية المطلوبة غير متوفرة في المخزن";
                }
            }
        } else {
            $errors[] = "التركيبة غير موجودة أو غير متوفرة";
        }
    }
    // إزالة عنصر
    if (isset($_GET['remove_item'])) {
        $item_id = $_GET['remove_item'];
        // للمستخدمين المسجلين
        if ($is_logged_in) {
            $stmt = $conn->prepare("DELETE FROM cart_items WHERE id = ? AND cart_id = ?");
            $stmt->execute([$item_id, $cart_id]);
        }
        // للزوار
        elseif ($is_guest && isset($_SESSION['guest_cart'][$item_id])) {
            unset($_SESSION['guest_cart'][$item_id]);
        }
        // إضافة رسالة نجاح
        $_SESSION['cart_update_success'] = 'تم حذف المنتج من السلة';
        header("Location: " . SITE_URL . "pages/cart.php");
        exit;
    }
    // إفراغ السلة بالكامل
    if (isset($_GET['empty_cart'])) {
        // للمستخدمين المسجلين
        if ($is_logged_in) {
            $stmt = $conn->prepare("DELETE FROM cart_items WHERE cart_id = ?");
            $stmt->execute([$cart_id]);
        }
        // للزوار
        elseif ($is_guest) {
            $_SESSION['guest_cart'] = [];
        }
        $_SESSION['cart_emptied'] = 'تم إفراغ سلة التسوق بنجاح';
        header("Location: " . SITE_URL . "pages/cart.php");
        exit;
    }
    // تحديث الكميات
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_cart'])) {
        foreach ($_POST['quantities'] as $item_id => $quantity) {
            $quantity = (int)$quantity;
            // للمستخدمين المسجلين
            if ($is_logged_in) {
                if ($quantity > 0) {
                    // التحقق من الكمية المتوفرة في المخزون قبل التحديث
                    $check_stmt = $conn->prepare("
                    SELECT ci.quantity, ci.product_id, ci.color, ci.size,
                           (SELECT pv.quantity 
                            FROM product_variants pv 
                            WHERE pv.product_id = ci.product_id 
                            AND pv.color = ci.color 
                            AND pv.size = ci.size 
                            LIMIT 1) as stock_quantity
                    FROM cart_items ci
                    WHERE ci.id = ? AND ci.cart_id = ?
                ");
                    $check_stmt->execute([$item_id, $cart_id]);
                    $item_info = $check_stmt->fetch();
                    if ($item_info && $quantity <= $item_info['stock_quantity']) {
                        $stmt = $conn->prepare("UPDATE cart_items SET quantity = ? WHERE id = ? AND cart_id = ?");
                        $stmt->execute([$quantity, $item_id, $cart_id]);
                    } else {
                        $_SESSION['cart_error'] = "الكمية المطلوبة لمنتج '{$item_info['name']}' غير متوفرة في المخزون";
                    }
                } else {
                    $stmt = $conn->prepare("DELETE FROM cart_items WHERE id = ? AND cart_id = ?");
                    $stmt->execute([$item_id, $cart_id]);
                }
            }
            // للزوار
            elseif ($is_guest && isset($_SESSION['guest_cart'][$item_id])) {
                if ($quantity > 0) {
                    $_SESSION['guest_cart'][$item_id]['quantity'] = $quantity;
                } else {
                    unset($_SESSION['guest_cart'][$item_id]);
                }
            }
        }
        // إضافة رسالة نجاح في الجلسة
        if (!isset($_SESSION['cart_error'])) {
            $_SESSION['cart_success'] = 'تم تحديث سلة التسوق بنجاح';
        }
        header("Location: " . SITE_URL . "pages/cart.php");
        exit;
    }
    // حساب المجموع الفرعي
    $subtotal = 0;
    foreach ($cart_items as $item) {
        // استخدام السعر الحالي المحسوب مسبقاً
        $item_price = isset($item['current_price']) ? $item['current_price'] : $item['price'];
        $subtotal += $item_price * $item['quantity'];
    }
    // التحقق من توفر جميع المنتجات قبل الانتقال إلى صفحة الدفع
    // ✅ ملاحظة: لا نُعيد التوجيه هنا لتجنب حلقة إعادة التوجيه اللانهائية (ERR_TOO_MANY_REDIRECTS)
    // بدلاً من ذلك، نعرض رسالة الخطأ في الصفحة نفسها
    $all_available = true;
    $unavailable_products = [];
    foreach ($cart_items as $item) {
        // التحقق من توفر الكمية
        if ($item['stock_quantity'] <= 0 || $item['quantity'] > $item['stock_quantity']) {
            $all_available = false;
            $unavailable_products[] = [
                'name' => $item['name'],
                'color' => $item['color'],
                'size' => $item['size'],
                'requested' => $item['quantity'],
                'available' => $item['stock_quantity']
            ];
        }
    }
    // عرض رسالة الخطأ للمستخدم (بدون إعادة توجيه)
    if (!$all_available) {
        $_SESSION['unavailable_products'] = $unavailable_products;
        $_SESSION['cart_error'] = "بعض المنتجات في سلتك غير متوفرة بالكمية المطلوبة. يرجى حذفها أو تعديل الكمية.";
    }
    $total = $subtotal + $shipping;

    // إذا تم الضغط على زر إتمام الطلب
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['proceed_to_checkout'])) {
        if ($all_available) {
            // كل المنتجات متوفرة، توجيه إلى صفحة الدفع (للمستخدمين والزوار)
            $_SESSION['cart_validated'] = true;
            header("Location: " . SITE_URL . "pages/checkout.php");
            exit;
        } else {
            // تخزين المنتجات غير المتوفرة في الجلسة لعرضها
            $_SESSION['unavailable_products'] = $unavailable_products;
            // ✅ إعادة التوجيه مسموحة هنا فقط لأنها داخل POST check
            header("Location: " . SITE_URL . "pages/cart.php");
            exit;
        }
    }
} catch (PDOException $e) {
    $errors[] = "حدث خطأ في قاعدة البيانات: " . $e->getMessage();
}
include __DIR__ . '/../includes/header.php';
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>سلة التسوق - متجرك الإلكتروني</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.rtl.min.css">
    <!-- <link rel="stylesheet" href="<?php echo SITE_URL; ?>assets/css/style.css"> -->
    <!-- Font Awesome - نسخة محلية (لا يعتمد على CDN) -->
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>assets/css/font-awesome.min.css">
    <!-- نسخة احتياطية من CDN -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" media="all" onerror="this.onerror=null;this.href='https://use.fontawesome.com/releases/v6.4.0/css/all.css';">
    <style>
        .product-sku-cart {
            font-family: 'Courier New', monospace;
            font-size: 0.8em;
            color: #666;
            background-color: #f8f9fa;
            padding: 2px 6px;
            border-radius: 3px;
            margin: 2px 0;
            display: inline-block;
            border: 1px solid #e9ecef;
        }

        .cart-table td {
            vertical-align: middle;
        }

        /* تنسيقات السلة على الهاتف - بطاقات بدلاً من جدول */
        .cart-item-card {
            display: none;
            background: #fff;
            border: 1px solid #e9ecef;
            border-radius: 12px;
            padding: 16px;
            margin-bottom: 16px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.06);
            transition: box-shadow 0.3s ease;
        }

        .cart-item-card:hover {
            box-shadow: 0 4px 14px rgba(0,0,0,0.1);
        }

        .cart-item-card .card-top {
            display: flex;
            gap: 12px;
            align-items: flex-start;
            padding-bottom: 12px;
            border-bottom: 1px dashed #e9ecef;
            margin-bottom: 12px;
        }

        .cart-item-card .card-image {
            flex: 0 0 90px;
            width: 90px;
            height: 90px;
            border-radius: 8px;
            overflow: hidden;
            background: #f8f9fa;
        }

        .cart-item-card .card-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .cart-item-card .card-info {
            flex: 1;
            min-width: 0;
        }

        .cart-item-card .card-info .product-name {
            font-weight: 700;
            color: #2c3e50;
            font-size: 15px;
            margin-bottom: 4px;
            display: block;
            text-decoration: none;
            line-height: 1.3;
        }

        .cart-item-card .card-info .product-attrs {
            font-size: 13px;
            color: #6c757d;
            line-height: 1.6;
        }

        .cart-item-card .card-info .product-attrs .attr-badge {
            display: inline-block;
            background: #f8f9fa;
            padding: 2px 8px;
            border-radius: 4px;
            margin-inline-end: 6px;
            margin-bottom: 4px;
            font-size: 12px;
        }

        .cart-item-card .card-bottom {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 8px;
            flex-wrap: wrap;
        }

        .cart-item-card .price-block {
            text-align: start;
        }

        .cart-item-card .price-block .item-price {
            font-size: 13px;
            color: #6c757d;
            display: block;
        }

        .cart-item-card .price-block .item-total {
            font-size: 17px;
            font-weight: 700;
            color: #ff6b8b;
            display: block;
        }

        .cart-item-card .qty-control {
            display: flex;
            align-items: center;
            gap: 6px;
            background: #f8f9fa;
            border-radius: 8px;
            padding: 4px;
        }

        .cart-item-card .qty-btn {
            width: 32px;
            height: 32px;
            border: none;
            background: #fff;
            border-radius: 6px;
            color: #ff6b8b;
            font-weight: 700;
            font-size: 16px;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.2s;
            box-shadow: 0 1px 2px rgba(0,0,0,0.05);
        }

        .cart-item-card .qty-btn:hover {
            background: #ff6b8b;
            color: #fff;
        }

        .cart-item-card .qty-input-mobile {
            width: 44px;
            text-align: center;
            border: none;
            background: transparent;
            font-weight: 700;
            font-size: 15px;
            color: #2c3e50;
            -moz-appearance: textfield;
        }

        .cart-item-card .qty-input-mobile::-webkit-outer-spin-button,
        .cart-item-card .qty-input-mobile::-webkit-inner-spin-button {
            -webkit-appearance: none;
            margin: 0;
        }

        .cart-item-card .remove-btn-mobile {
            background: none;
            border: none;
            color: #dc3545;
            font-size: 18px;
            padding: 6px 10px;
            cursor: pointer;
            border-radius: 6px;
            transition: all 0.2s;
        }

        .cart-item-card .remove-btn-mobile:hover {
            background: #fde8ea;
        }

        .cart-item-card .stock-warning {
            background: #fff3cd;
            color: #856404;
            padding: 8px 12px;
            border-radius: 6px;
            font-size: 13px;
            margin-top: 8px;
            display: flex;
            align-items: center;
            gap: 6px;
        }

        /* إظهار البطاقات وإخفاء الجدول على الهاتف */
        @media (max-width: 767.98px) {
            .cart-table-wrapper {
                display: none !important;
            }
            .cart-item-card {
                display: block !important;
            }
            .cart-page {
                padding: 16px 0 !important;
            }
            .cart-form-mobile {
                padding: 0 !important;
                background: transparent !important;
                box-shadow: none !important;
            }
            .page-title {
                font-size: 22px !important;
                margin-bottom: 16px !important;
            }
            .cart-actions {
                flex-direction: column;
                gap: 10px;
            }
            .cart-actions .btn {
                width: 100%;
            }
            .cart-totals {
                margin-top: 16px !important;
            }
        }

        /* تحسين تنسيق الجدول على الأجهزة الكبيرة */
        @media (min-width: 768px) {
            .cart-form-mobile {
                display: block;
            }
        }

        /* تحسين تنسيق الإجماليات على الهاتف */
        @media (max-width: 767.98px) {
            .totals-table th,
            .totals-table td {
                padding: 8px 6px !important;
                font-size: 14px;
            }
            .cart-totals {
                padding: 16px !important;
            }
            .cart-totals h3 {
                font-size: 18px !important;
            }
        }

        /* تحسين القائمة العلوية للهاتف */
        @media (max-width: 767.98px) {
            .header-icons {
                gap: 8px !important;
            }
            .header-icons .icon-link {
                font-size: 18px !important;
                position: relative;
            }
            .cart-count {
                position: absolute;
                top: -5px;
                inset-inline-end: -8px;
                background: #ff6b8b;
                color: #fff;
                font-size: 10px !important;
                min-width: 16px;
                height: 16px;
                border-radius: 50%;
                display: flex;
                align-items: center;
                justify-content: center;
                padding: 0 4px !important;
                font-weight: 700;
                line-height: 1;
            }
        }
    </style>
</head>

<body>
    <?php if ($is_guest): ?>
        <div class="guest-notice">
            <h5><i class="fas fa-info-circle"></i> أنت تتسوق كزائر</h5>
            <p>لتتمكن من إتمام عملية الشرك، يرجى:</p>
            <ul>
                <li>إنشاء حساب جديد للاحتفاظ بسلة التسوق الخاصة بك</li>
                <li>أو تسجيل الدخول إذا كان لديك حساب بالفعل</li>
            </ul>
            <div class="guest-actions">
                <a href="<?php echo SITE_URL; ?>pages/register.php" class="btn btn-primary">إنشاء حساب</a>
                <a href="<?php echo SITE_URL; ?>pages/login.php" class="btn btn-outline-primary">تسجيل الدخول</a>
            </div>
        </div>
    <?php endif; ?>
    <main class="cart-page py-5">
        <div class="container">
            <h1 class="page-title text-center mb-5">
                <i class="fas fa-shopping-cart me-2"></i>سلة التسوق
            </h1>
            <?php if (!empty($errors)): ?>
                <div class="alert alert-danger alert-dismissible fade show">
                    <?php foreach ($errors as $error): ?>
                        <p class="mb-0"><?= htmlspecialchars($error) ?></p>
                    <?php endforeach; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>
            <?php if (empty($cart_items)): ?>
                <div class="empty-cart text-center py-5">
                    <i class="fas fa-shopping-cart fa-4x mb-4 text-muted"></i>
                    <h2 class="mb-3">سلة التسوق فارغة</h2>
                    <p class="text-muted mb-4">ليس لديك أي منتجات في سلة التسوق الخاصة بك</p>
                    <a href="<?php echo SITE_URL; ?>" class="btn btn-primary px-4">
                        <i class="fas fa-arrow-left me-2"></i>العودة للتسوق
                    </a>
                </div>
            <?php else: ?>
                <div class="row">
                    <div class="col-lg-8">
                        <form method="post" action="cart.php" class="cart-form bg-white p-4 rounded shadow-sm">
                            <div class="table-responsive cart-table-wrapper">
                                <table class="table cart-table">
                                    <thead class="table-light">
                                        <tr>
                                            <th width="100">الصورة</th>
                                            <th>تفاصيل المنتج</th>
                                            <th width="120">السعر</th>
                                            <th width="150">الكمية</th>
                                            <th width="120">الإجمالي</th>
                                            <th width="50"></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($cart_items as $item):
                                            // حساب السعر المخفض إذا لزم الأمر
                                            $item_price = isset($item['current_price']) ? $item['current_price'] : $item['price'];
                                            $item_total = $item_price * $item['quantity'];
                                            // تحديد حالة التوفر
                                            $is_available = $item['stock_quantity'] > 0 && $item['quantity'] <= $item['stock_quantity'];
                                        ?>
                                            <tr class="cart-item align-middle <?= !$is_available ? 'table-danger' : '' ?>">
                                                <td>
                                                    <a href="<?php echo SITE_URL; ?>pages/details_product.php?id=<?= $item['product_id'] ?>">
                                                        <img src="<?php echo SITE_URL; ?>assets/images/<?= !empty($item['image_url']) ? htmlspecialchars($item['image_url']) : 'default-product.png' ?>"
                                                            alt="<?= htmlspecialchars($item['name']) ?>" class="img-thumbnail" width="80">
                                                    </a>
                                                </td>
                                                <td>
                                                    <a href="<?php echo SITE_URL; ?>pages/details_product.php?id=<?= $item['product_id'] ?>" class="text-decoration-none">
                                                        <strong><?= htmlspecialchars($item['name']) ?></strong>
                                                    </a>
                                                    <div class="text-muted small mt-2">
                                                        <?php if (!empty($item['sku'])): ?>
                                                            <div class="product-sku-cart">
                                                                SKU: <?= htmlspecialchars($item['sku']) ?>
                                                            </div>
                                                            <br>
                                                        <?php endif; ?>
                                                        <?= $item['color'] ? 'اللون: ' . htmlspecialchars($item['color']) : '' ?>
                                                        <?= $item['size'] ? '<br>المقاس: ' . htmlspecialchars($item['size']) : '' ?>
                                                    </div>
                                                    <?php if (!$is_available): ?>
                                                        <div class="text-danger small mt-1">
                                                            <i class="fas fa-exclamation-circle me-1"></i>
                                                            <?php if ($item['stock_quantity'] <= 0): ?>
                                                                المنتج غير متوفر حالياً
                                                            <?php else: ?>
                                                                الكمية المطلوبة غير متوفرة (المتبقي: <?= $item['stock_quantity'] ?>)
                                                            <?php endif; ?>
                                                        </div>
                                                    <?php endif; ?>
                                                </td>
                                                <td><?= number_format($item_price, 2) ?> ر.ي</td>
                                                <td>
                                                    <input type="number"
                                                        name="quantities[<?= $item['id'] ?>]"
                                                        value="<?= $item['quantity'] ?>"
                                                        min="0"
                                                        max="<?= max(0, (int)$item['stock_quantity']) ?>"
                                                        class="form-control quantity-input <?= !$is_available ? 'is-invalid' : '' ?>">
                                                </td>
                                                <td><?= number_format($item_total, 2) ?> ر.ي</td>
                                                <td>
                                                    <a href="<?php echo SITE_URL; ?>pages/cart.php?remove_item=<?= $item['id'] ?>"
                                                        class="btn btn-sm btn-outline-danger remove-item">
                                                        <i class="fas fa-trash"></i>
                                                    </a>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>

                            <!-- تصميم البطاقات للهاتف -->
                            <div class="cart-mobile-list">
                                <?php foreach ($cart_items as $item):
                                    $item_price = isset($item['current_price']) ? $item['current_price'] : $item['price'];
                                    $item_total = $item_price * $item['quantity'];
                                    $is_available = $item['stock_quantity'] > 0 && $item['quantity'] <= $item['stock_quantity'];
                                ?>
                                    <div class="cart-item-card <?= !$is_available ? 'card-unavailable' : '' ?>">
                                        <div class="card-top">
                                            <a href="<?php echo SITE_URL; ?>pages/details_product.php?id=<?= $item['product_id'] ?>" class="card-image">
                                                <img src="<?php echo SITE_URL; ?>assets/images/<?= !empty($item['image_url']) ? htmlspecialchars($item['image_url']) : 'default-product.png' ?>"
                                                    alt="<?= htmlspecialchars($item['name']) ?>">
                                            </a>
                                            <div class="card-info">
                                                <a href="<?php echo SITE_URL; ?>pages/details_product.php?id=<?= $item['product_id'] ?>" class="product-name">
                                                    <?= htmlspecialchars($item['name']) ?>
                                                </a>
                                                <div class="product-attrs">
                                                    <?php if (!empty($item['sku'])): ?>
                                                        <span class="attr-badge"><i class="fas fa-barcode"></i> <?= htmlspecialchars($item['sku']) ?></span>
                                                    <?php endif; ?>
                                                    <?php if ($item['color']): ?>
                                                        <span class="attr-badge"><i class="fas fa-palette"></i> <?= htmlspecialchars($item['color']) ?></span>
                                                    <?php endif; ?>
                                                    <?php if ($item['size']): ?>
                                                        <span class="attr-badge"><i class="fas fa-tshirt"></i> <?= htmlspecialchars($item['size']) ?></span>
                                                    <?php endif; ?>
                                                </div>
                                                <?php if (!$is_available): ?>
                                                    <div class="stock-warning">
                                                        <i class="fas fa-exclamation-triangle"></i>
                                                        <?php if ($item['stock_quantity'] <= 0): ?>
                                                            غير متوفر حالياً
                                                        <?php else: ?>
                                                            متبقي: <?= $item['stock_quantity'] ?> فقط
                                                        <?php endif; ?>
                                                    </div>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="card-bottom">
                                            <div class="price-block">
                                                <span class="item-price">السعر: <?= number_format($item_price, 2) ?> ر.ي</span>
                                                <span class="item-total"><?= number_format($item_total, 2) ?> ر.ي</span>
                                            </div>
                                            <div class="d-flex align-items-center gap-2">
                                                <div class="qty-control">
                                                    <button type="button" class="qty-btn qty-decrease" data-target="qty-mobile-<?= $item['id'] ?>" aria-label="إنقاص">
                                                        <i class="fas fa-minus"></i>
                                                    </button>
                                                    <input type="number"
                                                        name="quantities[<?= $item['id'] ?>]"
                                                        value="<?= $item['quantity'] ?>"
                                                        min="0"
                                                        max="<?= max(0, (int)$item['stock_quantity']) ?>"
                                                        id="qty-mobile-<?= $item['id'] ?>"
                                                        class="qty-input-mobile <?= !$is_available ? 'is-invalid' : '' ?>">
                                                    <button type="button" class="qty-btn qty-increase" data-target="qty-mobile-<?= $item['id'] ?>"
                                                        data-max="<?= max(0, (int)$item['stock_quantity']) ?>" aria-label="زيادة">
                                                        <i class="fas fa-plus"></i>
                                                    </button>
                                                </div>
                                                <a href="<?php echo SITE_URL; ?>pages/cart.php?remove_item=<?= $item['id'] ?>"
                                                    class="remove-btn-mobile remove-item" title="حذف">
                                                    <i class="fas fa-trash-alt"></i>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                            <div class="alert alert-info mt-3">
                                <ul class="mb-0">
                                    <li><i class="fas fa-info-circle me-1"></i> عند زيادة الكميه يرجاء تحديث السلة لضمان اضافة منتجاتك الى طلبك !</li>
                                    <li><i class="fas fa-info-circle me-1"></i> تنبيه اذا وجد خصم لمنتج وهو في السلة يرجا ازالة المنتج من السلة واضافته مره اخرا</li>
                                </ul>
                            </div>
                            <div class="cart-actions d-flex justify-content-between mt-4">
                                <a href="<?php echo SITE_URL; ?>" class="btn btn-outline-secondary">
                                    <i class="fas fa-arrow-left me-2"></i>متابعة التسوق
                                </a>
                                <div class="d-flex gap-2">
                                    <button type="submit" name="update_cart" class="btn btn-primary">
                                        <i class="fas fa-sync-alt me-2"></i>تحديث السلة
                                    </button>
                                    <button type="button" id="empty-cart-btn" class="btn btn-danger">
                                        <i class="fas fa-trash-alt me-2"></i>إفراغ السلة
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                    <div class="col-lg-4 mt-4 mt-lg-0">
                        <div class="cart-totals bg-white p-4 rounded shadow-sm">
                            <h3 class="h5 mb-4 border-bottom pb-3">
                                <i class="fas fa-receipt me-2"></i>إجماليات الطلب
                            </h3>
                            <table class="table totals-table">
                                <tr>
                                    <th>المجموع الفرعي</th>
                                    <td class="text-end"><?= number_format($subtotal, 2) ?> ر.ي</td>
                                </tr>
                                <!-- عرض معلومات التوصيل المجاني إذا كان متاحًا -->
                                <?php if ($free_shipping_threshold && $free_shipping_threshold > 0): ?>
                                    <tr class="shipping-info">
                                        <th colspan="2" class="text-center">
                                            <div class="alert alert-info p-2 mb-0">
                                                <i class="fas fa-truck me-2"></i>
                                                <?php if ($subtotal >= $free_shipping_threshold): ?>
                                                    <span class="text-success">
                                                        <strong>مؤهل للتوصيل المجاني!</strong>
                                                    </span>
                                                <?php else: ?>
                                                    أنفق <?= number_format($free_shipping_threshold - $subtotal, 2) ?> ر.ي أخرى للحصول على توصيل مجاني
                                                <?php endif; ?>
                                            </div>
                                        </th>
                                    </tr>
                                <?php endif; ?>
                                <!-- عرض خصم الشحن إذا كان متاحًا -->
                                <?php if ($shipping_discount > 0): ?>
                                    <tr class="shipping-discount">
                                        <th colspan="2" class="text-center">
                                            <div class="alert alert-warning p-2 mb-0">
                                                <i class="fas fa-percentage me-2"></i>
                                                <strong>خصم <?= $shipping_discount ?>% على الشحن</strong>
                                                مطبق على جميع الطلبات
                                            </div>
                                        </th>
                                    </tr>
                                <?php endif; ?>
                                <tr>
                                    <th>تكلفة الشحن</th>
                                    <td class="text-end">
                                        <?php if ($free_shipping_threshold && $subtotal >= $free_shipping_threshold): ?>
                                            <span class="text-success">مجاني</span>
                                        <?php else: ?>
                                            حدد الموقع لحساب تكلفة الشحن
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <tr class="fw-bold">
                                    <th>المجموع الكلي</th>
                                    <td class="text-end"><?= number_format($total, 2) ?> ر.ي</td>
                                </tr>
                            </table>
                            <form action="cart.php" method="post" class="checkout-form">
                                <input type="hidden" name="proceed_to_checkout" value="1">
                                <!--تم الغاء الزر مواقت يكون الطلب عن طريق الواتس اب -->
                                <!--<button type="submit" class="btn btn-success w-100 mt-3 py-2">-->
                                <!--    <i class="fas fa-credit-card me-2"></i>تحديد الموقع و الدفع-->
                                <!--</button>-->
                                <?php if (!empty($_SESSION['unavailable_products'])): ?>
                                    <div class="alert alert-danger mt-3">
                                        <h5 class="alert-heading">المنتجات التالية غير متوفرة بالكمية المطلوبة:</h5>
                                        <ul class="mb-0">
                                            <?php foreach ($_SESSION['unavailable_products'] as $product): ?>
                                                <li>
                                                    <strong><?= htmlspecialchars($product['name']) ?></strong>
                                                    <?= $product['color'] ? ' - اللون: ' . htmlspecialchars($product['color']) : '' ?>
                                                    <?= $product['size'] ? ' - المقاس: ' . htmlspecialchars($product['size']) : '' ?>
                                                    (المطلوب: <?= $product['requested'] ?> | المتوفر: <?= $product['available'] ?>)
                                                </li>
                                            <?php endforeach; ?>
                                            <?php unset($_SESSION['unavailable_products']); ?>
                                        </ul>
                                        <p class="mb-0 mt-2">يرجى تعديل الكميات أو إزالة المنتجات غير المتوفرة قبل المتابعة.</p>
                                    </div>
                                <?php endif; ?>
                            </form>
                            <!-- إضافة زر الطلب عبر واتساب -->
                            <button type="button" id="whatsapp-order-btn" class="btn btn-success w-100 mt-3 py-2" style="background-color: #25D366; border-color: #25D366;">
                                <i class="fab fa-whatsapp me-2"></i>الطلب عبر واتساب
                            </button>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </main>
    <!-- 5. إضافة عرض رسائل الخطأ والنجاح في واجهة المستخدم: -->
    <!-- عرض رسائل الأخطاء والنجاح من PHP باستخدام SweetAlert -->
    <?php if (isset($_SESSION['cart_error'])): ?>
        Swal.fire({
        title: 'خطأ',
        text: '<?= $_SESSION['cart_error'] ?>',
        icon: 'error',
        confirmButtonText: 'حسناً',
        confirmButtonColor: '#ff6b8b'
        });
        <?php unset($_SESSION['cart_error']); ?>
    <?php endif; ?>
    <?php if (isset($_SESSION['cart_success'])): ?>
        Swal.fire({
        title: 'نجاح',
        text: '<?= $_SESSION['cart_success'] ?>',
        icon: 'success',
        confirmButtonText: 'حسناً',
        confirmButtonColor: '#ff6b8b'
        });
        <?php unset($_SESSION['cart_success']); ?>
    <?php endif; ?>
    <!-- ------------------------------------- -->
    <?php include __DIR__ . '/../includes/footer.php'; ?>
    <!-- استخدم CDN بدلاً من الملف المحلي لتجنب الخطأ الأول -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        // الانتظار حتى تحميل DOM بالكامل
        document.addEventListener('DOMContentLoaded', function() {
            // عرض رسائل الأخطاء من PHP باستخدام SweetAlert
            <?php if (!empty($errors)): ?>
                Swal.fire({
                    title: 'حدث خطأ',
                    html: `<?php foreach ($errors as $error): ?><p><?= htmlspecialchars($error) ?></p><?php endforeach; ?>`,
                    icon: 'error',
                    confirmButtonText: 'حسناً',
                    confirmButtonColor: '#ff6b8b'
                });
            <?php endif; ?>
            // التحكم في كميات المنتجات
            document.querySelectorAll('.quantity-input').forEach(input => {
                input.addEventListener('change', function() {
                    let value = parseInt(this.value);
                    let max = parseInt(this.max);
                    if (isNaN(value) || value < 0) {
                        this.value = 0;
                    } else if (!isNaN(max) && value > max) {
                        Swal.fire({
                            title: 'كمية غير متوفرة',
                            text: `الكمية المتاحة فقط ${max} قطعة`,
                            icon: 'warning',
                            confirmButtonText: 'حسناً',
                            confirmButtonColor: '#ff6b8b'
                        });
                        this.value = max;
                    }
                });
            });

            // التحكم في أزرار الكمية (+/-) على الهاتف
            document.querySelectorAll('.qty-increase').forEach(btn => {
                btn.addEventListener('click', function() {
                    const targetId = this.getAttribute('data-target');
                    const input = document.getElementById(targetId);
                    const max = parseInt(this.getAttribute('data-max'));
                    let value = parseInt(input.value) || 0;
                    if (value < max) {
                        input.value = value + 1;
                        input.dispatchEvent(new Event('change'));
                    } else {
                        Swal.fire({
                            title: 'كمية غير متوفرة',
                            text: `الكمية المتاحة فقط ${max} قطعة`,
                            icon: 'warning',
                            confirmButtonText: 'حسناً',
                            confirmButtonColor: '#ff6b8b'
                        });
                    }
                });
            });

            document.querySelectorAll('.qty-decrease').forEach(btn => {
                btn.addEventListener('click', function() {
                    const targetId = this.getAttribute('data-target');
                    const input = document.getElementById(targetId);
                    let value = parseInt(input.value) || 0;
                    if (value > 0) {
                        input.value = value - 1;
                        input.dispatchEvent(new Event('change'));
                    }
                });
            });

            // مزامنة الكمية بين الجدول (ديسكتوب) والبطاقات (هاتف) عند تغيير أي منهما
            document.querySelectorAll('input[name^="quantities"]').forEach(input => {
                input.addEventListener('change', function() {
                    const name = this.getAttribute('name');
                    document.querySelectorAll(`input[name="${name}"]`).forEach(otherInput => {
                        if (otherInput !== this) {
                            otherInput.value = this.value;
                        }
                    });
                });
            });
            // تأكيد حذف المنتج من السلة
            document.querySelectorAll('.remove-item').forEach(link => {
                link.addEventListener('click', function(e) {
                    e.preventDefault();
                    const href = this.getAttribute('href');
                    Swal.fire({
                        title: 'حذف المنتج',
                        text: 'هل أنت متأكد من حذف هذا المنتج من السلة؟',
                        icon: 'question',
                        showCancelButton: true,
                        confirmButtonText: 'نعم، احذف',
                        cancelButtonText: 'إلغاء',
                        confirmButtonColor: '#ff6b8b',
                        cancelButtonColor: '#6c757d'
                    }).then((result) => {
                        if (result.isConfirmed) {
                            window.location.href = href;
                        }
                    });
                });
            });
            // تأكيد إفراغ السلة (مع التحقق من وجود الزر أولاً)
            const emptyCartBtn = document.getElementById('empty-cart-btn');
            if (emptyCartBtn) {
                emptyCartBtn.addEventListener('click', function() {
                    Swal.fire({
                        title: 'إفراغ السلة',
                        text: 'هل أنت متأكد من إفراغ سلة التسوق بالكامل؟',
                        icon: 'warning',
                        showCancelButton: true,
                        confirmButtonText: 'نعم، أفرغ السلة',
                        cancelButtonText: 'إلغاء',
                        confirmButtonColor: '#ff6b8b',
                        cancelButtonColor: '#6c757d',
                        reverseButtons: true
                    }).then((result) => {
                        if (result.isConfirmed) {
                            window.location.href = 'cart.php?empty_cart=1';
                        }
                    });
                });
            }
            // عرض رسائل النجاح
            <?php if (isset($_SESSION['cart_update_success'])): ?>
                Swal.fire({
                    title: 'تم التحديث',
                    text: '<?= $_SESSION['cart_update_success'] ?>',
                    icon: 'success',
                    confirmButtonText: 'حسناً',
                    confirmButtonColor: '#ff6b8b'
                });
                <?php unset($_SESSION['cart_update_success']); ?>
            <?php endif; ?>
            <?php if (isset($_SESSION['cart_emptied'])): ?>
                Swal.fire({
                    title: 'تم الإفراغ',
                    text: '<?= $_SESSION['cart_emptied'] ?>',
                    icon: 'success',
                    confirmButtonText: 'حسناً',
                    confirmButtonColor: '#ff6b8b'
                }).then(() => {
                    window.location.href = 'cart.php';
                });
                <?php unset($_SESSION['cart_emptied']); ?>
            <?php endif; ?>
            // دالة إرسال الطلب عبر واتساب (مع التحقق من وجود الزر أولاً)
            const whatsappOrderBtn = document.getElementById('whatsapp-order-btn');
            if (whatsappOrderBtn) {
                whatsappOrderBtn.addEventListener('click', function() {
                    // جمع معلومات المنتجات في السلة
                    let orderDetails = "🎯 *طلب جديد من المتجر* 🎯%0A%0A";
                    orderDetails += "*تفاصيل الطلب:*%0A%0A";
                    // استخدام البيانات الفعلية من PHP
                    <?php
                    $whatsappItems = "";
                    $whatsappTotal = 0;
                    foreach ($cart_items as $item) {
                        $item_price = isset($item['current_price']) ? $item['current_price'] : $item['price'];
                        $item_total = $item_price * $item['quantity'];
                        $whatsappTotal += $item_total;
                        $whatsappItems .= "▪️ " . htmlspecialchars($item['name']);
                        if (!empty($item['sku'])) {
                            $whatsappItems .= " (SKU: " . htmlspecialchars($item['sku']) . ")";
                        }
                        if ($item['color']) {
                            $whatsappItems .= " - اللون: " . htmlspecialchars($item['color']);
                        }
                        if ($item['size']) {
                            $whatsappItems .= " - المقاس: " . htmlspecialchars($item['size']);
                        }
                        $whatsappItems .= " × " . $item['quantity'] . " = " . number_format($item_total, 2) . " ر.ي%0A";
                    }
                    ?>
                    orderDetails += "<?= $whatsappItems ?>";
                    orderDetails += "%0A*المجموع الفرعي:* <?= number_format($subtotal, 2) ?> ر.ي%0A";
                    orderDetails += "*الإجمالي النهائي:* <?= number_format($total, 2) ?> ر.ي%0A%0A";
                    orderDetails += "🛒 *تم إنشاء الطلب عبر الموقع الإلكتروني*%0A";
                    orderDetails += "📋 *يرجى الطلب وتأكيد التفاصيل*";
                    // رقم واتساب المتجر
                    const whatsappNumber = '775232319';
                    // إنشاء رابط واتساب
                    const whatsappURL = `https://wa.me/${whatsappNumber}?text=${orderDetails}`;
                    // فتح واتساب في نافذة جديدة
                    window.open(whatsappURL, '_blank');
                });
            }
            // إضافة مستمع حدث لنسخ SKU
            const skuElements = document.querySelectorAll('.product-sku-cart');
            skuElements.forEach(element => {
                element.addEventListener('click', function() {
                    const sku = this.textContent.replace('SKU: ', '').trim();
                    navigator.clipboard.writeText(sku).then(() => {
                        const originalText = this.innerHTML;
                        this.innerHTML = '✓ تم النسخ!';
                        setTimeout(() => {
                            this.innerHTML = originalText;
                        }, 1500);
                    });
                });
                element.style.cursor = 'pointer';
                element.title = 'انقر لنسخ SKU';
            });
        });
    </script>
</body>

</html>
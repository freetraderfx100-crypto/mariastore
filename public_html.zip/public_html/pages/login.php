<?php
if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.gc_probability', 1);
    ini_set('session.gc_divisor', 100);
    ini_set('session.gc_maxlifetime', 3600);

    session_start([
        'cookie_lifetime' => 3600,
        'cookie_secure' => false,
        'cookie_httponly' => true,
        'cookie_samesite' => 'Lax'
    ]);
}

require_once __DIR__ . '/../includes/db_connect.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/visitor_tracking.php';

// إنشاء كائن تتبع الزوار
$visitorTracker = new VisitorTracker($conn);
$visitorTracker->recordPageView($_SERVER['REQUEST_URI']);

// في بداية ملف login.php بعد إنشاء كائن التتبع
if (isset($_GET['guest']) && $_GET['guest'] == 'true') {
    // إنشاء معرف فريد للزائر
    $guest_id = 'guest_' . uniqid() . '_' . time();

    // تعيين بيانات الزائر في الجلسة
    $_SESSION['guest_id'] = $guest_id;
    $_SESSION['user_id'] = null;
    $_SESSION['username'] = 'زائر';
    $_SESSION['role'] = 'guest';
    $_SESSION['last_activity'] = time();

    // تسجيل الزائر في نظام التتبع
    $visitorTracker->updateGuestId($guest_id);

    // توجيه الزائر إلى الصفحة السابقة أو الرئيسية
    $redirect_url = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : SITE_URL;
    header("Location: " . $redirect_url);
    exit;
}

// دالة لنقل سلة الزائر إلى حساب المستخدم - تم نقلها إلى هنا
function transferGuestCartToUser($user_id, $guest_cart)
{
    global $conn;

    try {
        // البحث عن سلة المستخدم أو إنشاؤها
        $stmt = $conn->prepare("SELECT id FROM carts WHERE user_id = ?");
        $stmt->execute([$user_id]);
        $cart = $stmt->fetch();

        if (!$cart) {
            $stmt = $conn->prepare("INSERT INTO carts (user_id) VALUES (?)");
            $stmt->execute([$user_id]);
            $cart_id = $conn->lastInsertId();
        } else {
            $cart_id = $cart['id'];
        }

        // إضافة عناصر سلة الزائر إلى سلة المستخدم
        foreach ($guest_cart as $item) {
            // التحقق من وجود المنتج في سلة المستخدم
            $stmt = $conn->prepare("SELECT id, quantity FROM cart_items WHERE cart_id = ? AND product_id = ? AND color = ? AND size = ?");
            $stmt->execute([$cart_id, $item['product_id'], $item['color'], $item['size']]);
            $existing_item = $stmt->fetch();

            if ($existing_item) {
                // تحديث الكمية
                $new_quantity = $existing_item['quantity'] + $item['quantity'];
                $stmt = $conn->prepare("UPDATE cart_items SET quantity = ? WHERE id = ?");
                $stmt->execute([$new_quantity, $existing_item['id']]);
            } else {
                // إضافة عنصر جديد
                $stmt = $conn->prepare("INSERT INTO cart_items (cart_id, product_id, quantity, color, size, image_url, price) VALUES (?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([$cart_id, $item['product_id'], $item['quantity'], $item['color'], $item['size'], $item['image_url'], $item['price']]);
            }
        }

        return true;
    } catch (PDOException $e) {
        error_log("Error transferring guest cart: " . $e->getMessage());
        return false;
    }
}
// معالجة تسجيل الدخول كزائر
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['guest_login'])) {
    // إنشاء معرف فريد للزائر
    $guest_id = 'guest_' . uniqid() . '_' . time();

    // تعيين بيانات الزائر في الجلسة
    $_SESSION['guest_id'] = $guest_id;
    $_SESSION['user_id'] = null;
    $_SESSION['username'] = 'زائر';
    $_SESSION['role'] = 'guest';
    $_SESSION['last_activity'] = time();

    // تسجيل الزائر في نظام التتبع
    $visitorTracker->updateGuestId($guest_id);

    // توجيه الزائر إلى الصفحة الرئيسية
    header("Location: " . SITE_URL);
    exit;
}

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['email'])) {
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    if (empty($email) || empty($password)) {
        $errors[] = "البريد الإلكتروني وكلمة المرور مطلوبان";
    } else {
        $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch();
        
        if ($user && password_verify($password, $user['password'])) {
            if (!$user['is_active']) {
                $errors[] = "الحساب غير مفعل. يرجى انتظار موافقة الإدارة.";
            } else {
                // ↓ أضف هذا السطر ↓
                $_SESSION['user_avatar'] = $user['avatar'] ?? 'default-avatar.png';

                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['email'] = $user['email'];
                $_SESSION['role'] = $user['role'];
                $_SESSION['last_activity'] = time();

                // نقل سلة الزائر إلى حساب المستخدم إذا كانت موجودة
                if (isset($_SESSION['guest_cart']) && !empty($_SESSION['guest_cart'])) {
                    transferGuestCartToUser($user['id'], $_SESSION['guest_cart']);
                    unset($_SESSION['guest_cart']);
                }

                // مسح أي بيانات زائر إذا كان مسجلاً مسبقاً كزائر
                if (isset($_SESSION['guest_id'])) {
                    unset($_SESSION['guest_id']);
                }

                // التوجيه إلى الصفحة المناسبة
                if (isset($_SESSION['redirect_after_login'])) {
                    $redirect_url = $_SESSION['redirect_after_login'];
                    unset($_SESSION['redirect_after_login']);
                    header("Location: " . $redirect_url);
                } else if ($user['role'] == 'admin') {
                    header("Location: " . SITE_URL . "admin/dashboard.php");
                } else {
                    header("Location: " . SITE_URL);
                }
                exit;
            }
        } else {
            $errors[] = "بيانات الدخول غير صحيحة";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تسجيل الدخول - متجرك الإلكتروني</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.rtl.min.css">
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>assets/css/auth.css">
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>assets/css/style.css">
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>assets/css/admin.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .logout-warning {
            display: none;
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 5px 25px rgba(0, 0, 0, 0.3);
            z-index: 1000;
            text-align: center;
            width: 90%;
            max-width: 400px;
            border: 2px solid #e74c3c;
        }

        .overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.6);
            z-index: 999;
        }

        .inactivity-timer {
            position: fixed;
            bottom: 20px;
            left: 20px;
            background: rgba(231, 76, 60, 0.9);
            color: white;
            padding: 10px 15px;
            border-radius: 50px;
            font-size: 14px;
            display: none;
            z-index: 100;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
        }

        .guest-login-section {
            margin: 20px 0;
            text-align: center;
            position: relative;
        }

        .guest-login-section .divider {
            display: flex;
            align-items: center;
            margin: 20px 0;
        }

        .guest-login-section .divider::before,
        .guest-login-section .divider::after {
            content: "";
            flex: 1;
            height: 1px;
            background-color: #ddd;
        }

        .guest-login-section .divider-text {
            padding: 0 15px;
            color: #6c757d;
            font-size: 14px;
        }

        .btn-guest {
            background-color: #6c757d;
            border-color: #6c757d;
            color: white;
            transition: all 0.3s ease;
        }

        .btn-guest:hover {
            background-color: #5a6268;
            border-color: #545b62;
            color: white;
        }

        .guest-features {
            margin-top: 20px;
            padding: 15px;
            background-color: #f8f9fa;
            border-radius: 5px;
            text-align: right;
        }

        .guest-features h6 {
            color: #495057;
            margin-bottom: 10px;
            font-weight: 600;
        }

        .guest-features ul {
            list-style-type: none;
            padding: 0;
            margin: 0;
        }

        .guest-features li {
            margin-bottom: 8px;
            color: #6c757d;
            font-size: 14px;
        }

        .guest-features li i {
            color: #28a745;
            margin-left: 5px;
        }

        @media (max-width:768px) {
            .inactivity-timer {
                bottom: 10px;
                left: 10px;
                right: 10px;
                text-align: center;
            }

            .guest-features {
                padding: 10px;
            }
        }
    </style>
</head>

<body class="auth-page">
    <div class="auth-container">
        <div class="auth-card">
            <div class="auth-header">
                <h1><i class="fas fa-sign-in-alt"></i> تسجيل الدخول</h1>
                <p>مرحباً بعودتك! سجل الدخول للوصول إلى حسابك</p>
            </div>

            <?php if (!empty($errors)): ?>
                <div class="alert alert-danger">
                    <?php foreach ($errors as $error): ?>
                        <p class="mb-0"><i class="fas fa-exclamation-circle"></i> <?= htmlspecialchars($error) ?></p>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

            <form method="POST" class="auth-form">
                <div class="form-group">
                    <label for="email"><i class="fas fa-envelope"></i> البريد الإلكتروني</label>
                    <input type="email" id="email" name="email" required class="form-control" placeholder="أدخل بريدك الإلكتروني">
                </div>

                <div class="form-group">
                    <label for="password"><i class="fas fa-lock"></i> كلمة المرور</label>
                    <input type="password" id="password" name="password" required class="form-control" placeholder="أدخل كلمة المرور">
                    <small class="text-muted"><a href="<?php echo SITE_URL; ?>pages/forget_password.php">نسيت كلمة المرور؟</a></small>
                </div>

                <button type="submit" class="btn btn-primary btn-block">
                    <i class="fas fa-sign-in-alt"></i> تسجيل الدخول
                </button>

                <div class="auth-footer">
                    <p>ليس لديك حساب؟ <a href="<?php echo SITE_URL; ?>pages/register.php">إنشاء حساب جديد</a></p>
                </div>
            </form>

            <!-- قسم تسجيل الدخول كزائر -->
            <div class="guest-login-section">
                <div class="divider">
                    <span class="divider-text">أو</span>
                </div>

                <form method="POST">
                    <button type="submit" name="guest_login" class="btn btn-guest btn-block">
                        <i class="fas fa-user-circle"></i> تسجيل الدخول كزائر
                    </button>
                </form>

                <div class="guest-features">
                    <h6><i class="fas fa-info-circle"></i> ميزات التسجيل كزائر:</h6>
                    <ul>
                        <li><i class="fas fa-check"></i> تصفح المنتجات والعروض</li>
                        <li><i class="fas fa-check"></i> إضافة المنتجات إلى السلة</li>
                        <li><i class="fas fa-check"></i> حفظ المنتجات في المفضلة</li>
                        <li><i class="fas fa-check"></i> الطلب باحساب زائر</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <script src="<?php echo SITE_URL; ?>assets/js/bootstrap.bundle.min.js"></script>
    <script>
        // إضافة تأثيرات عند التمرير على زر الزائر
        document.addEventListener('DOMContentLoaded', function() {
            const guestBtn = document.querySelector('.btn-guest');

            if (guestBtn) {
                guestBtn.addEventListener('mouseenter', function() {
                    this.style.transform = 'translateY(-2px)';
                    this.style.boxShadow = '0 4px 8px rgba(0,0,0,0.15)';
                });

                guestBtn.addEventListener('mouseleave', function() {
                    this.style.transform = 'translateY(0)';
                    this.style.boxShadow = 'none';
                });
            }
        });
    </script>
</body>

</html>
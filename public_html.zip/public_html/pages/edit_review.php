<?php
session_start();
require_once __DIR__ . '/../includes/db_connect.php';
require_once __DIR__ . '/../includes/auth.php';

// التحقق من تسجيل الدخول (صاحب التقييم فقط يمكنه التعديل)
checkLogin();

// ✅ التحقق من أن الطلب POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: " . SITE_URL);
    exit;
}

$user_id = $_SESSION['user_id'];
$review_id = intval($_POST['review_id'] ?? 0);
$product_id = intval($_POST['product_id'] ?? 0);
$rating = intval($_POST['rating'] ?? 0);
$comment = trim($_POST['comment'] ?? '');

// ✅ التحقق من صحة المدخلات
if ($review_id <= 0 || $product_id <= 0) {
    $_SESSION['review_error'] = "بيانات غير صالحة";
    header("Location: " . SITE_URL . "pages/products.php");
    exit;
}

if ($rating < 1 || $rating > 5) {
    header("Location: " . SITE_URL . "pages/details_product.php?id=$product_id&error=invalid_rating");
    exit;
}

if (empty($comment)) {
    header("Location: " . SITE_URL . "pages/details_product.php?id=$product_id&error=empty_comment");
    exit;
}

try {
    // ✅ التحقق من وجود المنتج (منع FK constraint error)
    $check_product = $conn->prepare("SELECT id FROM products WHERE id = ?");
    $check_product->execute([$product_id]);
    if (!$check_product->fetch()) {
        error_log("Edit review: product_id={$product_id} not found. user_id={$user_id}");
        $_SESSION['review_error'] = "المنتج غير موجود أو تم حذفه";
        header("Location: " . SITE_URL . "pages/products.php");
        exit;
    }

    // تأكد أن التقييم يخص نفس المستخدم
    $stmt = $conn->prepare("SELECT id FROM reviews WHERE id = ? AND user_id = ?");
    $stmt->execute([$review_id, $user_id]);
    $review = $stmt->fetch();

    if (!$review) {
        header("Location: " . SITE_URL . "pages/details_product.php?id=$product_id&error=unauthorized");
        exit;
    }

    $stmt = $conn->prepare("UPDATE reviews SET rating = ?, comment = ?, created_at = NOW() WHERE id = ?");
    $stmt->execute([$rating, $comment, $review_id]);

    header("Location: " . SITE_URL . "pages/details_product.php?id=$product_id&success=edit");
    exit;

} catch (PDOException $e) {
    error_log("Edit review error: " . $e->getMessage() . " | review_id={$review_id}, user_id={$user_id}");
    $_SESSION['review_error'] = "حدث خطأ أثناء تعديل التقييم، يرجى المحاولة لاحقاً";
    header("Location: " . SITE_URL . "pages/details_product.php?id=$product_id&error=server");
    exit;
}
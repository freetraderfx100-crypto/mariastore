<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../includes/db_connect.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

// التحقق من تسجيل الدخول
checkLogin();

$user_id = $_SESSION['user_id'];
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['avatar'])) {
    $upload_dir = __DIR__ . '/../assets/images/users/avatars/';

    // إنشاء المجلد إذا لم يكن موجوداً
    if (!file_exists($upload_dir)) {
        mkdir($upload_dir, 0755, true);
    }

    $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];
    $file_type = $_FILES['avatar']['type'];
    $file_size = $_FILES['avatar']['size'];
    $file_tmp = $_FILES['avatar']['tmp_name'];
    $file_ext = strtolower(pathinfo($_FILES['avatar']['name'], PATHINFO_EXTENSION));
    $file_name = 'avatar_' . $user_id . '_' . time() . '.' . $file_ext;
    $file_path = $upload_dir . $file_name;

    // التحقق من نوع الملف
    if (!in_array($file_type, $allowed_types)) {
        $errors[] = "نوع الملف غير مسموح به. يرجى رفع صورة (JPEG, PNG, GIF)";
    }

    // التحقق من حجم الملف (2MB كحد أقصى)
    if ($file_size > 2097152) {
        $errors[] = "حجم الملف كبير جداً. الحد الأقصى 2MB";
    }

    if (empty($errors)) {
        // حذف الصورة القديمة إذا كانت موجودة
        $stmt = $conn->prepare("SELECT avatar FROM users WHERE id = ?");
        $stmt->execute([$user_id]);
        $old_avatar = $stmt->fetchColumn();

        if ($old_avatar && file_exists($upload_dir . $old_avatar)) {
            unlink($upload_dir . $old_avatar);
        }

        // رفع الصورة الجديدة
        if (move_uploaded_file($file_tmp, $file_path)) {
            // تحديث قاعدة البيانات
            $stmt = $conn->prepare("UPDATE users SET avatar = ? WHERE id = ?");
            $stmt->execute([$file_name, $user_id]);

            $_SESSION['avatar'] = $file_name;
        } else {
            $errors[] = "حدث خطأ أثناء رفع الملف";
        }
    }
}

// العودة إلى صفحة الملف الشخصي مع رسائل الخطأ إذا وجدت
$_SESSION['avatar_errors'] = $errors;
header("Location: " . SITE_URL . "pages/profile.php");
exit;

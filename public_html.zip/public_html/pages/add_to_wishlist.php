<?php
// require_once __DIR__ . '/../includes/session_config.php';
require_once __DIR__ . '/../includes/db_connect.php';

header('Content-Type: application/json');

// التحقق من تسجيل الدخول
if (!isset($_SESSION['user_id']) || !isset($_SESSION['email'])) {
    echo json_encode(['success' => false, 'error' => 'يجب تسجيل الدخول أولاً']);
    exit;
}

$user_id = $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['product_id'])) {
    $product_id = intval($_POST['product_id']);

    try {
        // التحقق إن كان المنتج موجود مسبقًا في المفضلة
        $check_stmt = $conn->prepare("SELECT COUNT(*) FROM wishlist WHERE user_id = ? AND product_id = ?");
        $check_stmt->execute([$user_id, $product_id]);
        $exists = $check_stmt->fetchColumn();

        if (!$exists) {
            $insert_stmt = $conn->prepare("INSERT INTO wishlist (user_id, product_id) VALUES (?, ?)");
            $insert_stmt->execute([$user_id, $product_id]);
        }

        echo json_encode(['success' => true]);
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'error' => 'خطأ في قاعدة البيانات']);
    }
} else {
    echo json_encode(['success' => false, 'error' => 'طلب غير صالح']);
}

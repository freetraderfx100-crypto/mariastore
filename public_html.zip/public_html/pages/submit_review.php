<?php
session_start();
require_once __DIR__ . '/../includes/db_connect.php';
require_once __DIR__ . '/../includes/auth.php';

// التحقق من تسجيل الدخول (أي مستخدم يمكنه التقييم)
checkLogin();

// ✅ التحقق من أن الطلب POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: " . SITE_URL);
    exit;
}

$user_id = $_SESSION['user_id'];
$product_id = intval($_POST['product_id'] ?? 0);
$rating = intval($_POST['rating'] ?? 0);
$comment = trim($_POST['comment'] ?? '');

// ✅ fallback: لو كان product_id فارغاً، نحاول قراءته من GET (للحالات الطارئة)
if ($product_id <= 0) {
    $product_id = intval($_GET['product_id'] ?? 0);
}

// ✅ التحقق من صحة المدخلات
if ($product_id <= 0) {
    // بدلاً من redirect لـ products.php، نعيد المستخدم لصفحة الدخول إن وُجد product_id في referer
    $referer = $_SERVER['HTTP_REFERER'] ?? '';
    error_log("Review submit: invalid product_id. POST=" . json_encode($_POST) . " | user_id={$user_id} | referer={$referer}");
    $_SESSION['review_error'] = "معرف المنتج غير صالح. يرجى إعادة تحميل الصفحة والمحاولة مرة أخرى.";
    
    // محاولة العودة للصفحة السابقة
    if (!empty($referer)) {
        header("Location: " . $referer);
    } else {
        header("Location: " . SITE_URL . "pages/products.php");
    }
    exit;
}

if ($rating < 1 || $rating > 5) {
    header("Location: " . SITE_URL . "pages/details_product.php?id=$product_id&error=invalid_rating");
    exit;
}

if (empty($comment)) {
    header("Location: " . SITE_URL . "pages/details_product.php?id=$product_id&error=empty_comment");
    exit;
}

try {
    // ✅ خطوة حرجة: التحقق من وجود المنتج فعلاً في قاعدة البيانات
    // هذا يمنع خطأ FK constraint لو كان المنتج محذوفاً أو غير موجود
    $check_stmt = $conn->prepare("SELECT id, is_active FROM products WHERE id = ?");
    $check_stmt->execute([$product_id]);
    $product = $check_stmt->fetch();

    if (!$product) {
        // المنتج غير موجود (محذوف غالباً)
        error_log("Review submit: product_id={$product_id} not found. user_id={$user_id}");
        $_SESSION['review_error'] = "المنتج غير موجود أو تم حذفه";
        header("Location: " . SITE_URL . "pages/products.php");
        exit;
    }

    // ✅ تحقق هل المستخدم قيّم هذا المنتج من قبل
    $stmt = $conn->prepare("SELECT id FROM reviews WHERE user_id = ? AND product_id = ?");
    $stmt->execute([$user_id, $product_id]);
    $existing = $stmt->fetch();

    if ($existing) {
        header("Location: " . SITE_URL . "pages/details_product.php?id=$product_id&error=exists");
        exit;
    }

    // ✅ إدراج التقييم
    $stmt = $conn->prepare("INSERT INTO reviews (product_id, user_id, rating, comment, created_at) VALUES (?, ?, ?, ?, NOW())");
    $stmt->execute([$product_id, $user_id, $rating, $comment]);
    header("Location: " . SITE_URL . "pages/details_product.php?id=$product_id&success=submit");
    exit;

} catch (PDOException $e) {
    // ✅ تسجيل الخطأ داخلياً بدلاً من كشفه للمستخدم
    error_log("Review submit error: " . $e->getMessage() . " | product_id={$product_id}, user_id={$user_id}");

    // رسالة ودية بدلاً من رسالة SQL الخام
    $_SESSION['review_error'] = "حدث خطأ أثناء إرسال التقييم، يرجى المحاولة لاحقاً";
    header("Location: " . SITE_URL . "pages/details_product.php?id=$product_id&error=server");
    exit;
}

<?php
// require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/db_connect.php';

$page_title = "عن المتجر";
include('../includes/header.php');
?>

<div class="about-page">
    <div class="container">
        <h1 class="text-center my-5">عن متجرنا</h1>

        <div class="about-section mb-5">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <img src="<?php echo SITE_URL; ?>assets/images/logo-white.png" alt="متجر الملابس النسائية" class="img-fluid rounded">
                </div>
                <div class="col-md-6">
                    <h2>قصتنا</h2>
                    <p>تأسس متجرنا المتخصص في الملابس النسائية عام 2010 في قلب العاصمة صنعاء، ومنذ ذلك الحين ونحن نعمل بجد لتقديم أحدث صيحات الموضة والأزياء التي تناسب المرأة اليمنية بكل أذواقها.</p>
                    <p>نفتخر بأننا كبرنا من متجر صغير إلى سلسلة متاجر منتشرة في عدة مواقع في محافظة صنعاء، مع الحفاظ على جودة منتجاتنا وخدمتنا المميزة.</p>
                </div>
            </div>
        </div>

        <div class="mission-section mb-5">
            <h2 class="text-center mb-4">رؤيتنا ورسالتنا</h2>
            <div class="row">
                <div class="col-md-6 mb-4">
                    <div class="card h-100">
                        <div class="card-body">
                            <h3 class="card-title">رؤيتنا</h3>
                            <p class="card-text">أن نكون الوجهة الأولى للمرأة اليمنية التي تبحث عن الجودة والأناقة في الملابس بأسعار تنافسية.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 mb-4">
                    <div class="card h-100">
                        <div class="card-body">
                            <h3 class="card-title">رسالتنا</h3>
                            <p class="card-text">تقديم تشكيلة متنوعة من الملابس النسائية التي تلبي جميع الأذواق والمناسبات، مع التركيز على الجودة والمواكبة لأحدث صيحات الموضة العالمية.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="branches-section mb-5">
            <h2 class="text-center mb-4">فروعنا في صنعاء</h2>
            <div class="row">
                <div class="col-md-4 mb-4">
                    <div class="card h-100">
                        <div class="card-body">
                            <h3 class="card-title">الفرع الرئيسي</h3>
                            <p class="card-text">الاصبحي شارع الحربي</p>
                            <p class="card-text">📞: 775616559</p>
                            <p class="card-text">مواعيد العمل: 9 صباحاً - 10 مساءً</p>
                        </div>
                    </div>
                </div>
                

        <div class="team-section mb-5">
            <h2 class="text-center mb-4">فريقنا</h2>
            <p class="text-center mb-5">نحن فريق من المحترفين في عالم الموضة والأزياء، نعمل معاً لتقديم أفضل تجربة تسوق لعملائنا الكرام.</p>
            <div class="row justify-content-center">
                <!-- يمكنك إضافة أعضاء الفريق هنا -->
            </div>
        </div>
    </div>
</div>

<?php include('../includes/footer.php'); ?>
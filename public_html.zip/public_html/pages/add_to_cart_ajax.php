<?php
require_once __DIR__ . '/../includes/db_connect.php';
require_once __DIR__ . '/../includes/functions.php';
// require_once __DIR__ . '/../includes/session_config.php';
require_once __DIR__ . '/../includes/visitor_tracking.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] != 'POST') {
    echo json_encode(['success' => false, 'message' => 'طريقة الطلب غير صحيحة']);
    exit;
}

if (!isset($_POST['product_id'])) {
    echo json_encode(['success' => false, 'message' => 'معرف المنتج مطلوب']);
    exit;
}

// بدء الجلسة إذا لم تكن بدأت
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// التحقق من تسجيل الدخول أو إذا كان زائراً
$is_guest = isset($_SESSION['guest_id']);
$is_logged_in = isset($_SESSION['user_id']);

if (!$is_logged_in && !$is_guest) {
    // إضافة رابط الدخول كزائر إلى رسالة الخطأ
    $login_url = SITE_URL . 'pages/login.php';
    $guest_login_url = SITE_URL . 'pages/login.php?guest=true';

    echo json_encode([
        'success' => false,
        'message' => 'يجب تسجيل الدخول أولاً',
        'requires_login' => true,
        'login_url' => $login_url,
        'guest_login_url' => $guest_login_url
    ]);
    exit;
}

// بدء الجلسة إذا لم تكن بدأت
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// التحقق من تسجيل الدخول أو إذا كان زائراً
$is_guest = isset($_SESSION['guest_id']);
$is_logged_in = isset($_SESSION['user_id']);

if (!$is_logged_in && !$is_guest) {
    echo json_encode(['success' => false, 'message' => 'يجب تسجيل الدخول أولاً']);
    exit;
}

$user_id = $is_logged_in ? $_SESSION['user_id'] : null;
$guest_id = $is_guest ? $_SESSION['guest_id'] : null;
$product_id = filter_var($_POST['product_id'], FILTER_SANITIZE_NUMBER_INT);
$quantity = isset($_POST['quantity']) ? (int)$_POST['quantity'] : 1;
$color = isset($_POST['color']) ? $_POST['color'] : '';
$size = isset($_POST['selected_size']) ? $_POST['selected_size'] : '';
$image_url = isset($_POST['image_url']) ? $_POST['image_url'] : '';
// ✅ إصلاح أمني حرج: لا نثق بالأسعار المرسلة من العميل
// نتجاهل original_price و discount_percentage من POST ونحسبها من DB
$product_name = isset($_POST['product_name']) ? $_POST['product_name'] : '';

// التحقق من البيانات المطلوبة
if (empty($color) || empty($size)) {
    echo json_encode(['success' => false, 'message' => 'اللون والمقاس مطلوبان']);
    exit;
}

try {
    // ✅ إصلاح أمني: جلب السعر الفعلي من قاعدة البيانات (لا نثق بالعميل)
    $price_stmt = $conn->prepare("
        SELECT p.price AS original_price, p.discount_percentage, p.discount_end_date,
               p.name AS product_name
        FROM products p
        WHERE p.id = ? AND p.is_active = 1
    ");
    $price_stmt->execute([$product_id]);
    $price_data = $price_stmt->fetch();

    if (!$price_data) {
        echo json_encode(['success' => false, 'message' => 'المنتج غير موجود أو غير متاح']);
        exit;
    }

    $original_price = (float)$price_data['original_price'];
    $discount_percentage = (float)$price_data['discount_percentage'];

    // التحقق من صلاحية الخصم (لم ينتهِ تاريخه)
    if (!empty($price_data['discount_end_date']) && $price_data['discount_end_date'] < date('Y-m-d')) {
        $discount_percentage = 0;
    }

    if (empty($product_name)) {
        $product_name = $price_data['product_name'];
    }

    // حساب السعر بعد الخصم
    $final_price = $original_price;
    if ($discount_percentage > 0) {
        $final_price = $original_price * (1 - $discount_percentage / 100);
    }

    // البحث عن سلة المستخدم أو إنشاؤها (للمستخدمين المسجلين)
    if ($is_logged_in) {
        $stmt = $conn->prepare("SELECT id FROM carts WHERE user_id = ?");
        $stmt->execute([$user_id]);
        $cart = $stmt->fetch();

        if (!$cart) {
            $stmt = $conn->prepare("INSERT INTO carts (user_id) VALUES (?)");
            $stmt->execute([$user_id]);
            $cart_id = $conn->lastInsertId();
        } else {
            $cart_id = $cart['id'];
        }
    }
    // للزوار، نستخدم الجلسة لتخزين السلة
    else {
        if (!isset($_SESSION['guest_cart'])) {
            $_SESSION['guest_cart'] = [];
        }
    }

    // التحقق من وجود المتغير في المخزون
    $variant_stmt = $conn->prepare("SELECT id, quantity, image_url FROM product_variants WHERE product_id = ? AND color = ? AND size = ?");
    $variant_stmt->execute([$product_id, $color, $size]);
    $variant = $variant_stmt->fetch();

    if (!$variant) {
        echo json_encode(['success' => false, 'message' => 'التركيبة غير موجودة']);
        exit;
    }

    // استخدام صورة المتغير إذا لم تكن الصورة محددة
    if (empty($image_url) && !empty($variant['image_url'])) {
        $image_url = $variant['image_url'];
    }

    // التحقق من الكمية المتاحة
    if ($variant['quantity'] < $quantity) {
        echo json_encode(['success' => false, 'message' => 'الكمية المطلوبة غير متوفرة. المتوفر: ' . $variant['quantity']]);
        exit;
    }

    // للمستخدمين المسجلين: استخدام قاعدة البيانات
    if ($is_logged_in) {
        // التحقق إذا كان المنتج موجودًا بالفعل في السلة
        $stmt = $conn->prepare("SELECT id, quantity FROM cart_items WHERE cart_id = ? AND product_id = ? AND color = ? AND size = ?");
        $stmt->execute([$cart_id, $product_id, $color, $size]);
        $existing_item = $stmt->fetch();

        if ($existing_item) {
            // تحديث الكمية إذا كان المنتج موجودًا
            $new_quantity = $existing_item['quantity'] + $quantity;
            if ($new_quantity <= $variant['quantity']) {
                $stmt = $conn->prepare("UPDATE cart_items SET quantity = ?, price = ? WHERE id = ?");
                $stmt->execute([$new_quantity, $final_price, $existing_item['id']]);
            } else {
                echo json_encode(['success' => false, 'message' => 'الكمية الإجمالية تتجاوز المخزون المتاح']);
                exit;
            }
        } else {
            // إضافة منتج جديد إلى السلة
            $stmt = $conn->prepare("INSERT INTO cart_items (cart_id, product_id, quantity, color, size, image_url, price) 
                                   VALUES (?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([$cart_id, $product_id, $quantity, $color, $size, $image_url, $final_price]);
        }

        // الحصول على عدد العناصر في السلة
        $stmt = $conn->prepare("SELECT SUM(quantity) as total FROM cart_items WHERE cart_id = ?");
        $stmt->execute([$cart_id]);
        $cart_count = $stmt->fetch()['total'] ?? 0;
    }
    // للزوار: استخدام الجلسة
    else {
        // إنشاء مفتاح فريد للعنصر بناءً على product_id + color + size
        $item_key = $product_id . '_' . $color . '_' . $size;

        if (isset($_SESSION['guest_cart'][$item_key])) {
            // تحديث الكمية إذا كان المنتج موجودًا
            $new_quantity = $_SESSION['guest_cart'][$item_key]['quantity'] + $quantity;
            if ($new_quantity <= $variant['quantity']) {
                $_SESSION['guest_cart'][$item_key]['quantity'] = $new_quantity;
            } else {
                echo json_encode(['success' => false, 'message' => 'الكمية الإجمالية تتجاوز المخزون المتاح']);
                exit;
            }
        } else {
            // إضافة منتج جديد إلى سلة الزائر
            $_SESSION['guest_cart'][$item_key] = [
                'product_id' => $product_id,
                'quantity' => $quantity,
                'color' => $color,
                'size' => $size,
                'image_url' => $image_url,
                'price' => $final_price,
                'original_price' => $original_price,
                'discount_percentage' => $discount_percentage,
                'product_name' => $product_name
            ];
        }

        // حساب عدد العناصر في سلة الزائر
        $cart_count = 0;
        foreach ($_SESSION['guest_cart'] as $item) {
            $cart_count += $item['quantity'];
        }
    }

    echo json_encode(['success' => true, 'message' => 'تمت الإضافة إلى السلة بنجاح', 'cart_count' => $cart_count]);
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'حدث خطأ في قاعدة البيانات: ' . $e->getMessage()]);
}

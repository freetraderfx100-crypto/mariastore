<?php
session_start();
require_once __DIR__ . '/../includes/db_connect.php';
require_once __DIR__ . '/../includes/auth.php';

// التحقق من تسجيل الدخول
checkLogin();

$user_id = $_SESSION['user_id'];

// دالة لتحويل حالة الطلب إلى العربية
function translateOrderStatus($status)
{
    $statusMap = [
        'pending' => 'قيد الانتظار',
        'processing' => 'قيد المعالجة',
        'in_the_way' => 'في الطريق',
        'completed' => 'مكتمل',
        'cancelled' => 'ملغي'
    ];

    return $statusMap[$status] ?? $status;
}

try {
    $stmt = $conn->prepare("
        SELECT id, total_amount, status, payment_method, shipping_address, created_at 
        FROM orders 
        WHERE user_id = ? 
        ORDER BY created_at DESC
    ");
    $stmt->execute([$user_id]);
    $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $error = "خطأ في قاعدة البيانات: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">

<head>
    <meta charset="UTF-8">
    <title>طلباتي</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.rtl.min.css" integrity="sha384-Xbg45MqvDIk1e563NLpGEulpX6AvL404DP+/iCgW9eFa2BqztiwTexswJo2jLMue" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>assets/css/style.css">
    <!-- <link rel="stylesheet" href="<?php echo SITE_URL; ?>assets/css/dash.css"> -->
</head>

<body>
    <div class="container py-5">
        <h2 class="mb-4 text-center"><i class="fas fa-box"></i> طلباتي</h2>

        <?php if (!empty($error)): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php elseif (empty($orders)): ?>
            <div class="alert alert-info text-center">لا توجد طلبات حالياً.</div>
        <?php else: ?>
            <table class="table table-bordered table-striped">
                <thead class="table-light">
                    <tr>
                        <th>رقم الطلب</th>
                        <th>المبلغ الإجمالي</th>
                        <th>الحالة</th>
                        <th>طريقة الدفع</th>
                        <th>العنوان</th>
                        <th>التاريخ</th>
                        <th>تفاصيل</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($orders as $order): ?>
                        <tr>
                            <td>#<?= $order['id'] ?></td>
                            <td><?= number_format($order['total_amount'], 2) ?> ر.ي</td>
                            <td><?= translateOrderStatus($order['status']) ?></td>
                            <td><?= htmlspecialchars($order['payment_method']) ?></td>
                            <td><?= htmlspecialchars($order['shipping_address']) ?></td>
                            <td><?= htmlspecialchars($order['created_at']) ?></td>
                            <td><a href="<?php echo SITE_URL; ?>pages/track-order.php?order_id=<?= $order['id'] ?>" class="btn btn-sm btn-outline-primary">تتبع</a></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>

    <script src="<?php echo SITE_URL; ?>assets/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/js/all.min.js"></script>
</body>

</html>
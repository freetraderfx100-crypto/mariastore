<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

// بدء الجلسة
if (session_status() === PHP_SESSION_NONE) {
    session_start([
        'cookie_lifetime' => 86400,
        'cookie_secure' => false,
        'cookie_httponly' => true,
        'cookie_samesite' => 'Lax'
    ]);
}

require_once __DIR__ . '/../includes/db_connect.php';
require_once __DIR__ . '/../includes/functions.php';

if (!isset($conn) || !($conn instanceof PDO)) {
    die("خطأ في اتصال قاعدة البيانات");
}

$errors = [];
$success = false;
$token = $_GET['token'] ?? '';

if (empty($token)) {
    die("لم يتم تقديم رمز إعادة التعيين");
}

try {
    // ضبط المنطقة الزمنية قبل التحقق من الصلاحية
    $conn->exec("SET time_zone = '+03:00'");

    $stmt = $conn->prepare("SELECT id FROM users WHERE reset_token = ? AND reset_token_expires > NOW()");
    $stmt->execute([$token]);
    $user = $stmt->fetch();

    if (!$user) {
        $errors[] = "رابط إعادة التعيين غير صالح أو منتهي الصلاحية";
    }
} catch (PDOException $e) {
    die("حدث خطأ في الاتصال بقاعدة البيانات: " . $e->getMessage());
}

// معالجة إرسال النموذج
if ($_SERVER['REQUEST_METHOD'] === 'POST' && empty($errors)) {
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';

    if (empty($password)) {
        $errors[] = "كلمة المرور الجديدة مطلوبة";
    } elseif (strlen($password) < 8) {
        $errors[] = "كلمة المرور يجب أن تكون 8 أحرف على الأقل";
    }

    if (empty($confirm_password)) {
        $errors[] = "تأكيد كلمة المرور مطلوب";
    } elseif ($password !== $confirm_password) {
        $errors[] = "كلمتا المرور غير متطابقتين";
    }

    if (empty($errors)) {
        try {
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("UPDATE users SET password = ?, reset_token = NULL, reset_token_expires = NULL WHERE id = ?");
            $stmt->execute([$hashed_password, $user['id']]);
            $success = true;
        } catch (PDOException $e) {
            $errors[] = "حدث خطأ في تحديث كلمة المرور: " . $e->getMessage();
        }
    }
}
?>


<!DOCTYPE html>
<html lang="ar" dir="rtl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إعادة تعيين كلمة المرور</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.rtl.min.css">
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>assets/css/auth.css">
</head>

<body class="auth-page">
    <div class="auth-container">
        <div class="auth-card">
            <div class="auth-header">
                <h1><i class="fas fa-key"></i> إعادة تعيين كلمة المرور</h1>
            </div>

            <?php if (!empty($errors)): ?>
                <div class="alert alert-danger">
                    <?php foreach ($errors as $error): ?>
                        <p><?= htmlspecialchars($error) ?></p>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

            <?php if ($success): ?>
                <div class="alert alert-success">
                    <p>تم تحديث كلمة المرور بنجاح!</p>
                    <p><a href="<?php echo SITE_URL; ?>pages/login.php">اضغط هنا لتسجيل الدخول</a></p>
                </div>
            <?php elseif (empty($errors)): ?>
                <form method="POST" class="auth-form">
                    <div class="form-group">
                        <label for="password"><i class="fas fa-lock"></i> كلمة المرور الجديدة</label>
                        <input type="password" id="password" name="password" required class="form-control">
                    </div>

                    <div class="form-group">
                        <label for="confirm_password"><i class="fas fa-lock"></i> تأكيد كلمة المرور</label>
                        <input type="password" id="confirm_password" name="confirm_password" required class="form-control">
                    </div>

                    <button type="submit" class="btn btn-primary btn-block">
                        <i class="fas fa-save"></i> حفظ كلمة المرور الجديدة
                    </button>
                </form>
            <?php endif; ?>
        </div>
    </div>
</body>

</html>
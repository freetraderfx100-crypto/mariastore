<?php
require_once __DIR__ . '/../includes/db_connect.php';
require_once __DIR__ . '/../includes/functions.php';
// require_once __DIR__ . '/../includes/session_config.php';

header('Content-Type: application/json');

// بدء الجلسة إذا لم تكن بدأت
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$is_logged_in = isset($_SESSION['user_id']);
$is_guest = isset($_SESSION['guest_id']);

try {
    $cart_count = 0;

    // للمستخدمين المسجلين
    if ($is_logged_in) {
        $user_id = $_SESSION['user_id'];

        $stmt = $conn->prepare("SELECT id FROM carts WHERE user_id = ?");
        $stmt->execute([$user_id]);
        $cart = $stmt->fetch();

        if ($cart) {
            $stmt = $conn->prepare("SELECT SUM(quantity) as total FROM cart_items WHERE cart_id = ?");
            $stmt->execute([$cart['id']]);
            $result = $stmt->fetch();
            $cart_count = $result['total'] ?? 0;
        }
    }
    // للزوار
    elseif ($is_guest && isset($_SESSION['guest_cart'])) {
        foreach ($_SESSION['guest_cart'] as $item) {
            $cart_count += $item['quantity'];
        }
    }

    echo json_encode(['success' => true, 'count' => $cart_count]);
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'count' => 0, 'error' => $e->getMessage()]);
}

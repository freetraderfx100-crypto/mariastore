<?php
require_once __DIR__ . '/../includes/db_connect.php';
require_once __DIR__ . '/../includes/functions.php';
// require_once __DIR__ . '/../includes/session_config.php';
require_once __DIR__ . '/../includes/visitor_tracking.php'; // إضافة هذا السطر
// إنشاء كائن تتبع الزوار
$visitorTracker = new VisitorTracker($conn);
$visitorTracker->recordPageView($_SERVER['REQUEST_URI']);
$isLoggedIn = isset($_SESSION['user_id']);
if (!isset($_GET['id'])) {
    header("Location: " . SITE_URL);
    exit;
}
$product_id = filter_var($_GET['id'], FILTER_SANITIZE_NUMBER_INT);
$user_id = $_SESSION['user_id'] ?? null; // مستخدم مسجل دخول أم لا

try {
    // جلب بيانات المنتج المحدد
    // جلب بيانات المنتج المحدد - تم التعديل لإضافة SKU
    $stmt = $conn->prepare("SELECT id, name, sku, description, price, discount_percentage, category_id, is_active FROM products WHERE id = ?");
    $stmt->execute([$product_id]);
    $product = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$product) {
        header("Location: " . SITE_URL);
        exit;
    }
    // جلب جميع صور المنتج
    // جلب جميع صور المنتج
    $images_stmt = $conn->prepare("SELECT * FROM product_variants WHERE product_id = ?");
    $images_stmt->execute([$product_id]);
    $product_variants = $images_stmt->fetchAll(PDO::FETCH_ASSOC);
    // استخراج الصور الفريدة من image_urls
    $unique_images = [];
    foreach ($product_variants as $variant) {
        if (!empty($variant['image_urls'])) {
            $images = json_decode($variant['image_urls'], true);
            if (is_array($images)) {
                foreach ($images as $image) {
                    if (!in_array($image, $unique_images)) {
                        $unique_images[] = $image;
                    }
                }
            }
        }
    }
    // إذا لم يتم العثور على صور، استخدم صورة افتراضية
    if (empty($unique_images)) {
        $unique_images[] = 'default-product-image.png';
    }

    // ✅ فلترة الصور المفقودة على القرص - يحل مشكلة ظهور أيقونة معطوبة في صفحة التفاصيل
    $images_dir = __DIR__ . '/../assets/images/';
    $valid_images = [];
    foreach ($unique_images as $img) {
        $clean = str_replace(['\\', '"', "'"], '', $img);
        $clean = str_replace('assets/images/', '', $clean);
        $clean = ltrim($clean, '/');
        $full_path = $images_dir . $clean;
        if (file_exists($full_path)) {
            $valid_images[] = $img;
        }
    }
    if (empty($valid_images)) {
        $valid_images = ['__PLACEHOLDER__'];
    }
    $unique_images = $valid_images;
    // استخراج الألوان المتوفرة للمنتج من الصور
    $color_stmt = $conn->prepare("SELECT DISTINCT color FROM product_variants WHERE product_id = ?");
    $color_stmt->execute([$product_id]);
    $product_colors = $color_stmt->fetchAll(PDO::FETCH_COLUMN);
    // حساب متوسط التقييم وعدد التقييمات
    $rating_stmt = $conn->prepare("SELECT AVG(rating) AS avg_rating, COUNT(*) AS total_reviews FROM reviews WHERE product_id = ?");
    $rating_stmt->execute([$product_id]);
    $rating_data = $rating_stmt->fetch(PDO::FETCH_ASSOC);
    $avg_rating = round($rating_data['avg_rating'], 1); // مثل: 4.3
    $total_reviews = $rating_data['total_reviews'];
    // إذا لم يكن هناك صور، نستخدم صورة افتراضية
    if (empty($product_variants)) {
        $product_variants[] = ['image_url' => 'default-product-image.png'];
    }
    // كود اضافه امنتج الى المفضله
    $isInWishlist = false;
    if ($isLoggedIn) {
        $checkWishlist = $conn->prepare("SELECT COUNT(*) FROM wishlist WHERE user_id = ? AND product_id = ?");
        $checkWishlist->execute([$_SESSION['user_id'], $product['id']]);
        $isInWishlist = $checkWishlist->fetchColumn() > 0;
    }

    if (!$product) {
        die("المنتج غير موجود");
    }
    // تحقق هل المنتج موجود في المفضلة للمستخدم الحالي
    $is_in_wishlist = false;
    if ($user_id) {
        $checkStmt = $conn->prepare("SELECT COUNT(*) FROM wishlist WHERE user_id = ? AND product_id = ?");
        $checkStmt->execute([$user_id, $product_id]);
        $is_in_wishlist = $checkStmt->fetchColumn() > 0;
    }
} catch (PDOException $e) {
    die("خطأ في جلب بيانات المنتج: " . $e->getMessage());
}
// جلب المقاسات المتوفرة للمنتج
try {
    $sizes_stmt = $conn->prepare("SELECT size FROM product_variants WHERE product_id = ?");
    $sizes_stmt->execute([$product['id']]);
    $available_sizes = $sizes_stmt->fetchAll(PDO::FETCH_COLUMN);
} catch (PDOException $e) {
    $available_sizes = [];
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_to_cart'])) {
    $quantity = isset($_POST['quantity']) ? (int)$_POST['quantity'] : 1;
    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }
    $_SESSION['cart'][$product_id] = isset($_SESSION['cart'][$product_id]) ?
        $_SESSION['cart'][$product_id] + $quantity : $quantity;
    header("Location: " . SITE_URL . "/pages/cart.php");
    exit;
}
// كود الاضافه الى المفضله
$isInWishlist = false;
if ($isLoggedIn) {
    $checkWishlist = $conn->prepare("SELECT COUNT(*) FROM wishlist WHERE user_id = ? AND product_id = ?");
    $checkWishlist->execute([$_SESSION['user_id'], $product['id']]);
    $isInWishlist = $checkWishlist->fetchColumn() > 0;
}

$pageTitle = $product['name'] . " | " . SITE_NAME;
include __DIR__ . '/../includes/header.php';
?>
<link rel="stylesheet" href="<?php echo SITE_URL; ?>assets/css/discount_style.css">
<style>
    .product-sku-info {
        margin: 5px 0;
        padding: 5px 10px;
        background-color: #f8f9fa;
        border-radius: 4px;
        font-family: 'Courier New', monospace;
        font-size: 0.9em;
        color: #666;
        border: 1px solid #e9ecef;
    }

    .product-sku-info span {
        font-weight: bold;
    }

    /* تنسيقات إضافية للتوافق */
    .product-meta>div {
        margin-bottom: 8px;
    }

    /* تنسيقات جديدة لتجميع الصور حسب اللون */
    /* ✅ الحاوية الرئيسية: تجعل كل أقسام الألوان في صف أفقي واحد */
    #thumbnailsContainer {
        display: flex !important;
        flex-direction: row !important;
        flex-wrap: wrap !important;
        gap: 12px !important;
        align-items: flex-start !important;
        margin-top: 10px;
    }

    .color-section {
        display: inline-flex;
        flex-direction: column;
        margin-bottom: 0 !important;
        margin-left: 0;
    }

    .color-title {
        font-size: 12px;
        font-weight: bold;
        margin-bottom: 5px;
        color: #555;
        display: flex;
        align-items: center;
    }

    .color-title .color-dot {
        width: 12px;
        height: 12px;
        border-radius: 50%;
        margin-left: 6px;
        display: inline-block;
        border: 1px solid #ddd;
    }

    /* ✅ الصور المصغرة لكل لون: أفقي داخل القسم */
    .color-thumbnails {
        display: flex;
        gap: 6px;
        overflow-x: auto;
        padding-bottom: 5px;
        max-width: 100%;
    }

    .color-thumbnails::-webkit-scrollbar {
        height: 4px;
    }

    .color-thumbnails::-webkit-scrollbar-thumb {
        background-color: #ccc;
        border-radius: 3px;
    }

    .color-thumbnail {
        flex: 0 0 auto;
        width: 60px;
        height: 60px;
        border-radius: 4px;
        overflow: hidden;
        cursor: pointer;
        border: 2px solid transparent;
        transition: border-color 0.2s;
    }

    .color-thumbnail:hover {
        border-color: #ddd;
    }

    .color-thumbnail.active {
        border-color: #ff6b8b;
    }

    .color-thumbnail img {
        width: 100%;
        height: 100%;
        object-fit: cover;
    }

    /* تنسيق زر اللون النشط */
    .color-btn.active {
        background-color: #ff6b8b;
        color: white;
        border-color: #ff6b8b;
    }
</style>
<section class="product-page">
    <div class="container">
        <!-- مسار التنقل (Breadcrumb) -->
        <nav class="breadcrumb">
            <!-- <a href="/online_store/">الرئيسية</a> -->
            <span></span>
            <a href="<?php echo SITE_URL; ?>pages/products.php?category_id=<?= $product['category_id'] ?>">
                <?php
                // يمكنك جلب أسماء التصنيفات من قاعدة البيانات بدلاً من المصفوفة الثابتة
                $categories_stmt = $conn->query("SELECT id, name FROM categories");
                $categories = $categories_stmt->fetchAll(PDO::FETCH_KEY_PAIR);
                // ثم استخدمها كالتالي:
                $category_name = $categories[$product['category_id']] ?? 'غير مصنف';
                ?>
            </a>
            <span>/</span>
            <span><?= htmlspecialchars($product['name']) ?></span>
        </nav>
        <!-- تفاصيل المنتج الرئيسية -->
        <div class="product-grid">
            <!-- معرض الصور -->
            <!-- معرض الصور مع المقاسات -->
            <!-- معرض الصور -->
            <div class="product-gallery">
                <div class="main-image">
                    <?php
                    // placeholder SVG مضمون
                    $placeholder_svg = 'data:image/svg+xml;base64,' . base64_encode(
                        '<svg xmlns="http://www.w3.org/2000/svg" width="600" height="600" viewBox="0 0 600 600">' .
                        '<rect width="600" height="600" fill="#f8f9fa"/>' .
                        '<text x="300" y="270" font-size="80" text-anchor="middle" fill="#cccccc" font-family="sans-serif">👕</text>' .
                        '<text x="300" y="360" font-size="24" text-anchor="middle" fill="#999999" font-family="sans-serif">صورة غير متوفرة</text>' .
                        '</svg>'
                    );
                    if ($unique_images[0] === '__PLACEHOLDER__') {
                        echo '<img src="' . $placeholder_svg . '" alt="' . htmlspecialchars($product['name']) . '" id="mainProductImage">';
                    } else {
                        echo '<img src="' . SITE_URL . 'assets/images/' . htmlspecialchars($unique_images[0]) . '"
                            alt="' . htmlspecialchars($product['name']) . '"
                            id="mainProductImage"
                            onerror="this.src=\'' . $placeholder_svg . '\'; this.onerror=null;">';
                    }
                    ?>
                </div>
                <!-- سيتم استبدال الصور المصغرة بالهيكلية الجديدة -->
                <div class="thumbnails-container" id="thumbnailsContainer">
                    <!-- سيتم ملؤها بالجافاسكربت -->
                </div>
            </div>
            <!-- معلومات المنتج -->
            <div class="product-info">
                <h1 class="product-title"><?= htmlspecialchars($product['name']) ?></h1>
                <div class="product-meta">
                    <div class="product-rating">
                        <div class="stars">
                            <?php
                            $fullStars = floor($avg_rating);
                            $halfStar = ($avg_rating - $fullStars) >= 0.5;
                            $emptyStars = 5 - $fullStars - ($halfStar ? 1 : 0);
                            for ($i = 0; $i < $fullStars; $i++) {
                                echo '<i class="fas fa-star"></i>';
                            }
                            if ($halfStar) {
                                echo '<i class="fas fa-star-half-alt"></i>';
                            }
                            for ($i = 0; $i < $emptyStars; $i++) {
                                echo '<i class="far fa-star"></i>';
                            }
                            ?>
                        </div>
                        <span class="review-count">(<?= $total_reviews ?> تقييم)</span>
                    </div>
                    <div class="product-code">
                        <span>رقم المنتج: <?= $product['id'] ?></span>
                    </div>
                    <?php if (!empty($product['sku'])): ?>
                        <div class="product-sku-info">
                            <label>SKU:</label>
                            <span><?= htmlspecialchars($product['sku']) ?></span>
                        </div>
                    <?php endif; ?>
                    <div id="variantAvailability" class="product-availability">
                        <i class="fas fa-info-circle"></i>
                        <span>يرجى اختيار اللون والمقاس</span>
                    </div>
                </div>
                <div class="product-price">
                    <?php if ($product['discount_percentage'] > 0): ?>
                        <?php
                        $discounted_price = $product['price'] * (1 - $product['discount_percentage'] / 100);
                        $saved_amount = $product['price'] - $discounted_price;
                        ?>
                        <span class="original-price"><?= number_format($product['price'], 2) ?> ر.ي</span>
                        <span class="discounted-price"><?= number_format($discounted_price, 2) ?> ر.ي</span>
                        <span class="save-amount">وفر <?= number_format($saved_amount, 2) ?> ر.ي (خصم <?= $product['discount_percentage'] ?>%)</span>
                    <?php else: ?>
                        <span class="current-price"><?= number_format($product['price'], 2) ?> ر.ي</span>
                    <?php endif; ?>
                </div>
                <div class="product-description">
                    <h3>وصف المنتج</h3>
                    <p><?= nl2br(htmlspecialchars($product['description'])) ?></p>
                </div>
                <!-- اختيار اللون -->
                <div class="color-options">
                    <label class="color-label">اختر اللون:</label>
                    <div class="color-buttons">
                        <?php foreach ($product_colors as $color): ?>
                            <button type="button" class="color-btn"
                                onclick="filterImagesByColor('<?= htmlspecialchars($color) ?>', this)">
                                <?= htmlspecialchars($color) ?>
                            </button>
                        <?php endforeach; ?>
                    </div>
                </div>

                <!-- اختيار المقاسات -->
                <?php if (!empty($available_sizes)): ?>
                    <!-- اختيار المقاسات -->
                    <!-- اختيار المقاسات -->
                    <div class="product-sizes">
                        <label>اختر المقاس:</label>
                        <div class="size-options" id="sizeOptions">
                            <!-- سيتم ملؤها بالجافاسكربت -->
                            <div class="size-loading">اختر اللون لاظهار المقاس...</div>
                        </div>
                        <div class="size-guide-link">
                            <a href="#" data-toggle="modal" data-target="#sizeGuideModal">دليل المقاسات</a>
                        </div>
                    </div>
                    <!-- دليل المقاسات (مودال) -->
                    <div class="modal fade" id="sizeGuideModal" tabindex="-1" role="dialog" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title">دليل المقاسات</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <?php
                                    $size_guide_path = __DIR__ . '/../assets/images/size-guide.jpg';
                                    if (file_exists($size_guide_path)):
                                    ?>
                                        <img src="<?php echo SITE_URL; ?>assets/images/size-guide.jpg" alt="دليل المقاسات" class="img-fluid">
                                    <?php else: ?>
                                        <div style="text-align: center; padding: 40px 20px; color: #7f8c8d;">
                                            <i class="fas fa-ruler" style="font-size: 48px; color: #bdc3c7;"></i>
                                            <p style="margin-top: 15px;">دليل المقاسات غير متوفر حالياً</p>
                                            <p style="font-size: 13px; color: #95a5a6;">للحصول على دليل المقاسات، يرجى التواصل معنا عبر WhatsApp.</p>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="product-sizes">
                        <label>المقاسات:</label>
                        <p>غير متوفرة حالياً</p>
                    </div>
                <?php endif; ?>
                <form method="post" class="add-to-cart-form" id="addToCartForm">
                    <input type="hidden" name="product_id" value="<?= htmlspecialchars($product['id']) ?>">
                    <input type="hidden" name="color" id="selectedColor">
                    <input type="hidden" name="selected_size" id="selectedSize">
                    <input type="hidden" name="image_url" id="selectedImageUrl">
                    <input type="hidden" name="original_price" value="<?= $product['price'] ?>">
                    <input type="hidden" name="discount_percentage" value="<?= $product['discount_percentage'] ?>">
                    <input type="hidden" name="product_name" value="<?= htmlspecialchars($product['name']) ?>">
                    <div class="quantity-selector">
                        <label for="quantity">الكمية:</label>
                        <div class="quantity-controls">
                            <button type="button" class="quantity-btn minus" aria-label="إنقاص الكمية">
                                <i class="fas fa-minus"></i>
                            </button>
                            <input type="number" id="quantity" name="quantity" value="1" min="1" max="1">
                            <button type="button" class="quantity-btn plus" aria-label="زيادة الكمية">
                                <i class="fas fa-plus"></i>
                            </button>
                        </div>
                    </div>
                    <button type="submit" name="add_to_cart" class="btn btn-pink btn-add-to-cart">
                        <i class="fas fa-shopping-cart"></i> أضف إلى السلة
                    </button>
                </form>
                <div class="product-actions">
                    <!-- زر الإضافة إلى المفضلة -->
                    <div id="wishlistButtons">
                        <?php if ($is_in_wishlist): ?>
                            <button id="removeFromWishlistBtn" data-product-id="<?= $product['id'] ?>" class="btn btn-danger">
                                ❌ إزالة من المفضلة
                            </button>
                        <?php else: ?>
                            <button id="addToWishlistBtn" data-product-id="<?= $product['id'] ?>" class="btn btn-outline-danger">
                                ❤️ أضف إلى المفضلة
                            </button>
                        <?php endif; ?>
                    </div>
                    <div id="wishlistMessage" style="margin-top: 10px; color: red;"></div>

                    <div class="social-share">
                        <span>شارك المنتج:</span>
                        <a href="https://www.facebook.com" target="_blank" class="facebook"><i class="fab fa-facebook-f"></i></a>
                        <a href="https://www.twitter.com" target="_blank" class="twitter"><i class="fab fa-twitter"></i></a>
                        <a href="https://instagram.com" target="_blank" class="instagram"><i class="fab fa-instagram"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- تضمين قسم المنتجات ذات الصلة -->
    <?php include __DIR__ . '/related_products.php'; ?>
    <!-- تضمين قسم التقييمات والتعليقات -->
    <?php include __DIR__ . '/product_reviews.php'; ?>
</section>
<?php include __DIR__ . '/../includes/footer.php'; ?>
<!-- تنسيقات التعليقات مع زر تغيير اللون -->
<!-- ✅ إضافة ?v=2 لكسر الكاش -->
<link rel="stylesheet" href="<?php echo SITE_URL; ?>assets/css/details_product_style.css?v=2">
<script>
    // placeholder SVG مضمون للصور المفقودة
    var PLACEHOLDER_SVG = 'data:image/svg+xml;base64,<?php echo base64_encode(
        '<svg xmlns="http://www.w3.org/2000/svg" width="200" height="200" viewBox="0 0 200 200">' .
        '<rect width="200" height="200" fill="#f8f9fa"/>' .
        '<text x="100" y="90" font-size="30" text-anchor="middle" fill="#cccccc" font-family="sans-serif">👕</text>' .
        '<text x="100" y="120" font-size="10" text-anchor="middle" fill="#999999" font-family="sans-serif">صورة غير متوفرة</text>' .
        '</svg>'
    ); ?>';

    // دالة لعرض الصور المصغرة مجمعة حسب اللون
    function displayThumbnailsByColor() {
        const variants = <?= json_encode($product_variants) ?>;
        const thumbnailsContainer = document.getElementById('thumbnailsContainer');

        // تجميع الصور حسب اللون
        const colorGroups = {};
        variants.forEach(variant => {
            const color = variant.color;
            if (!colorGroups[color]) {
                colorGroups[color] = [];
            }

            if (variant.image_urls) {
                const images = JSON.parse(variant.image_urls);
                if (Array.isArray(images)) {
                    images.forEach(image => {
                        if (!colorGroups[color].includes(image)) {
                            colorGroups[color].push(image);
                        }
                    });
                }
            }
        });

        // إنشاء HTML لعرض الصور المصغرة
        let html = '';
        Object.keys(colorGroups).forEach(color => {
            html += `
            <div class="color-section">
                <div class="color-title">
                    ${color}
                    <span class="color-dot" style="background-color: ${getColorCode(color)}"></span>
                </div>
                <div class="color-thumbnails">
            `;

            colorGroups[color].forEach((image, index) => {
                const isActive = index === 0 ? 'active' : '';
                html += `
                <div class="color-thumbnail ${isActive}" 
                     onclick="changeMainImage(this, '${color}')" 
                     data-color="${color}">
                    <img src="<?php echo SITE_URL; ?>assets/images/${image}" 
                         alt="${color}"
                         onerror="this.onerror=null; this.src='${PLACEHOLDER_SVG}';">
                </div>
                `;
            });

            html += `
                </div>
            </div>
            `;
        });

        thumbnailsContainer.innerHTML = html;
    }

    // دالة للحصول على كود اللون (يمكن توسيعها لتشمل المزيد من الألوان)
    function getColorCode(colorName) {
        const colorMap = {
            'أحمر': '#ff0000',
            'أزرق': '#0000ff',
            'أخضر': '#008000',
            'أسود': '#000000',
            'أبيض': '#ffffff',
            'أصفر': '#ffff00',
            'برتقالي': '#ffa500',
            'بنفسجي': '#800080',
            'رمادي': '#808080',
            'بني': '#a52a2a',
            'وردي': '#ffc0cb',
            'فضي': '#c0c0c0',
            'ذهبي': '#ffd700'
        };
        return colorMap[colorName] || '#cccccc';
    }

    // دالة لتغيير الصورة الرئيسية عند النقر على صورة مصغرة
    function changeMainImage(thumbnail, color) {
        const mainImg = document.getElementById('mainProductImage');
        const img = thumbnail.querySelector('img');

        // تحديث الصورة الرئيسية
        mainImg.src = img.src;
        // ✅ إضافة onerror fallback للصورة الرئيسية
        mainImg.onerror = function() {
            this.onerror = null;
            this.src = PLACEHOLDER_SVG;
        };

        // تحديث حقل الصورة المختارة
        document.getElementById('selectedImageUrl').value = img.src.split('/').pop();

        // إزالة التحديد من جميع الصور المصغرة
        document.querySelectorAll('.color-thumbnail').forEach(t => t.classList.remove('active'));

        // تمييز الصورة المحددة
        thumbnail.classList.add('active');

        // تحديث اللون المختار
        document.getElementById('selectedColor').value = color;

        // تمييز زر اللون المناسب
        document.querySelectorAll('.color-btn').forEach(btn => {
            btn.classList.remove('active');
            if (btn.textContent.trim() === color) {
                btn.classList.add('active');
            }
        });

        // تحديث المقاسات المتاحة للون المحدد
        loadSizeOptions(color);
    }

    // دالة لفلترة الصور حسب اللون
    function filterImagesByColor(color, button) {
        // تحديث الصورة الرئيسية بأول صورة للون المحدد
        const firstThumbnail = document.querySelector(`.color-thumbnail[data-color="${color}"]`);
        if (firstThumbnail) {
            changeMainImage(firstThumbnail, color);
        }

        // تمرير إلى قسم الصور الخاصة باللون المحدد
        const colorSection = document.querySelector(`.color-section:has(.color-thumbnail[data-color="${color}"])`);
        if (colorSection) {
            colorSection.scrollIntoView({
                behavior: 'smooth',
                block: 'nearest'
            });
        }
    }

    // دالة لتحميل وعرض المقاسات
    function loadSizeOptions(color) {
        const sizeOptionsDiv = document.getElementById('sizeOptions');
        sizeOptionsDiv.innerHTML = '<div class="size-loading">اختر اللون لاظهار المقاس...</div>';
        const variants = <?= json_encode($product_variants) ?>;

        // تصفية المتغيرات حسب اللون المحدد
        const colorVariants = variants.filter(v => v.color === color);

        // الحصول على المقاسات الفريدة مع حالة التوفر
        const sizeMap = {};
        colorVariants.forEach(v => {
            if (!sizeMap[v.size]) {
                // استخراج الصورة الأولى من image_urls
                let imageUrl = '';
                if (v.image_urls) {
                    const images = JSON.parse(v.image_urls);
                    if (Array.isArray(images) && images.length > 0) {
                        imageUrl = images[0];
                    }
                }
                sizeMap[v.size] = {
                    size: v.size,
                    available: v.quantity > 0,
                    image: imageUrl
                };
            }
        });

        // إنشاء عناصر المقاسات
        let html = '';
        Object.values(sizeMap).forEach(sizeInfo => {
            const sizeId = `size_${sizeInfo.size.replace(/\s+/g, '_')}`;
            html += `
            <div class="size-option">
                <input type="radio" id="${sizeId}" name="size" value="${sizeInfo.size}" 
                    ${!sizeInfo.available ? 'disabled' : ''}
                    data-image="${sizeInfo.image}">
                <label for="${sizeId}" class="${!sizeInfo.available ? 'size-out-of-stock' : ''}">
                    ${sizeInfo.size}
                    ${!sizeInfo.available ? '<span class="size-tooltip">غير متوفر</span>' : ''}
                </label>
            </div>
            `;
        });

        sizeOptionsDiv.innerHTML = html || '<div class="size-none">لا توجد مقاسات متوفرة لهذا اللون</div>';

        // إضافة مستمعات الأحداث للمقاسات
        document.querySelectorAll('.size-option input[name="size"]').forEach(radio => {
            radio.addEventListener('change', function() {
                if (this.checked) {
                    document.getElementById('selectedSize').value = this.value;
                    // تحديث الصورة إذا كانت هناك صورة خاصة بهذا المقاس
                    if (this.dataset.image) {
                        const mainImg = document.getElementById('mainProductImage');
                        mainImg.src = `<?php echo SITE_URL; ?>assets/images/${this.dataset.image}`;
                        // ✅ إضافة fallback للصورة المفقودة
                        mainImg.onerror = function() {
                            this.onerror = null;
                            this.src = PLACEHOLDER_SVG;
                        };
                        document.getElementById('selectedImageUrl').value = this.dataset.image;
                    }
                    // تحديث حالة التوفر
                    updateAvailability(color, this.value);
                }
            });
        });
    }

    // دالة لتحديث حالة التوفر
    function updateAvailability(color, size) {
        const variants = <?= json_encode($product_variants) ?>;
        const quantityInput = document.getElementById('quantity');
        const availabilityDiv = document.getElementById('variantAvailability');

        if (!color || !size) {
            availabilityDiv.innerHTML = `<i class="fas fa-info-circle"></i> <span>يرجى اختيار اللون والمقاس</span>`;
            quantityInput.max = 1;
            return;
        }

        const variant = variants.find(v => v.color === color && v.size === size);
        if (variant) {
            const qty = variant.quantity;
            availabilityDiv.innerHTML = qty > 0 ?
                `<i class="fas fa-check-circle"></i> <span>متوفر (${qty} قطعة)</span>` :
                `<i class="fas fa-times-circle"></i> <span>غير متوفر حالياً</span>`;
            quantityInput.max = qty;
            // تحديث الكمية القصوى المسموح بها
            if (parseInt(quantityInput.value) > qty) {
                quantityInput.value = qty;
            }
        } else {
            availabilityDiv.innerHTML = `<i class="fas fa-times-circle"></i> <span>هذه التركيبة غير متوفرة</span>`;
            quantityInput.max = 1;
        }
    }

    // عند تحميل الصفحة
    document.addEventListener("DOMContentLoaded", function() {
        // عرض الصور المصغرة مجمعة حسب اللون
        displayThumbnailsByColor();

        const colorButtons = document.querySelectorAll('.color-btn');

        // تفعيل اللون الأول تلقائياً إذا كان هناك لون واحد
        if (colorButtons.length === 1) {
            const defaultColor = colorButtons[0].textContent.trim();
            filterImagesByColor(defaultColor, colorButtons[0]);
        }

        // إذا لم يتم اختيار لون، استخدم أول لون متوفر
        if (colorButtons.length > 0 && !document.getElementById('selectedColor').value) {
            const firstColor = colorButtons[0].textContent.trim();
            filterImagesByColor(firstColor, colorButtons[0]);
        }
    });
</script>
<!-- باقي الأكواد JavaScript -->
<script>
    // تغيير الصورة الرئيسية عند النقر على الصور المصغرة (للخلفية)
    function changeMainImageOld(thumbnail) {
        const mainImage = document.getElementById('mainProductImage');
        const img = thumbnail.querySelector('img');
        mainImage.src = img.src;
        // ✅ إضافة fallback للصورة المفقودة
        mainImage.onerror = function() {
            this.onerror = null;
            this.src = PLACEHOLDER_SVG;
        };
        // تحديث الصورة النشطة
        document.querySelectorAll('.thumbnail').forEach(t => t.classList.remove('active'));
        thumbnail.classList.add('active');
        // تحديث حقل الصورة المختارة
        document.getElementById('selectedImageUrl').value = img.src.split('/').pop();
    }
    // إدارة الكمية
    // إدارة الكمية مع التحقق من التوفر
    const minusBtn = document.querySelector('.quantity-btn.minus');
    if (minusBtn) minusBtn.addEventListener('click', function() {
        const quantityInput = document.getElementById('quantity');
        let value = parseInt(quantityInput.value);
        if (value > 1) {
            quantityInput.value = value - 1;
        }
    });
    const plusBtn = document.querySelector('.quantity-btn.plus');
    if (plusBtn) plusBtn.addEventListener('click', function() {
        const quantityInput = document.getElementById('quantity');
        let value = parseInt(quantityInput.value);
        let max = parseInt(quantityInput.max) || 1;
        if (value < max) {
            quantityInput.value = value + 1;
        } else {
            alert('لا يمكن تجاوز الكمية المتوفرة في المخزن');
        }
    });
    // التحقق من إدخال الكمية يدوياً
    const qtyInput = document.getElementById('quantity');
    if (qtyInput) qtyInput.addEventListener('change', function() {
        let value = parseInt(this.value);
        let max = parseInt(this.max) || 1;
        if (isNaN(value) || value < 1) {
            this.value = 1;
        } else if (value > max) {
            this.value = max;
            alert('الكمية المطلوبة تتجاوز الكمية المتوفرة في المخزن');
        }
    });
    // إضافة إلى المفضلة
    const wishlistBtnEl = document.querySelector('.wishlist-btn');
    if (wishlistBtnEl) wishlistBtnEl.addEventListener('click', function(e) {
        e.preventDefault();
        this.classList.toggle('added');
        if (this.classList.contains('added')) {
            this.innerHTML = '<i class="fas fa-heart"></i> تم الإضافة إلى المفضلة';
        } else {
            this.innerHTML = '<i class="far fa-heart"></i> أضف إلى المفضلة';
        }
    });
</script>
<!--  منع المستخدم من الإرسال قبل اختيار اللون/المقاس -->
<script>
    const addToCartFormEl = document.querySelector('.add-to-cart-form');
    if (addToCartFormEl) addToCartFormEl.addEventListener('submit', function(e) {
        const color = document.getElementById('selectedColor').value;
        const size = document.getElementById('selectedSize').value;
        if (!color) {
            e.preventDefault();
            Swal.fire({
                icon: 'warning',
                title: 'اختيار اللون مطلوب',
                text: 'يرجى اختيار اللون قبل إضافة المنتج إلى السلة.',
                confirmButtonText: 'حسناً'
            });
            return;
        }
        if (!size) {
            e.preventDefault();
            Swal.fire({
                icon: 'warning',
                title: 'اختيار المقاس مطلوب',
                text: 'يرجى اختيار المقاس قبل إضافة المنتج إلى السلة.',
                confirmButtonText: 'حسناً'
            });
            return;
        }
    });
</script>
<!-- سكربت لعرض النافذه المنبثقه لتعديل التعليق والتقييم -->
<script>
    function openEditModal(reviewId, rating, comment) {
        document.getElementById('edit_review_id').value = reviewId;
        document.getElementById('edit_rating').value = rating;
        document.getElementById('edit_comment').value = comment;
        document.getElementById('editReviewModal').style.display = 'block';
    }

    function closeModal() {
        document.getElementById('editReviewModal').style.display = 'none';
    }
    window.onclick = function(event) {
        const modal = document.getElementById('editReviewModal');
        if (event.target === modal) {
            closeModal();
        }
    }
</script>
<!-- لإخفاء الرسالة تم التعديل بعد 4 ثوانٍ   -->
<script>
    // إخفاء رسائل النجاح أو الخطأ بعد 4 ثوانٍ
    setTimeout(function() {
        const alertBox = document.querySelector('.alert');
        if (alertBox) {
            alertBox.classList.add('fade-out');
            setTimeout(() => alertBox.remove(), 500);
        }
    }, 4000);
</script>
<!-- لتحديث الحقل عند اختيار المستخدم للحجم -->
<script>
    const sizeSelectEl = document.getElementById('size');
    if (sizeSelectEl) sizeSelectEl.addEventListener('change', function() {
        document.getElementById('selectedSize').value = this.value;
    });
</script>
<!-- سكربت اضافه المنتج الى المفضله -->
<script>
    const wishlistBtnEl2 = document.getElementById('wishlistBtn');
    if (wishlistBtnEl2) wishlistBtnEl2.addEventListener('click', function() {
        const btn = this;
        const productId = btn.dataset.productId;
        const isAdded = btn.classList.contains('added');
        fetch(`<?php echo SITE_URL; ?>pages/${isAdded ? 'remove_wishlist.php' : 'add_to_wishlist.php'}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                body: `product_id=${productId}`
            })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    btn.classList.toggle('added');
                    btn.querySelector('i').className = btn.classList.contains('added') ? 'fas fa-heart' : 'far fa-heart';
                    btn.querySelector('span').textContent = btn.classList.contains('added') ? 'تمت الإضافة للمفضلة' : 'أضف إلى المفضلة';
                } else {
                    alert(data.error || 'حدث خطأ ما.');
                }
            })
            .catch(() => alert('فشل الاتصال بالخادم.'));
    });
</script>
<!-- سكربت اضافه وحذف من المفضله -->
<script>
    document.addEventListener("DOMContentLoaded", function() {
        const wishlistButtonsDiv = document.getElementById("wishlistButtons");
        const messageDiv = document.getElementById("wishlistMessage");
        // إضافة المنتج إلى المفضلة
        function addToWishlist(productId) {
            fetch("<?php echo SITE_URL; ?>pages/add_to_wishlist.php", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/x-www-form-urlencoded"
                    },
                    body: "product_id=" + encodeURIComponent(productId)
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        messageDiv.style.color = "green";
                        messageDiv.textContent = "تمت إضافة المنتج إلى المفضلة بنجاح.";
                        renderRemoveButton(productId);
                    } else {
                        messageDiv.style.color = "red";
                        messageDiv.textContent = data.error || "حدث خطأ أثناء الإضافة.";
                    }
                })
                .catch(() => {
                    messageDiv.style.color = "red";
                    messageDiv.textContent = "فشل الاتصال بالخادم.";
                });
        }
        // إزالة المنتج من المفضلة
        function removeFromWishlist(productId) {
            fetch("<?php echo SITE_URL; ?>pages/remove_wishlist.php", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/x-www-form-urlencoded"
                    },
                    body: "product_id=" + encodeURIComponent(productId)
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        messageDiv.style.color = "green";
                        messageDiv.textContent = "تمت إزالة المنتج من المفضلة.";
                        renderAddButton(productId);
                    } else {
                        messageDiv.style.color = "red";
                        messageDiv.textContent = data.error || "حدث خطأ أثناء الإزالة.";
                    }
                })
                .catch(() => {
                    messageDiv.style.color = "red";
                    messageDiv.textContent = "فشل الاتصال بالخادم.";
                });
        }
        // عرض زر إضافة المفضلة
        function renderAddButton(productId) {
            wishlistButtonsDiv.innerHTML = `
            <button id="addToWishlistBtn" data-product-id="${productId}" class="btn btn-outline-danger">
                ❤️ أضف إلى المفضلة
            </button>
        `;
            document.getElementById("addToWishlistBtn").addEventListener("click", function() {
                addToWishlist(productId);
            });
        }
        // عرض زر إزالة المفضلة
        function renderRemoveButton(productId) {
            wishlistButtonsDiv.innerHTML = `
            <button id="removeFromWishlistBtn" data-product-id="${productId}" class="btn btn-danger">
                ❌ إزالة من المفضلة
            </button>
        `;
            document.getElementById("removeFromWishlistBtn").addEventListener("click", function() {
                removeFromWishlist(productId);
            });
        }
        // ربط الحدث المناسب عند التحميل
        if (document.getElementById("addToWishlistBtn")) {
            document.getElementById("addToWishlistBtn").addEventListener("click", function() {
                const productId = this.getAttribute("data-product-id");
                addToWishlist(productId);
            });
        }
        if (document.getElementById("removeFromWishlistBtn")) {
            document.getElementById("removeFromWishlistBtn").addEventListener("click", function() {
                const productId = this.getAttribute("data-product-id");
                removeFromWishlist(productId);
            });
        }
    });
</script>
<script>
    const addToCartFormEl2 = document.getElementById('addToCartForm');
    if (addToCartFormEl2) addToCartFormEl2.addEventListener('submit', function(e) {
        e.preventDefault();
        const color = document.getElementById('selectedColor').value;
        const size = document.getElementById('selectedSize').value;
        const formData = new FormData(this);
        // التحقق من اختيار اللون والمقاس
        if (!color) {
            Swal.fire({
                icon: 'warning',
                title: 'اختيار اللون مطلوب',
                text: 'يرجى اختيار اللون قبل إضافة المنتج إلى السلة.',
                confirmButtonText: 'حسناً'
            });
            return;
        }
        if (!size) {
            Swal.fire({
                icon: 'warning',
                title: 'اختيار المقاس مطلوب',
                text: 'يرجى اختيار المقاس قبل إضافة المنتج إلى السلة.',
                confirmButtonText: 'حسناً'
            });
            return;
        }
        // إرسال البيانات عبر Ajax
        // إرسال البيانات عبر Ajax
        fetch('<?php echo SITE_URL; ?>pages/add_to_cart_ajax.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    Swal.fire({
                        icon: 'success',
                        title: 'تمت الإضافة إلى السلة',
                        text: data.message,
                        confirmButtonText: 'موافق'
                    });
                    // تحديث عداد السلة
                    updateCartCount();
                } else {
                    // إذا كان الخطأ يتطلب تسجيل الدخول وعرض خيار الدخول كزائر
                    if (data.requires_login) {
                        Swal.fire({
                            icon: 'warning',
                            title: 'تسجيل الدخول مطلوب',
                            html: data.message + '<br><br>يمكنك <a href="' + data.guest_login_url + '">الدخول كزائر</a> للمتابعة',
                            showCancelButton: true,
                            confirmButtonText: 'تسجيل الدخول',
                            cancelButtonText: 'الدخول كزائر',
                            showCloseButton: true
                        }).then((result) => {
                            if (result.isConfirmed) {
                                window.location.href = data.login_url;
                            } else if (result.dismiss === Swal.DismissReason.cancel) {
                                // الدخول كزائر
                                window.location.href = data.guest_login_url;
                            }
                        });
                    } else {
                        Swal.fire({
                            icon: 'error',
                            title: 'خطأ',
                            text: data.message,
                            confirmButtonText: 'حسناً'
                        });
                    }
                }
            })
            .catch(error => {
                Swal.fire({
                    icon: 'error',
                    title: 'خطأ',
                    text: 'حدث خطأ في الاتصال بالخادم',
                    confirmButtonText: 'حسناً'
                });
            });
    });
    // دالة لتحديث عداد السلة
    function updateCartCount() {
        fetch('<?php echo SITE_URL; ?>pages/get_cart_count.php')
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    const cartCountElements = document.querySelectorAll('.cart-count');
                    cartCountElements.forEach(element => {
                        element.textContent = data.count;
                    });
                }
            });
    }
</script>
<!-- SweetAlert2 CDN -->
<!-- روابط -->
<script src="<?php echo SITE_URL; ?>assets/js/sweetalert2.min.js"></script>
<script src="<?php echo SITE_URL; ?>assets/js/coby_code_SKU.js"></script>
<!-- قبل </head>، أضف structured data -->
<script type="application/ld+json">
    {
        "@context": "https://schema.org/",
        "@type": "Product",
        "name": "<?= htmlspecialchars($product['name']) ?>",
        "sku": "<?= htmlspecialchars($product['sku']) ?>",
        "description": "<?= strip_tags($product['description']) ?>",
        "offers": {
            "@type": "Offer",
            "price": "<?= $product['discount_percentage'] > 0 ? $discounted_price : $product['price'] ?>",
            "priceCurrency": "SAR"
        }
    }
</script>
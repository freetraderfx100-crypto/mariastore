<?php
require_once __DIR__ . '/../includes/db_connect.php';
require_once __DIR__ . '/../includes/functions.php';

if (!isset($_GET['product_id'])) {
    header('HTTP/1.1 400 Bad Request');
    exit('Product ID is required');
}

$product_id = filter_var($_GET['product_id'], FILTER_SANITIZE_NUMBER_INT);
$offset = isset($_GET['offset']) ? (int)$_GET['offset'] : 4;
$filter = isset($_GET['filter']) ? $_GET['filter'] : 'rating';

try {
    // جلب بيانات المنتج الأساسية لمعرفة التصنيف
    $stmt = $conn->prepare("SELECT category_id FROM products WHERE id = ? AND is_active = 1");
    $stmt->execute([$product_id]);
    $product = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$product) {
        header('HTTP/1.1 404 Not Found');
        exit('Product not found');
    }

    // جلب parent_id للقسم الحالي
    $category_stmt = $conn->prepare("SELECT parent_id FROM categories WHERE id = ?");
    $category_stmt->execute([$product['category_id']]);
    $category = $category_stmt->fetch(PDO::FETCH_ASSOC);
    $parent_id = $category['parent_id'] ?? $product['category_id'];

    // تحديد نوع الترتيب حسب الفلتر
    $order_by = "";
    switch ($filter) {
        case 'sales':
            $order_by = "(SELECT COUNT(*) FROM order_items WHERE product_id = p.id) DESC";
            break;
        case 'newest':
            $order_by = "p.created_at DESC";
            break;
        case 'price_asc':
            $order_by = "p.price ASC";
            break;
        case 'price_desc':
            $order_by = "p.price DESC";
            break;
        default: // التقييم هو القيمة الافتراضية
            $order_by = "(SELECT AVG(rating) FROM reviews WHERE product_id = p.id) DESC";
    }

    // جلب المنتجات الإضافية من نفس القسم أو الأقسام الفرعية
    $query = "
        SELECT p.id, p.name, p.price,
            (SELECT image_urls FROM product_variants WHERE product_id = p.id LIMIT 1) AS image_urls,
            (SELECT AVG(rating) FROM reviews WHERE product_id = p.id) AS avg_rating,
            (SELECT COUNT(*) FROM order_items WHERE product_id = p.id) AS sales_count
        FROM products p
        JOIN categories c ON p.category_id = c.id
        WHERE (c.id = :current_category OR c.parent_id = :parent_id)
        AND p.id != :product_id
        AND p.is_active = 1
        AND EXISTS (
            SELECT 1 FROM product_variants pv 
            WHERE pv.product_id = p.id 
            AND pv.quantity > 0)
        ORDER BY 
            CASE 
                WHEN p.category_id = :current_category THEN 0
                ELSE 1
            END,
            $order_by
        LIMIT 4 OFFSET :offset
    ";

    $related_products_stmt = $conn->prepare($query);
    $related_products_stmt->bindValue(':current_category', $product['category_id'], PDO::PARAM_INT);
    $related_products_stmt->bindValue(':parent_id', $parent_id, PDO::PARAM_INT);
    $related_products_stmt->bindValue(':product_id', $product_id, PDO::PARAM_INT);
    $related_products_stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
    $related_products_stmt->execute();
    $more_related_products = $related_products_stmt->fetchAll(PDO::FETCH_ASSOC);

    if (empty($more_related_products)) {
        header('HTTP/1.1 204 No Content');
        exit();
    }

    // دالة لاستخراج أول صورة من JSON
    function getFirstImage($image_urls_json)
    {
        if (empty($image_urls_json)) {
            return 'default-product-image.jpg';
        }

        $images = json_decode($image_urls_json, true);
        if (is_array($images) && !empty($images)) {
            return $images[0];
        }

        return 'default-product-image.jpg';
    }

    foreach ($more_related_products as $related):
        // استخراج أول صورة من JSON
        $first_image = getFirstImage($related['image_urls']);
?>
        <div class="product-card">
            <a href="<?php echo SITE_URL; ?>pages/details_product.php?id=<?= $related['id'] ?>" class="product-image">
                <img src="<?php echo SITE_URL; ?>assets/images/<?= htmlspecialchars($first_image) ?>"
                    alt="<?= htmlspecialchars($related['name']) ?>">
            </a>
            <div class="product-details">
                <h3 class="product-name">
                    <a href="<?php echo SITE_URL; ?>pages/details_product.php?id=<?= $related['id'] ?>">
                        <?= htmlspecialchars($related['name']) ?>
                    </a>
                </h3>
                <div class="product-meta">
                    <span class="product-price"><?= number_format($related['price'], 2) ?> ر.ي</span>
                    <?php if ($filter == 'sales'): ?>
                        <span class="sales-count">(تم بيع <?= $related['sales_count'] ?>)</span>
                    <?php endif; ?>
                </div>
                <a href="<?php echo SITE_URL; ?>pages/details_product.php?id=<?= $related['id'] ?>" class="btn btn-outline">عرض التفاصيل</a>
            </div>
        </div>
<?php endforeach;
} catch (PDOException $e) {
    // تسجيل الخطأ بدلاً من عرضه للمستخدم
    error_log("Database error in load_more_related_products.php: " . $e->getMessage());
    header('HTTP/1.1 500 Internal Server Error');
    exit('حدث خطأ في تحميل المنتجات. يرجى المحاولة مرة أخرى لاحقاً.');
}

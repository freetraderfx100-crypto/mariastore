<!DOCTYPE html>
<html lang="ar" dir="rtl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>الطلبات</title>
    <style>
        :root {
            --primary-color: #4a6fdc;
            --secondary-color: #6c757d;
            --success-color: #28a745;
            --danger-color: #dc3545;
            --warning-color: #ffc107;
            --info-color: #17a2b8;
            --light-bg: #f8f9fa;
            --border-color: #dee2e6;
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background-color: #f5f7f9;
            padding: 20px;
            color: #333;
        }

        .container {
            max-width: 100%;
            margin: 0 auto;
            background: white;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            overflow: hidden;
        }

        h1 {
            text-align: center;
            margin-bottom: 20px;
            color: var(--primary-color);
            font-size: 24px;
        }

        .responsive-table {
            width: 100%;
            overflow-x: auto;
            -webkit-overflow-scrolling: touch;
        }

        .orders-table {
            width: 100%;
            border-collapse: collapse;
            min-width: 1200px;
            /* الحد الأدنى لعرض الجدول */
        }

        .orders-table th,
        .orders-table td {
            padding: 10px 8px;
            text-align: right;
            border-bottom: 1px solid var(--border-color);
            font-size: 13px;
            white-space: nowrap;
        }

        .orders-table th {
            background-color: var(--primary-color);
            color: white;
            font-weight: 600;
            position: sticky;
            top: 0;
        }

        .orders-table tr:hover td {
            background-color: rgba(74, 111, 220, 0.05);
        }

        /* تخصيص عرض الأعمدة */
        .orders-table th:nth-child(1),
        .orders-table td:nth-child(1) {
            width: 70px;
            /* رقم الطلب */
        }

        .orders-table th:nth-child(2),
        .orders-table td:nth-child(2) {
            width: 90px;
            /* نوع العميل */
        }

        .orders-table th:nth-child(3),
        .orders-table td:nth-child(3) {
            width: 180px;
            /* العميل */
        }

        .orders-table th:nth-child(4),
        .orders-table td:nth-child(4) {
            width: 150px;
            /* البريد الإلكتروني */
        }

        .orders-table th:nth-child(5),
        .orders-table td:nth-child(5),
        .orders-table th:nth-child(6),
        .orders-table td:nth-child(6),
        .orders-table th:nth-child(7),
        .orders-table td:nth-child(7),
        .orders-table th:nth-child(8),
        .orders-table td:nth-child(8),
        .orders-table th:nth-child(9),
        .orders-table td:nth-child(9) {
            width: 90px;
            /* الأعمدة الرقمية */
            text-align: center;
        }

        .orders-table th:nth-child(10),
        .orders-table td:nth-child(10) {
            width: 100px;
            /* تاريخ الطلب */
        }

        .orders-table th:nth-child(11),
        .orders-table td:nth-child(11) {
            width: 100px;
            /* طريقة الدفع */
        }

        .orders-table th:nth-child(12),
        .orders-table td:nth-child(12) {
            width: 120px;
            /* الحالة */
        }

        .orders-table th:nth-child(13),
        .orders-table td:nth-child(13) {
            width: 100px;
            /* الإجراءات */
            text-align: center;
        }

        .contact-icon {
            color: var(--secondary-color);
            text-decoration: none;
            font-size: 14px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 25px;
            height: 25px;
            border-radius: 50%;
            background: var(--light-bg);
            transition: all 0.3s;
        }

        .contact-icon:hover {
            background: var(--primary-color);
            color: white;
        }

        .status-badge {
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 500;
            display: inline-block;
            text-align: center;
        }

        .status-badge.pending {
            background-color: #fff3cd;
            color: #856404;
        }

        .status-badge.processing {
            background-color: #cce5ff;
            color: #004085;
        }

        .status-badge.in_the_way {
            background-color: #d1ecf1;
            color: #0c5460;
        }

        .status-badge.completed {
            background-color: #d4edda;
            color: #155724;
        }

        .status-badge.cancelled {
            background-color: #f8d7da;
            color: #721c24;
        }

        .order-actions {
            display: flex;
            justify-content: center;
            gap: 5px;
        }

        .btn-action {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 30px;
            height: 30px;
            border-radius: 5px;
            background: var(--light-bg);
            color: var(--secondary-color);
            text-decoration: none;
            transition: all 0.3s;
        }

        .btn-action:hover {
            background: var(--primary-color);
            color: white;
        }

        .dropdown {
            position: relative;
            display: inline-block;
        }

        .dropdown-content {
            display: none;
            position: absolute;
            left: 0;
            background-color: white;
            min-width: 160px;
            box-shadow: 0px 8px 16px 0px rgba(0, 0, 0, 0.2);
            z-index: 1;
            border-radius: 5px;
            padding: 10px;
        }

        .dropdown:hover .dropdown-content {
            display: block;
        }

        .dropdown-content select {
            width: 100%;
            padding: 5px;
            margin-bottom: 10px;
            border-radius: 4px;
            border: 1px solid var(--border-color);
        }

        .btn-delete {
            display: block;
            padding: 5px 10px;
            background: var(--danger-color);
            color: white;
            text-decoration: none;
            border-radius: 4px;
            text-align: center;
            font-size: 12px;
            margin-top: 5px;
        }

        .btn-delete:hover {
            background: #c82333;
        }

        .positive-profit {
            color: var(--success-color);
            font-weight: bold;
        }

        .negative-profit {
            color: var(--danger-color);
            font-weight: bold;
        }

        /* شريط التمرير المخصص */
        .responsive-table::-webkit-scrollbar {
            height: 8px;
        }

        .responsive-table::-webkit-scrollbar-track {
            background: #f1f1f1;
            border-radius: 10px;
        }

        .responsive-table::-webkit-scrollbar-thumb {
            background: var(--primary-color);
            border-radius: 10px;
        }

        .responsive-table::-webkit-scrollbar-thumb:hover {
            background: #3a5abb;
        }

        @media (max-width: 1400px) {

            .orders-table th,
            .orders-table td {
                font-size: 12px;
                padding: 8px 6px;
            }

            .orders-table {
                min-width: 1100px;
            }
        }

        @media (max-width: 1200px) {
            .container {
                padding: 15px;
            }

            .orders-table {
                min-width: 1000px;
            }
        }

        /* تحسينات للهواتف */
        @media (max-width: 768px) {
            body {
                padding: 10px;
            }

            .container {
                padding: 10px;
                border-radius: 8px;
            }

            h1 {
                font-size: 20px;
            }

            .responsive-table {
                border: 1px solid var(--border-color);
                border-radius: 5px;
            }
        }
    </style>
</head>

<body>
    <div class="container">
        <h1>إدارة الطلبات</h1>

        <div class="responsive-table">
            <table class="orders-table">
                <thead>
                    <tr>
                        <th>رقم الطلب</th>
                        <th>نوع العميل</th>
                        <th>العميل</th>
                        <th>البريد الإلكتروني</th>
                        <th>سعر المنتجات</th>
                        <th>سعر الشحن</th>
                        <th>المبلغ الإجمالي</th>
                        <th>تكلفة المنتجات</th>
                        <th>ربح المنتجات</th>
                        <th>تاريخ الطلب</th>
                        <th>طريقة الدفع</th>
                        <th>الحالة</th>
                        <th>الإجراءات</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- سيتم ملء هذا القسم بواسطة PHP -->
                    <tr>
                        <td>#1001</td>
                        <td>مستخدم مسجل</td>
                        <td>
                            <div style="display: flex; align-items: center; gap: 5px; justify-content: flex-end;">
                                أحمد محمد
                                <a href="tel:0512345678" class="contact-icon phone-icon" title="اتصال بالعميل">
                                    <i class="fas fa-phone"></i>
                                </a>
                                <a href="mailto:ahmed@example.com" class="contact-icon email-icon" title="إرسال بريد إلكتروني">
                                    <i class="fas fa-envelope"></i>
                                </a>
                            </div>
                        </td>
                        <td>ahmed@example.com</td>
                        <td class="order-products-amount">250.00 ر.ي</td>
                        <td class="order-shipping-cost">25.00 ر.ي</td>
                        <td class="order-total-amount">275.00 ر.ي</td>
                        <td class="order-cost">150.00 ر.ي</td>
                        <td class="order-profit positive-profit">100.00 ر.ي</td>
                        <td>2023/10/15</td>
                        <td>بطاقة ائتمان</td>
                        <td>
                            <span class="status-badge completed">
                                مكتمل
                            </span>
                        </td>
                        <td class="order-actions">
                            <a href="#" class="btn-action btn-view" title="تفاصيل الطلب">
                                <i class="fas fa-eye"></i>
                            </a>

                            <div class="dropdown">
                                <button class="btn-action btn-more" title="المزيد">
                                    <i class="fas fa-ellipsis-v"></i>
                                </button>
                                <div class="dropdown-content">
                                    <form method="post" class="status-form">
                                        <input type="hidden" name="order_id" value="1001">
                                        <select name="status">
                                            <option value="">تغيير الحالة</option>
                                            <option value="pending">قيد الانتظار</option>
                                            <option value="processing">قيد المعالجة</option>
                                            <option value="in_the_way">في الطريق</option>
                                            <option value="completed" selected>مكتمل</option>
                                            <option value="cancelled">ملغي</option>
                                        </select>
                                        <input type="hidden" name="update_status" value="1">
                                    </form>

                                    <a href="#" class="btn-delete" onclick="return confirm('هل أنت متأكد من حذف هذا الطلب؟')">
                                        <i class="fas fa-trash-alt"></i> حذف
                                    </a>
                                </div>
                            </div>
                        </td>
                    </tr>

                    <tr>
                        <td>#1002</td>
                        <td>زائر</td>
                        <td>
                            <div style="display: flex; align-items: center; gap: 5px; justify-content: flex-end;">
                                سارة عبدالله
                                <a href="tel:0512345679" class="contact-icon phone-icon" title="اتصال بالعميل">
                                    <i class="fas fa-phone"></i>
                                </a>
                                <a href="mailto:sara@example.com" class="contact-icon email-icon" title="إرسال بريد إلكتروني">
                                    <i class="fas fa-envelope"></i>
                                </a>
                            </div>
                        </td>
                        <td>sara@example.com</td>
                        <td class="order-products-amount">180.00 ر.ي</td>
                        <td class="order-shipping-cost">20.00 ر.ي</td>
                        <td class="order-total-amount">200.00 ر.ي</td>
                        <td class="order-cost">120.00 ر.ي</td>
                        <td class="order-profit positive-profit">60.00 ر.ي</td>
                        <td>2023/10/16</td>
                        <td>الدفع عند الاستلام</td>
                        <td>
                            <span class="status-badge processing">
                                قيد المعالجة
                            </span>
                        </td>
                        <td class="order-actions">
                            <a href="#" class="btn-action btn-view" title="تفاصيل الطلب">
                                <i class="fas fa-eye"></i>
                            </a>

                            <div class="dropdown">
                                <button class="btn-action btn-more" title="المزيد">
                                    <i class="fas fa-ellipsis-v"></i>
                                </button>
                                <div class="dropdown-content">
                                    <form method="post" class="status-form">
                                        <input type="hidden" name="order_id" value="1002">
                                        <select name="status">
                                            <option value="">تغيير الحالة</option>
                                            <option value="pending">قيد الانتظار</option>
                                            <option value="processing" selected>قيد المعالجة</option>
                                            <option value="in_the_way">في الطريق</option>
                                            <option value="completed">مكتمل</option>
                                            <option value="cancelled">ملغي</option>
                                        </select>
                                        <input type="hidden" name="update_status" value="1">
                                    </form>

                                    <a href="#" class="btn-delete" onclick="return confirm('هل أنت متأكد من حذف هذا الطلب؟')">
                                        <i class="fas fa-trash-alt"></i> حذف
                                    </a>
                                </div>
                            </div>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Font Awesome for icons -->
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
</body>

</html>
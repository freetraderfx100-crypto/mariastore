<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start([
        'cookie_lifetime' => 86400,
        'cookie_secure' => true,
        'cookie_httponly' => true,
        'cookie_samesite' => 'Lax'
    ]);
}

require_once __DIR__ . '/../includes/db_connect.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/smtp_config.php';
require __DIR__ . '/../vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

if (!isset($_SESSION['pending_activation_email'])) {
    header("Location: " . SITE_URL . "pages/register.php");
    exit;
}

// إنشاء كود جديد
$new_activation_code = rand(100000, 999999);
$_SESSION['activation_code'] = $new_activation_code;

// تحديث الكود في قاعدة البيانات
try {
    $stmt = $conn->prepare("UPDATE users SET activation_code = ? WHERE email = ?");
    $stmt->execute([$new_activation_code, $_SESSION['pending_activation_email']]);
    
    // إرسال البريد
    $mail = new PHPMailer(true);

    // تهيئة SMTP من includes/smtp_config.php
    configure_smtp($mail);

    $mail->addAddress($_SESSION['pending_activation_email']);
    
    $mail->isHTML(true);
    $mail->Subject = 'كود التفعيل الجديد';
    $mail->Body = "
        <div style='font-family: Arial, sans-serif; direction: rtl;'>
            <h2>كود التفعيل الجديد</h2>
            <p>كود التفعيل الجديد الخاص بك هو: <strong>$new_activation_code</strong></p>
            <p>الرجاء استخدام هذا الكود لتفعيل حسابك.</p>
        </div>
    ";
    
    $mail->send();
    
    $_SESSION['resend_success'] = true;
    header("Location: " . SITE_URL . "pages/activate.php");
    exit;
    
} catch (Exception $e) {
    $_SESSION['resend_error'] = "فشل في إرسال كود التفعيل: " . $e->getMessage();
    header("Location: " . SITE_URL . "pages/activate.php");
    exit;
}
?>
<?php
session_start();
require_once __DIR__ . '/../includes/db_connect.php';
// require_once __DIR__ . '/../includes/session_config.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'error' => 'غير مسموح بالوصول']);
    exit;
}

$user_id = $_SESSION['user_id'];

try {
    $stmt = $conn->prepare("DELETE FROM wishlist WHERE user_id = ?");
    $stmt->execute([$user_id]);

    if ($stmt->rowCount() > 0) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'error' => 'لا توجد منتجات في المفضلة']);
    }
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'error' => 'حدث خطأ في قاعدة البيانات: ' . $e->getMessage()]);
}

<?php
// بدء الجلسة بشكل آمن
if (session_status() === PHP_SESSION_NONE) {
    session_start([
        'cookie_lifetime' => 86400,
        'cookie_secure' => true,
        'cookie_httponly' => true,
        'cookie_samesite' => 'Lax'
    ]);
}

require_once __DIR__ . '/../includes/db_connect.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

// التحقق من تسجيل الدخول
checkLogin();

$user_id = $_SESSION['user_id'];
$errors = [];
$success = '';

// جلب بيانات المستخدم
try {
    $stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch();

    if (!$user) {
        session_destroy();
        header("Location: " . SITE_URL . "pages/login.php");
        exit;
    }
} catch (PDOException $e) {
    $errors[] = "حدث خطأ في جلب بيانات المستخدم";
}

// معالجة تحديث البيانات
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['update_profile'])) {
        $username = trim($_POST['username'] ?? '');
        // ✅ إصلاح: تفعيل البريد الإلكتروني وإزالة الكود المعطّل
        $email = trim($_POST['email'] ?? '');

        // التحقق من البيانات الأساسية
        if (empty($username)) {
            $errors[] = "اسم المستخدم مطلوب";
        } elseif (!preg_match('/^[\p{L}\p{N}_-]{3,20}$/u', $username)) {
            $errors[] = "اسم المستخدم غير صالح (3-20 حرفًا، حروف وأرقام فقط)";
        }

        if (empty($email)) {
            $errors[] = "البريد الإلكتروني مطلوب";
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors[] = "البريد الإلكتروني غير صالح";
        }

        if (empty($errors)) {
            try {
                // التحقق من عدم استخدام البريد من قبل مستخدم آخر
                $stmt = $conn->prepare("SELECT id FROM users WHERE email = ? AND id != ?");
                $stmt->execute([$email, $user_id]);

                if ($stmt->fetch()) {
                    $errors[] = "هذا البريد الإلكتروني مسجل مسبقاً";
                } else {
                    // ✅ إصلاح: تحديث البيانات بشكل صحيح (username + email فقط)
                    $stmt = $conn->prepare("UPDATE users SET username = ?, email = ? WHERE id = ?");
                    $stmt->execute([$username, $email, $user_id]);

                    // تحديث بيانات الجلسة
                    $_SESSION['username'] = $username;
                    $_SESSION['email'] = $email;

                    $success = "تم تحديث الملف الشخصي بنجاح";

                    // إعادة جلب بيانات المستخدم المحدّثة
                    $stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
                    $stmt->execute([$user_id]);
                    $user = $stmt->fetch();
                }
            } catch (PDOException $e) {
                error_log("Profile update error: " . $e->getMessage());
                $errors[] = "حدث خطأ في تحديث البيانات، يرجى المحاولة لاحقاً";
            }
        }
    }
}

// جلب عدد الطلبات
$orders_count = 0;
try {
    $stmt = $conn->prepare("SELECT COUNT(*) FROM orders WHERE user_id = ?");
    $stmt->execute([$user_id]);
    $orders_count = $stmt->fetchColumn();
} catch (PDOException $e) {
    // يمكن تجاهل الخطأ أو تسجيله
}

include __DIR__ . '/../includes/header.php';
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>الملف الشخصي - <?= htmlspecialchars($user['username']) ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.rtl.min.css" integrity="sha384-Xbg45MqvDIk1e563NLpGEulpX6AvL404DP+/iCgW9eFa2BqztiwTexswJo2jLMue" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>assets/css/profile.css">
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>

<body>
    <div class="profile-page">
        <div class="container py-5">
            <div class="row">
                <div class="col-lg-4">
                    <div class="profile-card shadow-sm rounded p-4 mb-4">
                        <div class="text-center mb-4">
                            <div class="profile-avatar">
                                <?php if (!empty($user['avatar'])): ?>
                                    <img src="<?php echo SITE_URL; ?>assets/images/users/avatars/<?= htmlspecialchars($user['avatar']) ?>"
                                        alt="صورة <?= htmlspecialchars($user['username']) ?>"
                                        class="img-fluid rounded-circle">
                                <?php else: ?>
                                    <div class="avatar-placeholder">
                                        <i class="fas fa-user"></i>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <h3 class="mt-3"><?= htmlspecialchars($user['username']) ?></h3>
                            <p class="text-muted"><?= htmlspecialchars($user['email']) ?></p>

                            <form action="upload_avatar.php" method="post" enctype="multipart/form-data" class="mt-3">
                                <div class="input-group mb-3">
                                    <input type="file" name="avatar" class="form-control" id="avatarUpload" accept="image/*" style="display: none;">
                                    <label for="avatarUpload" class="btn btn-outline-primary w-100">
                                        <i class="fas fa-camera me-2"></i> تغيير الصورة
                                    </label>
                                </div>
                            </form>
                        </div>

                        <div class="profile-stats">
                            <div class="stat-item">
                                <div class="stat-icon">
                                    <i class="fas fa-shopping-bag"></i>
                                </div>
                                <div class="stat-info">
                                    <h5><?= $orders_count ?></h5>
                                    <p>الطلبات</p>
                                </div>
                            </div>
                            <div class="stat-item">
                                <div class="stat-icon">
                                    <i class="fas fa-calendar-alt"></i>
                                </div>
                                <div class="stat-info">
                                    <h5><?= date('Y-m-d', strtotime($user['created_at'])) ?></h5>
                                    <p>تاريخ الانضمام</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-8">
                    <div class="profile-content shadow-sm rounded p-4">
                        <h2 class="mb-4"><i class="fas fa-user-cog me-2"></i> إعدادات الحساب</h2>

                        <?php if (!empty($errors)): ?>
                            <div class="alert alert-danger">
                                <?php foreach ($errors as $error): ?>
                                    <p class="mb-0"><i class="fas fa-exclamation-circle me-2"></i> <?= htmlspecialchars($error) ?></p>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>

                        <?php if (!empty($success)): ?>
                            <div class="alert alert-success">
                                <p class="mb-0"><i class="fas fa-check-circle me-2"></i> <?= htmlspecialchars($success) ?></p>
                            </div>
                        <?php endif; ?>

                        <form method="POST" class="profile-form">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group mb-3">
                                        <label for="username"><i class="fas fa-user me-2"></i> اسم المستخدم</label>
                                        <input type="text" id="username" name="username" class="form-control"
                                            value="<?= htmlspecialchars($user['username']) ?>" required>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group mb-3">
                                        <label for="email"><i class="fas fa-envelope me-2"></i> البريد الإلكتروني</label>
                                        <input type="email" id="email" name="email" class="form-control"
                                            value="<?= htmlspecialchars($user['email']) ?>" required>
                                    </div>
                                </div>
                            </div>

                            <!-- <h4 class="mt-5 mb-3"><i class="fas fa-lock me-2"></i> تغيير كلمة المرور</h4>
                            <div class="alert alert-info">
                                <i class="fas fa-info-circle me-2"></i> اترك الحقول فارغة إذا كنت لا تريد تغيير كلمة المرور
                            </div>

                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group mb-3">
                                        <label for="current_password">كلمة المرور الحالية</label>
                                        <input type="password" id="current_password" name="current_password" class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group mb-3">
                                        <label for="new_password">كلمة المرور الجديدة</label>
                                        <input type="password" id="new_password" name="new_password" class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group mb-3">
                                        <label for="confirm_password">تأكيد كلمة المرور</label>
                                        <input type="password" id="confirm_password" name="confirm_password" class="form-control">
                                    </div>
                                </div>
                            </div> -->

                            <div class="form-group mt-4">
                                <button type="submit" name="update_profile" class="btn btn-primary px-4">
                                    <i class="fas fa-save me-2"></i> حفظ التغييرات
                                </button>
                            </div>
                        </form>

                        <hr class="my-5">

                        <div class="account-actions">
                            <h4 class="mb-3"><i class="fas fa-cog me-2"></i> إجراءات الحساب</h4>
                            <div class="d-flex flex-wrap gap-3">
                                <a href="<?php echo SITE_URL; ?>pages/orders_user.php" class="btn btn-outline-primary">
                                    <i class="fas fa-shopping-bag me-2"></i> طلباتي
                                </a>
                                <!-- <a href="<?php echo SITE_URL; ?>pages/addresses.php" class="btn btn-outline-secondary">
                                    <i class="fas fa-map-marker-alt me-2"></i> العناوين
                                </a> -->
                                <a href="<?php echo SITE_URL; ?>includes/logout.php" class="btn btn-outline-danger">
                                    <i class="fas fa-sign-out-alt me-2"></i> تسجيل الخروج
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="<?php echo SITE_URL; ?>assets/js/bootstrap.bundle.min.js"></script>
    <script>
        // عرض معاينة الصورة قبل رفعها
        document.getElementById('avatarUpload').addEventListener('change', function(e) {
            if (this.files && this.files[0]) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    const avatar = document.querySelector('.profile-avatar img');
                    if (avatar) {
                        avatar.src = e.target.result;
                    } else {
                        const placeholder = document.querySelector('.avatar-placeholder');
                        placeholder.innerHTML = `<img src="${e.target.result}" class="img-fluid rounded-circle">`;
                    }
                }
                reader.readAsDataURL(this.files[0]);
                this.form.submit();
            }
        });
    </script>
</body>

</html>
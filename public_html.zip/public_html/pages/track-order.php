<?php
require_once __DIR__ . '/../includes/db_connect.php';
// session_start(); // ← ضروري لتفعيل الجلسة

$order = null;
$error = '';
$order_id = $_GET['order_id'] ?? null;
$user_id = $_SESSION['user_id'] ?? null;

if (!$order_id && $user_id) {
    // إذا لم يتم تحديد order_id، اجلب آخر طلب
    try {
        $stmt = $conn->prepare("SELECT id FROM orders WHERE user_id = ? ORDER BY created_at DESC LIMIT 1");
        $stmt->execute([$user_id]);
        $last_order = $stmt->fetch();
        if ($last_order) {
            $order_id = $last_order['id'];
        } else {
            $error = "لم تقم بأي طلبات حتى الآن.";
        }
    } catch (PDOException $e) {
        $error = "حدث خطأ أثناء جلب آخر طلب: " . $e->getMessage();
    }
}

if ($order_id && is_numeric($order_id) && $user_id) {
    try {
        // جلب الطلب للمستخدم الحالي فقط
        $stmt = $conn->prepare("SELECT o.*, u.username FROM orders o JOIN users u ON o.user_id = u.id WHERE o.id = ? AND o.user_id = ?");
        $stmt->execute([$order_id, $user_id]);
        $order = $stmt->fetch();

        if ($order) {
            // جلب عناصر الطلب
            $stmt = $conn->prepare("
                SELECT oi.*, p.name 
                FROM order_items oi 
                JOIN products p ON oi.product_id = p.id 
                WHERE oi.order_id = ?
            ");
            $stmt->execute([$order_id]);
            $order_items = $stmt->fetchAll();
        } else {
            $error = "لم يتم العثور على طلب بهذا الرقم أو أنك لا تملك صلاحية الوصول له.";
        }
    } catch (PDOException $e) {
        $error = "حدث خطأ: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">

<head>
    <meta charset="UTF-8">
    <title>تتبع الطلب</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.rtl.min.css" integrity="sha384-Xbg45MqvDIk1e563NLpGEulpX6AvL404DP+/iCgW9eFa2BqztiwTexswJo2jLMue" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>assets/css/style.css">
    <style>
        body {
            background: #f5f5f5;
            padding: 40px;
            font-family: 'Cairo', sans-serif;
        }

        .container {
            max-width: 800px;
            margin: auto;
            background: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 0 10px #ccc;
        }

        .status-box {
            padding: 15px;
            background-color: #e0f7fa;
            border-radius: 8px;
            margin-bottom: 20px;
        }

        .order-item {
            border-bottom: 1px solid #eee;
            padding: 10px 0;
        }

        .status-tracker {
            display: flex;
            justify-content: space-between;
            margin: 30px 0;
        }

        .status-tracker .step {
            text-align: center;
            flex: 1;
            color: #aaa;
            opacity: 0.5;
        }

        .status-tracker .step i {
            font-size: 24px;
            margin-bottom: 5px;
            display: block;
        }

        .status-tracker .step.active,
        .status-tracker .step.passed {
            color: #000;
            opacity: 1;
        }

        .status-tracker .step.active i {
            font-weight: bold;
        }

        .status-tracker .step p {
            margin: 0;
            font-size: 14px;
        }

        .status-tracker .cancelled-step {
            color: #dc3545 !important;
            opacity: 1 !important;
        }
    </style>
</head>

<body>
    <div class="container">
        <h2 class="mb-4 text-center"><i class="fas fa-search"></i> تتبع الطلب</h2>

        <form method="GET" class="mb-4">
            <ul class="nav-list">
                <li style="background-color: #ff85a2; border-radius: 25px"><a href="<?php echo SITE_URL; ?>">الرئيسية</a style="color: black;"></li>
            </ul>
            <label for="order_id" class="form-label">رقم الطلب:</label>
            <input type="number" name="order_id" id="order_id" class="form-control" required value="<?= htmlspecialchars($order_id ?? '') ?>">
            <button type="submit" class="btn btn-primary mt-3"><i class="fas fa-search me-2"></i>بحث</button>
        </form>


        <?php if ($error): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php elseif ($order): ?>
            <div class="status-box">
                <p><strong>اسم العميل:</strong> <?= htmlspecialchars($order['username']) ?></p>
                <p><strong>الحالة:</strong> <?= htmlspecialchars($order['status']) ?></p>
                <p><strong>طريقة الدفع:</strong> <?= htmlspecialchars($order['payment_method']) ?></p>
                <p><strong>العنوان:</strong> <?= htmlspecialchars($order['shipping_address']) ?></p>
                <p><strong>التاريخ:</strong> <?= htmlspecialchars($order['created_at']) ?></p>
            </div>

            <?php
            $statuses = [
                'pending'     => ['label' => 'قيد المراجعة', 'icon' => 'fas fa-list'],
                'processing'  => ['label' => 'قيد التحضير', 'icon' => 'fas fa-shopping-bag'],
                'in_the_way'  => ['label' => 'في الطريق', 'icon' => 'fas fa-truck'],
                'completed'   => ['label' => 'تم التوصيل', 'icon' => 'fas fa-check-circle'],
                'cancelled'   => ['label' => 'ملغي', 'icon' => 'fas fa-times-circle']
            ];
            $current_status = $order['status'];
            $status_found = false;
            ?>

            <div class="status-tracker">
                <?php foreach ($statuses as $key => $info): ?>
                    <?php
                    if ($current_status === 'cancelled') {
                        $class = ($key === 'cancelled') ? 'cancelled-step' : 'disabled';
                    } else {
                        if ($key === $current_status) {
                            $class = 'active';
                            $status_found = true;
                        } elseif (!$status_found) {
                            $class = 'passed';
                        } else {
                            $class = 'disabled';
                        }
                    }
                    ?>
                    <div class="step <?= $class ?>">
                        <i class="<?= $info['icon'] ?>"></i>
                        <p><?= $info['label'] ?></p>
                    </div>
                <?php endforeach; ?>
            </div>


            <h5>تفاصيل المنتجات:</h5>
            <?php foreach ($order_items as $item): ?>
                <div class="order-item">
                    <strong><?= htmlspecialchars($item['name']) ?></strong><br>
                    الكمية: <?= $item['quantity'] ?> - السعر: <?= number_format($item['price'], 2) ?> ر.ي
                </div>
            <?php endforeach; ?>

            <hr>
            <p class="fw-bold">الإجمالي الكلي: <?= number_format($order['total_amount'], 2) ?> ر.ي</p>
        <?php endif; ?>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/js/all.min.js"></script>
    <script src="<?php echo SITE_URL; ?>assets/js/bootstrap.bundle.min.js"></script>
</body>

</html>
<?php
// بداية الجلسة إذا لم تبدأ
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../includes/db_connect.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/translated_colors.php';

// دالة لتطبيع الكلمات العربية (إزالة التشكيل والاختلافات)
function normalizeArabicWord($word)
{
    // إزالة التشكيل
    $normalized = preg_replace('/[\x{064B}-\x{065F}]/u', '', $word);

    // تحويل الهمزات إلى شكل موحد
    $normalized = str_replace(
        ['أ', 'إ', 'آ', 'ء', 'ئ', 'ؤ'],
        'ا',
        $normalized
    );

    // تحويل التاء المربوطة إلى هاء
    $normalized = str_replace('ة', 'ه', $normalized);

    // تحويل الياء إلى الألف المقصورة
    $normalized = str_replace('ى', 'ي', $normalized);

    return mb_strtolower($normalized);
}

// دعم وضع الخصم من خلال URL
$discount_mode = isset($_GET['discount']) && $_GET['discount'] == 1;
$pageTitle = $discount_mode ? "نتائج البحث عن المنتجات المخفضة - ماريا" : "نتائج البحث - ماريا";

// الحصول على كلمة البحث
$searchQuery = isset($_GET['q']) ? trim($_GET['q']) : '';

if (empty($searchQuery)) {
    header("Location: " . SITE_URL);
    exit();
}

// تطبيع كلمة البحث للاستخدام في فصل الألوان
$normalizedSearchQuery = normalizeArabicWord($searchQuery);

// تحليل كلمات البحث لفصل الألوان عن باقي الكلمات
$searchTerms = preg_split('/\s+/', $searchQuery, -1, PREG_SPLIT_NO_EMPTY);

// استخراج جميع الألوان العربية والإنجليزية من خريطة الألوان
$arabicColors = array_keys($translated_colors);
$englishColors = array_values($translated_colors);
$allColors = array_merge($arabicColors, $englishColors);

// فصل الألوان عن باقي كلمات البحث
$colorTerms = [];
$otherTerms = [];

foreach ($searchTerms as $term) {
    $normalizedTerm = normalizeArabicWord($term);
    $termFound = false;

    // البحث في الألوان العربية
    foreach ($arabicColors as $color) {
        $normalizedColor = normalizeArabicWord($color);
        if ($normalizedTerm === $normalizedColor) {
            $colorTerms[] = $color;
            $termFound = true;
            break;
        }
    }

    // إذا لم يتم العثور على لون عربي، ابحث في الألوان الإنجليزية
    if (!$termFound) {
        foreach ($englishColors as $color) {
            $normalizedColor = mb_strtolower($color);
            if ($normalizedTerm === $normalizedColor) {
                // العثور على المفتاح العربي المقابل
                $arabicKey = array_search($color, $translated_colors);
                if ($arabicKey !== false) {
                    $colorTerms[] = $arabicKey;
                } else {
                    $colorTerms[] = $color;
                }
                $termFound = true;
                break;
            }
        }
    }

    if (!$termFound) {
        $otherTerms[] = $term;
    }
}

// إذا لم يتم العثور على ألوان محددة، نتعامل مع جميع الكلمات ككلمات عادية
if (empty($colorTerms)) {
    $otherTerms = $searchTerms;
}

// إنشاء استعلام البحث
try {
    $sql = "
        SELECT 
            p.*, 
            c.name AS category_name,
            p.price * (1 - p.discount_percentage/100) as discounted_price,
        GROUP_CONCAT(DISTINCT pv.image_urls ORDER BY pv.id SEPARATOR '|||') as variant_images
        FROM products p
        LEFT JOIN categories c ON p.category_id = c.id
        LEFT JOIN product_variants pv ON p.id = pv.product_id
        WHERE p.is_active = 1
    ";

    // إضافة شروط البحث للكلمات غير اللونية
    if (!empty($otherTerms)) {
        $sql .= " AND (";
        $conditions = [];
        foreach ($otherTerms as $index => $term) {
            $normalizedTerm = normalizeArabicWord($term);
            $conditions[] = "(LOWER(p.name) LIKE :term_$index OR 
                             LOWER(p.description) LIKE :term_$index OR 
                             LOWER(c.name) LIKE :term_$index OR
                             LOWER(REPLACE(REPLACE(REPLACE(REPLACE(p.name, 'أ', 'ا'), 'إ', 'ا'), 'آ', 'ا'), 'ة', 'ه')) LIKE :normalized_term_$index OR
                             LOWER(REPLACE(REPLACE(REPLACE(REPLACE(p.description, 'أ', 'ا'), 'إ', 'ا'), 'آ', 'ا'), 'ة', 'ه')) LIKE :normalized_term_$index OR
                             LOWER(REPLACE(REPLACE(REPLACE(REPLACE(c.name, 'أ', 'ا'), 'إ', 'ا'), 'آ', 'ا'), 'ة', 'ه')) LIKE :normalized_term_$index)";
        }
        $sql .= implode(" AND ", $conditions) . ")";
    }

    // إضافة شروط البحث للألوان
    if (!empty($colorTerms)) {
        $sql .= " AND (";
        $colorConditions = [];
        foreach ($colorTerms as $index => $color) {
            $paramIndex = count($otherTerms) + $index;

            // البحث باللون العربي والإنجليزي
            $arabicColor = $color;
            $englishColor = isset($translated_colors[$color]) ? $translated_colors[$color] : $color;

            $colorConditions[] = "(LOWER(pv.color) LIKE :color_arabic_$index OR 
                                 LOWER(pv.color) LIKE :color_english_$index OR
                                 LOWER(REPLACE(REPLACE(REPLACE(REPLACE(pv.color, 'أ', 'ا'), 'إ', 'ا'), 'آ', 'ا'), 'ة', 'ه')) LIKE :normalized_color_arabic_$index OR
                                 LOWER(REPLACE(REPLACE(REPLACE(REPLACE(pv.color, 'أ', 'ا'), 'إ', 'ا'), 'آ', 'ا'), 'ة', 'ه')) LIKE :normalized_color_english_$index)";
        }
        $sql .= implode(" OR ", $colorConditions) . ")";
    }

    // إضافة شرط الخصم إذا كان في وضع الخصم
    if ($discount_mode) {
        $sql .= " AND p.discount_percentage > 0";
    }

    $sql .= " GROUP BY p.id ORDER BY ";
    $sql .= $discount_mode ? "p.discount_percentage DESC" : "p.created_at DESC";

    // إعداد وتنفيذ الاستعلام
    $stmt = $conn->prepare($sql);

    // ربط معلمات البحث للكلمات غير اللونية
    foreach ($otherTerms as $index => $term) {
        $searchParam = "%" . mb_strtolower($term) . "%";
        $normalizedParam = "%" . normalizeArabicWord($term) . "%";

        $stmt->bindValue(":term_$index", $searchParam);
        $stmt->bindValue(":normalized_term_$index", $normalizedParam);
    }

    // ربط معلمات البحث للألوان
    foreach ($colorTerms as $index => $color) {
        $arabicColor = $color;
        $englishColor = isset($translated_colors[$color]) ? $translated_colors[$color] : $color;

        $arabicParam = "%" . mb_strtolower($arabicColor) . "%";
        $englishParam = "%" . mb_strtolower($englishColor) . "%";
        $normalizedArabicParam = "%" . normalizeArabicWord($arabicColor) . "%";
        $normalizedEnglishParam = "%" . normalizeArabicWord($englishColor) . "%";

        $stmt->bindValue(":color_arabic_$index", $arabicParam);
        $stmt->bindValue(":color_english_$index", $englishParam);
        $stmt->bindValue(":normalized_color_arabic_$index", $normalizedArabicParam);
        $stmt->bindValue(":normalized_color_english_$index", $normalizedEnglishParam);
    }

    // تنفيذ الاستعلام
    $stmt->execute();
    $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Search error: " . $e->getMessage());
    $products = [];
    $error = "حدث خطأ أثناء البحث. يرجى المحاولة مرة أخرى.";
}

include __DIR__ . '/../includes/header.php';
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $pageTitle ?></title>
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>assets/css/product-slider.css">
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>assets/css/discount_style.css?v=5">
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>assets/css/style.css?v=4">
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>assets/css/search.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .search-filters {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
        }

        .filter-tags {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin-top: 10px;
        }

        .filter-tag {
            background: #e9ecef;
            padding: 5px 12px;
            border-radius: 20px;
            display: flex;
            align-items: center;
            font-size: 14px;
        }

        .filter-tag .remove {
            margin-right: 5px;
            cursor: pointer;
            color: #6c757d;
        }

        .filter-tag .remove:hover {
            color: #dc3545;
        }

        .search-info {
            margin-bottom: 20px;
            padding: 15px;
            background: #f8f9fa;
            border-radius: 8px;
        }

        .color-match {
            background-color: #d4edda;
            color: #155724;
            padding: 3px 8px;
            border-radius: 4px;
            font-size: 12px;
            margin-right: 5px;
        }

        /* تصميم اسم المنتج */
        .product-name {
            font-size: 16px;
            font-weight: bold;
            color: #333;
            margin: 10px 0;
            text-align: center;
            line-height: 1.4;
            height: 2.8em;
            overflow: hidden;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
        }
    </style>
</head>

<body>
    <main class="search-page">
        <div class="container">
            <?php if ($discount_mode): ?>
                <div class="discount-banner">
                    <h1>نتائج البحث عن المنتجات المخفضة</h1>
                    <p>عروض وخصومات على منتجاتنا التي تبحث عنها</p>
                </div>
            <?php else: ?>
                <div class="page-header">
                    <h1 class="page-title">نتائج البحث عن "<?= htmlspecialchars($searchQuery) ?>"</h1>
                    <p class="results-count"><?= count($products) ?> منتج وجدناه لك</p>
                </div>
            <?php endif; ?>

            <div class="search-info">
                <p>بحث في:
                    <?php if (!empty($otherTerms)): ?>
                        <strong>الاسم والوصف والتصنيف</strong> (<?= implode(" + ", $otherTerms) ?>)
                    <?php endif; ?>

                    <?php if (!empty($otherTerms) && !empty($colorTerms)): ?>
                        <span> و </span>
                    <?php endif; ?>

                    <?php if (!empty($colorTerms)): ?>
                        <strong>الألوان</strong> (
                        <?php
                        $colorDisplay = [];
                        foreach ($colorTerms as $color) {
                            $englishColor = isset($translated_colors[$color]) ? $translated_colors[$color] : $color;
                            $colorDisplay[] = "$color (<small>$englishColor</small>)";
                        }
                        echo implode(" + ", $colorDisplay);
                        ?>
                        )
                    <?php endif; ?>
                </p>
            </div>

            <?php if (isset($error)): ?>
                <div class="alert alert-danger"><?= $error ?></div>
            <?php endif; ?>

            <?php if (empty($products)): ?>
                <div class="no-results">
                    <i class="fas fa-search"></i>
                    <h3>لم نعثر على نتائج لبحثك</h3>
                    <p>حاولي استخدام كلمات  مختلفة أو تصفحي متجرنا لاكتشاف منتجات جديدة</p>
                    <a href="<?php echo SITE_URL; ?>index.php" class="btn">تصفح جميع المنتجات</a>
                </div>
            <?php else: ?>
                <div class="products-grid">
                    <?php foreach ($products as $product): ?>
                        <?php
                        // معالجة الصور بشكل صحيح للبيانات JSON
                        $images = [];
                        $variant_images = explode('|||', $product['variant_images']);

                        foreach ($variant_images as $image_data) {
                            if (!empty($image_data)) {
                                $image_array = json_decode($image_data, true);
                                if (is_array($image_array)) {
                                    $images = array_merge($images, $image_array);
                                }
                            }
                        }

                        $images = array_unique($images);
                        $images = array_filter($images);

                        if (empty($images)) {
                            $images[] = 'default-product-image.jpg';
                        }

                        // ✅ فلترة الصور المفقودة على القرص
                        $images_dir = __DIR__ . '/../assets/images/';
                        $valid_images = [];
                        foreach ($images as $img) {
                            $clean = str_replace(['\\', '"', "'"], '', $img);
                            $clean = str_replace('assets/images/', '', $clean);
                            $clean = ltrim($clean, '/');
                            $full_path = $images_dir . $clean;
                            if (file_exists($full_path)) {
                                $valid_images[] = $img;
                            }
                        }
                        if (empty($valid_images)) {
                            $valid_images = ['__PLACEHOLDER__'];
                        }
                        $images = $valid_images;

                        // إضافة حساب السعر المخفض والمبلغ المدخر هنا
                        $discounted_price = $product['price'] * (1 - $product['discount_percentage'] / 100);
                        $saved_amount = $product['price'] - $discounted_price;
                        ?>

                        <div class="product-card">
                            <?php if (!empty($product['is_new'])): ?>
                                <span class="new-badge" title="منتج جديد">
                                    <i class="fas fa-bolt"></i> جديد
                                </span>
                            <?php endif; ?>
                            <?php if ($product['discount_percentage'] > 0):
                                $disc_pct = (int)$product['discount_percentage']; // ✅ عرض كعدد صحيح
                            ?>
                                <span class="discount-badge" title="خصم <?= $disc_pct ?>%">
                                    <i class="fas fa-tag"></i> -<?= $disc_pct ?>%
                                </span>
                            <?php endif; ?>

                            <div class="product-slider-container">
                                <div class="product-slider">
                                    <div class="product-slides">
                                        <?php foreach ($images as $index => $image): ?>
                                            <div class="product-slide <?= $index === 0 ? 'active' : '' ?>" data-index="<?= $index ?>">
                                                <a href="<?php echo SITE_URL; ?>pages/details_product.php?id=<?= $product['id'] ?>">
                                                    <?php
                                                    $placeholder_svg = 'data:image/svg+xml;base64,' . base64_encode(
                                                        '<svg xmlns="http://www.w3.org/2000/svg" width="400" height="400" viewBox="0 0 400 400">' .
                                                        '<rect width="400" height="400" fill="#f8f9fa"/>' .
                                                        '<text x="200" y="180" font-size="60" text-anchor="middle" fill="#cccccc" font-family="sans-serif">👕</text>' .
                                                        '<text x="200" y="240" font-size="18" text-anchor="middle" fill="#999999" font-family="sans-serif">صورة غير متوفرة</text>' .
                                                        '</svg>'
                                                    );
                                                    if ($image === '__PLACEHOLDER__') {
                                                        echo '<img src="' . $placeholder_svg . '" alt="' . htmlspecialchars($product['name']) . '">';
                                                    } else {
                                                        $image_path = SITE_URL . 'assets/images/' . ltrim($image, '/');
                                                        echo '<img src="' . htmlspecialchars($image_path) . '" alt="' . htmlspecialchars($product['name']) . '" loading="lazy" onerror="this.src=\'' . $placeholder_svg . '\'; this.onerror=null;">';
                                                    }
                                                    ?>
                                                </a>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                            </div>

                            <div class="product-details">
                                <!-- اسم المنتج كعنوان عادي (ليس رابط) -->
                                <h3 class="product-name"><?= htmlspecialchars($product['name']) ?></h3>

                                <p class="product-category"><?= htmlspecialchars($product['category_name']) ?></p>

                                <div class="product-price">
                                    <?php if ($product['discount_percentage'] > 0): ?>
                                        <span class="discounted-price"><?= number_format($discounted_price, 2) ?> ر.ي</span>
                                        <span class="original-price"><?= number_format($product['price'], 2) ?> ر.ي</span>
                                        <span class="save-amount">وفر <?= number_format($saved_amount, 2) ?> ر.ي</span>
                                    <?php else: ?>
                                        <span class="price"><?= number_format($product['price'], 2) ?> ر.ي</span>
                                    <?php endif; ?>
                                </div>

                                <!-- تم إزالة قسم الألوان والمقاسات -->
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </main>

    <script src="<?php echo SITE_URL; ?>assets/js/product-slider.js"></script>
    <script>
        function slideProduct(sliderElement, direction) {
            const slidesContainer = sliderElement.querySelector('.product-slides');
            const slides = slidesContainer.querySelectorAll('.product-slide');
            let activeIndex = Array.from(slides).findIndex(slide => slide.classList.contains('active'));

            slides[activeIndex].classList.remove('active');

            let newIndex = activeIndex + direction;
            if (newIndex < 0) newIndex = slides.length - 1;
            if (newIndex >= slides.length) newIndex = 0;

            slides[newIndex].classList.add('active');
        }
    </script>
</body>

</html>
<?php
require_once __DIR__ . '/../includes/db_connect.php';

define('STORE_LAT', 15.286037); // خط عرض المتجر
define('STORE_LON', 44.236734); // خط طول المتجر

header('Content-Type: application/json');

if (!isset($_GET['lat']) || !isset($_GET['lng']) || !isset($_GET['subtotal'])) {
    echo json_encode(['error' => 'المعطيات مطلوبة']);
    exit;
}

$lat = (float)$_GET['lat'];
$lng = (float)$_GET['lng'];
$subtotal = (float)$_GET['subtotal'];

function calculateDistance($lat1, $lon1, $lat2, $lon2)
{
    $earthRadius = 6371;
    $dLat = deg2rad($lat2 - $lat1);
    $dLon = deg2rad($lon2 - $lon1);
    $a = sin($dLat / 2) * sin($dLat / 2) +
        cos(deg2rad($lat1)) * cos(deg2rad($lat2)) *
        sin($dLon / 2) * sin($dLon / 2);
    $c = 2 * atan2(sqrt($a), sqrt(1 - $a));
    return $earthRadius * $c;
}

function calculateShippingCost($distance, $subtotal = 0)
{
    // جلب إعدادات الشحن
    global $conn;

    $settings = [
        'free_shipping_threshold' => null,
        'shipping_discount_percentage' => 0,
        'is_active' => true,
        'base_cost' => 1000,
        'cost_per_km' => 100,
        'min_cost' => 1000,
        'max_cost' => 5000
    ];

    try {
        $stmt = $conn->query("SELECT * FROM shipping_settings WHERE is_active = 1 ORDER BY id DESC LIMIT 1");
        $db_settings = $stmt->fetch();

        if ($db_settings) {
            $settings = array_merge($settings, $db_settings);
        }
    } catch (PDOException $e) {
        // في حالة الخطأ، نستخدم الإعدادات الافتراضية
        error_log("Error fetching shipping settings: " . $e->getMessage());
    }

    // إذا كان نظام الشحن معطل
    if (!$settings['is_active']) {
        return [
            'base_cost' => 0,
            'discount' => 0,
            'final_cost' => 0,
            'is_free' => true,
            'reason' => 'نظام الشحن معطل'
        ];
    }

    // حساب التكلفة الأساسية باستخدام الإعدادات من قاعدة البيانات
    $base_cost = $settings['base_cost'] + ($distance * $settings['cost_per_km']);

    // تقريب السعر لأقرب مئة
    $rounded_cost = round($base_cost / 100) * 100;

    // تطبيق الحد الأدنى والأقصى
    $base_cost = min(max($rounded_cost, $settings['min_cost']), $settings['max_cost']);

    // التحقق من التوصيل المجاني
    if ($settings['free_shipping_threshold'] && $subtotal >= $settings['free_shipping_threshold']) {
        return [
            'base_cost' => $base_cost,
            'discount' => $base_cost,
            'final_cost' => 0,
            'is_free' => true,
            'reason' => 'الطلب مؤهل للتوصيل المجاني'
        ];
    }

    // تطبيق خصم الشحن إذا موجود
    $discount = 0;
    if ($settings['shipping_discount_percentage'] > 0) {
        $discount = ($base_cost * $settings['shipping_discount_percentage']) / 100;
    }

    $final_cost = $base_cost - $discount;

    // التأكد من أن التكلفة النهائية لا تقل عن الحد الأدنى
    if ($final_cost < $settings['min_cost']) {
        $final_cost = $settings['min_cost'];
        $discount = $base_cost - $final_cost;
    }

    return [
        'base_cost' => $base_cost,
        'discount' => $discount,
        'final_cost' => $final_cost,
        'is_free' => false,
        'reason' => ''
    ];
}

$distance = calculateDistance(STORE_LAT, STORE_LON, $lat, $lng);
$shipping_info = calculateShippingCost($distance, $subtotal);

echo json_encode([
    'distance' => round($distance, 2),
    'base_shipping' => round($shipping_info['base_cost'], 2),
    'shipping_discount' => round($shipping_info['discount'], 2),
    'shipping' => round($shipping_info['final_cost'], 2),
    'is_free' => $shipping_info['is_free'],
    'reason' => $shipping_info['reason']
]);

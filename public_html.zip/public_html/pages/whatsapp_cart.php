<!DOCTYPE html>
<html lang="ar" dir="rtl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>طلب عبر واتساب - متجرك الإلكتروني</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #25D366;
            --secondary-color: #128C7E;
            --dark-color: #075E54;
            --light-color: #DCF8C6;
        }

        body {
            background-color: #f8f9fa;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .whatsapp-header {
            background: linear-gradient(135deg, var(--primary-color), var(--dark-color));
            color: white;
            padding: 2rem 0;
            text-align: center;
            border-radius: 0 0 20px 20px;
        }

        .order-container {
            max-width: 800px;
            margin: -50px auto 20px;
            position: relative;
        }

        .order-card {
            background: white;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            overflow: hidden;
        }

        .product-item {
            border-bottom: 1px solid #eee;
            padding: 15px;
            transition: all 0.3s;
        }

        .product-item:hover {
            background-color: #f9f9f9;
        }

        .whatsapp-btn {
            background-color: var(--primary-color);
            border: none;
            color: white;
            padding: 12px 25px;
            border-radius: 50px;
            font-weight: 600;
            transition: all 0.3s;
            display: inline-flex;
            align-items: center;
            justify-content: center;
        }

        .whatsapp-btn:hover {
            background-color: var(--dark-color);
            transform: translateY(-2px);
            color: white;
        }

        .form-control:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 0.2rem rgba(37, 211, 102, 0.25);
        }

        .quantity-btn {
            background: #f1f1f1;
            border: none;
            width: 30px;
            height: 30px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
        }

        .quantity-input {
            width: 50px;
            text-align: center;
            border: 1px solid #ddd;
            border-radius: 5px;
            margin: 0 10px;
        }

        .cart-total {
            background-color: var(--light-color);
            border-radius: 10px;
            padding: 15px;
            margin-top: 20px;
        }

        .step-number {
            width: 30px;
            height: 30px;
            background-color: var(--primary-color);
            color: white;
            border-radius: 50%;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            margin-left: 10px;
        }
    </style>
</head>

<body>
    <div class="whatsapp-header">
        <div class="container">
            <i class="fab fa-whatsapp fa-3x mb-3"></i>
            <h1>الطلب عبر واتساب</h1>
            <p class="mb-0">اختر المنتجات وارسل الطلب مباشرة إلى واتساب المتجر</p>
        </div>
    </div>

    <div class="container order-container">
        <div class="order-card">
            <div class="p-4">
                <div class="d-flex align-items-center mb-4">
                    <span class="step-number">1</span>
                    <h4 class="mb-0">المنتجات المتاحة</h4>
                </div>

                <div class="product-list">
                    <div class="product-item">
                        <div class="row align-items-center">
                            <div class="col-md-6">
                                <h5>سماعات لاسلكية</h5>
                                <p class="text-muted mb-0">جودة صوت عالية مع عزل للضوضاء</p>
                            </div>
                            <div class="col-md-2">
                                <span class="fw-bold">120 ر.س</span>
                            </div>
                            <div class="col-md-4">
                                <div class="d-flex align-items-center justify-content-end">
                                    <button class="quantity-btn" onclick="updateQuantity('product1', -1)">-</button>
                                    <input type="number" id="product1-quantity" class="quantity-input" value="0" min="0">
                                    <button class="quantity-btn" onclick="updateQuantity('product1', 1)">+</button>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="product-item">
                        <div class="row align-items-center">
                            <div class="col-md-6">
                                <h5>شاحن سريع</h5>
                                <p class="text-muted mb-0">شاحن سريع 45 وات مع كابل</p>
                            </div>
                            <div class="col-md-2">
                                <span class="fw-bold">85 ر.س</span>
                            </div>
                            <div class="col-md-4">
                                <div class="d-flex align-items-center justify-content-end">
                                    <button class="quantity-btn" onclick="updateQuantity('product2', -1)">-</button>
                                    <input type="number" id="product2-quantity" class="quantity-input" value="0" min="0">
                                    <button class="quantity-btn" onclick="updateQuantity('product2', 1)">+</button>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="product-item">
                        <div class="row align-items-center">
                            <div class="col-md-6">
                                <h5>حافظة هاتف</h5>
                                <p class="text-muted mb-0">حافظة متينة مع حماية كاملة</p>
                            </div>
                            <div class="col-md-2">
                                <span class="fw-bold">45 ر.س</span>
                            </div>
                            <div class="col-md-4">
                                <div class="d-flex align-items-center justify-content-end">
                                    <button class="quantity-btn" onclick="updateQuantity('product3', -1)">-</button>
                                    <input type="number" id="product3-quantity" class="quantity-input" value="0" min="0">
                                    <button class="quantity-btn" onclick="updateQuantity('product3', 1)">+</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="cart-total">
                    <div class="row">
                        <div class="col-md-6">
                            <h5>ملخص الطلب</h5>
                            <div id="order-summary">
                                <p class="text-muted">لم يتم إضافة منتجات بعد</p>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="d-flex justify-content-between mb-2">
                                <span>المجموع:</span>
                                <span id="total-amount">0 ر.س</span>
                            </div>
                            <div class="d-flex justify-content-between mb-2">
                                <span>الضريبة (15%):</span>
                                <span id="tax-amount">0 ر.س</span>
                            </div>
                            <div class="d-flex justify-content-between fw-bold">
                                <span>الإجمالي:</span>
                                <span id="final-amount">0 ر.س</span>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="d-flex align-items-center mt-4 mb-3">
                    <span class="step-number">2</span>
                    <h4 class="mb-0">معلومات العميل</h4>
                </div>

                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="name" class="form-label">الاسم بالكامل</label>
                        <input type="text" class="form-control" id="name" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="phone" class="form-label">رقم الهاتف</label>
                        <input type="tel" class="form-control" id="phone" required>
                    </div>
                    <div class="col-12 mb-3">
                        <label for="address" class="form-label">عنوان التوصيل</label>
                        <textarea class="form-control" id="address" rows="2"></textarea>
                    </div>
                    <div class="col-12 mb-3">
                        <label for="notes" class="form-label">ملاحظات إضافية</label>
                        <textarea class="form-control" id="notes" rows="2" placeholder="ملاحظات حول الطلب أو وقت التوصيل"></textarea>
                    </div>
                </div>

                <div class="text-center mt-4">
                    <button class="whatsapp-btn" onclick="sendOrderViaWhatsApp()">
                        <i class="fab fa-whatsapp me-2"></i> إرسال الطلب عبر واتساب
                    </button>
                </div>
            </div>
        </div>
    </div>

    <script>
        // بيانات المنتجات
        const products = {
            'product1': {
                name: 'سماعات لاسلكية',
                price: 120
            },
            'product2': {
                name: 'شاحن سريع',
                price: 85
            },
            'product3': {
                name: 'حافظة هاتف',
                price: 45
            }
        };

        // تحديث الكمية
        function updateQuantity(productId, change) {
            const input = document.getElementById(`${productId}-quantity`);
            let newValue = parseInt(input.value) + change;
            if (newValue < 0) newValue = 0;
            input.value = newValue;
            updateOrderSummary();
        }

        // تحديث ملخص الطلب
        function updateOrderSummary() {
            let total = 0;
            let summaryHTML = '';

            for (const [id, product] of Object.entries(products)) {
                const quantity = parseInt(document.getElementById(`${id}-quantity`).value);
                if (quantity > 0) {
                    const productTotal = product.price * quantity;
                    total += productTotal;
                    summaryHTML += `<div class="d-flex justify-content-between">
                        <span>${product.name} (${quantity})</span>
                        <span>${productTotal} ر.س</span>
                    </div>`;
                }
            }

            if (summaryHTML === '') {
                document.getElementById('order-summary').innerHTML = '<p class="text-muted">لم يتم إضافة منتجات بعد</p>';
            } else {
                document.getElementById('order-summary').innerHTML = summaryHTML;
            }

            const tax = total * 0.15;
            const final = total + tax;

            document.getElementById('total-amount').textContent = `${total} ر.س`;
            document.getElementById('tax-amount').textContent = `${tax.toFixed(2)} ر.س`;
            document.getElementById('final-amount').textContent = `${final.toFixed(2)} ر.س`;
        }

        // إرسال الطلب عبر واتساب
        function sendOrderViaWhatsApp() {
            const name = document.getElementById('name').value;
            const phone = document.getElementById('phone').value;
            const address = document.getElementById('address').value;
            const notes = document.getElementById('notes').value;

            if (!name || !phone) {
                alert('يرجى إدخال الاسم ورقم الهاتف');
                return;
            }

            let orderDetails = `🎯 *طلب جديد من المتجر* 🎯%0A%0A`;
            orderDetails += `*العميل:* ${name}%0A`;
            orderDetails += `*الهاتف:* ${phone}%0A`;

            if (address) {
                orderDetails += `*العنوان:* ${address}%0A`;
            }

            orderDetails += `%0A*المنتجات:*%0A%0A`;

            let total = 0;
            for (const [id, product] of Object.entries(products)) {
                const quantity = parseInt(document.getElementById(`${id}-quantity`).value);
                if (quantity > 0) {
                    const productTotal = product.price * quantity;
                    total += productTotal;
                    orderDetails += `- ${product.name} × ${quantity} = ${productTotal} ر.س%0A`;
                }
            }

            const tax = total * 0.15;
            const final = total + tax;

            orderDetails += `%0A*المجموع:* ${total} ر.س%0A`;
            orderDetails += `*الضريبة (15%):* ${tax.toFixed(2)} ر.س%0A`;
            orderDetails += `*الإجمالي النهائي:* ${final.toFixed(2)} ر.س%0A%0A`;

            if (notes) {
                orderDetails += `*ملاحظات العميل:*%0A${notes}%0A%0A`;
            }

            orderDetails += `🛒 *تم إنشاء الطلب عبر الموقع الإلكتروني*`;

            // رقم واتساب المتجر - ضع رقمك هنا
            const whatsappNumber = '966123456789'; // استبدل برقمك مع إزالة الصفر الأول

            // إنشاء رابط واتساب
            const whatsappURL = `https://wa.me/${whatsappNumber}?text=${orderDetails}`;

            // فتح واتساب
            window.open(whatsappURL, '_blank');
        }

        // تحديث أولي لملخص الطلب
        document.querySelectorAll('.quantity-input').forEach(input => {
            input.addEventListener('change', updateOrderSummary);
        });
    </script>
</body>

</html>
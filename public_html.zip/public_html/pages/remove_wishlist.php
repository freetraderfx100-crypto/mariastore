<?php
// require_once __DIR__ . '/../includes/session_config.php';
require_once __DIR__ . '/../includes/db_connect.php';

header('Content-Type: application/json');

// التحقق من الجلسة
if (!isset($_SESSION['user_id']) || !isset($_SESSION['email'])) {
    echo json_encode(['success' => false, 'error' => 'يجب تسجيل الدخول أولاً']);
    exit;
}

$user_id = $_SESSION['user_id'];

if (!isset($_POST['product_id'])) {
    echo json_encode(['success' => false, 'error' => 'رقم المنتج غير موجود']);
    exit;
}

$product_id = intval($_POST['product_id']);

try {
    $stmt = $conn->prepare("DELETE FROM wishlist WHERE user_id = ? AND product_id = ?");
    $stmt->execute([$user_id, $product_id]);

    echo json_encode(['success' => true]);
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'error' => 'حدث خطأ أثناء الحذف']);
}

<?php
require_once __DIR__ . '/../includes/db_connect.php';
require_once __DIR__ . '/../includes/functions.php';

$category_id = isset($_GET['category_id']) ? (int)$_GET['category_id'] : null;
$discount_mode = isset($_GET['discount']) && $_GET['discount'] == 1;
$category_name = '';
$error_message = '';
$products = [];

$products_per_page = 15;
$page = isset($_GET['page']) && is_numeric($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $products_per_page;
$total_products = 0;
$total_pages = 1;

// ✅ دالة مساعدة لإنشاء كرت منتج (لتجنب تكرار الكود)
function renderProductCard($product, $site_url, $images_dir, $placeholder_svg_base64) {
    $images = [];
    if (!empty($product['variant_images'])) {
        $variant_images = explode('|||', $product['variant_images']);
        foreach ($variant_images as $image_data) {
            if (!empty($image_data)) {
                $image_array = json_decode($image_data, true);
                if (is_array($image_array)) {
                    $images = array_merge($images, $image_array);
                } else {
                    $images[] = $image_data;
                }
            }
        }
    }
    $images = array_unique($images);
    $images = array_filter($images);
    if (empty($images)) {
        $images[] = 'default-product-image.jpg';
    }

    // فلترة الصور المفقودة
    $valid_images = [];
    foreach ($images as $img) {
        $clean = str_replace(['\\', '"', "'"], '', $img);
        $clean = str_replace('assets/images/', '', $clean);
        $clean = ltrim($clean, '/');
        $full_path = $images_dir . $clean;
        if (file_exists($full_path)) {
            $valid_images[] = $img;
        }
    }
    if (empty($valid_images)) {
        $valid_images = ['__PLACEHOLDER__'];
    }
    $images = $valid_images;

    $discounted_price = $product['price'] * (1 - $product['discount_percentage'] / 100);
    $saved_amount = $product['price'] - $discounted_price;

    $html = '<div class="product-card">';
    // ✅ شارة "جديد"
    if (!empty($product['is_new'])) {
        $html .= '<span class="new-badge" title="منتج جديد">';
        $html .= '<i class="fas fa-bolt"></i> جديد';
        $html .= '</span>';
    }
    if ($product['discount_percentage'] > 0) {
        $html .= '<span class="discount-badge" title="خصم ' . htmlspecialchars($product['discount_percentage']) . '%">';
        $html .= '<i class="fas fa-tag"></i> -' . htmlspecialchars($product['discount_percentage']) . '%';
        $html .= '</span>';
    }
    $html .= '<div class="product-slider-container"><div class="product-slider"><div class="product-slides">';
    foreach ($images as $index => $image) {
        $activeClass = $index === 0 ? 'active' : '';
        $html .= '<div class="product-slide ' . $activeClass . '" data-index="' . $index . '">';
        $html .= '<a href="' . $site_url . 'pages/details_product.php?id=' . $product['id'] . '" aria-label="عرض تفاصيل ' . htmlspecialchars($product['name']) . '">';
        if ($image === '__PLACEHOLDER__') {
            $html .= '<img src="' . $placeholder_svg_base64 . '" alt="' . htmlspecialchars($product['name']) . '" width="300" height="300">';
        } else {
            $image_path = $site_url . 'assets/images/' . ltrim($image, '/');
            $html .= '<img src="' . htmlspecialchars($image_path) . '" alt="' . htmlspecialchars($product['name']) . ' - صورة ' . ($index + 1) . '" loading="lazy" width="300" height="300" onerror="this.src=\'' . $placeholder_svg_base64 . '\'; this.onerror=null;">';
        }
        $html .= '</a></div>';
    }
    $html .= '</div></div></div>';
    $html .= '<div class="product-details">';
    $html .= '<div class="product-name-container">';
    $html .= '<h3 class="product-name" title="' . htmlspecialchars($product['name']) . '">';
    $html .= '<a href="' . $site_url . 'pages/details_product.php?id=' . $product['id'] . '" class="product-link">' . htmlspecialchars($product['name']) . '</a>';
    $html .= '</h3></div>';
    $html .= '<div class="product-price">';
    if ($product['discount_percentage'] > 0) {
        $html .= '<div class="price-row">';
        $html .= '<span class="original-price">' . number_format($product['price'], 2) . ' ر.ي</span>';
        $html .= '<span class="discounted-price">' . number_format($discounted_price, 2) . ' ر.ي</span>';
        $html .= '</div>';
        $html .= '<span class="save-amount">وفر ' . number_format($saved_amount, 2) . ' ر.ي</span>';
    } else {
        $html .= '<span class="price">' . number_format($product['price'], 2) . ' ر.ي</span>';
    }
    $html .= '</div></div></div>';
    return $html;
}

// ✅ معالجة طلب AJAX لتحميل المزيد من المنتجات (Infinite Scroll)
if (isset($_GET['ajax']) && $_GET['ajax'] == 'load_more') {
    header('Content-Type: text/html; charset=utf-8');

    $ajax_page = isset($_GET['page']) && is_numeric($_GET['page']) ? (int)$_GET['page'] : 2;
    $ajax_offset = ($ajax_page - 1) * $products_per_page;

    // ✅ توليد seed للترتيب العشوائي (ثابت طوال الجلسة)
    if (!isset($_SESSION['random_seed'])) {
        $_SESSION['random_seed'] = rand(1, 999999);
    }
    $random_seed = (int)$_SESSION['random_seed'];

    try {
        $query = "
            SELECT 
                p.*,
                c.name as category_name,
                p.price * (1 - p.discount_percentage/100) as discounted_price,
                GROUP_CONCAT(DISTINCT pv.image_urls ORDER BY pv.id SEPARATOR '|||') as variant_images
            FROM products p
            LEFT JOIN categories c ON p.category_id = c.id
            LEFT JOIN product_variants pv ON p.id = pv.product_id
            WHERE p.is_active = 1
        ";
        $params = [];
        if ($category_id) {
            $query .= " AND p.category_id = :category_id";
            $params[':category_id'] = $category_id;
        }
        if ($discount_mode) {
            $query .= " AND p.discount_percentage > 0";
        }
        $query .= " GROUP BY p.id ORDER BY ";
        // ✅ ترتيب: المنتجات الجديدة أولاً، ثم عشوائي
        if ($discount_mode) {
            $query .= "p.is_new DESC, p.discount_percentage DESC, RAND($random_seed)";
        } else {
            $query .= "p.is_new DESC, RAND($random_seed)";
        }
        $query .= " LIMIT :limit OFFSET :offset";

        $stmt = $conn->prepare($query);
        foreach ($params as $key => $val) {
            $stmt->bindValue($key, $val, PDO::PARAM_INT);
        }
        $stmt->bindValue(':limit', $products_per_page, PDO::PARAM_INT);
        $stmt->bindValue(':offset', $ajax_offset, PDO::PARAM_INT);
        $stmt->execute();
        $ajax_products = $stmt->fetchAll(PDO::FETCH_ASSOC);

        if (empty($ajax_products)) {
            echo '<div class="no-more-products" data-end="true">لا يوجد المزيد من المنتجات</div>';
            exit;
        }

        $images_dir = __DIR__ . '/../assets/images/';
        $placeholder_svg_base64 = 'data:image/svg+xml;base64,' . base64_encode(
            '<svg xmlns="http://www.w3.org/2000/svg" width="400" height="400" viewBox="0 0 400 400">' .
            '<rect width="400" height="400" fill="#f8f9fa"/>' .
            '<text x="200" y="180" font-size="60" text-anchor="middle" fill="#cccccc" font-family="sans-serif">👕</text>' .
            '<text x="200" y="240" font-size="18" text-anchor="middle" fill="#999999" font-family="sans-serif">صورة غير متوفرة</text>' .
            '</svg>'
        );

        foreach ($ajax_products as $product) {
            echo renderProductCard($product, SITE_URL, $images_dir, $placeholder_svg_base64);
        }
    } catch (PDOException $e) {
        echo '<div class="no-more-products" data-error="true">خطأ في تحميل المنتجات</div>';
    }
    exit;
}

try {
    // حساب العدد الكلي للمنتجات
    $count_query = "SELECT COUNT(*) as total FROM products p WHERE p.is_active = 1";
    if ($category_id) {
        $count_query .= " AND p.category_id = :category_id";
    }
    if ($discount_mode) {
        $count_query .= " AND p.discount_percentage > 0";
    }

    $count_stmt = $conn->prepare($count_query);
    if ($category_id) {
        $count_stmt->bindValue(':category_id', $category_id, PDO::PARAM_INT);
    }
    $count_stmt->execute();
    $total_products = $count_stmt->fetchColumn();

    // حساب عدد الصفحات
    $total_pages = ceil($total_products / $products_per_page);

    // استعلام المنتجات
    // يجب تغيير image_url إلى image_urls
    // استعلام المنتجات مع اسم التصنيف
    $query = "
    SELECT 
    p.*,
    c.name as category_name,
    p.price * (1 - p.discount_percentage/100) as discounted_price,
    GROUP_CONCAT(DISTINCT pv.image_urls ORDER BY pv.id SEPARATOR '|||') as variant_images
    FROM products p
    LEFT JOIN categories c ON p.category_id = c.id
    LEFT JOIN product_variants pv ON p.id = pv.product_id
    WHERE p.is_active = 1
    ";

    $params = [];

    if ($category_id) {
        $query .= " AND p.category_id = :category_id";
        $params[':category_id'] = $category_id;
    }

    if ($discount_mode) {
        $query .= " AND p.discount_percentage > 0";
    }

    // ✅ توليد seed جديد عند فتح/تحديث الصفحة (للترتيب العشوائي الجديد)
    if (!isset($_SESSION['random_seed']) || (isset($_GET['page']) && $_GET['page'] == 1)) {
        $_SESSION['random_seed'] = rand(1, 999999);
    }
    $random_seed = (int)$_SESSION['random_seed'];

    $query .= " GROUP BY p.id ORDER BY ";
    // ✅ ترتيب: المنتجات الجديدة أولاً، ثم عشوائي
    if ($discount_mode) {
        $query .= "p.is_new DESC, p.discount_percentage DESC, RAND($random_seed)";
    } else {
        $query .= "p.is_new DESC, RAND($random_seed)";
    }
    $query .= " LIMIT :limit OFFSET :offset";

    $stmt = $conn->prepare($query);
    foreach ($params as $key => $val) {
        $stmt->bindValue($key, $val, PDO::PARAM_INT);
    }
    $stmt->bindValue(':limit', $products_per_page, PDO::PARAM_INT);
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
    $stmt->execute();
    $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("خطأ في جلب المنتجات: " . $e->getMessage());
    $error_message = "حدث خطأ في تحميل المنتجات. يرجى المحاولة مرة أخرى.";
    $products = [];
}

$pageTitle = $discount_mode ? "المنتجات المخفضة | " . SITE_NAME : ($category_id ? htmlspecialchars($category_name) . " | " . SITE_NAME : "المنتجات | " . SITE_NAME);
include __DIR__ . '/../includes/header.php';
?>

<head>
    <!-- <link rel="stylesheet" href="../assets/css/responsive.css"> -->
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>assets/css/discount_style.css?v=5">
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>assets/css/style.css">
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>assets/css/index.css">
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>assets/css/product-slider.css">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .product-slide {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            opacity: 0;
            transition: opacity 0.5s ease;
        }

        .product-slide.active {
            opacity: 1;
            position: relative;
        }

        .product-slides {
            position: relative;
            height: 100%;
        }

        /* تحسينات الصور والأداء */
        .product-slider-container {
            position: relative;
            overflow: hidden;
            aspect-ratio: 1/1;
            /* نسبة ثابتة للصور */
        }

        .product-slides {
            position: relative;
            height: 100%;
            width: 100%;
        }

        .product-slide {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            opacity: 0;
            transition: opacity 0.3s ease-in-out;
            will-change: opacity;
        }

        .product-slide.active {
            opacity: 1;
            z-index: 2;
        }

        .product-slide img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            /* تغطية المساحة دون تشويه */
            object-position: center;
            transition: transform 0.3s ease;
        }

        .product-slide:hover img {
            transform: scale(1.05);
        }

        /* مؤشر التحميل */
        .loading-spinner {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 40px;
            height: 40px;
            border: 3px solid #f3f3f3;
            border-top: 3px solid #3498db;
            border-radius: 50%;
            animation: spin 1s linear infinite;
            z-index: 1;
        }

        @keyframes spin {
            0% {
                transform: translate(-50%, -50%) rotate(0deg);
            }

            100% {
                transform: translate(-50%, -50%) rotate(360deg);
            }
        }

        /* تحسينات لعرض اسم المنتج - إصلاح مشكلة الهاتف */
        .product-name {
            font-size: 16px;
            font-weight: bold;
            color: #333;
            margin: 8px 0;
            line-height: 1.4;
            /* إزالة الارتفاع الثابت والحدود */
            overflow: visible;
            display: block;
            -webkit-line-clamp: unset;
            -webkit-box-orient: unset;
            text-overflow: unset;
            white-space: normal;
            height: auto;
            min-height: 2.8em;
            /* ارتفاع أدنى بدلاً من ثابت */
        }

        .product-name a {
            color: inherit;
            text-decoration: none;
            transition: color 0.3s ease;
            display: block;
            width: 100%;
        }

        .product-name a:hover {
            color: #007bff;
            text-decoration: underline;
        }

        /* تحسينات للجوال */
        @media (max-width: 768px) {
            .product-name {
                font-size: 14px;
                min-height: 2.4em;
                /* ارتفاع أدنى أقل للجوال */
                margin: 5px 0;
                /* السماح للاسم بالتمدد حسب المحتوى */
                height: auto;
                max-height: none;
            }

            .product-details {
                padding: 8px 3px;
                min-height: auto;
                /* إزالة الحد الأدنى للارتفاع */
            }

            .product-card {
                height: auto;
                /* ارتفاع تلقائي للبطاقة */
                min-height: 320px;
                /* ارتفاع أدنى فقط */
            }
        }

        /* تحسينات للشاشات الكبيرة */
        @media (min-width: 1200px) {
            .product-name {
                font-size: 17px;
            }
        }

        /* تحسينات إضافية للهواتف الصغيرة */
        @media (max-width: 480px) {
            .products-grid {
                grid-template-columns: repeat(2, 1fr);
                gap: 10px;
            }

            .product-card {
                min-height: 300px;
                padding: 5px;
            }

            .product-name {
                font-size: 13px;
                line-height: 1.3;
                margin: 3px 0;
            }

            .product-price {
                font-size: 12px;
            }

            .discounted-price,
            .price {
                font-size: 13px;
            }

            .original-price {
                font-size: 11px;
            }

            .save-amount {
                font-size: 10px;
            }
        }

        /* تحسينات للهواتف المتوسطة */
        @media (max-width: 360px) {
            .products-grid {
                grid-template-columns: 1fr;
                gap: 8px;
            }

            .product-card {
                min-height: 280px;
                margin: 0 5px;
            }

            .product-name {
                font-size: 12px;
            }
        }

        /* منع كسر الكلمات الطويلة */
        .product-name {
            word-wrap: break-word;
            word-break: break-word;
            hyphens: auto;
        }

        /* تحسينات للبطاقة ككل */
        .product-card {
            display: flex;
            flex-direction: column;
            height: auto;
            /* ارتفاع تلقائي */
            min-height: 380px;
            /* ارتفاع أدنى مناسب */
        }

        .product-slider-container {
            flex: 0 0 auto;
            /* لا يتمدد */
        }

        .product-details {
            flex: 1;
            /* يتمدد لملء المساحة المتبقية */
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            min-height: 120px;
            /* ارتفاع أدنى للتفاصيل */
        }

        .product-name-container {
            flex: 1;
            /* يتمدد لملء المساحة */
        }

        .product-price {
            flex: 0 0 auto;
            /* لا يتمدد */
            margin-top: auto;
            /* يدفع نفسه للأسفل */
        }

        /* تحسينات لعرض اسم المنتج */
        .product-details {
            text-align: center;
            padding: 10px 5px;
        }
    </style>

</head>

<section class="products-page">
    <div class="container">
        <?php if ($discount_mode): ?>
            <div class="discount-banner">
                <h1>خصومات مميزة</h1>
                <p>استفد من أفضل العروض والخصومات على منتجاتنا</p>
            </div>
        <?php else: ?>
            <h1 class="section-title">
                <?= $category_id ? htmlspecialchars($category_name) : 'كل المنتجات'; ?>
            </h1>
        <?php endif; ?>

        <div class="products-grid">
            <?php if (!empty($products)): ?>
                <?php foreach ($products as $product): ?>
                    <?php
                    // معالجة الصور بشكل صحيح للبيانات JSON
                    $images = [];
                    $variant_images = explode('|||', $product['variant_images']);

                    foreach ($variant_images as $image_data) {
                        if (!empty($image_data)) {
                            $image_array = json_decode($image_data, true);
                            if (is_array($image_array)) {
                                $images = array_merge($images, $image_array);
                            } else {
                                // إذا كانت البيانات ليست JSON، تعامل معها كسلسلة عادية
                                $images[] = $image_data;
                            }
                        }
                    }

                    $images = array_unique($images);
                    $images = array_filter($images);

                    if (empty($images)) {
                        $images[] = 'default-product-image.jpg';
                    }

                    // ✅ فلترة الصور المفقودة على القرص - يحل مشكلة دوران السلايدر بين صور موجودة ومفقودة
                    $images_dir = __DIR__ . '/../assets/images/';
                    $valid_images = [];
                    foreach ($images as $img) {
                        $clean = str_replace(['\\', '"', "'"], '', $img);
                        $clean = str_replace('assets/images/', '', $clean);
                        $clean = ltrim($clean, '/');
                        $full_path = $images_dir . $clean;
                        if (file_exists($full_path)) {
                            $valid_images[] = $img;
                        }
                    }
                    if (empty($valid_images)) {
                        $valid_images = ['__PLACEHOLDER__'];
                    }
                    $images = $valid_images;

                    // حساب السعر بعد الخصم والمبلغ المدخر
                    $discounted_price = $product['price'] * (1 - $product['discount_percentage'] / 100);
                    $saved_amount = $product['price'] - $discounted_price;
                    ?>

                    <!-- تعديل هيكل المنتج -->
                    <div class="product-card">
                        <?php if (!empty($product['is_new'])): ?>
                            <span class="new-badge" title="منتج جديد">
                                <i class="fas fa-bolt"></i> جديد
                            </span>
                        <?php endif; ?>
                        <?php if ($product['discount_percentage'] > 0): ?>
                            <span class="discount-badge" title="خصم <?= $product['discount_percentage'] ?>%">
                                <i class="fas fa-tag"></i> -<?= $product['discount_percentage'] ?>%
                            </span>
                        <?php endif; ?>

                        <div class="product-slider-container">
                            <div class="product-slider">
                                <div class="product-slides">
                                    <?php foreach ($images as $index => $image): ?>
                                        <div class="product-slide <?= $index === 0 ? 'active' : '' ?>" data-index="<?= $index ?>">
                                            <a href="<?php echo SITE_URL; ?>pages/details_product.php?id=<?= $product['id'] ?>"
                                                aria-label="عرض تفاصيل <?= htmlspecialchars($product['name']) ?>">
                                                <?php
                                                // placeholder SVG مضمون
                                                $placeholder_svg = 'data:image/svg+xml;base64,' . base64_encode(
                                                    '<svg xmlns="http://www.w3.org/2000/svg" width="400" height="400" viewBox="0 0 400 400">' .
                                                    '<rect width="400" height="400" fill="#f8f9fa"/>' .
                                                    '<text x="200" y="180" font-size="60" text-anchor="middle" fill="#cccccc" font-family="sans-serif">👕</text>' .
                                                    '<text x="200" y="240" font-size="18" text-anchor="middle" fill="#999999" font-family="sans-serif">صورة غير متوفرة</text>' .
                                                    '</svg>'
                                                );
                                                if ($image === '__PLACEHOLDER__') {
                                                    // صورة placeholder - استخدم SVG مباشرة
                                                    echo '<img src="' . $placeholder_svg . '" alt="' . htmlspecialchars($product['name']) . '" width="300" height="300">';
                                                } else {
                                                    $image_path = SITE_URL . 'assets/images/' . ltrim($image, '/');
                                                    echo '<img src="' . htmlspecialchars($image_path) . '"
                                                        alt="' . htmlspecialchars($product['name']) . ' - صورة ' . ($index + 1) . '"
                                                        loading="lazy"
                                                        width="300"
                                                        height="300"
                                                        onerror="this.src=\'' . $placeholder_svg . '\'; this.onerror=null;">';
                                                }
                                                ?>
                                            </a>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        </div>

                        <div class="product-details">
                            <!-- اسم المنتج مع تحسينات المرونة -->
                            <div class="product-name-container">
                                <h3 class="product-name" title="<?= htmlspecialchars($product['name']) ?>">
                                    <a href="<?php echo SITE_URL; ?>pages/details_product.php?id=<?= $product['id'] ?>"
                                        class="product-link">
                                        <?= htmlspecialchars($product['name']) ?>
                                    </a>
                                </h3>
                            </div>

                            <!-- السعر في الجزء السفلي -->
                            <div class="product-price">
                                <?php if ($product['discount_percentage'] > 0): ?>
                                    <div class="price-row">
                                        <span class="original-price"><?= number_format($product['price'], 2) ?> ر.ي</span>
                                        <span class="discounted-price"><?= number_format($discounted_price, 2) ?> ر.ي</span>
                                    </div>
                                    <span class="save-amount">وفر <?= number_format($saved_amount, 2) ?> ر.ي</span>
                                <?php else: ?>
                                    <span class="price"><?= number_format($product['price'], 2) ?> ر.ي</span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="no-products-message">
                    <i class="fas fa-box-open"></i>
                    <p><?= $discount_mode ? 'لا توجد منتجات مخفضة حالياً' : $error_message ?></p>
                    <a href="<?php echo SITE_URL; ?>index.php" class="btn">تصفح جميع المنتجات</a>
                </div>
            <?php endif; ?>

            <?php if ($total_pages > 1): ?>
                <!-- ✅ مؤشر تحميل المزيد (داخل products-grid) -->
                <div class="loading-indicator" id="loadingIndicator" style="text-align: center; padding: 30px; clear: both; grid-column: 1 / -1;">
                    <div class="loading-spinner" style="display: inline-block; width: 40px; height: 40px; border: 4px solid #f3f3f3; border-top: 4px solid #ff6b8b; border-radius: 50%; animation: spin 1s linear infinite;"></div>
                    <p style="margin-top: 15px; color: #666; font-size: 14px;">جاري تحميل المزيد من المنتجات...</p>
                </div>
            <?php endif; ?>
        </div>

        <?php if ($total_pages > 1): ?>
            <!-- ✅ الترقيم يبقى للتوافق لكن يُخفى بصرياً -->
            <div class="pagination" style="display: none;" id="paginationFallback">
                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                    <a href="?<?=
                                ($category_id ? "category_id=$category_id&" : "") .
                                    ($discount_mode ? "discount=1&" : "") ?>page=<?= $i ?>"
                        class="<?= $i == $page ? 'active' : '' ?>">
                        <?= $i ?>
                    </a>
                <?php endfor; ?>
            </div>
        <?php endif; ?>
    </div>
</section>

<style>
    @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
    }

    .loading-indicator.hidden {
        display: none !important;
    }

    .no-more-products {
        text-align: center;
        padding: 30px;
        color: #7f8c8d;
        font-size: 14px;
        clear: both;
        width: 100%;
    }

    .no-more-products::before {
        content: "✓ ";
        color: #27ae60;
        font-size: 18px;
    }
</style>

<script>
    // ✅ التمرير اللانهائي - تحميل المزيد عند الوصول لأسفل الصفحة
    (function() {
        // ✅ انتظر حتى تحميل الصفحة كاملة (window.load) - أضمن من DOMContentLoaded
        window.addEventListener('load', function() {
            console.log('🔄 Infinite scroll: window loaded, initializing...');
            console.log('  - currentPage: <?= $page ?>');
            console.log('  - totalPages: <?= $total_pages ?>');
            console.log('  - hasMore: <?= $page < $total_pages ? 'true' : 'false' ?>');

            let currentPage = <?= $page ?>;
            const totalPages = <?= $total_pages ?>;
            let isLoading = false;
            let hasMore = currentPage < totalPages;

            const loadingIndicator = document.getElementById('loadingIndicator');
            console.log('  - loadingIndicator element:', loadingIndicator);

            if (!loadingIndicator) {
                console.error('❌ loadingIndicator not found in DOM!');
                return;
            }

            if (!hasMore) {
                console.log('ℹ️ Already on last page, no more to load');
                loadingIndicator.innerHTML = '<div class="no-more-products">✓ تم تحميل جميع المنتجات</div>';
                return;
            }

            function loadMoreProducts() {
                if (isLoading || !hasMore) return;
                isLoading = true;
                currentPage++;
                console.log('📦 Loading page', currentPage);

                // ✅ إظهار spinner أثناء التحميل
                loadingIndicator.innerHTML = '<div style="display: inline-block; width: 40px; height: 40px; border: 4px solid #f3f3f3; border-top: 4px solid #ff6b8b; border-radius: 50%; animation: spin 1s linear infinite;"></div><p style="margin-top: 15px; color: #666;">جاري تحميل المزيد...</p>';

                // ✅ بناء URL الطلب
                let ajaxUrl = '?ajax=load_more&page=' + currentPage;
                <?php if ($category_id): ?>
                ajaxUrl += '&category_id=<?= $category_id ?>';
                <?php endif; ?>
                <?php if ($discount_mode): ?>
                ajaxUrl += '&discount=1';
                <?php endif; ?>
                console.log('  - AJAX URL:', ajaxUrl);

                fetch(ajaxUrl)
                    .then(response => {
                        console.log('  - Response status:', response.status);
                        return response.text();
                    })
                    .then(html => {
                        console.log('  - Response length:', html.length, 'chars');
                        if (html.includes('data-end="true"') || html.includes('data-error="true"')) {
                            hasMore = false;
                            loadingIndicator.innerHTML = '<div class="no-more-products">' +
                                (html.includes('data-error') ? 'حدث خطأ في التحميل' : '✓ تم تحميل جميع المنتجات') +
                                '</div>';
                        } else if (html.trim() === '') {
                            hasMore = false;
                            loadingIndicator.innerHTML = '<div class="no-more-products">✓ تم تحميل جميع المنتجات</div>';
                        } else {
                            // ✅ إضافة المنتجات الجديدة قبل loading-indicator
                            const productsContainer = document.querySelector('.products-grid');
                            if (productsContainer) {
                                const temp = document.createElement('div');
                                temp.innerHTML = html;
                                const fragment = document.createDocumentFragment();
                                while (temp.firstChild) {
                                    fragment.appendChild(temp.firstChild);
                                }
                                if (loadingIndicator.parentElement === productsContainer) {
                                    productsContainer.insertBefore(fragment, loadingIndicator);
                                } else {
                                    productsContainer.appendChild(fragment);
                                }
                                console.log('  - Added new products, count now:', productsContainer.querySelectorAll('.product-card').length);

                                if (typeof initProductSliders === 'function') {
                                    setTimeout(initProductSliders, 100);
                                }
                            }
                            loadingIndicator.innerHTML = '<div style="display: inline-block; width: 40px; height: 40px; border: 4px solid #f3f3f3; border-top: 4px solid #ff6b8b; border-radius: 50%; animation: spin 1s linear infinite;"></div><p style="margin-top: 15px; color: #666;">مرر لأسفل للمزيد...</p>';
                        }
                    })
                    .catch(error => {
                        console.error('❌ Error loading more products:', error);
                        hasMore = false;
                        loadingIndicator.innerHTML = '<div class="no-more-products">حدث خطأ في التحميل</div>';
                    })
                    .finally(() => {
                        isLoading = false;
                    });
            }

            // ✅ IntersectionObserver
            if ('IntersectionObserver' in window) {
                const observer = new IntersectionObserver(function(entries) {
                    entries.forEach(function(entry) {
                        if (entry.isIntersecting && !isLoading && hasMore) {
                            console.log('📉 Loading indicator in view, loading more...');
                            loadMoreProducts();
                        }
                    });
                }, {
                    root: null,
                    rootMargin: '500px 0px',
                    threshold: 0.01
                });
                observer.observe(loadingIndicator);
                console.log('  - IntersectionObserver attached successfully');
            }

            // ✅ Fallback قوي: scroll event - يعمل دائماً حتى لو فشل IntersectionObserver
            console.log('  - Adding scroll event listener (additional trigger)');
            let scrollTimeout;
            window.addEventListener('scroll', function() {
                if (isLoading || !hasMore) return;
                if (scrollTimeout) clearTimeout(scrollTimeout);
                scrollTimeout = setTimeout(function() {
                    if (isLoading || !hasMore) return;
                    const rect = loadingIndicator.getBoundingClientRect();
                    // ✅ لو المؤشر قريب من أسفل الشاشة بـ 800px
                    if (rect.top <= window.innerHeight + 800) {
                        console.log('📉 Scroll triggered: loading indicator near view, loading more...');
                        loadMoreProducts();
                    }
                }, 100);
            }, { passive: true });

            console.log('✅ Infinite scroll initialized');
        });
    })();
</script>

<script src="<?php echo SITE_URL; ?>assets/js/product-slider.js"></script>

<script>
    function slideProduct(sliderElement, direction) {
        const slidesContainer = sliderElement.querySelector('.product-slides');
        const slides = slidesContainer.querySelectorAll('.product-slide');
        let activeIndex = Array.from(slides).findIndex(slide => slide.classList.contains('active'));

        // إزالة العنصر النشط الحالي
        slides[activeIndex].classList.remove('active');

        // حساب العنصر التالي
        let newIndex = activeIndex + direction;
        if (newIndex < 0) {
            newIndex = slides.length - 1; // يرجع لآخر صورة
        } else if (newIndex >= slides.length) {
            newIndex = 0; // يرجع لأول صورة
        }

        // تفعيل العنصر الجديد
        slides[newIndex].classList.add('active');
    }
</script>

<script>
    // دالة محسنة لتحسين السلايدر
    function initProductSliders() {
        const sliders = document.querySelectorAll('.product-slider');

        sliders.forEach(slider => {
            const slides = slider.querySelectorAll('.product-slide');
            const prevBtn = slider.querySelector('.product-prev');
            const nextBtn = slider.querySelector('.product-next');
            const indicators = slider.querySelectorAll('.indicator');

            if (slides.length <= 1) {
                if (prevBtn) prevBtn.style.display = 'none';
                if (nextBtn) nextBtn.style.display = 'none';
                if (indicators.length > 0) {
                    indicators[0].parentElement.style.display = 'none';
                }
                return;
            }

            let currentIndex = 0;
            let autoSlideInterval;

            function showSlide(index) {
                // تطبيع الفهرس
                if (index < 0) index = slides.length - 1;
                if (index >= slides.length) index = 0;

                // إخفاء جميع الشرائح
                slides.forEach(slide => slide.classList.remove('active'));

                // إظهار الشريحة المطلوبة
                slides[index].classList.add('active');

                // تحديث المؤشرات
                indicators.forEach(indicator => indicator.classList.remove('active'));
                if (indicators[index]) {
                    indicators[index].classList.add('active');
                }

                currentIndex = index;
            }

            function startAutoSlide() {
                stopAutoSlide();
                autoSlideInterval = setInterval(() => {
                    showSlide(currentIndex + 1);
                }, 3000);
            }

            function stopAutoSlide() {
                clearInterval(autoSlideInterval);
            }

            // إضافة event listeners للأزرار
            if (prevBtn) {
                prevBtn.addEventListener('click', () => {
                    stopAutoSlide();
                    showSlide(currentIndex - 1);
                    startAutoSlide();
                });
            }

            if (nextBtn) {
                nextBtn.addEventListener('click', () => {
                    stopAutoSlide();
                    showSlide(currentIndex + 1);
                    startAutoSlide();
                });
            }

            // إضافة event listeners للمؤشرات
            indicators.forEach((indicator, index) => {
                indicator.addEventListener('click', () => {
                    stopAutoSlide();
                    showSlide(index);
                    startAutoSlide();
                });
            });

            // التحكم بالسلايدر التلقائي
            slider.addEventListener('mouseenter', stopAutoSlide);
            slider.addEventListener('mouseleave', startAutoSlide);
            slider.addEventListener('touchstart', stopAutoSlide);
            slider.addEventListener('touchend', startAutoSlide);

            // بدء السلايدر التلقائي
            startAutoSlide();
        });
    }

    // تهيئة عند تحميل الصفحة
    document.addEventListener('DOMContentLoaded', function() {
        // الصور الآن تستخدم src مباشرة (بدون lazy loading)
        // فقط تهيئة السلايدرات
        initProductSliders();

        // تحسين الأداء للشاشات الكبيرة
        if (window.innerWidth > 1200) {
            const products = document.querySelectorAll('.product-card');
            products.forEach(product => {
                product.addEventListener('mousemove', function(e) {
                    const rect = this.getBoundingClientRect();
                    const x = e.clientX - rect.left;
                    const y = e.clientY - rect.top;

                    const centerX = rect.width / 2;
                    const centerY = rect.height / 2;

                    const rotateY = (x - centerX) / 25;
                    const rotateX = (centerY - y) / 25;

                    this.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg)`;
                });

                product.addEventListener('mouseleave', function() {
                    this.style.transform = 'perspective(1000px) rotateX(0) rotateY(0)';
                });
            });
        }
    });

    // دالة السلايدر الأساسية (للحفاظ على التوافق)
    function slideProduct(sliderElement, direction) {
        const slidesContainer = sliderElement.querySelector('.product-slides');
        const slides = slidesContainer.querySelectorAll('.product-slide');
        let activeIndex = Array.from(slides).findIndex(slide => slide.classList.contains('active'));

        slides[activeIndex].classList.remove('active');

        let newIndex = activeIndex + direction;
        if (newIndex < 0) newIndex = slides.length - 1;
        if (newIndex >= slides.length) newIndex = 0;

        slides[newIndex].classList.add('active');
    }
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>
<?php
session_start();
require_once __DIR__ . '/../includes/db_connect.php';
require_once __DIR__ . '/../includes/auth.php';

// التحقق من تسجيل الدخول (صاحب التقييم فقط يمكنه الحذف)
checkLogin();

$user_id = $_SESSION['user_id'];
$review_id = intval($_POST['review_id']);
$product_id = intval($_POST['product_id']);

// تأكد أن التقييم للمستخدم الحالي
$stmt = $conn->prepare("SELECT id FROM reviews WHERE id = ? AND user_id = ?");
$stmt->execute([$review_id, $user_id]);
$review = $stmt->fetch();

if (!$review) {
    header("Location: " . SITE_URL . "pages/details_product.php?id=$product_id&error=unauthorized");
    exit;
}

try {
    $stmt = $conn->prepare("DELETE FROM reviews WHERE id = ?");
    $stmt->execute([$review_id]);

    header("Location: " . SITE_URL . "pages/details_product.php?id=$product_id&success=deleted");
    exit;
} catch (PDOException $e) {
    die("حدث خطأ أثناء حذف التقييم: " . $e->getMessage());
}

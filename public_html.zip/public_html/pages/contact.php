<?php
session_start();
require_once __DIR__ . '/../includes/db_connect.php';
require_once __DIR__ . '/../includes/auth.php';

// توليد CSRF token إذا لم يكن موجوداً
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// التحقق من تسجيل الدخول أولاً
checkLogin();

// الآن بعد التحقق من التسجيل، يمكننا استخدام user_id بأمان
$user_id = $_SESSION['user_id'];
// الحصول على البريد الإلكتروني بشكل آمن
$user_email = $_SESSION['email'] ?? '';

$error = '';
$success = '';
$remaining_messages = 0;
$max_messages = 5;

// التحقق من عدد الرسائل المرسلة من هذا المستخدم
try {
    $stmt = $conn->prepare("SELECT COUNT(*) FROM contact_messages WHERE user_id = ? AND created_at > DATE_SUB(NOW(), INTERVAL 24 HOUR)");
    $stmt->execute([$user_id]);
    $message_count = $stmt->fetchColumn();

    $remaining_messages = max(0, $max_messages - $message_count);
} catch (PDOException $e) {
    error_log("Database error: " . $e->getMessage());
    $error = "خطأ في الاتصال بقاعدة البيانات.";
    $remaining_messages = 0;
}

// عند إرسال النموذج
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $remaining_messages > 0) {
    // التحقق من CSRF token
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $error = "رمز التحقق غير صالح.";
    } else {
        $name = trim($_POST['name'] ?? '');
        $subject = trim($_POST['subject'] ?? '');
        $message = trim($_POST['message'] ?? '');
        $phone = trim($_POST['phone'] ?? '');

        // تحقق من صحة البيانات
        $validation_errors = [];

        if (empty($name) || strlen($name) > 100) {
            $validation_errors[] = "الاسم يجب أن يكون بين 1 و 100 حرف.";
        }

        if (empty($subject) || strlen($subject) > 200) {
            $validation_errors[] = "الموضوع يجب أن يكون بين 1 و 200 حرف.";
        }

        if (empty($message) || strlen($message) > 2000) {
            $validation_errors[] = "الرسالة يجب أن تكون بين 1 و 2000 حرف.";
        }

        if (!empty($phone) && !preg_match('/^[\d\s\-\+\(\)]{10,20}$/', $phone)) {
            $validation_errors[] = "رقم الهاتف غير صالح.";
        }

        if (empty($validation_errors)) {
            try {
                $stmt = $conn->prepare("INSERT INTO contact_messages (user_id, name, email, phone, subject, message, created_at) VALUES (?, ?, ?, ?, ?, ?, NOW())");
                $stmt->execute([
                    $user_id,
                    htmlspecialchars($name, ENT_QUOTES, 'UTF-8'),
                    $user_email,
                    !empty($phone) ? htmlspecialchars($phone, ENT_QUOTES, 'UTF-8') : NULL,
                    htmlspecialchars($subject, ENT_QUOTES, 'UTF-8'),
                    htmlspecialchars($message, ENT_QUOTES, 'UTF-8')
                ]);

                $success = "✅ تم إرسال رسالتك بنجاح.";
                // تحديث عدد الرسائل المتبقية بعد الإرسال
                $remaining_messages--;

                // إعادة توليد CSRF token بعد الاستخدام الناجح
                $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
            } catch (PDOException $e) {
                error_log("Database error: " . $e->getMessage());
                $error = "حدث خطأ أثناء إرسال الرسالة.";
            }
        } else {
            $error = implode("<br>", $validation_errors);
        }
    }
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>اتصل بنا</title>
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>assets/css/contact_style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>

<body>
    <div class="container">
        <h2><i class="fas fa-envelope contact-icon"></i>اتصل بنا</h2>

        <?php if ($error): ?>
            <div class="alert alert-danger"><?= $error ?></div>
        <?php elseif ($success): ?>
            <div class="alert alert-success"><?= $success ?></div>
        <?php endif; ?>

        <!-- عدّاد الرسائل -->
        <div class="message-counter">
            <div class="counter-text">✉️ عدد الرسائل المسموح بها: <?= $max_messages ?></div>
            <div class="counter-number <?= $remaining_messages == 0 ? 'counter-zero' : '' ?>">
                📮 المتبقي لك: <?= $remaining_messages ?> رسالة
            </div>
        </div>

        <form method="post">
            <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">

            <div class="form-group">
                <label for="name">الاسم:</label>
                <input type="text" name="name" id="name" required maxlength="100"
                    value="<?= isset($_POST['name']) ? htmlspecialchars($_POST['name']) : '' ?>">
            </div>

            <div class="form-group">
                <label for="subject">الموضوع:</label>
                <input type="text" name="subject" id="subject" required maxlength="200"
                    value="<?= isset($_POST['subject']) ? htmlspecialchars($_POST['subject']) : '' ?>">
            </div>

            <div class="form-group">
                <label for="email">البريد الإلكتروني:</label>
                <input type="email" name="email" id="email" required
                    value="<?= htmlspecialchars($user_email) ?>"
                    <?= !empty($user_email) ? 'readonly' : '' ?>>
            </div>

            <div class="form-group">
                <label for="phone">رقم الهاتف:</label>
                <input type="tel" name="phone" id="phone" maxlength="20"
                    value="<?= isset($_POST['phone']) ? htmlspecialchars($_POST['phone']) : '' ?>">
            </div>

            <div class="form-group">
                <label for="message">الرسالة:</label>
                <textarea name="message" id="message" required maxlength="2000"><?=
                                                                                isset($_POST['message']) ? htmlspecialchars($_POST['message']) : ''
                                                                                ?></textarea>
            </div>

            <button type="submit" <?= $remaining_messages == 0 ? 'disabled' : '' ?>>
                <i class="fas fa-paper-plane"></i> إرسال الرسالة
            </button>
        </form>

        <div class="text-center">
            <a href="<?php echo SITE_URL; ?>" class="home-btn">
                <i class="fas fa-home"></i> العودة إلى الصفحة الرئيسية
            </a>
        </div>
    </div>
</body>

</html>
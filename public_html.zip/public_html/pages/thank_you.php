<?php
require_once('../includes/db_connect.php');
// بدء الجلسة
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . '/../includes/auth.php';

// التحقق من تسجيل الدخول
checkLogin();
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">

<head>
    <meta charset="UTF-8">
    <title>شكراً لطلبك</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.rtl.min.css" integrity="sha384-Xbg45MqvDIk1e563NLpGEulpX6AvL404DP+/iCgW9eFa2BqztiwTexswJo2jLMue" crossorigin="anonymous">
    <!-- <link rel="stylesheet" href="<?php echo SITE_URL; ?>assets/css/style.css"> -->
    <style>
        body {
            background-color: #f9f9f9;
            font-family: 'Cairo', sans-serif;
            text-align: center;
            padding: 50px;
        }

        .thank-you-container {
            background: #fff;
            border-radius: 12px;
            padding: 40px;
            max-width: 600px;
            margin: auto;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
        }

        .thank-you-container h1 {
            color: #28a745;
            margin-bottom: 20px;
        }

        .thank-you-container p {
            font-size: 18px;
            color: #555;
        }

        .thank-you-container a {
            display: inline-block;
            margin-top: 30px;
            padding: 12px 24px;
            background-color: #007bff;
            color: #fff;
            border-radius: 8px;
            text-decoration: none;
        }

        .thank-you-container a:hover {
            background-color: #0056b3;
        }
    </style>
</head>

<body>
    <div class="thank-you-container">
        <h1><i class="fas fa-check-circle"></i> شكراً لطلبك!</h1>
        <p>تم استلام طلبك بنجاح. سنقوم بمعالجته وشحنه في أقرب وقت ممكن.</p>
        <p>يمكنك متابعة حالة الطلب من خلال حسابك.</p>
        <a href="<?php echo SITE_URL; ?>">العودة إلى الصفحة الرئيسية</a>


    </div>

    <script src="<?php echo SITE_URL; ?>assets/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/js/all.min.js"></script>
</body>

</html>
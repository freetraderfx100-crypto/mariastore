<?php
session_start();
require_once __DIR__ . '/../includes/db_connect.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/inactivity_logout.php';

// التحقق من حالة المستخدم
$is_logged_in = isset($_SESSION['user_id']);
$is_guest = isset($_SESSION['guest_id']);

// إذا كان المستخدم زائراً، توجيهه إلى صفحة التسجيل مع رسالة توضيحية
if (!$is_logged_in) {
    if ($is_guest) {
        $_SESSION['redirect_after_login'] = SITE_URL . 'pages/wishlist.php';
        $_SESSION['info_message'] = 'يجب إنشاء حساب أو تسجيل الدخول للوصول إلى قائمة المفضلة';
        header("Location: " . SITE_URL . "pages/login.php");
        exit;
    } else {
        // إذا لم يكن مسجلاً ولا زائراً، توجيه إلى صفحة التسجيل
        header("Location: " . SITE_URL . "pages/login.php");
        exit;
    }
}

// للمستخدمين المسجلين فقط: جلب عناصر المفضلة
$user_id = $_SESSION['user_id'];
$user_email = $_SESSION['email'];

try {
    $stmt = $conn->prepare("
        SELECT p.*,
               pv.image_urls
        FROM wishlist w
        JOIN products p ON w.product_id = p.id
        LEFT JOIN product_variants pv ON pv.product_id = p.id
        WHERE w.user_id = ?
        GROUP BY p.id
    ");
    $stmt->execute([$user_id]);
    $wishlist_items = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // ✅ استخراج أول صورة من حقل image_urls (JSON array) لكل منتج
    foreach ($wishlist_items as &$item) {
        $first_image = null;
        if (!empty($item['image_urls'])) {
            $images = json_decode($item['image_urls'], true);
            if (is_array($images) && !empty($images)) {
                $first_image = $images[0];
            }
        }
        $item['image_url'] = $first_image; // المسار الفعلي للصورة
        unset($item['image_urls']); // لا نحتاجه في الواجهة
    }
    unset($item); // كسر المرجع
} catch (PDOException $e) {
    die("حدث خطأ: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>قائمة المفضلة</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>assets/css/wishlist.css">
    <?php
    // ✅ placeholder SVG مضمون للصور المفقودة
    $placeholder_svg = 'data:image/svg+xml;base64,' . base64_encode(
        '<svg xmlns="http://www.w3.org/2000/svg" width="400" height="400" viewBox="0 0 400 400">' .
        '<rect width="400" height="400" fill="#f8f9fa"/>' .
        '<text x="200" y="180" font-size="60" text-anchor="middle" fill="#cccccc" font-family="sans-serif">👕</text>' .
        '<text x="200" y="240" font-size="18" text-anchor="middle" fill="#999999" font-family="sans-serif">صورة غير متوفرة</text>' .
        '</svg>'
    );
    ?>
    <script>
        // ✅ placeholder متاح للاستخدام في JS
        var PLACEHOLDER_SVG = '<?php echo $placeholder_svg; ?>';
    </script>
</head>

<body>
    <?php include '../includes/header.php'; ?>

    <div class="wishlist-container">
        <div class="wishlist-header">
            <h1 class="wishlist-title">
                <i class="fas fa-heart"></i>
                قائمة المفضلة
                <?php if (!empty($wishlist_items)): ?>
                    <span class="wishlist-count"><?= count($wishlist_items) ?></span>
                <?php endif; ?>
            </h1>

            <?php if (!empty($wishlist_items)): ?>
                <button class="remove-all-btn" id="removeAllWishlist">
                    <i class="fas fa-trash-alt"></i> إزالة الكل
                </button>
            <?php endif; ?>
        </div>

        <?php if (empty($wishlist_items)): ?>
            <div class="empty-wishlist">
                <i class="fas fa-heart-broken"></i>
                <h3>قائمة المفضلة فارغة</h3>
                <p>لم تقم بإضافة أي منتجات إلى المفضلة بعد</p>
                <a href="<?php echo SITE_URL; ?>pages/products.php" class="btn-primary">
                    <i class="fas fa-shopping-bag"></i> تصفح المتجر
                </a>
            </div>
        <?php else: ?>
            <div class="wishlist-grid">
                <?php foreach ($wishlist_items as $product):
                    // ✅ فحص وجود صورة المنتج على القرص
                    $image_path_raw = $product['image_url'] ?? '';
                    $clean_image = str_replace(['\\', '"', "'"], '', $image_path_raw);
                    $clean_image = str_replace('assets/images/', '', $clean_image);
                    $clean_image = ltrim($clean_image, '/');
                    $full_image_path = __DIR__ . '/../assets/images/' . $clean_image;
                    $image_exists = !empty($clean_image) && file_exists($full_image_path);
                ?>
                    <div class="wishlist-item" data-product-id="<?= $product['id'] ?>">
                        <a href="<?php echo SITE_URL; ?>pages/details_product.php?id=<?= $product['id'] ?>" class="wishlist-item-img">
                            <?php if ($image_exists): ?>
                                <img src="<?php echo SITE_URL; ?>assets/images/<?= htmlspecialchars($clean_image) ?>"
                                    alt="<?= htmlspecialchars($product['name']) ?>"
                                    onerror="this.onerror=null; this.src='<?= $placeholder_svg ?>';">
                            <?php else: ?>
                                <img src="<?= $placeholder_svg ?>"
                                    alt="<?= htmlspecialchars($product['name']) ?>">
                            <?php endif; ?>
                        </a>
                        <div class="wishlist-item-details">
                            <h3 class="wishlist-item-title"><?= htmlspecialchars($product['name']) ?></h3>
                            <p class="wishlist-item-price"><?= number_format($product['price'], 2) ?> ر.ي</p>
                            <div class="wishlist-item-actions">
                                <button class="btn-remove remove-from-wishlist">
                                    <i class="fas fa-trash-alt"></i> إزالة
                                </button>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>

    <?php include '../includes/footer.php'; ?>

    <!-- روابط -->
    <script src="<?php echo SITE_URL; ?>assets/js/sweetalert2.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // إزالة عنصر من المفضلة
            document.querySelectorAll('.remove-from-wishlist').forEach(button => {
                button.addEventListener('click', function() {
                    const productId = this.closest('.wishlist-item').dataset.productId;
                    removeFromWishlist(productId);
                });
            });

            // إزالة كل العناصر من المفضلة
            const removeAllBtn = document.getElementById('removeAllWishlist');
            if (removeAllBtn) {
                removeAllBtn.addEventListener('click', function() {
                    Swal.fire({
                        title: 'هل أنت متأكد؟',
                        text: "سيتم إزالة جميع المنتجات من قائمة المفضلة",
                        icon: 'warning',
                        showCancelButton: true,
                        confirmButtonColor: '#d33',
                        cancelButtonColor: '#3085d6',
                        confirmButtonText: 'نعم، إزالة الكل',
                        cancelButtonText: 'إلغاء',
                        customClass: {
                            container: 'rtl-swal'
                        }
                    }).then((result) => {
                        if (result.isConfirmed) {
                            fetch('remove_all_wishlist.php', {
                                    method: 'POST',
                                    headers: {
                                        'Content-Type': 'application/json',
                                    },
                                    credentials: 'same-origin'
                                })
                                .then(response => {
                                    if (!response.ok) {
                                        throw new Error('Network response was not ok');
                                    }
                                    return response.json();
                                })
                                .then(data => {
                                    if (data.success) {
                                        Swal.fire({
                                            title: 'تمت الإزالة!',
                                            text: 'تمت إزالة جميع المنتجات من المفضلة.',
                                            icon: 'success',
                                            customClass: {
                                                container: 'rtl-swal'
                                            }
                                        }).then(() => {
                                            // إعادة تحميل الصفحة لعرض الحالة الفارغة
                                            location.reload();
                                        });
                                    } else {
                                        Swal.fire({
                                            title: 'خطأ!',
                                            text: data.error || 'لا توجد منتجات في المفضلة',
                                            icon: 'error',
                                            customClass: {
                                                container: 'rtl-swal'
                                            }
                                        });
                                    }
                                })
                                .catch(error => {
                                    console.error('Error:', error);
                                    Swal.fire({
                                        title: 'خطأ!',
                                        text: 'حدث خطأ في الاتصال بالخادم: ' + error.message,
                                        icon: 'error',
                                        customClass: {
                                            container: 'rtl-swal'
                                        }
                                    });
                                });
                        }
                    });
                });
            }
        });

        function removeFromWishlist(productId) {
            Swal.fire({
                title: 'هل أنت متأكد؟',
                text: "سيتم إزالة هذا المنتج من المفضلة",
                icon: 'question',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'نعم، إزالة',
                cancelButtonText: 'إلغاء'
            }).then((result) => {
                if (result.isConfirmed) {
                    fetch('remove_wishlist.php', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/x-www-form-urlencoded',
                            },
                            body: `product_id=${productId}`
                        })
                        .then(response => response.json())
                        .then(data => {
                            if (data.success) {
                                Swal.fire(
                                    'تمت الإزالة!',
                                    'تمت إزالة المنتج من المفضلة.',
                                    'success'
                                ).then(() => {
                                    document.querySelector(`.wishlist-item[data-product-id="${productId}"]`).remove();

                                    // تحديث العداد في العنوان
                                    const wishlistCount = document.querySelector('.wishlist-count');
                                    if (wishlistCount) {
                                        const currentCount = parseInt(wishlistCount.textContent) || 0;
                                        if (currentCount > 1) {
                                            wishlistCount.textContent = currentCount - 1;
                                        } else {
                                            location.reload();
                                        }
                                    }
                                });
                            } else {
                                Swal.fire(
                                    'خطأ!',
                                    data.error || 'حدث خطأ أثناء الإزالة',
                                    'error'
                                );
                            }
                        })
                        .catch(error => {
                            Swal.fire(
                                'خطأ!',
                                'حدث خطأ في الاتصال بالخادم',
                                'error'
                            );
                        });
                }
            });
        }
    </script>
</body>

</html>
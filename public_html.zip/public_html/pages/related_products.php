<?php
require_once __DIR__ . '/../includes/db_connect.php';
// جلب المنتجات ذات الصلة مع إضافة خيارات التصفية
try {
    // أولاً: نجلب parent_id للقسم الحالي
    $category_stmt = $conn->prepare("SELECT parent_id FROM categories WHERE id = ?");
    $category_stmt->execute([$product['category_id']]);
    $category = $category_stmt->fetch(PDO::FETCH_ASSOC);
    $parent_id = $category['parent_id'] ?? $product['category_id'];

    // تحديد نوع التصفية المطلوبة (من GET أو استخدام القيمة الافتراضية)
    $filter = isset($_GET['related_filter']) ? $_GET['related_filter'] : 'rating';

    // بناء استعلام SQL حسب نوع التصفية
    $order_by = "";
    switch ($filter) {
        case 'sales':
            $order_by = "(SELECT COUNT(*) FROM order_items WHERE product_id = p.id) DESC";
            break;
        case 'newest':
            $order_by = "p.created_at DESC";
            break;
        case 'price_asc':
            $order_by = "p.price ASC";
            break;
        case 'price_desc':
            $order_by = "p.price DESC";
            break;
        default: // التقييم هو القيمة الافتراضية
            $order_by = "(SELECT AVG(rating) FROM reviews WHERE product_id = p.id) DESC";
    }

    // ثانياً: نجلب المنتجات من نفس القسم أو الأقسام الفرعية لنفس القسم الرئيسي
    $related_products_stmt = $conn->prepare("
        SELECT p.id, p.name, p.price,
            (SELECT image_urls FROM product_variants WHERE product_id = p.id LIMIT 1) AS image_urls,
            (SELECT AVG(rating) FROM reviews WHERE product_id = p.id) AS avg_rating,
            (SELECT COUNT(*) FROM order_items WHERE product_id = p.id) AS sales_count
        FROM products p
        JOIN categories c ON p.category_id = c.id
        WHERE (c.id = :current_category OR c.parent_id = :parent_id)
        AND p.id != :product_id
        AND p.is_active = 1
        AND EXISTS (
            SELECT 1 FROM product_variants pv 
            WHERE pv.product_id = p.id 
            AND pv.quantity > 0)
        ORDER BY 
            CASE 
                WHEN p.category_id = :current_category THEN 0
                ELSE 1
            END,
            $order_by
        LIMIT 4
    ");
    $related_products_stmt->execute([
        'current_category' => $product['category_id'],
        'parent_id' => $parent_id,
        'product_id' => $product_id
    ]);
    $initial_related_products = $related_products_stmt->fetchAll(PDO::FETCH_ASSOC);

    // دالة لاستخراج أول صورة من JSON
    function getFirstImage($image_urls_json)
    {
        if (empty($image_urls_json)) {
            return 'default-product-image.jpg';
        }

        $images = json_decode($image_urls_json, true);
        if (is_array($images) && !empty($images)) {
            return $images[0];
        }

        return 'default-product-image.jpg';
    }

    // إضافة الصور الأولى لكل منتج
    // ✅ إصلاح حرج: استخدام اسم متغير مختلف (related_item) بدلاً من $product
    // لأن foreach as &$product يكسر المتغير $product الأصلي المعرف في details_product.php
    // مما يسبب مشاكل في product_reviews.php التي تعتمد على $product['id']
    foreach ($initial_related_products as &$related_item) {
        $related_item['first_image'] = getFirstImage($related_item['image_urls']);
    }
    unset($related_item); // كسر المرجع
} catch (PDOException $e) {
    $initial_related_products = [];
    error_log("Error fetching related products: " . $e->getMessage());
}
?>
<section class="related-products">
    <h2 class="section-title">منتجات ذات صلة</h2>
    <!-- إضافة خيارات التصفية -->
    <!-- استبدال قسم التصفية بهذا الكود -->
    <div class="related-products-filter">
        <form method="get" class="filter-tabs-form">
            <input type="hidden" name="id" value="<?= $product_id ?>">
            <div class="filter-tabs">
                <input type="radio" id="filter-rating" name="related_filter" value="rating"
                    <?= ($filter == 'rating') ? 'checked' : '' ?>>
                <label for="filter-rating" class="filter-tab">
                    <i class="fas fa-star"></i>
                    <span>الأعلى تقييماً</span>
                </label>
                <input type="radio" id="filter-sales" name="related_filter" value="sales"
                    <?= ($filter == 'sales') ? 'checked' : '' ?>>
                <label for="filter-sales" class="filter-tab">
                    <i class="fas fa-fire"></i>
                    <span>الأكثر مبيعاً</span>
                </label>
                <input type="radio" id="filter-newest" name="related_filter" value="newest"
                    <?= ($filter == 'newest') ? 'checked' : '' ?>>
                <label for="filter-newest" class="filter-tab">
                    <i class="fas fa-clock"></i>
                    <span>الأحدث</span>
                </label>
                <input type="radio" id="filter-price-asc" name="related_filter" value="price_asc"
                    <?= ($filter == 'price_asc') ? 'checked' : '' ?>>
                <label for="filter-price-asc" class="filter-tab">
                    <i class="fas fa-sort-amount-down"></i>
                    <span>السعر (أقل أولاً)</span>
                </label>
                <input type="radio" id="filter-price-desc" name="related_filter" value="price_desc"
                    <?= ($filter == 'price_desc') ? 'checked' : '' ?>>
                <label for="filter-price-desc" class="filter-tab">
                    <i class="fas fa-sort-amount-up"></i>
                    <span>السعر (أعلى أولاً)</span>
                </label>
            </div>
        </form>
    </div>
    <div class="products-grid" id="relatedProductsContainer">
        <?php foreach ($initial_related_products as $related): ?>
            <div class="product-card">
                <a href="<?php echo SITE_URL; ?>pages/details_product.php?id=<?= $related['id'] ?>" class="product-image">
                    <img src="<?php echo SITE_URL; ?>assets/images/<?= htmlspecialchars($related['first_image']) ?>"
                        alt="<?= htmlspecialchars($related['name']) ?>">
                </a>
                <div class="product-details">
                    <h3 class="product-name">
                        <a href="<?php echo SITE_URL; ?>pages/details_product.php?id=<?= $related['id'] ?>">
                            <?= htmlspecialchars($related['name']) ?>
                        </a>
                    </h3>
                    <div class="product-meta">
                        <span class="product-price"><?= number_format($related['price'], 2) ?> ر.ي</span>
                        <?php if ($filter == 'sales'): ?>
                            <span class="sales-count">(تم بيع <?= $related['sales_count'] ?>)</span>
                        <?php endif; ?>
                    </div>
                    <a href="<?php echo SITE_URL; ?>pages/details_product.php?id=<?= $related['id'] ?>" class="btn btn-outline">عرض التفاصيل</a>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
    <?php if (count($initial_related_products) >= 4): ?>
        <div class="text-center mt-4">
            <button id="loadMoreProductsBtn" class="btn btn-outline-primary">
                عرض المزيد من المنتجات
            </button>
        </div>
    <?php endif; ?>
</section>
<style>
    /* تصاميم شرائح التصفية */
    .filter-tabs-form {
        margin: 20px 0;
    }

    .filter-tabs {
        display: flex;
        flex-wrap: wrap;
        gap: 8px;
        justify-content: center;
    }

    .filter-tabs input[type="radio"] {
        display: none;
    }

    .filter-tab {
        display: flex;
        align-items: center;
        padding: 10px 15px;
        border-radius: 30px;
        background-color: #f5f5f5;
        color: #555;
        cursor: pointer;
        transition: all 0.3s ease;
        font-size: 14px;
        border: 1px solid #e0e0e0;
    }

    .filter-tab i {
        margin-left: 5px;
        font-size: 14px;
    }

    .filter-tabs input[type="radio"]:checked+.filter-tab {
        background-color: #ff6b6b;
        color: white;
        border-color: #ff6b6b;
    }

    .filter-tab:hover {
        background-color: #eee;
    }

    .filter-tabs input[type="radio"]:checked+.filter-tab:hover {
        background-color: #ff5252;
    }

    /* تأثير النشاط عند النقر */
    .filter-tab:active {
        transform: scale(0.95);
    }

    /* تصميم للشاشات الصغيرة */
    @media (max-width: 768px) {
        .filter-tabs {
            gap: 5px;
        }

        .filter-tab {
            padding: 8px 12px;
            font-size: 12px;
        }

        .filter-tab i {
            font-size: 12px;
        }
    }

    /* تحسينات لعرض المنتجات */
    .products-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
        gap: 20px;
    }

    .product-card {
        border: 1px solid #eee;
        border-radius: 8px;
        overflow: hidden;
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }

    .product-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
    }

    .product-image {
        display: block;
        height: 200px;
        overflow: hidden;
    }

    .product-image img {
        width: 100%;
        height: 100%;
        object-fit: cover;
        transition: transform 0.3s ease;
    }

    .product-card:hover .product-image img {
        transform: scale(1.05);
    }

    .product-details {
        padding: 15px;
    }

    .product-name {
        margin: 0 0 10px;
        font-size: 16px;
        font-weight: 600;
        line-height: 1.4;
        height: 2.8em;
        overflow: hidden;
        display: -webkit-box;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
    }

    .product-name a {
        color: #333;
        text-decoration: none;
    }

    .product-name a:hover {
        color: #ff6b6b;
    }

    .product-meta {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 15px;
    }

    .product-price {
        font-weight: 700;
        color: #ff6b6b;
        font-size: 18px;
    }

    .sales-count {
        font-size: 14px;
        color: #666;
    }

    .btn-outline {
        display: inline-block;
        padding: 8px 15px;
        background-color: transparent;
        border: 1px solid #ff6b6b;
        color: #ff6b6b;
        border-radius: 4px;
        text-decoration: none;
        font-weight: 500;
        text-align: center;
        transition: all 0.3s ease;
    }

    .btn-outline:hover {
        background-color: #ff6b6b;
        color: white;
    }
</style>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const loadMoreBtn = document.getElementById('loadMoreProductsBtn');
        const relatedContainer = document.getElementById('relatedProductsContainer');
        const productId = <?= isset($product_id) ? $product_id : 'null' ?>;
        const filterType = '<?= $filter ?>';
        let offset = 4;
        let isLoading = false;

        if (loadMoreBtn) {
            loadMoreBtn.addEventListener('click', async function() {
                if (isLoading) return;
                isLoading = true;
                const originalText = loadMoreBtn.innerHTML;
                loadMoreBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> جاري التحميل...';
                loadMoreBtn.disabled = true;

                try {
                    const response = await fetch(`<?php echo SITE_URL; ?>pages/load_more_related_products.php?product_id=${productId}&offset=${offset}&filter=${filterType}`);

                    console.log('Response status:', response.status);

                    if (response.status === 204) {
                        loadMoreBtn.style.display = 'none';
                        return;
                    }

                    if (!response.ok) {
                        throw new Error('Network response was not ok');
                    }

                    const html = await response.text();
                    console.log('Response HTML:', html);

                    if (html.trim() === '') {
                        loadMoreBtn.style.display = 'none';
                    } else {
                        relatedContainer.insertAdjacentHTML('beforeend', html);
                        offset += 4;

                        // تحقق إذا كان عدد المنتجات التي تم تحميلها أقل من 4
                        const newProductsCount = (html.match(/class="product-card"/g) || []).length;
                        if (newProductsCount < 4) {
                            loadMoreBtn.style.display = 'none';
                        }
                    }
                } catch (error) {
                    console.error('Error:', error);
                    loadMoreBtn.innerHTML = 'حدث خطأ، حاول مرة أخرى';
                    setTimeout(() => {
                        loadMoreBtn.innerHTML = originalText;
                    }, 2000);
                } finally {
                    isLoading = false;
                    loadMoreBtn.disabled = false;
                    loadMoreBtn.innerHTML = originalText;
                }
            });
        }
    });
</script>
<script>
    // تفعيل التصفية التلقائية عند النقر على الأزرار
    document.querySelectorAll('.filter-tabs input[type="radio"]').forEach(radio => {
        radio.addEventListener('change', function() {
            this.closest('form').submit();
        });
    });
</script>
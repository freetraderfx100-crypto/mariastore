<?php
require_once __DIR__ . '/../includes/db_connect.php';
require_once __DIR__ . '/../includes/functions.php';

$slug = $_GET['slug'] ?? '';

$stmt = $conn->prepare("SELECT * FROM blog_posts WHERE slug = ?");
$stmt->execute([$slug]);
$post = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$post) {
    echo "المقال غير موجود.";
    exit;
}

include('../includes/header.php');
?>

<!DOCTYPE html>
<html lang="ar">

<head>
    <meta charset="UTF-8">
    <title><?= htmlspecialchars($post['title']) ?></title>
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>assets/css/style.css">
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>assets/css/blog.css">

</head>

<body>
    <div class="blog-details-container">
        <div class="blog-details-header">
            <img src="<?php echo SITE_URL; ?>assets/images/uploads/<?= htmlspecialchars($post['image']) ?>" alt="<?= htmlspecialchars($post['title']) ?>">
            <div>
                <h1><?= htmlspecialchars($post['title']) ?></h1>
                <p class="blog-meta"><strong>الكاتب:</strong> <?= htmlspecialchars($post['author']) ?> | <small><?= $post['created_at'] ?></small></p>
            </div>
        </div>

        <div class="blog-content">
            <?= nl2br($post['content']) ?>
        </div>

        <a class="back-link" href="<?php echo SITE_URL; ?>pages/blog.php">← عودة إلى المدونة</a>
    </div>
</body>

</html>
<?php
require_once __DIR__ . '/../includes/db_connect.php';

// جلب التقييمات
try {
    $reviews_stmt = $conn->prepare("
        SELECT r.*, u.username 
        FROM reviews r 
        JOIN users u ON r.user_id = u.id 
        WHERE r.product_id = ? 
        ORDER BY r.created_at DESC
    ");
    $reviews_stmt->execute([$product_id]);
    $reviews = $reviews_stmt->fetchAll();
} catch (PDOException $e) {
    $reviews = [];
}
?>

<?php if (isset($_GET['success']) || isset($_GET['error']) || isset($_SESSION['review_error'])): ?>
    <div id="toast" class="<?= (isset($_GET['error']) || isset($_SESSION['review_error'])) ? 'toast error' : 'toast success' ?>">
        <?php
        // ✅ دعم رسائل الخطأ من session (للحالات الحرجة)
        if (isset($_SESSION['review_error'])) {
            echo "❌ " . htmlspecialchars($_SESSION['review_error']);
            unset($_SESSION['review_error']);
        } elseif (isset($_GET['success'])) {
            echo $_GET['success'] === 'edit' ? "✅ تم تعديل التقييم بنجاح." : "✅ تم إرسال التقييم بنجاح.";
        } elseif (isset($_GET['error'])) {
            // ✅ رسائل خطأ ودية لكل حالة
            switch ($_GET['error']) {
                case 'exists':
                    echo "⚠️ لقد قمت مسبقًا بتقييم هذا المنتج.";
                    break;
                case 'invalid_rating':
                    echo "⚠️ التقييم يجب أن يكون من 1 إلى 5 نجوم.";
                    break;
                case 'empty_comment':
                    echo "⚠️ يرجى كتابة تعليق.";
                    break;
                case 'unauthorized':
                    echo "⚠️ ليس لديك صلاحية لهذا الإجراء.";
                    break;
                case 'server':
                    echo "❌ حدث خطأ تقني، يرجى المحاولة لاحقاً.";
                    break;
                default:
                    echo "⚠️ حدث خطأ غير متوقع.";
            }
        }
        ?>
    </div>
<?php endif; ?>

<section class="product-reviews">
    <h2>تقييمات وتعليقات العملاء</h2>

    <?php if (!empty($reviews)): ?>
        <div id="reviews-container">
            <?php foreach ($reviews as $index => $review): ?>
                <div class="review <?= $index >= 3 ? 'hidden-review' : '' ?>">
                    <strong><?= htmlspecialchars($review['username']) ?></strong>
                    <div class="rating"><?= str_repeat("⭐", $review['rating']) ?></div>
                    <p><?= nl2br(htmlspecialchars($review['comment'])) ?></p>
                    <small><?= date('Y-m-d', strtotime($review['created_at'])) ?></small>

                    <?php if ($isLoggedIn && $_SESSION['user_id'] == $review['user_id']): ?>
                        <div style="margin-top: 10px;">
                            <button class="btn-edit" onclick="openEditModal(<?= $review['id'] ?>, <?= $review['rating'] ?>, `<?= htmlspecialchars($review['comment'], ENT_QUOTES) ?>`)">تعديل</button>
                            <form action="delete_review.php" method="post" style="display:inline;">
                                <input type="hidden" name="review_id" value="<?= $review['id'] ?>">
                                <input type="hidden" name="product_id" value="<?= htmlspecialchars($product_id) ?>">
                                <button type="submit" class="btn-delete">حذف</button>
                            </form>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>

        <?php if (count($reviews) > 3): ?>
            <div style="margin-top: 10px; text-align: center;">
                <button id="toggleReviewsBtn" class="btn-show-more">عرض المزيد</button>
            </div>
        <?php endif; ?>
    <?php else: ?>
        <p>لا توجد تقييمات بعد.</p>
    <?php endif; ?>
</section>

<?php if ($isLoggedIn): ?>
    <section class="submit-review">
        <h3>أضف تقييمك</h3>
        <form method="post" action="<?php echo SITE_URL; ?>pages/submit_review.php">
            <input type="hidden" name="product_id" value="<?= htmlspecialchars($product_id) ?>">

            <label for='evaluation'>التقييم:</label>
            <select name="rating" id='evaluation' required>
                <option value="">اختر</option>
                <option value="5">⭐⭐⭐⭐⭐</option>
                <option value="4">⭐⭐⭐⭐</option>
                <option value="3">⭐⭐⭐</option>
                <option value="2">⭐⭐</option>
                <option value="1">⭐</option>
            </select>
            <label>تعليقك:</label>
            <textarea name="comment" placeholder="اكتب تعليقك هناء" required rows="3"></textarea>

            <button type="submit">إرسال</button>
        </form>

        <div id="editReviewModal" class="modal">
            <div class="modal-content">
                <span class="close-btn" onclick="closeModal()">&times;</span>
                <h3>تعديل التقييم</h3>
                <form id="editReviewForm" method="post" action="edit_review.php">
                    <input type="hidden" name="review_id" id="edit_review_id">
                    <input type="hidden" name="product_id" value="<?= htmlspecialchars($product_id) ?>">

                    <?php if (isset($_GET['success'])): ?>
                        <div class="alert success">
                            <?php
                            switch ($_GET['success']) {
                                case 'edit':
                                    echo "✅ تم تعديل التقييم بنجاح.";
                                    break;
                                case 'submit':
                                    echo "✅ تم إرسال التقييم بنجاح.";
                                    break;
                            }
                            ?>
                        </div>
                    <?php elseif (isset($_GET['error']) && $_GET['error'] === 'exists'): ?>
                        <div class="alert error">
                            ⚠️ لقد قمت مسبقًا بتقييم هذا المنتج.
                        </div>
                    <?php endif; ?>

                    <label>التقييم:</label>
                    <select name="rating" id="edit_rating" required>
                        <option value="5">⭐⭐⭐⭐⭐</option>
                        <option value="4">⭐⭐⭐⭐</option>
                        <option value="3">⭐⭐⭐</option>
                        <option value="2">⭐⭐</option>
                        <option value="1">⭐</option>
                    </select>

                    <label>تعليقك:</label>
                    <textarea name="comment" id="edit_comment" rows="3" required></textarea>

                    <div style="display: flex; justify-content: space-between; margin-top: 15px;">
                        <button type="submit">حفظ التعديل</button>
                        <button type="button" onclick="closeModal()" style="background: #aaa; color:white;">إلغاء</button>
                    </div>
                </form>
            </div>
        </div>
    </section>
<?php else: ?>
    <p>يجب <a href="<?php echo SITE_URL; ?>pages/login.php">تسجيل الدخول</a> لإضافة تعليق أو تقييم.</p>
<?php endif; ?>

<script>
    // عرض/إخفاء المزيد من التقييمات
    document.addEventListener('DOMContentLoaded', function() {
        const toggleBtn = document.getElementById('toggleReviewsBtn');
        if (toggleBtn) {
            const hiddenReviews = document.querySelectorAll('.hidden-review');
            const reviewsContainer = document.getElementById('reviews-container');
            let isExpanded = false;

            toggleBtn.addEventListener('click', function() {
                isExpanded = !isExpanded;

                hiddenReviews.forEach(el => {
                    el.style.display = isExpanded ? 'block' : 'none';
                });

                toggleBtn.textContent = isExpanded ? 'عرض أقل' : 'عرض المزيد';

                if (!isExpanded && reviewsContainer) {
                    reviewsContainer.scrollIntoView({
                        behavior: 'smooth'
                    });
                }
            });
        }
    });

    // إدارة نافذة تعديل التقييم
    function openEditModal(reviewId, rating, comment) {
        document.getElementById('edit_review_id').value = reviewId;
        document.getElementById('edit_rating').value = rating;
        document.getElementById('edit_comment').value = comment;
        document.getElementById('editReviewModal').style.display = 'block';
    }

    function closeModal() {
        document.getElementById('editReviewModal').style.display = 'none';
    }

    window.onclick = function(event) {
        const modal = document.getElementById('editReviewModal');
        if (event.target === modal) {
            closeModal();
        }
    }

    // إخفاء رسائل النجاح/الخطأ بعد 4 ثوان
    setTimeout(function() {
        const alertBox = document.querySelector('.alert');
        if (alertBox) {
            alertBox.classList.add('fade-out');
            setTimeout(() => alertBox.remove(), 500);
        }
    }, 4000);
</script>
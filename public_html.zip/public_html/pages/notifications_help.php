<?php
/**
 * pages/notifications_help.php
 * --------------------------------------------------------------------
 * ✅ صفحة تعليمات: كيف تضمن وصول الإشعارات على الهاتف
 *
 * تشرح للمستخدمين:
 *   - لماذا قد لا تصل الإشعارات
 *   - كيفية إعداد Android و iOS
 *   - كيفية تثبيت التطبيق كـ PWA
 * --------------------------------------------------------------------
 */

require_once __DIR__ . '/../includes/db_connect.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

$pageTitle = "كيف تضمن وصول الإشعارات - " . SITE_NAME;
include __DIR__ . '/../includes/header.php';
?>

<style>
.help-container {
    max-width: 900px;
    margin: 40px auto;
    padding: 0 15px;
    font-family: 'Tajawal', sans-serif;
}

.help-hero {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    padding: 40px 30px;
    border-radius: 20px;
    text-align: center;
    margin-bottom: 30px;
    box-shadow: 0 10px 40px rgba(102, 126, 234, 0.3);
}

.help-hero h1 {
    font-size: 32px;
    margin: 0 0 10px;
    font-weight: 700;
}

.help-hero p {
    font-size: 16px;
    opacity: 0.95;
    margin: 0;
}

.help-section {
    background: white;
    border-radius: 16px;
    padding: 25px;
    margin-bottom: 20px;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
    border-right: 5px solid #667eea;
}

.help-section h2 {
    color: #333;
    font-size: 22px;
    margin: 0 0 15px;
    display: flex;
    align-items: center;
    gap: 10px;
}

.help-section h3 {
    color: #667eea;
    font-size: 18px;
    margin: 20px 0 10px;
}

.help-section p {
    color: #555;
    line-height: 1.7;
    margin-bottom: 12px;
}

.help-section ol,
.help-section ul {
    color: #555;
    line-height: 1.8;
    padding-right: 20px;
}

.help-section ol li,
.help-section ul li {
    margin-bottom: 8px;
}

.platform-badge {
    display: inline-block;
    padding: 4px 12px;
    border-radius: 20px;
    font-size: 13px;
    font-weight: 600;
    margin-left: 8px;
}

.badge-android {
    background: #e3f2fd;
    color: #1976d2;
}

.badge-ios {
    background: #fce4ec;
    color: #c2185b;
}

.badge-all {
    background: #e8f5e9;
    color: #2e7d32;
}

.tip-box {
    background: #fff3e0;
    border-right: 4px solid #ff9800;
    padding: 15px;
    border-radius: 8px;
    margin: 15px 0;
}

.tip-box strong {
    color: #e65100;
}

.warning-box {
    background: #ffebee;
    border-right: 4px solid #f44336;
    padding: 15px;
    border-radius: 8px;
    margin: 15px 0;
}

.warning-box strong {
    color: #c62828;
}

.success-box {
    background: #e8f5e9;
    border-right: 4px solid #4caf50;
    padding: 15px;
    border-radius: 8px;
    margin: 15px 0;
}

.success-box strong {
    color: #2e7d32;
}

.step-number {
    background: #667eea;
    color: white;
    width: 28px;
    height: 28px;
    border-radius: 50%;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    font-weight: bold;
    margin-left: 8px;
    font-size: 14px;
}

.toc {
    background: #f8f9fa;
    padding: 20px;
    border-radius: 12px;
    margin-bottom: 25px;
}

.toc h3 {
    margin: 0 0 12px;
    color: #333;
    font-size: 18px;
}

.toc ul {
    margin: 0;
    padding-right: 20px;
    color: #555;
}

.toc a {
    color: #667eea;
    text-decoration: none;
}

.toc a:hover {
    text-decoration: underline;
}

@media (max-width: 768px) {
    .help-hero h1 {
        font-size: 24px;
    }
    .help-hero p {
        font-size: 14px;
    }
    .help-section {
        padding: 20px 15px;
    }
    .help-section h2 {
        font-size: 18px;
    }
}
</style>

<div class="help-container">

    <div class="help-hero">
        <h1>📱 كيف تضمن وصول الإشعارات؟</h1>
        <p>دليل شامل لإعداد هاتفك لاستقبال إشعارات متجر ماريا</p>
    </div>

    <div class="toc">
        <h3>📋 المحتويات</h3>
        <ul>
            <li><a href="#install">1. تثبيت التطبيق (مهم جداً)</a></li>
            <li><a href="#android">2. إعدادات Android</a></li>
            <li><a href="#ios">3. إعدادات iOS</a></li>
            <li><a href="#troubleshoot">4. استكشاف الأخطاء</a></li>
            <li><a href="#faq">5. أسئلة شائعة</a></li>
        </ul>
    </div>

    <!-- 1. تثبيت التطبيق -->
    <div class="help-section" id="install">
        <h2>
            <span class="step-number">1</span>
            تثبيت التطبيق <span class="platform-badge badge-all">الكل</span>
        </h2>
        <p>
            للحصول على أفضل تجربة مع الإشعارات، نوصي بتثبيت التطبيق كـ PWA (Progressive Web App).
            هذا يجعل الإشعارات تعمل بشكل أقوى وموثوق أكثر.
        </p>

        <h3>📱 على Android (Chrome):</h3>
        <ol>
            <li>افتح موقع متجر ماريا في Chrome</li>
            <li>اضغط زر القائمة (⋮) في أعلى المتصفح</li>
            <li>اختر <strong>"تثبيت التطبيق"</strong> (Install app)</li>
            <li>اضغط <strong>"تثبيت"</strong></li>
            <li>ستجد أيقونة "ماريا" على شاشتك الرئيسية</li>
        </ol>

        <h3>🍎 على iOS (Safari):</h3>
        <ol>
            <li>افتح موقع متجر ماريا في Safari</li>
            <li>اضغط زر المشاركة <strong>(مربع بسهم ↑)</strong></li>
            <li>اختر <strong>"Add to Home Screen"</strong></li>
            <li>اضغط <strong>"Add"</strong></li>
            <li>ستجد أيقونة "ماريا" على شاشتك الرئيسية</li>
        </ol>

        <div class="success-box">
            <strong>✅ بعد التثبيت:</strong> افتح التطبيق من الشاشة الرئيسية (وليس من المتصفح)
            للحصول على إشعارات أقوى!
        </div>
    </div>

    <!-- 2. إعدادات Android -->
    <div class="help-section" id="android">
        <h2>
            <span class="step-number">2</span>
            إعدادات Android <span class="platform-badge badge-android">Android فقط</span>
        </h2>
        <p>
            على Android، النظام لديه ميزة "تحسين البطارية" قد تحظر وصول الإشعارات.
            لتجنب ذلك، اتبع الخطوات التالية:
        </p>

        <h3>🔋 الخطوة 1: إلغاء تحسين البطارية للتطبيق</h3>
        <ol>
            <li>افتح <strong>الإعدادات</strong> → <strong>التطبيقات</strong></li>
            <li>ابحث عن <strong>"ماريا"</strong> (أو Chrome لو لم تثبت التطبيق)</li>
            <li>اضغط على <strong>"البطارية"</strong></li>
            <li>اختر <strong>"غير مقيّد" (Unrestricted)</strong>
                <ul>
                    <li>❌ ليس "مُحسَّن" (Optimized) - هذا يسبب تأخر الإشعارات!</li>
                    <li>❌ ليس "مقيّد" (Restricted)</li>
                </ul>
            </li>
        </ol>

        <h3>🔔 الخطوة 2: تفعيل الإشعارات</h3>
        <ol>
            <li>في نفس صفحة التطبيق → <strong>"الإشعارات"</strong></li>
            <li>فعّل <strong>"السماح بالإشعارات"</strong></li>
            <li>فعّل كل أنواع الإشعارات</li>
            <li>فعّل <strong>"تجاوز عدم الإزعاج"</strong> (لو متاح)</li>
        </ol>

        <h3>⚙️ الخطوة 3: إيقاف Doze Mode</h3>
        <ol>
            <li>افتح <strong>الإعدادات</strong> → <strong>البطارية</strong></li>
            <li>ابحث عن <strong>"تحسين البطارية"</strong> أو <strong>"Battery optimization"</strong></li>
            <li>اضغط على <strong>"جميع التطبيقات"</strong></li>
            <li>ابحث عن <strong>"ماريا"</strong></li>
            <li>اختر <strong>"عدم التحسين" (Don't optimize)</strong></li>
        </ol>

        <div class="warning-box">
            <strong>⚠️ ملاحظة مهمة:</strong>
            حتى بعد هذه الإعدادات، إذا أغلقت التطبيق قسراً (Force Stop) من إدارة التطبيقات،
            لن تصل الإشعارات حتى تفتحه مرة أخرى.
        </div>
    </div>

    <!-- 3. إعدادات iOS -->
    <div class="help-section" id="ios">
        <h2>
            <span class="step-number">3</span>
            إعدادات iOS <span class="platform-badge badge-ios">iOS فقط</span>
        </h2>
        <p>
            iOS أكثر تقييداً من Android، لكن يمكنك تحسين وصول الإشعارات بهذه الإعدادات:
        </p>

        <h3>🔔 تفعيل الإشعارات للتطبيق</h3>
        <ol>
            <li>افتح <strong>الإعدادات</strong> → <strong>"ماريا"</strong></li>
            <li>اضغط <strong>"الإشعارات"</strong></li>
            <li>فعّل <strong>"السماح بالإشعارات"</strong></li>
            <li>فعّل <strong>"الإشعارات المؤقتة" (Banners)</strong></li>
            <li>فعّل <strong>"الشارات" (Badges)</strong></li>
            <li>فعّل <strong>"الأصوات" (Sounds)</strong></li>
        </ol>

        <h3>🔄 تحديث التطبيق في الخلفية</h3>
        <ol>
            <li>افتح <strong>الإعدادات</strong> → <strong>عام</strong> → <strong>"تحديث التطبيق في الخلفية"</strong></li>
            <li>فعّل الخيار لـ <strong>"ماريا"</strong></li>
        </ol>

        <div class="warning-box">
            <strong>⚠️ قيود iOS:</strong>
            <ul>
                <li>iOS أقل من 16.4: لا يدعم إشعارات PWA على الإطلاق</li>
                <li>بعد ساعات من إغلاق التطبيق: قد لا تصل الإشعارات فوراً</li>
                <li>في وضع توفير الطاقة: قد تتأخر الإشعارات</li>
            </ul>
        </div>
    </div>

    <!-- 4. استكشاف الأخطاء -->
    <div class="help-section" id="troubleshoot">
        <h2>
            <span class="step-number">4</span>
            استكشاف الأخطاء <span class="platform-badge badge-all">الكل</span>
        </h2>

        <h3>❓ الإشعار لا يصل أبداً</h3>
        <ol>
            <li>تأكد أنك <strong>سمحت بالإشعارات</strong> عند فتح الموقع (اضغط الجرس 🔔)</li>
            <li>تأكد أن التطبيق <strong>مثبت كـ PWA</strong> (وليس مجرد اختصار)</li>
            <li>تحقق من <strong>إعدادات البطارية</strong> (Android) - اختر "غير مقيّد"</li>
            <li>تحقق من <strong>إعدادات الإشعارات</strong> للنظام</li>
            <li>افتح التطبيق مرة واحدة على الأقل يومياً (للحفاظ على SW نشط)</li>
        </ol>

        <h3>❓ الإشعار يصل متأخراً</h3>
        <ol>
            <li>هذا طبيعي على الهاتف بسبب <strong>Doze mode</strong></li>
            <li>الحل: فعّل <strong>"غير مقيّد"</strong> في إعدادات البطارية</li>
            <li>على Desktop: الإشعارات تصل فوراً</li>
        </ol>

        <h3>❓ الإشعار يصل فقط عند فتح التطبيق</h3>
        <p>هذا يعني أن:</p>
        <ul>
            <li>التطبيق مغلق قسراً (Force Stop)</li>
            <li>أو البطارية في وضع "مقيّد"</li>
            <li>أو Doze mode شديد (الهاتف ساكن لساعات)</li>
        </ul>
        <p>الحل: اتبع خطوات Android أعلاه</p>

        <h3>❓ لا أرى الجرس 🔔 في الموقع</h3>
        <ol>
            <li>تأكد أنك فتحت التطبيق (وليس مجرد زيارة الموقع)</li>
            <li>افتح الـ Console (F12) للتحقق من الأخطاء</li>
            <li>امسح cache المتصفح وأعد المحاولة</li>
        </ol>
    </div>

    <!-- 5. أسئلة شائعة -->
    <div class="help-section" id="faq">
        <h2>
            <span class="step-number">5</span>
            أسئلة شائعة <span class="platform-badge badge-all">الكل</span>
        </h2>

        <h3>❓ لماذا يعمل الإشعار على Desktop لكن ليس على الهاتف؟</h3>
        <p>
            على Desktop، Chrome يعمل في System Tray (شريط المهام) حتى لو أغلقت النوافذ،
            فيستقبل الإشعارات فوراً. أما على الهاتف، OS يحظر إيقاظ التطبيقات المغلقة لتوفير البطارية.
        </p>

        <h3>❓ هل أحتاج لفتح التطبيق يومياً؟</h3>
        <p>
            ننصح بفتح التطبيق مرة يومياً للحفاظ على نشاط Service Worker.
            لكن لو اتبعت إعدادات "البطارية غير مقيّدة"، قد لا يحتاج.
        </p>

        <h3>❓ هل الإشعارات تستهلك البطارية؟</h3>
        <p>
            لا بشكل ملحوظ. Web Push مُحسَّن جداً، ولا يوقظ التطبيق إلا عند وصول إشعار فعلي.
        </p>

        <h3>❓ لماذا لا أرى زر "تثبيت التطبيق"؟</h3>
        <p>
            قد يكون السبب:
        </p>
        <ul>
            <li>المتصفح لا يدعم PWA (مثل Firefox Private Mode)</li>
            <li>التطبيق مثبت بالفعل</li>
            <li>أنت تستخدم متصفح لا يدعم beforeinstallprompt</li>
        </ul>

        <h3>❓ هل أحتاج إنترنت لاستلام الإشعارات؟</h3>
        <p>
            نعم، الإشعارات تحتاج إنترنت للوصول من FCM لجهازك.
            لكن بمجرد وصولها، تُحفظ في الجهاز حتى لو فُقد الإنترنت بعدها.
        </p>
    </div>

    <div class="tip-box">
        <strong>💡 نصيحة:</strong>
        لاختبار الإشعارات، افتح التطبيق على هاتفك واضغط الجرس 🔔.
        إذا سمحت بالإشعارات، جرب إرسال إشعار من لوحة الإدارة.
    </div>

</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>

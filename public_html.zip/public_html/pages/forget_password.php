<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start([
        'cookie_lifetime' => 86400,
        'cookie_secure' => false, // ضع true إذا موقعك يستخدم https
        'cookie_httponly' => true,
        'cookie_samesite' => 'Lax'
    ]);
}

require_once __DIR__ . '/../includes/db_connect.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/smtp_config.php';
require_once __DIR__ . '/../vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

$errors = [];
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');

    if (empty($email)) {
        $errors[] = "البريد الإلكتروني مطلوب";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "البريد الإلكتروني غير صالح";
    } else {
        try {
            // التحقق من وجود البريد في قاعدة البيانات
            $stmt = $conn->prepare("SELECT id, username FROM users WHERE email = ?");
            $stmt->execute([$email]);
            $user = $stmt->fetch();

            if ($user) {
                // ضبط المنطقة الزمنية على +03:00 قبل إنشاء الرمز
                $conn->exec("SET time_zone = '+03:00'");

                // إنشاء رمز إعادة تعيين وتاريخ انتهاء الصلاحية
                $reset_token = bin2hex(random_bytes(32));
                $expires_at = date('Y-m-d H:i:s', strtotime('+1 hour'));

                // حفظ الرمز في قاعدة البيانات
                $stmt = $conn->prepare("UPDATE users SET reset_token = ?, reset_token_expires = ? WHERE id = ?");
                $stmt->execute([$reset_token, $expires_at, $user['id']]);

                // إرسال رابط إعادة التعيين
                $reset_link = SITE_URL . "pages/reset_password.php?token=" . urlencode($reset_token);

                $mail = new PHPMailer(true);
                try {
                    // تهيئة SMTP من includes/smtp_config.php
                    configure_smtp($mail);
                    $mail->addAddress($email, $user['username']);

                    $mail->isHTML(true);
                    $mail->Subject = 'إعادة تعيين كلمة المرور';
                    $mail->Body = "
                        <div style='font-family: Arial, sans-serif; direction: rtl;'>
                            <h2>مرحباً {$user['username']}،</h2>
                            <p>لقد تلقينا طلباً لإعادة تعيين كلمة المرور الخاصة بحسابك.</p>
                            <p>اضغط على الرابط التالي لإعادة التعيين (صالح لمدة ساعة واحدة):</p>
                            <p><a href='$reset_link' style='background: #007bff; color: white; padding: 10px 15px; text-decoration: none; border-radius: 5px;'>إعادة تعيين كلمة المرور</a></p>
                            <p>إذا لم تطلب هذا الرابط، يرجى تجاهل هذه الرسالة.</p>
                            <hr>
                            <p>مع تحيات،<br>فريق متجرك الإلكتروني</p>
                        </div>
                    ";

                    $mail->send();
                    $success = true;
                } catch (Exception $e) {
                    $errors[] = "حدث خطأ في إرسال البريد: " . $e->getMessage();
                }
            } else {
                $success = true; // نفس الرسالة حتى لو البريد غير مسجل
            }
        } catch (PDOException $e) {
            $errors[] = "حدث خطأ في معالجة الطلب: " . $e->getMessage();
        }
    }
}
?>


<!DOCTYPE html>
<html lang="ar" dir="rtl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>استعادة كلمة المرور - متجرك الإلكتروني</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.rtl.min.css">
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>assets/css/auth.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>

<body class="auth-page">
    <div class="auth-container">
        <div class="auth-card">
            <div class="auth-header">
                <h1><i class="fas fa-key"></i> استعادة كلمة المرور</h1>
                <p>أدخل بريدك الإلكتروني لاستعادة حسابك</p>
            </div>

            <?php if (!empty($errors)): ?>
                <div class="alert alert-danger">
                    <?php foreach ($errors as $error): ?>
                        <p><?= htmlspecialchars($error) ?></p>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

            <?php if ($success): ?>
                <div class="alert alert-success">
                    <p>إذا كان البريد الإلكتروني مسجلاً لدينا، ستتلقى رابطاً لإعادة تعيين كلمة المرور.</p>
                    <p>الرجاء التحقق من بريدك (وعلبة الرسائل غير المرغوب فيها).</p>
                </div>
            <?php else: ?>
                <form method="POST" class="auth-form">
                    <div class="form-group">
                        <label for="email"><i class="fas fa-envelope"></i> البريد الإلكتروني</label>
                        <input type="email" id="email" name="email" required class="form-control"
                            value="<?= htmlspecialchars($email ?? '') ?>">
                    </div>

                    <button type="submit" class="btn btn-primary btn-block">
                        <i class="fas fa-paper-plane"></i> إرسال رابط التعيين
                    </button>

                    <div class="auth-footer mt-3">
                        <p>تذكرت كلمة المرور؟ <a href="<?php echo SITE_URL; ?>pages/login.php">سجل الدخول الآن</a></p>
                    </div>
                </form>
            <?php endif; ?>
        </div>
    </div>

    <script src="<?php echo SITE_URL; ?>assets/js/bootstrap.bundle.min.js"></script>
    <script>
        // تركيز المؤشر على حقل الإدخال عند تحميل الصفحة
        document.getElementById('email')?.focus();
    </script>
</body>

</html>
<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start([
        'cookie_lifetime' => 86400,
        'cookie_secure' => true,
        'cookie_httponly' => true,
        'cookie_samesite' => 'Lax'
    ]);
}

require_once __DIR__ . '/../includes/db_connect.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/smtp_config.php';
require_once __DIR__ . '/../vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

$errors = [
    'username' => '',
    'email' => '',
    'phone' => '',
    'password' => '',
    'confirm_password' => '',
    'general' => ''
];

$username = $email = $phone = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';

    // التحقق من البيانات (نفس الكود الحالي)
    if (empty($username)) {
        $errors['username'] = "يرجى إدخال اسم المستخدم";
    } elseif (strlen($username) < 3) {
        $errors['username'] = "اسم المستخدم قصير جداً (الحد الأدنى 3 أحرف)";
    } elseif (strlen($username) > 20) {
        $errors['username'] = "اسم المستخدم طويل جداً (الحد الأقصى 20 حرفاً)";
    } elseif (!preg_match('/^[\p{L}\p{N}_]+$/u', $username)) {
        $errors['username'] = "يسمح فقط بالأحرف والأرقام والشرطة السفلية (_)";
    }

    if (empty($email)) {
        $errors['email'] = "البريد الإلكتروني مطلوب";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = "البريد الإلكتروني غير صالح";
    }

    if (empty($phone)) {
        $errors['phone'] = "رقم الهاتف مطلوب";
    } elseif (!preg_match('/^(7[1378]\d{7}|\+9677[1378]\d{6})$/', $phone)) {
        $errors['phone'] = "رقم الهاتف غير صحيح";
    }

    if (empty($password)) {
        $errors['password'] = "كلمة المرور مطلوبة";
    } elseif (strlen($password) < 8) {
        $errors['password'] = "كلمة المرور يجب أن تكون 8 أحرف على الأقل";
    }

    if (empty($confirm_password)) {
        $errors['confirm_password'] = "تأكيد كلمة المرور مطلوب";
    } elseif ($password !== $confirm_password) {
        $errors['confirm_password'] = "كلمتا المرور غير متطابقتين";
    }

    // التحقق من البريد ورقم الهاتف إذا لم توجد أخطاء مبدئية
    if (empty(array_filter($errors))) {
        try {
            // تحقق من البريد
            $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
            $stmt->execute([$email]);
            if ($stmt->fetch()) {
                $errors['email'] = "هذا البريد الإلكتروني مسجل مسبقاً";
            }

            // تحقق من رقم الهاتف
            $stmt = $conn->prepare("SELECT id FROM users WHERE phone = ?");
            $stmt->execute([$phone]);
            if ($stmt->fetch()) {
                $errors['phone'] = "رقم الهاتف مسجل مسبقاً";
            }

            // إذا لا يوجد أي أخطاء، قم بالتسجيل
            if (empty(array_filter($errors))) {
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                $activation_code = rand(100000, 999999); // كود التفعيل العشوائي

                // حفظ المستخدم مع وضع is_active = 0 حتى يتم التفعيل
                $stmt = $conn->prepare("INSERT INTO users (username, email, phone, password, role, avatar, is_active, activation_code, is_verified)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([
                    $username,
                    $email,
                    $phone,
                    $hashed_password,
                    'user',
                    'default-avatar.png',
                    0, // غير مفعل بعد
                    $activation_code,
                    0  // غير موثق بعد
                ]);

                // إرسال كود التفعيل عبر البريد
                $mail = new PHPMailer(true);

                try {
                    // تهيئة SMTP من includes/smtp_config.php
                    configure_smtp($mail);

                    // المستقبل
                    $mail->addAddress($email, $username);

                    // محتوى البريد
                    $mail->isHTML(true);
                    $mail->Subject = 'تفعيل حسابك في متجر ماريا';
                    $mail->Body = "
                        <div style='font-family: Arial, sans-serif; direction: rtl;'>
                            <h2>مرحباً $username،</h2>
                            <p>شكراً لتسجيلك في متجر ماريا الإلكتروني</p>
                            <p>كود التفعيل الخاص بك هو: <strong>$activation_code</strong></p>
                            <p>الرجاء إدخال هذا الكود في صفحة التفعيل لتفعيل حسابك.</p>
                            <p>إذا لم تطلب هذا الرمز، يرجى تجاهل هذه الرسالة.</p>
                            <hr>
                            <p>مع تحيات،<br>فريق متجر ماريا</p>
                            <br>
                            <p>للتواصل مع فريق الدعم 775232319</p>
                        </div>
                    ";

                    $mail->send();

                    // حفظ بيانات الجلسة للتحقق لاحقاً
                    $_SESSION['pending_activation_email'] = $email;
                    $_SESSION['activation_code'] = $activation_code;

                    header("Location: " . SITE_URL . "pages/activate.php");
                    exit;
                } catch (Exception $e) {
                    $errors['general'] = "حدث خطأ في إرسال بريد التفعيل: " . $e->getMessage();
                    // يمكنك تسجيل الخطأ في ملف log هنا
                }
            }
        } catch (PDOException $e) {
            // تحليل رسالة الخطأ لتحديد نوعه
            if (strpos($e->getMessage(), 'Duplicate entry') !== false && strpos($e->getMessage(), 'username') !== false) {
                $errors['username'] = "اسم المستخدم هذا مستخدم بالفعل، يرجى اختيار اسم آخر";
            } elseif (strpos($e->getMessage(), 'Duplicate entry') !== false && strpos($e->getMessage(), 'email') !== false) {
                $errors['email'] = "البريد الإلكتروني مسجل مسبقاً";
            } elseif (strpos($e->getMessage(), 'Duplicate entry') !== false && strpos($e->getMessage(), 'phone') !== false) {
                $errors['phone'] = "رقم الهاتف مسجل مسبقاً";
            } else {
                $errors['general'] = "حدث خطأ غير متوقع أثناء التسجيل. يرجى المحاولة لاحقاً.";
                // يمكنك تسجيل الخطأ الكامل للسجلات
                error_log("Registration Error: " . $e->getMessage());
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إنشاء حساب - متجرك الإلكتروني</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.rtl.min.css" integrity="sha384-Xbg45MqvDIk1e563NLpGEulpX6AvL404DP+/iCgW9eFa2BqztiwTexswJo2jLMue" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>assets/css/auth.css">
    <!-- <link rel="stylesheet" href="<?php echo SITE_URL; ?>assets/css/style.css"> -->
    <!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"> -->
</head>

<body class="auth-page">
    <div class="auth-container">
        <div class="auth-card">
            <div class="auth-header">
                <h1><i class="fas fa-user-plus"></i> إنشاء حساب جديد</h1>
                <p>انضم إلينا واستمتع بتجربة تسوق فريدة</p>
            </div>

            <?php if (!empty($errors['general'])): ?>
                <div class="alert alert-danger"><?= htmlspecialchars($errors['general']) ?></div>
            <?php endif; ?>

            <form method="POST" class="auth-form" novalidate>
                <div class="form-group">
                    <label for="username"><i class="fas fa-user"></i> اسم المستخدم</label>
                    <input type="text" id="username" name="username" required class="form-control" value="<?= htmlspecialchars($username) ?>">
                    <?php if (!empty($errors['username'])): ?>
                        <small class="text-danger"><?= htmlspecialchars($errors['username']) ?></small>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <label for="email"><i class="fas fa-envelope"></i> البريد الإلكتروني</label>
                    <input type="email" id="email" name="email" required class="form-control" value="<?= htmlspecialchars($email) ?>">
                    <?php if (!empty($errors['email'])): ?>
                        <small class="text-danger"><?= htmlspecialchars($errors['email']) ?></small>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <label for="phone"><i class="fas fa-phone"></i> رقم الهاتف</label>
                    <input type="text" id="phone" name="phone" required class="form-control" value="<?= htmlspecialchars($phone) ?>">
                    <?php if (!empty($errors['phone'])): ?>
                        <small class="text-danger"><?= htmlspecialchars($errors['phone']) ?></small>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <label for="password"><i class="fas fa-lock"></i> كلمة المرور</label>
                    <input type="password" id="password" name="password" required class="form-control">
                    <?php if (!empty($errors['password'])): ?>
                        <small class="text-danger"><?= htmlspecialchars($errors['password']) ?></small>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <label for="confirm_password"><i class="fas fa-lock"></i> تأكيد كلمة المرور</label>
                    <input type="password" id="confirm_password" name="confirm_password" required class="form-control">
                    <?php if (!empty($errors['confirm_password'])): ?>
                        <small class="text-danger"><?= htmlspecialchars($errors['confirm_password']) ?></small>
                    <?php endif; ?>
                </div>

                <button type="submit" class="btn btn-primary btn-block">
                    <i class="fas fa-user-plus"></i> إنشاء حساب
                </button>

                <div class="auth-footer">
                    <p>لديك حساب بالفعل؟ <a href="<?php echo SITE_URL; ?>pages/login.php">سجل الدخول الآن</a></p>
                </div>
            </form>
        </div>

        <!-- <div class="auth-illustration">
            <img src="/online_store/assets/images/auth-register.svg" alt="إنشاء حساب">
        </div> -->
    </div>

    <script src="<?php echo SITE_URL; ?>assets/js/bootstrap.bundle.min.js"></script>
    <script>
        // التحقق من تطابق كلمات المرور في الفورم مباشرة
        document.getElementById('confirm_password').addEventListener('input', function() {
            const password = document.getElementById('password').value;
            if (this.value !== password && this.value.length > 0) {
                this.setCustomValidity("كلمتا المرور غير متطابقتين");
            } else {
                this.setCustomValidity("");
            }
        });
    </script>

    <!-- التحقق من تنسيق الحقول باستخدام JavaScript قبل -->
    <script>
        document.querySelector('.auth-form').addEventListener('submit', function(e) {
            let valid = true;
            const email = document.getElementById('email');
            const phone = document.getElementById('phone');
            const password = document.getElementById('password');
            const confirm = document.getElementById('confirm_password');

            // التحقق من البريد الإلكتروني
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(email.value)) {
                alert("يرجى إدخال بريد إلكتروني صحيح");
                email.focus();
                valid = false;
            }

            // التحقق من رقم الهاتف اليمني
            const phoneRegex = /^(7[1378]\d{7}|\+9677[1378]\d{6})$/;
            if (!phoneRegex.test(phone.value)) {
                alert("يرجى إدخال رقم هاتف يمني صحيح");
                phone.focus();
                valid = false;
            }

            // التحقق من طول كلمة المرور
            if (password.value.length < 8) {
                alert("كلمة المرور يجب أن تكون 8 أحرف على الأقل");
                password.focus();
                valid = false;
            }

            // تطابق كلمة المرور
            if (password.value !== confirm.value) {
                alert("كلمتا المرور غير متطابقتين");
                confirm.focus();
                valid = false;
            }

            if (!valid) e.preventDefault(); // منع الإرسال إن كان هناك خطأ
        });
    </script>

</body>

</html>
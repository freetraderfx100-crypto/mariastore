<?php
require_once __DIR__ . '/../includes/db_connect.php';
require_once __DIR__ . '/../includes/functions.php';


$stmt = $conn->query("SELECT * FROM blog_posts ORDER BY created_at DESC");
$posts = $stmt->fetchAll(PDO::FETCH_ASSOC);
include('../includes/header.php');

?>

<!DOCTYPE html>
<html lang="ar">

<head>
    <meta charset="UTF-8">
    <title>المدونة</title>
    <!-- <link rel="stylesheet" href="/online_store/assets/css/responsive.css"> -->
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>assets/css/style.css">
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>assets/css/blog.css">
</head>

<body>
    <h1>المدونة</h1>

    <div class="blog-container">
        <?php foreach ($posts as $post): ?>
            <div class="blog-post">
                <img src="<?php echo SITE_URL; ?>assets/images/uploads/<?= htmlspecialchars($post['image']) ?>" alt="<?= htmlspecialchars($post['title']) ?>" class="blog-image">

                <div class="blog-content">
                    <h2><?= htmlspecialchars($post['title']) ?></h2>
                    <p><?= mb_substr(strip_tags($post['content']), 0, 150) ?>...</p>
                    <p><strong>الكاتب:</strong> <?= htmlspecialchars($post['author']) ?> | <small><?= $post['created_at'] ?></small></p>
                    <a href="<?php echo SITE_URL; ?>pages/blog_details.php?slug=<?= urlencode($post['slug']) ?>">اقرأ المزيد</a>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</body>

</html>
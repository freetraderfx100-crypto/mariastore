<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start([
        'cookie_lifetime' => 86400,
        'cookie_secure' => true,
        'cookie_httponly' => true,
        'cookie_samesite' => 'Lax'
    ]);
}

require_once __DIR__ . '/../includes/db_connect.php';
require_once __DIR__ . '/../includes/functions.php';

// التحقق من وجود بريد في الجلسة
if (!isset($_SESSION['pending_activation_email']) || !isset($_SESSION['activation_code'])) {
    header("Location: " . SITE_URL . "pages/register.php");
    exit;
}

$errors = [];
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $entered_code = trim($_POST['activation_code'] ?? '');

    if (empty($entered_code)) {
        $errors[] = "يجب إدخال كود التفعيل";
    } elseif ($entered_code != $_SESSION['activation_code']) {
        $errors[] = "كود التفعيل غير صحيح";
    } else {
        try {
            // تفعيل الحساب في قاعدة البيانات
            $stmt = $conn->prepare("UPDATE users SET is_active = 1, is_verified = 1 WHERE email = ?");
            $stmt->execute([$_SESSION['pending_activation_email']]);

            // جلب بيانات المستخدم لتسجيل الدخول
            $stmt = $conn->prepare("SELECT id, username, email, phone, role FROM users WHERE email = ?");
            $stmt->execute([$_SESSION['pending_activation_email']]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($user) {
                // تسجيل الدخول
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['email'] = $user['email'];
                $_SESSION['phone'] = $user['phone'];
                $_SESSION['role'] = $user['role'];

                // مسح بيانات التفعيل من الجلسة
                unset($_SESSION['pending_activation_email']);
                unset($_SESSION['activation_code']);

                $success = true;

                // إعادة التوجيه بعد 3 ثواني
                header("Refresh: 3; url=" . SITE_URL);
            }
        } catch (PDOException $e) {
            $errors[] = "حدث خطأ في تفعيل الحساب: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تفعيل الحساب - متجرك الإلكتروني</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.rtl.min.css">
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>assets/css/auth.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>

<body class="auth-page">
    <div class="auth-container">
        <div class="auth-card">
            <div class="auth-header">
                <h1><i class="fas fa-user-check"></i> تفعيل الحساب</h1>
                <p>تم إرسال كود التفعيل إلى بريدك الإلكتروني</p>
            </div>

            <?php if (!empty($errors)): ?>
                <div class="alert alert-danger">
                    <?php foreach ($errors as $error): ?>
                        <p><?= htmlspecialchars($error) ?></p>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

            <?php if ($success): ?>
                <div class="alert alert-success">
                    <p>تم تفعيل حسابك بنجاح! سيتم توجيهك إلى الصفحة الرئيسية خلال ثوانٍ...</p>
                    <p><a href="<?php echo SITE_URL; ?>" class="alert-link">اضغط هنا إذا لم يتم التوجيه تلقائياً</a></p>
                </div>
            <?php else: ?>
                <form method="POST" class="auth-form">
                    <div class="form-group">
                        <label for="activation_code"><i class="fas fa-key"></i> كود التفعيل</label>
                        <input type="text" id="activation_code" name="activation_code" required
                            class="form-control" placeholder="أدخل الكود المكون من 6 أرقام"
                            maxlength="6" pattern="\d{6}">
                        <small class="text-muted">تحقق من بريدك الإلكتروني (وعلبة الرسائل غير المرغوب فيها)</small>
                    </div>

                    <button type="submit" class="btn btn-primary btn-block">
                        <i class="fas fa-check-circle"></i> تفعيل الحساب
                    </button>

                    <div class="text-center mt-3">
                        <a href="<?php echo SITE_URL; ?>pages/resend_activation.php" class="text-muted">لم تستلم الكود؟ إعادة إرسال</a>
                    </div>
                </form>
            <?php endif; ?>
        </div>
    </div>

    <script src="<?php echo SITE_URL; ?>assets/js/bootstrap.bundle.min.js"></script>
    <script>
        // تركيز المؤشر على حقل الإدخال عند تحميل الصفحة
        document.getElementById('activation_code')?.focus();

        // منع إدخال أي شيء غير أرقام
        document.getElementById('activation_code')?.addEventListener('input', function(e) {
            this.value = this.value.replace(/[^0-9]/g, '');
        });
    </script>
</body>

</html>
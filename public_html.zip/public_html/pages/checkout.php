<?php
session_start();
require_once __DIR__ . '/../includes/db_connect.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/visitor_tracking.php'; // إضافة هذا السطر

// إنشاء كائن تتبع الزوار
$visitorTracker = new VisitorTracker($conn);
$visitorTracker->recordPageView($_SERVER['REQUEST_URI']);

// التحقق من أن المستخدم قد مر عبر عملية التحقق من السلة
if (!isset($_SESSION['cart_validated'])) {
    header("Location: " . SITE_URL . "pages/cart.php");
    exit;
}

// السماح للزوار بإكمال عملية الشراء
if (!isset($_SESSION['user_id']) && !isset($_SESSION['guest_id'])) {
    // إنشاء معرف زائر إذا لم يكن موجوداً
    $_SESSION['guest_id'] = 'guest_' . uniqid() . '_' . time();
}

// إضافة هذه الدوال في بداية الملف بعد اتصال قاعدة البيانات

// إحداثيات المتجر الثابتة
define('STORE_LAT', 15.286037); // خط عرض المتجر
define('STORE_LON', 44.236734); // خط طول المتجر



// دالة لحساب المسافة باستخدام صيغة Haversine
function calculateDistance($lat1, $lon1, $lat2, $lon2)
{
    $earthRadius = 6371; // نصف قطر الأرض بالكيلومتر

    $dLat = deg2rad($lat2 - $lat1);
    $dLon = deg2rad($lon2 - $lon1);

    $a = sin($dLat / 2) * sin($dLat / 2) +
        cos(deg2rad($lat1)) * cos(deg2rad($lat2)) *
        sin($dLon / 2) * sin($dLon / 2);

    $c = 2 * atan2(sqrt($a), sqrt(1 - $a));

    return $earthRadius * $c;
}

// دالة للحصول على إحداثيات العنوان باستخدام Nominatim API
function getCoordinates($address)
{
    $url = "https://nominatim.openstreetmap.org/search?format=json&q=" . urlencode($address);

    $options = [
        'http' => [
            'header' => "User-Agent: YourAppName\r\n"
        ]
    ];

    $context = stream_context_create($options);
    $response = file_get_contents($url, false, $context);
    $data = json_decode($response, true);

    if (!empty($data)) {
        return [
            'lat' => (float)$data[0]['lat'],
            'lon' => (float)$data[0]['lon']
        ];
    }
    return null;
}

// دالة للتحقق من التوصيل المجاني
function isEligibleForFreeShipping($subtotal) {
    global $conn;
    
    try {
        $stmt = $conn->prepare("SELECT free_shipping_threshold FROM shipping_settings WHERE is_active = 1 ORDER BY id DESC LIMIT 1");
        $stmt->execute();
        $settings = $stmt->fetch();
        
        if ($settings && $settings['free_shipping_threshold'] > 0) {
            return $subtotal >= $settings['free_shipping_threshold'];
        }
        
        return false;
    } catch (PDOException $e) {
        error_log("Error checking free shipping: " . $e->getMessage());
        return false;
    }
}

// دالة محدثة لحساب تكلفة الشحن
function calculateShippingCost($distance, $subtotal = 0) {
    // التحقق من التوصيل المجاني أولاً
    if ($subtotal > 0 && isEligibleForFreeShipping($subtotal)) {
        return 0; // توصيل مجاني
    }
    
    // جلب إعدادات الشحن من قاعدة البيانات
    global $conn;

    $settings = [
        'base_cost' => 1000,
        'cost_per_km' => 100,
        'min_cost' => 1000,
        'max_cost' => 5000
    ];

    try {
        $stmt = $conn->query("SELECT base_cost, cost_per_km, min_cost, max_cost FROM shipping_settings WHERE is_active = 1 ORDER BY id DESC LIMIT 1");
        $db_settings = $stmt->fetch();

        if ($db_settings) {
            $settings = $db_settings;
        }
    } catch (PDOException $e) {
        error_log("Error fetching shipping settings: " . $e->getMessage());
    }

    // حساب التكلفة باستخدام الإعدادات من قاعدة البيانات
    $cost = $settings['base_cost'] + ($distance * $settings['cost_per_km']);

    // تقريب السعر لأقرب مئة
    $roundedCost = round($cost / 100) * 100;

    // تطبيق الحد الأدنى والأقصى
    return min(max($roundedCost, $settings['min_cost']), $settings['max_cost']);
}



$user_id = $_SESSION['user_id'];
$error = '';
$cart_items = [];
$subtotal = 0;
$shipping = 0;
$total = 0;

try {
    $cart_items = [];
    $subtotal = 0;
    $user_id = $_SESSION['user_id'] ?? null;
    $guest_id = $_SESSION['guest_id'] ?? null;

    // جلب عناصر السلة بناءً على نوع المستخدم
    if ($user_id) {
        // للمستخدمين المسجلين
        $stmt = $conn->prepare("SELECT id FROM carts WHERE user_id = ?");
        $stmt->execute([$user_id]);
        $cart = $stmt->fetch();

        if (!$cart) {
            header("Location: " . SITE_URL . "pages/cart.php");
            exit;
        }

        $cart_id = $cart['id'];

        // جلب عناصر السلة مع التحقق من المخزون
        // جلب عناصر السلة مع التحقق من المخزون
        $stmt = $conn->prepare("
            SELECT
                ci.id,
                p.id as product_id,
                p.name,
                ci.price,
                ci.quantity,
                ci.color,
                ci.size,
                ci.image_url,
                (SELECT pv.quantity 
                FROM product_variants pv 
                WHERE pv.product_id = ci.product_id 
                AND pv.color = ci.color 
                AND pv.size = ci.size 
                LIMIT 1) as stock_quantity,
                p.price as original_price, 
                p.discount_percentage 
            FROM cart_items ci
            JOIN products p ON ci.product_id = p.id
            WHERE ci.cart_id = ?
        ");
        $stmt->execute([$cart_id]);
        $cart_items = $stmt->fetchAll();
    } elseif ($guest_id && isset($_SESSION['guest_cart'])) {
        // للزوار - استخدام سلة الجلسة
        foreach ($_SESSION['guest_cart'] as $key => $item) {
            // جلب معلومات المنتج من قاعدة البيانات مع التحقق من المخزون
            // جلب معلومات المنتج من قاعدة البيانات مع التحقق من المخزون
            $stmt = $conn->prepare("
                SELECT 
                    p.id as product_id,
                    p.name,
                    p.price as original_price,
                    p.discount_percentage,
                    -- التحقق من المخزون بدون الاعتماد على image_url
                    (SELECT pv.quantity 
                    FROM product_variants pv 
                    WHERE pv.product_id = p.id 
                    AND pv.color = ? 
                    AND pv.size = ? 
                    LIMIT 1) as stock_quantity
                FROM products p
                WHERE p.id = ?
            ");
            $stmt->execute([
                $item['color'],
                $item['size'],
                $item['product_id']
            ]);
            $product_info = $stmt->fetch();

            if ($product_info) {
                $cart_items[] = [
                    'id' => $key, // استخدام المفتاح كمعرف مؤقت
                    'product_id' => $item['product_id'],
                    'name' => $product_info['name'],
                    'price' => $item['price'],
                    'quantity' => $item['quantity'],
                    'color' => $item['color'],
                    'size' => $item['size'],
                    'image_url' => $item['image_url'],
                    'stock_quantity' => $product_info['stock_quantity'] ?? 0,
                    'original_price' => $product_info['original_price'],
                    'discount_percentage' => $product_info['discount_percentage']
                ];
            }
        }
    }

    if (empty($cart_items)) {
        header("Location: " . SITE_URL . "pages/cart.php");
        exit;
    }

    // التحقق من توفر المنتجات مرة أخرى (حماية إضافية)
    // التحقق من توفر المنتجات مرة أخرى (حماية إضافية)
    $all_available = true;
    $unavailable_products = [];
    foreach ($cart_items as $item) {
        // التحقق من توفر الكمية
        if ($item['quantity'] > $item['stock_quantity']) {
            $all_available = false;
            $unavailable_products[] = [
                'name' => $item['name'],
                'color' => $item['color'],
                'size' => $item['size'],
                'requested' => $item['quantity'],
                'available' => $item['stock_quantity']
            ];
        }
        $subtotal += $item['price'] * $item['quantity'];
    }

    // إذا لم تكن جميع المنتجات متوفرة، أعد التوجيه إلى صفحة السلة
    if (!$all_available) {
        $_SESSION['unavailable_products'] = $unavailable_products;
        $_SESSION['cart_error'] = "بعض المنتجات في سلتك غير متوفرة بالكمية المطلوبة";
        header("Location: " . SITE_URL . "pages/cart.php");
        exit;
    }

    $total = $subtotal + $shipping;

    // التحقق من صحة القيم المحسوبة
    if (!is_numeric($subtotal) || !is_numeric($shipping) || !is_numeric($total)) {
        throw new Exception("قيم مالية غير صالحة: subtotal=$subtotal, shipping=$shipping, total=$total");
    }

    if (abs(($subtotal + $shipping) - $total) > 0.01) {
        throw new Exception("عدم تطابق في الحسابات: subtotal + shipping != total");
    }

    // معالجة إرسال الطلب
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['shipping_address'])) {
        if (!empty($error)) {
            throw new Exception($error);
        }

        $shipping_address = trim($_POST['shipping_address']);
        $payment_method = $_POST['payment_method'];

        // لو اختار وسيلة من قاعدة البيانات، نحفظ التفاصيل
        $payment_method_name = $payment_method;
        if (is_numeric($payment_method)) {
            $stmt = $conn->prepare("SELECT method_name, account_number FROM payment_methods WHERE id = ?");
            $stmt->execute([$payment_method]);
            $pm = $stmt->fetch();
            if ($pm) {
                $payment_method_name = $pm['method_name'] . ' - ' . $pm['account_number'];
            }
        }

        $latitude = $_POST['latitude'] ?? null;
        $longitude = $_POST['longitude'] ?? null;

        // حساب تكلفة الشحن إذا كانت هناك إحداثيات
        if ($latitude && $longitude) {
            $distance = calculateDistance(STORE_LAT, STORE_LON, $latitude, $longitude);
            $shipping = calculateShippingCost($distance, $subtotal);
            $total = $subtotal + $shipping;
        }

        // جمع معلومات الزائر إذا كان زائراً
        $guest_name = '';
        $guest_phone = '';
        $guest_email = '';

        if (!isset($_SESSION['user_id']) && isset($_SESSION['guest_id'])) {
            $guest_name = $_POST['guest_name'] ?? '';
            $guest_phone = $_POST['guest_phone'] ?? '';
            $guest_email = $_POST['guest_email'] ?? '';

            // التحقق من المعلومات الأساسية للزائر
            if (empty($guest_name) || empty($guest_phone)) {
                $error = "يرجى إدخال الاسم الكامل ورقم الهاتف لإكمال الطلب";
                throw new Exception($error);
            }

            // حفظ معلومات الزائر في الجلسة مؤقتاً
            $_SESSION['guest_info'] = [
                'name' => $guest_name,
                'phone' => $guest_phone,
                'email' => $guest_email
            ];
        }

        $conn->beginTransaction();

        try {
            // تحديد معرف المستخدم أو الزائر
            $order_user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;
            $order_guest_id = isset($_SESSION['guest_id']) ? $_SESSION['guest_id'] : null;

            // إنشاء الطلب مع معلومات الزائر
            $stmt = $conn->prepare("
            INSERT INTO orders 
            (user_id, guest_id, guest_name, guest_phone, guest_email, subtotal, shipping_cost, total_amount, status, payment_method, shipping_address, latitude, longitude, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'pending', ?, ?, ?, ?, NOW(), NOW())
            ");

            // تحويل NULL إلى قيمة مناسبة إذا لزم الأمر
            $order_user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;
            if ($order_user_id === null) {
                // إذا كان زائراً، يمكنك استخدام قيمة خاصة أو تركها NULL
                $order_user_id = null;
            }

            $stmt->execute([
                $order_user_id,      // قد يكون NULL للزوار
                $order_guest_id,
                $guest_name,
                $guest_phone,
                $guest_email,
                $subtotal,
                $shipping,
                $total,
                $payment_method,
                $shipping_address,
                $latitude,
                $longitude
            ]);

            $order_id = $conn->lastInsertId();

            // إضافة عناصر الطلب
            $stmt = $conn->prepare("
            INSERT INTO order_items 
            (order_id, product_id, quantity, price, color, size, image_url, original_price, discount_percentage) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");

            foreach ($cart_items as $item) {
                $stmt->execute([
                    $order_id,
                    $item['product_id'],
                    $item['quantity'],
                    $item['price'], // السعر بعد الخصم
                    $item['color'],
                    $item['size'],
                    $item['image_url'],
                    $item['original_price'], // السعر الأصلي
                    $item['discount_percentage'] // نسبة الخصم
                ]);
            }

            // تحديث المخزون
            $updateStmt = $conn->prepare("
                UPDATE product_variants 
                SET quantity = quantity - ? 
                WHERE product_id = ? 
                AND color = ? 
                AND size = ? 
                AND quantity >= ?
            ");
            foreach ($cart_items as $item) {
                $updateStmt->execute([
                    $item['quantity'],
                    $item['product_id'],
                    $item['color'],
                    $item['size'],
                    $item['quantity']
                ]);
                if ($updateStmt->rowCount() === 0) {
                    throw new Exception("فشل في تحديث المخزون للمنتج: {$item['name']}");
                }
            }

            // تنظيف السلة بعد إتمام الطلب
            if (isset($_SESSION['user_id'])) {
                // للمستخدمين المسجلين: حذف عناصر السلة
                $stmt = $conn->prepare("DELETE FROM cart_items WHERE cart_id = ?");
                $stmt->execute([$cart_id]);
            } elseif (isset($_SESSION['guest_id'])) {
                // للزوار: مسح سلة الجلسة
                unset($_SESSION['guest_cart']);
            }

            $conn->commit();

            // تنظيف الجلسة وإعادة التوجيه
            unset($_SESSION['cart_validated']);

            // حفظ رقم الطلب في الجلسة لعرضه في صفحة الشكر
            $_SESSION['last_order_id'] = $order_id;

            header("Location: " . SITE_URL . "pages/thank_you.php");
            exit;
        } catch (PDOException $e) {
            $conn->rollBack();
            $error = "حدث خطأ في قاعدة البيانات: " . $e->getMessage();
            error_log("Order Error: " . $e->getMessage());

            // تحقق من وجود الأعمدة المطلوبة
            if (
                strpos($e->getMessage(), 'guest_name') !== false ||
                strpos($e->getMessage(), 'guest_phone') !== false ||
                strpos($e->getMessage(), 'guest_email') !== false
            ) {
                $error .= "<br>تفاصيل الخطأ: تأكد من وجود الأعمدة guest_name, guest_phone, guest_email في جدول orders";
            } else {
                $error .= "<br>تفاصيل الخطأ: " . $e->getMessage();
            }
        }
    }
} catch (Exception $e) {
    $error = "حدث خطأ أثناء تنفيذ الطلب: " . $e->getMessage();
}

// تنظيف علامة التحقق من الجلسة إذا كان هناك خطأ
if (!empty($error)) {
    unset($_SESSION['cart_validated']);
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إتمام الطلب</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.rtl.min.css">

    <!-- <link rel="stylesheet" href="<?php echo SITE_URL; ?>assets/css/checkout.css"> -->
    <link rel="stylesheet" href="https://unpkg.com/leaflet/dist/leaflet.css" />
    <!-- إضافة SweetAlert2 -->
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>assets/css/sweetalert2.min.css">
    <!-- إضافة Font Awesome للأيقونات -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .alert-danger {
            color: #721c24;
            background-color: #f8d7da;
            border-color: #f5c6cb;
            padding: 10px;
            margin-bottom: 20px;
            border-radius: 4px;
        }

        .map-container {
            height: 400px;
            margin-bottom: 20px;
            border: 1px solid #ddd;
            border-radius: 4px;
            position: relative;
        }

        #map {
            height: 100%;
            width: 100%;
        }

        #locateMeBtn {
            position: absolute;
            top: 10px;
            right: 10px;
            z-index: 1000;
            padding: 5px 10px;
            background: white;
            border: 1px solid #ddd;
            border-radius: 4px;
            cursor: pointer;
        }

        .valid-location {
            border-color: #28a745 !important;
            background-color: #f8fff8 !important;
        }

        #shipping_address.invalid-location {
            border-color: #dc3545 !important;
            background-color: #fff8f8 !important;
        }
    </style>
</head>

<body>
    <div class="container py-5">
        <h2 class="text-center mb-4">إتمام الطلب</h2>

        <?php if (!empty($error)): ?>
            <div class="alert alert-danger text-center"><?= htmlspecialchars($error) ?></div>
            <div class="text-center mb-4">
                <a href="<?php echo SITE_URL; ?>pages/cart.php" class="btn btn-primary">العودة إلى السلة</a>
            </div>
        <?php else: ?>
            <div class="row">
                <div class="col-md-8 mx-auto">
                    <div class="card mb-4">
                        <div class="card-header">
                            <h4>تفاصيل الطلب</h4>
                        </div>
                        <div class="card-body">
                            <!-- في قسم عرض تفاصيل الطلب -->
                            <table class="table table-bordered">
                                <thead class="table-light">
                                    <tr>
                                        <th>المنتج</th>
                                        <th>السعر</th>
                                        <th>الكمية</th>
                                        <th>الإجمالي</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($cart_items as $item): ?>
                                        <tr>
                                            <td><?= htmlspecialchars($item['name']) ?></td>
                                            <td>
                                                <?php if ($item['discount_percentage'] > 0): ?>
                                                    <span class="text-decoration-line-through text-muted small">
                                                        <?= number_format($item['original_price'], 2) ?> ر.ي
                                                    </span><br>
                                                <?php endif; ?>
                                                <?= number_format($item['price'], 2) ?> ر.ي
                                                <?php if ($item['discount_percentage'] > 0): ?>
                                                    <br><small class="text-success">وفرت <?= number_format($item['original_price'] - $item['price'], 2) ?> ر.ي</small>
                                                <?php endif; ?>
                                            </td>
                                            <td><?= $item['quantity'] ?></td>
                                            <td><?= number_format($item['price'] * $item['quantity'], 2) ?> ر.ي</td>
                                        </tr>
                                    <?php endforeach; ?>
                                    <tr class="table-light">
                                        <td colspan="3" class="text-end">المجموع الفرعي</td>
                                        <td><?= number_format($subtotal, 2) ?> ر.ي</td>
                                    </tr>

                                    <!-- عرض خصم الشحن إذا كان مطبقًا -->
                                    <?php if (isset($shipping_discount) && $shipping_discount > 0): ?>
                                        <tr class="table-light">
                                            <td colspan="3" class="text-end">خصم الشحن (<?= $shipping_discount ?>%)</td>
                                            <td class="text-success">-<?= number_format($shipping * ($shipping_discount / 100), 2) ?> ر.ي</td>
                                        </tr>
                                    <?php endif; ?>

                                    <tr class="table-light">
                                        <td colspan="3" class="text-end">الشحن</td>
                                        <td id="shipping_cost">
                                            <?php if (isset($free_shipping_threshold) && $free_shipping_threshold && $subtotal >= $free_shipping_threshold): ?>
                                                <span class="text-success">مجاني</span>
                                            <?php else: ?>
                                                <?= number_format($shipping, 2) ?> ر.ي
                                            <?php endif; ?>
                                        </td>
                                    </tr>

                                    <tr class="table-primary fw-bold">
                                        <td colspan="3" class="text-end">الإجمالي النهائي</td>
                                        <td id="total_cost"><?= number_format($total, 2) ?> ر.ي</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <div class="card">
                        <div class="card-header">
                            <h4>معلومات العميل</h4>
                        </div>
                        <div class="card-body">
                            <?php
                            // جلب وسائل الدفع المفعلة من قاعدة البيانات
                            try {
                                $stmt = $conn->query("SELECT * FROM payment_methods WHERE is_active = 1 ORDER BY id DESC");
                                $payment_methods = $stmt->fetchAll(PDO::FETCH_ASSOC);
                            } catch (PDOException $e) {
                                $payment_methods = [];
                                error_log("Error fetching payment methods: " . $e->getMessage());
                            }
                            ?>

                            <form method="POST">
                                <?php if (!isset($_SESSION['user_id'])): ?>
                                    <!-- نموذج معلومات الزائر - داخل النموذج الرئيسي -->
                                    <div class="row">
                                        <div class="col-md-6 mb-3">
                                            <label for="guest_name" class="form-label">الاسم الكامل *</label>
                                            <input type="text" class="form-control" id="guest_name" name="guest_name" required
                                                value="<?= isset($_SESSION['guest_info']['name']) ? htmlspecialchars($_SESSION['guest_info']['name']) : '' ?>">
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <label for="guest_phone" class="form-label">رقم الهاتف *</label>
                                            <input type="tel" class="form-control" id="guest_phone" name="guest_phone" required
                                                value="<?= isset($_SESSION['guest_info']['phone']) ? htmlspecialchars($_SESSION['guest_info']['phone']) : '' ?>">
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <label for="guest_email" class="form-label">البريد الإلكتروني</label>
                                            <input type="email" class="form-control" id="guest_email" name="guest_email" placeholder="يمكنك تركه فارغ"
                                                value=" <?= isset($_SESSION['guest_info']['email']) ? htmlspecialchars($_SESSION['guest_info']['email']) : '' ?>">
                                        </div>
                                    </div>
                                <?php else: ?>
                                    <!-- عرض معلومات المستخدم المسجل -->
                                    <div class="alert alert-info">
                                        <strong>المستخدم:</strong> <?= $_SESSION['username'] ?><br>
                                        <strong>البريد الإلكتروني:</strong> <?= $_SESSION['email'] ?>
                                    </div>
                                <?php endif; ?>

                                <!-- باقي حقول النموذج هنا (بدون form إضافي) -->
                                <div class="mb-3">
                                    <label for="shipping_address" class="form-label">عنوان الشحن:</label>
                                    <input type="text" class="form-control" id="shipping_address" name="shipping_address" required readonly>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">حدد موقعك على الخريطة:</label>
                                    <div class="map-container">
                                        <button id="locateMeBtn" type="button" class="btn btn-sm btn-outline-primary" style="color: black;">📍 موقعي الحالي</button>
                                        <div id="map"></div>
                                    </div>
                                </div>

                                <div class="mb-3">
                                    <label for="address_search" class="form-label">ابحث عن عنوان:</label>
                                    <div class="input-group">
                                        <div class="position-relative w-100">
                                            <input type="text" class="form-control" id="address_search" placeholder="أدخل عنوان للبحث">
                                            <div id="suggestions" class="list-group"></div>
                                        </div>
                                        <button class="btn btn-outline-secondary" type="button" id="searchAddressBtn">بحث</button>
                                    </div>
                                </div>

                                <input type="hidden" id="latitude" name="latitude" value="">
                                <input type="hidden" id="longitude" name="longitude" value="">

                                <div class="mb-3">
                                    <label for="payment_method" class="form-label">طريقة الدفع:</label>
                                    <select class="form-select" name="payment_method" id="payment_method" required>
                                        <option value="">-- اختر وسيلة دفع --</option>
                                        <?php foreach ($payment_methods as $pm): ?>
                                            <option value="<?= htmlspecialchars($pm['id']) ?>">
                                                <?= htmlspecialchars($pm['method_name']) ?> - <?= htmlspecialchars($pm['account_number']) ?>
                                            </option>
                                        <?php endforeach; ?>
                                        <option value="cash">الدفع عند الاستلام</option>
                                    </select>
                                </div>


                                <div class="d-grid">
                                    <button type="submit" class="btn btn-success btn-lg">تأكيد الطلب</button>
                                </div>
                            </form> <!-- إغلاق النموذج الرئيسي هنا -->
                        </div>
                    </div>
                </div>
            <?php endif; ?>
            </div>

            <!-- إضافة مكتبات JavaScript -->
            <script src="https://unpkg.com/leaflet/dist/leaflet.js"></script>
            <script src="<?php echo SITE_URL; ?>assets/js/sweetalert2.min.js"></script>
            <script>
                // الخريطة والمتغيرات الأساسية
                const map = L.map('map').setView([<?= STORE_LAT ?>, <?= STORE_LON ?>], 13);
                L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                    attribution: '&copy; OpenStreetMap contributors'
                }).addTo(map);

                let marker = null;
                let storeMarker = L.marker([<?= STORE_LAT ?>, <?= STORE_LON ?>])
                    .addTo(map)
                    .bindPopup("موقع المتجر");

                // دالة لعرض رسائل SweetAlert2
                function showAlert(icon, title, text) {
                    return Swal.fire({
                        icon: icon,
                        title: title,
                        text: text,
                        confirmButtonText: 'حسناً',
                        customClass: {
                            confirmButton: 'btn btn-primary'
                        }
                    });
                }

                // دالة للتحقق من صحة الموقع مع SweetAlert2
                function validateLocation() {
                    const lat = document.getElementById('latitude').value;
                    const lng = document.getElementById('longitude').value;
                    const address = document.getElementById('shipping_address').value.trim();

                    if (!lat || !lng || !address || address === "جاري جلب العنوان..." || address === "تعذر الحصول على العنوان") {
                        showAlert('error', 'موقع غير صحيح', 'يجب تحديد موقع صحيح على الخريطة أو استخدام زر "موقعي الحالي" لتأكيد الطلب')
                            .then(() => {
                                document.getElementById('shipping_address').focus();
                            });
                        return false;
                    }

                    return true;
                }

                // تعديل حدث إرسال النموذج
                document.querySelector('form').addEventListener('submit', function(e) {
                    // التحقق من معلومات الزائر إذا كان زائراً
                    const isGuest = <?= !isset($_SESSION['user_id']) ? 'true' : 'false' ?>;

                    if (isGuest) {
                        const guestName = document.getElementById('guest_name').value.trim();
                        const guestPhone = document.getElementById('guest_phone').value.trim();

                        if (!guestName || !guestPhone) {
                            e.preventDefault();
                            showAlert('error', 'معلومات ناقصة', 'يرجى إدخال الاسم الكامل ورقم الهاتف لإكمال الطلب');
                            return false;
                        }
                    }

                    if (!validateLocation()) {
                        e.preventDefault();
                        return false;
                    }
                });

                // دالة للحصول على العنوان من الإحداثيات
                const addressCache = {};

                function getAddressFromCoordinates(lat, lng) {
                    const cacheKey = `${lat.toFixed(4)},${lng.toFixed(4)}`;
                    const addressField = document.getElementById('shipping_address');
                    addressField.classList.remove('valid-location');

                    if (addressCache[cacheKey]) {
                        addressField.value = addressCache[cacheKey];
                        addressField.classList.add('valid-location');
                        return;
                    }

                    addressField.value = "جاري جلب العنوان...";

                    fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}`)
                        .then(response => response.json())
                        .then(data => {
                            if (data && data.display_name) {
                                addressCache[cacheKey] = data.display_name;
                                addressField.value = data.display_name;
                                addressField.classList.add('valid-location');
                            } else {
                                addressField.value = "تعذر الحصول على العنوان";
                                addressField.classList.remove('valid-location');
                                showAlert('error', 'خطأ', 'تعذر الحصول على العنوان من الموقع المحدد');
                            }
                        })
                        .catch(error => {
                            console.error('Error fetching address:', error);
                            addressField.value = "حدث خطأ أثناء جلب العنوان";
                            addressField.classList.remove('valid-location');
                            showAlert('error', 'خطأ', 'حدث خطأ أثناء محاولة جلب العنوان');
                        });
                }

                // دالة لوضع العلامة على الخريطة
                function placeMarker(lat, lng) {
                    if (marker) {
                        marker.setLatLng([lat, lng]);
                    } else {
                        marker = L.marker([lat, lng]).addTo(map)
                            .bindPopup("موقع العميل");
                    }
                    document.getElementById('latitude').value = lat;
                    document.getElementById('longitude').value = lng;

                    getAddressFromCoordinates(lat, lng);
                    updateShippingCost(lat, lng);

                    document.getElementById('shipping_address').classList.add('valid-location');
                }

                // دالة لتحديث تكلفة الشحن
                // دالة محدثة لتحديث تكلفة الشحن وعرض التفاصيل
                // دالة محدثة لتحديث تكلفة الشحن
                function updateShippingCost(lat, lng) {
                    const subtotal = <?= $subtotal ?>;
                    const loadingAlert = Swal.fire({
                        title: 'جاري حساب تكلفة الشحن',
                        html: 'الرجاء الانتظار بينما نقوم بحساب تكلفة الشحن للموقع المحدد...',
                        allowOutsideClick: false,
                        didOpen: () => {
                            Swal.showLoading();
                        }
                    });

                    fetch(`calculate_shipping.php?lat=${lat}&lng=${lng}&subtotal=${subtotal}`)
                        .then(response => response.json())
                        .then(data => {
                            if (data.error) {
                                showAlert('error', 'خطأ', data.error);
                                return;
                            }

                            // تحديث الجدول
                            let shippingHtml = '';
                            if (data.is_free) {
                                shippingHtml = `<span class="text-success">مجاني</span>`;
                            } else {
                                shippingHtml = `
                    ${data.shipping.toFixed(2)} ر.ي
                    ${data.shipping_discount > 0 ? 
                        `<br><small class="text-success">وفرت ${data.shipping_discount.toFixed(2)} ر.ي</small>` : ''
                    }
                `;
                            }

                            document.getElementById('shipping_cost').innerHTML = shippingHtml;

                            const totalCost = subtotal + (data.is_free ? 0 : data.shipping);
                            document.getElementById('total_cost').textContent = totalCost.toFixed(2) + ' ر.ي';

                            // عرض رسالة تفصيلية
                            // في دالة updateShippingCost، عدّل جزء عرض الرسالة
                            // في دالة updateShippingCost، تحديث جزء عرض التفاصيل
                            let messageHtml = `
                        <div style="text-align: right; direction: rtl;">
                            <div style="margin-bottom: 15px;">
                                <h5 style="color: #28a745;">تم تحديد موقع الشحن بنجاح</h5>
                                <p style="margin-bottom: 5px;"><i class="fas fa-map-marker-alt" style="color: #dc3545;"></i> <strong>موقعك الحالي:</strong> ${document.getElementById('shipping_address').value}</p>
                            </div>
                            
                            <div style="background: #f8f9fa; padding: 15px; border-radius: 5px; margin-bottom: 15px;">
                                <p style="margin-bottom: 5px;"><i class="fas fa-route" style="color: #17a2b8;"></i> <strong>المسافة من المتجر:</strong> ${data.distance} كيلومتر</p>
                    `;

                            if (data.is_free) {
                                messageHtml += `
                                <p style="margin-bottom: 5px; color: #28a745;">
                                    <i class="fas fa-gift" style="color: #28a745;"></i> 
                                    <strong>التوصيل مجاني!</strong>
                                </p>
                                <p style="margin-bottom: 0; font-size: 0.9em;">${data.reason}</p>
                        `;
                            } else {
                                messageHtml += `
                                
                        `;

                                if (data.shipping_discount > 0) {
                                    messageHtml += `
                                <p style="margin-bottom: 5px; color: #28a745;">
                                    <i class="fas fa-tag" style="color: #28a745;"></i> 
                                    <strong>خصم الشحن:</strong> 
                                    -${data.shipping_discount.toFixed(2)} ريال يمني
                                </p>
                            `;
                                }

                                messageHtml += `
                                <p style="margin-bottom: 0;">
                                    <i class="fas fa-money-bill-wave" style="color: #28a745;"></i> 
                                    <strong>تكلفة الشحن النهائية:</strong> 
                                    ${data.shipping.toFixed(2)} ريال يمني
                                </p>
                        `;
                            }

                            messageHtml += `
                            </div>
                            
                            <div style="background: #e9ecef; padding: 10px; border-radius: 5px;">
                                <p style="margin-bottom: 0;">
                                    <i class="fas fa-receipt" style="color: #6f42c1;"></i> 
                                    <strong>الإجمالي النهائي:</strong> ${totalCost.toFixed(2)} ريال يمني
                                </p>
                            </div>
                        </div>
                    `;

                            Swal.fire({
                                title: 'تفاصيل تكلفة الشحن',
                                html: messageHtml,
                                icon: 'success',
                                confirmButtonText: 'تم',
                                customClass: {
                                    popup: 'animated bounceIn'
                                }
                            });
                        })
                        .catch(error => {
                            loadingAlert.close();
                            console.error('Error calculating shipping:', error);
                            showAlert('error', 'خطأ', 'حدث خطأ أثناء حساب تكلفة الشحن. يرجى المحاولة مرة أخرى.');
                        });
                }

                // زر تحديد الموقع الحالي
                document.getElementById('locateMeBtn').addEventListener('click', () => {
                    if (navigator.geolocation) {
                        showAlert('info', 'جاري تحديد الموقع', 'الرجاء الانتظار بينما نقوم بتحديد موقعك الحالي', false);

                        navigator.geolocation.getCurrentPosition(
                            (position) => {
                                Swal.close();
                                const lat = position.coords.latitude;
                                const lng = position.coords.longitude;
                                map.setView([lat, lng], 15);
                                placeMarker(lat, lng);
                            },
                            (error) => {
                                let errorMessage;
                                switch (error.code) {
                                    case error.PERMISSION_DENIED:
                                        errorMessage = "تم رفض طلب تحديد الموقع. يرجى السماح بالوصول إلى الموقع.";
                                        break;
                                    case error.POSITION_UNAVAILABLE:
                                        errorMessage = "معلومات الموقع غير متوفرة.";
                                        break;
                                    case error.TIMEOUT:
                                        errorMessage = "انتهت مهلة طلب تحديد الموقع.";
                                        break;
                                    default:
                                        errorMessage = "حدث خطأ غير معروف أثناء تحديد الموقع.";
                                }
                                showAlert('error', 'خطأ في تحديد الموقع', errorMessage);
                            }, {
                                enableHighAccuracy: true,
                                timeout: 10000,
                                maximumAge: 0
                            }
                        );
                    } else {
                        showAlert('error', 'غير مدعوم', 'المتصفح الخاص بك لا يدعم ميزة تحديد الموقع');
                    }
                });

                // البحث عن عنوان
                document.getElementById('searchAddressBtn').addEventListener('click', function() {
                    const address = document.getElementById('address_search').value;
                    if (!address.trim()) {
                        showAlert('warning', 'عنوان فارغ', 'الرجاء إدخال عنوان للبحث');
                        return;
                    }

                    showAlert('info', 'جاري البحث', 'الرجاء الانتظار بينما نبحث عن العنوان المطلوب', false);

                    fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(address)}`)
                        .then(response => response.json())
                        .then(data => {
                            Swal.close();
                            if (data && data.length > 0) {
                                const lat = parseFloat(data[0].lat);
                                const lon = parseFloat(data[0].lon);
                                map.setView([lat, lon], 15);
                                placeMarker(lat, lon);
                            } else {
                                showAlert('warning', 'غير موجود', 'لم يتم العثور على العنوان المطلوب');
                            }
                        })
                        .catch(error => {
                            console.error('Error searching address:', error);
                            showAlert('error', 'خطأ', 'حدث خطأ أثناء البحث عن العنوان');
                        });
                });
                // ---------------------------------------------------------------------
                const addressInput = document.getElementById('address_search');
                const suggestionsBox = document.getElementById('suggestions');

                // عند الكتابة في مربع البحث
                addressInput.addEventListener('input', function() {
                    const query = this.value.trim();

                    // لا تبحث إذا النص قصير جدا
                    if (query.length < 3) {
                        suggestionsBox.innerHTML = '';
                        return;
                    }

                    fetch(`https://nominatim.openstreetmap.org/search?format=json&limit=5&q=${encodeURIComponent(query)}`)
                        .then(response => response.json())
                        .then(data => {
                            suggestionsBox.innerHTML = '';
                            if (data && data.length > 0) {
                                data.forEach(item => {
                                    const option = document.createElement('button');
                                    option.type = 'button';
                                    option.className = 'list-group-item list-group-item-action';
                                    option.textContent = item.display_name;

                                    // لما يضغط المستخدم على اقتراح
                                    option.addEventListener('click', () => {
                                        addressInput.value = item.display_name;
                                        suggestionsBox.innerHTML = '';

                                        // حرك الخريطة للمكان
                                        const lat = parseFloat(item.lat);
                                        const lon = parseFloat(item.lon);
                                        map.setView([lat, lon], 15);
                                        placeMarker(lat, lon);
                                    });

                                    suggestionsBox.appendChild(option);
                                });
                            }
                        })
                        .catch(err => console.error('Autocomplete error:', err));
                });

                // إخفاء القائمة إذا فقد التركيز
                document.addEventListener('click', function(e) {
                    if (!suggestionsBox.contains(e.target) && e.target !== addressInput) {
                        suggestionsBox.innerHTML = '';
                    }
                });

                // ----------------------------------------------------
                // النقر على الخريطة
                map.on('click', function(e) {
                    const lat = e.latlng.lat;
                    const lng = e.latlng.lng;
                    placeMarker(lat, lng);
                });

                // تحديث التكلفة عند تحميل الصفحة إذا كانت هناك إحداثيات مخزنة
                <?php if (isset($_POST['latitude']) && isset($_POST['longitude'])): ?>
                    placeMarker(<?= $_POST['latitude'] ?>, <?= $_POST['longitude'] ?>);
                <?php endif; ?>
            </script>
</body>

</html>
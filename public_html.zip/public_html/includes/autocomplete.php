<?php
require_once __DIR__ . '/db_connect.php';

header('Content-Type: application/json');

$query = isset($_GET['q']) ? trim($_GET['q']) : '';

if (strlen($query) < 2) {
    echo json_encode([]);
    exit();
}

try {
    $stmt = $conn->prepare("
        SELECT 
            p.id, 
            p.name, 
            p.price,
            COALESCE(
                (SELECT image_urls 
                 FROM product_variants 
                 WHERE product_id = p.id 
                 AND image_urls IS NOT NULL 
                 AND image_urls != '[]' 
                 LIMIT 1),
                'default-product-image.jpg'
            ) as image_data
        FROM products p
        WHERE p.name LIKE :query
        AND p.is_active = 1
        GROUP BY p.id
        ORDER BY p.name ASC
        LIMIT 3
    ");
    $stmt->execute([':query' => "%$query%"]);
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // معالجة بيانات الصور
    foreach ($results as &$item) {
        if ($item['image_data'] && $item['image_data'] !== 'default-product-image.jpg') {
            $images = json_decode($item['image_data'], true);
            if (is_array($images) && !empty($images)) {
                $item['image'] = $images[0]; // أخذ أول صورة
            } else {
                $item['image'] = 'default-product-image.jpg';
            }
        } else {
            $item['image'] = 'default-product-image.jpg';
        }
        unset($item['image_data']); // إزالة الحقل المؤقت
    }

    echo json_encode($results);
} catch (PDOException $e) {
    error_log("Autocomplete error: " . $e->getMessage());
    echo json_encode([]);
}

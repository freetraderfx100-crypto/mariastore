<?php
/**
 * includes/pwa_install_banner.php
 * --------------------------------------------------------------------
 * ✅ رسالة تشجيعية لتثبيت الموقع كـ PWA
 *
 * تظهر فقط:
 *   - على الهاتف (Mobile)
 *   - للمستخدمين الذين لم يثبتوا التطبيق بعد
 *   - لم يُغلقوا الرسالة يدوياً
 *
 * الفائدة:
 *   - إشعارات فورية تصل حتى لو المتصفح مغلق
 *   - تجربة مستخدم أفضل كتطبيق أصلي
 *   - أيقونة على الشاشة الرئيسية
 * --------------------------------------------------------------------
 */
?>
<style>
    /* ✅ banner مخفي افتراضياً - يظهر فقط على الهاتف */
    .pwa-install-banner {
        display: none;
        position: relative;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        padding: 20px 15px;
        margin: 15px 10px;
        border-radius: 16px;
        box-shadow: 0 8px 32px rgba(102, 126, 234, 0.3);
        font-family: 'Tajawal', 'Segoe UI', Tahoma, sans-serif;
        overflow: hidden;
        animation: pwaBannerSlide 0.5s ease-out;
    }

    .pwa-install-banner.show {
        display: flex;
        align-items: center;
        gap: 15px;
    }

    /* عناصر داخلية */
    .pwa-install-banner .banner-icon {
        flex-shrink: 0;
        width: 56px;
        height: 56px;
        background: rgba(255, 255, 255, 0.2);
        border-radius: 14px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 28px;
        backdrop-filter: blur(10px);
        border: 1px solid rgba(255, 255, 255, 0.3);
    }

    .pwa-install-banner .banner-content {
        flex: 1;
        min-width: 0;
    }

    .pwa-install-banner .banner-title {
        font-size: 17px;
        font-weight: 700;
        margin-bottom: 4px;
        display: flex;
        align-items: center;
        gap: 6px;
    }

    .pwa-install-banner .banner-text {
        font-size: 13px;
        line-height: 1.5;
        opacity: 0.95;
        margin-bottom: 10px;
    }

    .pwa-install-banner .banner-features {
        display: flex;
        flex-wrap: wrap;
        gap: 6px;
        margin-bottom: 12px;
    }

    .pwa-install-banner .feature-pill {
        background: rgba(255, 255, 255, 0.2);
        padding: 3px 10px;
        border-radius: 12px;
        font-size: 11px;
        font-weight: 500;
        backdrop-filter: blur(10px);
        border: 1px solid rgba(255, 255, 255, 0.25);
    }

    .pwa-install-banner .banner-actions {
        display: flex;
        gap: 8px;
        align-items: center;
    }

    .pwa-install-banner .install-btn {
        background: white;
        color: #667eea;
        border: none;
        padding: 9px 18px;
        border-radius: 10px;
        font-size: 14px;
        font-weight: 700;
        cursor: pointer;
        display: flex;
        align-items: center;
        gap: 6px;
        transition: all 0.2s ease;
        font-family: inherit;
    }

    .pwa-install-banner .install-btn:hover {
        transform: translateY(-1px);
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
    }

    .pwa-install-banner .install-btn:active {
        transform: translateY(0);
    }

    .pwa-install-banner .dismiss-btn {
        background: rgba(255, 255, 255, 0.15);
        color: white;
        border: 1px solid rgba(255, 255, 255, 0.3);
        padding: 8px 14px;
        border-radius: 10px;
        font-size: 13px;
        font-weight: 500;
        cursor: pointer;
        transition: all 0.2s ease;
        font-family: inherit;
    }

    .pwa-install-banner .dismiss-btn:hover {
        background: rgba(255, 255, 255, 0.25);
    }

    /* زر إغلاق في الزاوية */
    .pwa-install-banner .close-x {
        position: absolute;
        top: 10px;
        left: 10px;
        background: rgba(255, 255, 255, 0.2);
        border: none;
        color: white;
        width: 28px;
        height: 28px;
        border-radius: 50%;
        cursor: pointer;
        font-size: 18px;
        display: flex;
        align-items: center;
        justify-content: center;
        opacity: 0.8;
        transition: all 0.2s;
    }

    .pwa-install-banner .close-x:hover {
        opacity: 1;
        background: rgba(255, 255, 255, 0.3);
        transform: rotate(90deg);
    }

    /* أيقونة نبض للفت الانتباه */
    .pwa-install-banner .banner-icon::before {
        content: '';
        position: absolute;
        width: 56px;
        height: 56px;
        border-radius: 14px;
        background: rgba(255, 255, 255, 0.3);
        animation: pwaPulse 2s infinite;
    }

    @keyframes pwaBannerSlide {
        from { transform: translateY(-20px); opacity: 0; }
        to { transform: translateY(0); opacity: 1; }
    }

    @keyframes pwaPulse {
        0% { transform: scale(1); opacity: 0.6; }
        50% { transform: scale(1.15); opacity: 0; }
        100% { transform: scale(1); opacity: 0; }
    }

    /* يظهر فقط على الهاتف (max-width: 768px) */
    @media (max-width: 768px) {
        .pwa-install-banner {
            display: none;
        }
        .pwa-install-banner.show-mobile {
            display: flex;
        }
    }

    /* على Desktop يظهر بشكل مختلف (sidebar) */
    @media (min-width: 769px) {
        .pwa-install-banner {
            margin: 20px auto;
            max-width: 800px;
            padding: 25px 30px;
        }
        .pwa-install-banner .banner-icon {
            width: 64px;
            height: 64px;
            font-size: 32px;
        }
        .pwa-install-banner .banner-title {
            font-size: 20px;
        }
        .pwa-install-banner .banner-text {
            font-size: 14px;
        }
    }
</style>

<div id="pwaInstallBanner" class="pwa-install-banner" style="display: none;">
    <button class="close-x" onclick="dismissPwaBanner()" aria-label="إغلاق">&times;</button>

    <div class="banner-icon">
        📱
    </div>

    <div class="banner-content">
        <div class="banner-title">
            <i class="fas fa-bell" style="color: #ffe066;"></i>
            ثبّت تطبيق ماريا الآن!
        </div>
        <div class="banner-text">
            احصل على إشعارات فورية عند وصول منتجات جديدة والعروض الحصرية، حتى لو المتصفح مغلق.
        </div>
        <div class="banner-features">
            <span class="feature-pill">🔔 إشعارات فورية</span>
            <span class="feature-pill">🚀 أسرع في التصفح</span>
            <span class="feature-pill">💯 يعمل بدون إنترنت (جزئياً)</span>
        </div>
        <div class="banner-actions">
            <button class="install-btn" onclick="installPwaApp()">
                <i class="fas fa-download"></i>
                تثبيت التطبيق
            </button>
            <button class="dismiss-btn" onclick="dismissPwaBanner()">
                لاحقاً
            </button>
            <a href="<?php echo SITE_URL; ?>pages/notifications_help.php" 
               style="color: rgba(255,255,255,0.9); font-size: 12px; text-decoration: underline; margin-right: 8px;" 
               target="_blank">
                لماذا لا تصل الإشعارات؟
            </a>
        </div>
    </div>
</div>

<script>
    (function() {
        // ✅ إظهار الـ banner بعد تحميل الصفحة
        function showBannerIfAppropriate() {
            // لا تُظهر لو الموقع مثبت بالفعل (standalone mode)
            const isStandalone = window.matchMedia('(display-mode: standalone)').matches
                || window.navigator.standalone === true;

            if (isStandalone) {
                console.log('[PWA Banner] Standalone mode - hiding banner');
                return;
            }

            // لا تُظهر لو المستخدم أغلقها يدوياً
            const dismissed = localStorage.getItem('pwa_banner_dismissed');
            if (dismissed === '1') {
                console.log('[PWA Banner] User dismissed before - hiding');
                return;
            }

            // لا تُظهر لو مثبت بالفعل
            if (localStorage.getItem('pwa_installed') === '1') {
                console.log('[PWA Banner] Already installed - hiding');
                return;
            }

            // ✅ إظهار الـ banner
            const banner = document.getElementById('pwaInstallBanner');
            if (banner) {
                // ننتظر 2 ثانية بعد تحميل الصفحة
                setTimeout(() => {
                    banner.style.display = 'flex';
                    banner.classList.add('show');

                    // على الهاتف نضيف class منفصل
                    if (window.innerWidth <= 768) {
                        banner.classList.add('show-mobile');
                    }
                }, 2000);
            }
        }

        // ✅ إغلاق الـ banner
        window.dismissPwaBanner = function() {
            const banner = document.getElementById('pwaInstallBanner');
            if (banner) {
                banner.style.animation = 'pwaBannerSlide 0.3s reverse';
                setTimeout(() => {
                    banner.style.display = 'none';
                }, 300);
            }
            // حفظ في localStorage - لا تُظهر مجدداً لمدة 7 أيام
            const expiry = Date.now() + (7 * 24 * 60 * 60 * 1000);
            localStorage.setItem('pwa_banner_dismissed', JSON.stringify({
                value: '1',
                expiry: expiry
            }));
        };

        // ✅ التحقق من انتهاء صلاحية الإغلاق
        function checkDismissExpiry() {
            const dismissed = localStorage.getItem('pwa_banner_dismissed');
            if (!dismissed) return;

            try {
                const data = JSON.parse(dismissed);
                if (data.expiry && Date.now() > data.expiry) {
                    localStorage.removeItem('pwa_banner_dismissed');
                }
            } catch (e) {
                localStorage.removeItem('pwa_banner_dismissed');
            }
        }

        // ✅ زر التثبيت
        window.installPwaApp = function() {
            // نُطلق حدث click على زر التثبيت في pwa-install.js (لو موجود)
            const installBtn = document.getElementById('pwa-install-btn');
            if (installBtn) {
                installBtn.click();
            } else {
                // لو pwa-install.js لم يُحمّل بعد
                alert('📱 لتثبيت التطبيق:\n\nعلى Chrome: اضغط زر القائمة (⋮) ثم "Install app"\nعلى Safari (iOS): اضغط زر المشاركة ثم "Add to Home Screen"');
            }
        };

        // ✅ إخفاء الـ banner بعد التثبيت
        window.addEventListener('appinstalled', () => {
            const banner = document.getElementById('pwaInstallBanner');
            if (banner) banner.style.display = 'none';
            localStorage.setItem('pwa_installed', '1');
        });

        // ✅ بدء
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', () => {
                checkDismissExpiry();
                showBannerIfAppropriate();
            });
        } else {
            checkDismissExpiry();
            showBannerIfAppropriate();
        }
    })();
</script>

<?php
/**
 * includes/notifications.php
 * --------------------------------------------------------------------
 * النواة المركزية لنظام الإشعارات في متجر ماريا
 * 
 * ✅ إصدار الملف: v3.0 (مع علامة التحقق NOTIF_V3)
 * 
 * الميزات:
 *   - إنشاء إشعارات (new_product, new_discount, order, etc)
 *   - جلب إشعارات المستخدم (مع دعم الزوار)
 *   - تسجيل القراءة
 *   - إرسال Web Push (لو مفعّل)
 *   - العمل حتى لو كان المتصفح مغلقاً (عبر cron + Web Push)
 * 
 * لا يعتمد على مكتبات خارجية - يعمل بشكل افتراضي.
 * لإضافة Web Push الحقيقي (للمتصفح المغلق)، فعّل المفاتيح من الإعدادات.
 * --------------------------------------------------------------------
 */

// ✅ علامة الإصدار - تظهر في test_notifications.php للتحقق من رفع الملف
define('NOTIFICATIONS_PHP_VERSION', 'v3.0');

require_once __DIR__ . '/db_connect.php';

class NotificationsManager
{
    private $conn;
    private $settings = null;

    public function __construct($conn)
    {
        $this->conn = $conn;
        $this->loadSettings();
    }

    /**
     * تحميل الإعدادات من قاعدة البيانات
     */
    private function loadSettings()
    {
        try {
            $stmt = $this->conn->query("SELECT setting_key, setting_value FROM notification_settings");
            $this->settings = [];
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                $this->settings[$row['setting_key']] = $row['setting_value'];
            }
        } catch (PDOException $e) {
            $this->settings = [];
        }
    }

    /**
     * الحصول على قيمة إعداد
     */
    public function getSetting($key, $default = null)
    {
        return $this->settings[$key] ?? $default;
    }

    /**
     * تحديث إعداد
     */
    public function setSetting($key, $value)
    {
        $stmt = $this->conn->prepare("
            INSERT INTO notification_settings (setting_key, setting_value) 
            VALUES (?, ?) 
            ON DUPLICATE KEY UPDATE setting_value = ?
        ");
        $stmt->execute([$key, $value, $value]);
        $this->settings[$key] = $value;
    }

    /**
     * إنشاء إشعار جديد
     * 
     * @param array $data بيانات الإشعار
     *   - type: نوع الإشعار (new_product, new_discount, order, etc)
     *   - title: العنوان
     *   - body: النص
     *   - url: رابط عند النقر (اختياري)
     *   - image: صورة مصغرة (اختياري)
     *   - icon: أيقونة Font Awesome (اختياري، افتراضي: fa-bell)
     *   - target_audience: all|users|guests|admin (افتراضي: all)
     *   - target_user_id: معرف مستخدم محدد (اختياري)
     *   - metadata: بيانات إضافية JSON (اختياري)
     *   - scheduled_at: وقت الإرسال المجدول (اختياري)
     *   - send_push: إرسال Web Push فوراً (افتراضي: true)
     * @return int|false معرف الإشعار أو false
     */
    public function create($data)
    {
        try {
            // التحقق من الحقول المطلوبة
            if (empty($data['title']) || empty($data['body'])) {
                error_log("NotificationsManager::create - missing title or body");
                return false;
            }

            $type = $data['type'] ?? 'general';
            $title = trim($data['title']);
            $body = trim($data['body']);
            $url = !empty($data['url']) ? $data['url'] : null;
            $image = !empty($data['image']) ? $data['image'] : null;
            $icon = !empty($data['icon']) ? $data['icon'] : 'fa-bell';
            $target_audience = $data['target_audience'] ?? 'all';
            $target_user_id = !empty($data['target_user_id']) ? (int)$data['target_user_id'] : null;
            $metadata = !empty($data['metadata']) ? (is_string($data['metadata']) ? $data['metadata'] : json_encode($data['metadata'], JSON_UNESCAPED_UNICODE)) : null;
            $scheduled_at = !empty($data['scheduled_at']) ? $data['scheduled_at'] : null;
            $expires_at = !empty($data['expires_at']) ? $data['expires_at'] : null;

            // فحص الإعدادات: هل هذا النوع مفعّل؟
            if ($type === 'new_product' && !$this->getSetting('notify_new_product', '1')) {
                return false;
            }
            if ($type === 'new_discount' && !$this->getSetting('notify_new_discount', '1')) {
                return false;
            }

            $stmt = $this->conn->prepare("
                INSERT INTO notifications 
                    (type, title, body, url, image, icon, target_audience, target_user_id, 
                     metadata, scheduled_at, expires_at, created_at)
                VALUES 
                    (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
            ");

            $stmt->execute([
                $type, $title, $body, $url, $image, $icon,
                $target_audience, $target_user_id,
                $metadata, $scheduled_at, $expires_at
            ]);

            $notification_id = $this->conn->lastInsertId();

            // ✅ v2.2: لا نرسل Web Push هنا (كان يعطّل admin لـ 30+ ثانية)
            // الإرسال يتم عبر cron job كل 5 دقائق تلقائياً
            // لو أردت الإرسال الفوري، استدعِ sendPushToAllSubscribers() يدوياً

            return $notification_id;

        } catch (PDOException $e) {
            error_log("NotificationsManager::create error: " . $e->getMessage());
            return false;
        }
    }

    /**
     * جلب إشعارات مستخدم/زائر
     * 
     * @param int|null $user_id معرف المستخدم (NULL للزائر)
     * @param string $visitor_session معرف جلسة الزائر
     * @param int $limit عدد الإشعارات
     * @param int $offset للترقيم
     * @return array
     */
    public function getForUser($user_id = null, $visitor_session = null, $limit = 20, $offset = 0)
    {
        try {
            // ✅ استعلام مبسّط جداً - بدون LIMIT ? OFFSET ? ديناميكي
            // لأن بعض إعدادات PDO لا تدعم ? في LIMIT
            $limit = max(1, min(100, (int)$limit));
            $offset = max(0, (int)$offset);
            
            if ($user_id) {
                // مستخدم مسجل
                $sql = "
                    SELECT n.*
                    FROM notifications n
                    WHERE (target_audience IN ('all', 'users') OR target_user_id = :user_id)
                    AND (expires_at IS NULL OR expires_at > NOW())
                    ORDER BY n.created_at DESC
                    LIMIT $limit OFFSET $offset
                ";
                $stmt = $this->conn->prepare($sql);
                $stmt->execute([':user_id' => (int)$user_id]);
            } else {
                // زائر
                $sql = "
                    SELECT n.*
                    FROM notifications n
                    WHERE target_audience IN ('all', 'guests')
                    AND (expires_at IS NULL OR expires_at > NOW())
                    ORDER BY n.created_at DESC
                    LIMIT $limit OFFSET $offset
                ";
                $stmt = $this->conn->prepare($sql);
                $stmt->execute();
            }
            
            $notifications = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // تحديد حالة القراءة لكل إشعار + تحسين البيانات
            foreach ($notifications as &$notif) {
                $notif['is_read'] = $this->isRead($notif['id'], $user_id, $visitor_session);
                
                // تحويل metadata من JSON
                if (!empty($notif['metadata'])) {
                    $notif['metadata'] = json_decode($notif['metadata'], true);
                }
                
                // بناء URL الصورة مع ترميز المسافات في اسم الملف فقط (وليس المسار)
                if (!empty($notif['image'])) {
                    // ✅ فصل المسار عن اسم الملف، ترميز اسم الملف فقط
                    $image_path = $notif['image'];
                    $last_slash = strrpos($image_path, '/');
                    if ($last_slash !== false) {
                        $dir = substr($image_path, 0, $last_slash + 1);
                        $filename = substr($image_path, $last_slash + 1);
                        $notif['image_url'] = SITE_URL . 'assets/images/' . $dir . rawurlencode($filename);
                    } else {
                        $notif['image_url'] = SITE_URL . 'assets/images/' . rawurlencode($image_path);
                    }
                } else {
                    $notif['image_url'] = null;
                }
            }

            return $notifications;

        } catch (PDOException $e) {
            error_log("NotificationsManager::getForUser error: " . $e->getMessage());
            return [];
        }
    }

    /**
     * عدد الإشعارات غير المقروءة
     */
    public function getUnreadCount($user_id = null, $visitor_session = null)
    {
        try {
            $notifications = $this->getForUser($user_id, $visitor_session, 100, 0);
            $unread = 0;
            foreach ($notifications as $n) {
                if (empty($n['is_read'])) {
                    $unread++;
                }
            }
            return $unread;
        } catch (Exception $e) {
            return 0;
        }
    }

    /**
     * تسجيل قراءة إشعار
     *
     * ✅ إصلاح v2.0: عند تسجيل دخول زائر كان قد قرأ إشعاراتاً كزائر (بـ visitor_session)
     *    يجب ربط سجل القراءة بحسابه الجديد (user_id) لتفادي أن تظهر له الإشعارات
     *    "غير مقروءة" مرة أخرى بعد تسجيل الدخول.
     *
     *    المنطق:
     *    1. لو user_id موجود + visitor_session موجود → حدّث أي صفوف سابقة بـ visitor_session
     *       لنفس الإشعار وعيّن user_id لها (ترحيل سجل الزائر لحساب المستخدم).
     *    2. ثم INSERT IGNORE صف جديد (لو لم يكن موجوداً بالفعل).
     */
    public function markAsRead($notification_id, $user_id = null, $visitor_session = null)
    {
        try {
            $notification_id = (int) $notification_id;
            if ($notification_id <= 0) {
                return false;
            }

            // ✅ الخطوة 1: ترحيل سجل القراءة من visitor_session إلى user_id
            // (يُطبَّق فقط لو كان المستخدم مسجلاً ولديه visitor_session)
            if (!empty($user_id) && !empty($visitor_session)) {
                $stmt = $this->conn->prepare("
                    UPDATE notification_user_reads
                    SET user_id = ?, visitor_session = NULL
                    WHERE notification_id = ?
                      AND visitor_session = ?
                      AND (user_id IS NULL OR user_id = ?)
                ");
                $stmt->execute([$user_id, $notification_id, $visitor_session, $user_id]);
            }

            // ✅ الخطوة 2: INSERT صف القراءة الحالي
            // لو موجود مسبقاً (نفس user_id أو نفس visitor_session) سيُتجاهل بسبب UNIQUE keys
            $stmt = $this->conn->prepare("
                INSERT IGNORE INTO notification_user_reads
                    (notification_id, user_id, visitor_session, read_at)
                VALUES (?, ?, ?, NOW())
            ");
            $stmt->execute([
                $notification_id,
                !empty($user_id) ? $user_id : null,
                !empty($visitor_session) ? $visitor_session : null,
            ]);

            return true;
        } catch (PDOException $e) {
            error_log("NotificationsManager::markAsRead error: " . $e->getMessage());
            return false;
        }
    }

    /**
     * تسجيل قراءة كل الإشعارات
     */
    public function markAllAsRead($user_id = null, $visitor_session = null)
    {
        try {
            $notifications = $this->getForUser($user_id, $visitor_session, 100, 0);
            foreach ($notifications as $n) {
                $this->markAsRead($n['id'], $user_id, $visitor_session);
            }
            return true;
        } catch (Exception $e) {
            return false;
        }
    }

    /**
     * التحقق إذا كان إشعار مقروء
     */
    private function isRead($notification_id, $user_id = null, $visitor_session = null)
    {
        try {
            $sql = "SELECT id FROM notification_user_reads WHERE notification_id = ?";
            $params = [$notification_id];
            
            if ($user_id) {
                $sql .= " AND user_id = ?";
                $params[] = $user_id;
            } elseif ($visitor_session) {
                $sql .= " AND visitor_session = ?";
                $params[] = $visitor_session;
            } else {
                return false;
            }
            
            $stmt = $this->conn->prepare($sql);
            $stmt->execute($params);
            return $stmt->fetch() ? true : false;
        } catch (PDOException $e) {
            return false;
        }
    }

    /**
     * تسجيل اشتراك Web Push جديد
     */
    public function subscribePush($subscription, $user_id = null)
    {
        try {
            $endpoint = $subscription['endpoint'] ?? '';
            $p256dh = $subscription['keys']['p256dh'] ?? '';
            $auth = $subscription['keys']['auth'] ?? '';
            $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';

            if (empty($endpoint) || empty($p256dh) || empty($auth)) {
                return false;
            }

            $stmt = $this->conn->prepare("
                INSERT INTO push_subscriptions 
                    (user_id, endpoint, p256dh, auth, user_agent, created_at, is_active)
                VALUES (?, ?, ?, ?, ?, NOW(), 1)
                ON DUPLICATE KEY UPDATE 
                    p256dh = VALUES(p256dh),
                    auth = VALUES(auth),
                    user_agent = VALUES(user_agent),
                    is_active = 1,
                    last_used_at = NOW()
            ");

            return $stmt->execute([$user_id, $endpoint, $p256dh, $auth, $user_agent]);
        } catch (PDOException $e) {
            error_log("NotificationsManager::subscribePush error: " . $e->getMessage());
            return false;
        }
    }

    /**
     * إلغاء اشتراك Web Push
     */
    public function unsubscribePush($endpoint)
    {
        try {
            $stmt = $this->conn->prepare("
                UPDATE push_subscriptions SET is_active = 0 WHERE endpoint = ?
            ");
            return $stmt->execute([$endpoint]);
        } catch (PDOException $e) {
            return false;
        }
    }

    /**
     * جلب جميع الاشتراكات النشطة
     */
    public function getActiveSubscriptions($user_id = null)
    {
        try {
            $sql = "SELECT * FROM push_subscriptions WHERE is_active = 1";
            $params = [];
            
            if ($user_id !== null) {
                $sql .= " AND (user_id = ? OR user_id IS NULL)";
                $params[] = $user_id;
            }
            
            $stmt = $this->conn->prepare($sql);
            $stmt->execute($params);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            return [];
        }
    }

    /**
     * إرسال Web Push لجميع المشتركين
     * (يتم استدعاؤها من cron job لو Web Push مفعّل)
     *
     * ✅ إصلاح v2.2: فقط حدّث is_sent=1 لو نجح الإرسال لاشتراك واحد على الأقل
     *    لو فشل الكل، اترك is_sent=0 ليحاول cron مرة أخرى
     */
    public function sendPushToAllSubscribers($notification_id)
    {
        // تحميل ملف Web Push لو موجود
        $push_web_file = __DIR__ . '/push_web.php';
        if (!file_exists($push_web_file)) {
            error_log("sendPushToAllSubscribers: push_web.php not found");
            return ['sent' => 0, 'failed' => 0, 'details' => []];
        }

        require_once $push_web_file;

        $subscriptions = $this->getActiveSubscriptions();
        if (empty($subscriptions)) {
            error_log("sendPushToAllSubscribers: no active subscriptions");
            return ['sent' => 0, 'failed' => 0, 'details' => []];
        }

        $sent = 0;
        $failed = 0;
        $details = [];
        $errors_log_file = __DIR__ . '/../cron/push_errors.log';

        foreach ($subscriptions as $sub) {
            $detail = [
                'sub_id' => $sub['id'],
                'user_id' => $sub['user_id'] ?? null,
                'endpoint_short' => substr($sub['endpoint'], 0, 60),
                'success' => false,
                'error' => null,
            ];

            try {
                $result = sendWebPushNotification($sub, $notification_id, $this->conn);
                if ($result === true) {
                    $sent++;
                    $detail['success'] = true;
                } else {
                    $failed++;
                    $detail['error'] = is_string($result) ? $result : 'Unknown error';
                }
            } catch (Exception $e) {
                $failed++;
                $detail['error'] = $e->getMessage();
            }

            $details[] = $detail;
        }

        // ✅ v2.3: تسجيل تفاصيل الأخطاء في ملف منفصل
        if ($failed > 0) {
            $log_lines = [
                "[" . date('Y-m-d H:i:s') . "] notif#{$notification_id}",
                "  Sent: {$sent}/" . count($subscriptions) . ", Failed: {$failed}",
            ];
            foreach ($details as $d) {
                if (!$d['success']) {
                    $log_lines[] = "  X sub#{$d['sub_id']} (user={$d['user_id']}): {$d['error']}";
                    $log_lines[] = "     endpoint: {$d['endpoint_short']}";
                }
            }
            @file_put_contents($errors_log_file, implode("\n", $log_lines) . "\n\n", FILE_APPEND | LOCK_EX);
        }

        // ✅ فقط لو نجح إرسال واحد على الأقل، نحدّث is_sent=1
        if ($sent > 0) {
            $stmt = $this->conn->prepare("UPDATE notifications SET is_sent = 1 WHERE id = ?");
            $stmt->execute([$notification_id]);
            error_log("sendPushToAllSubscribers: notif#{$notification_id} sent to {$sent}/" . count($subscriptions) . " subs");
        } else {
            error_log("sendPushToAllSubscribers: notif#{$notification_id} FAILED for all " . count($subscriptions) . " subs. See push_errors.log");
        }

        return ['sent' => $sent, 'failed' => $failed, 'details' => $details];
    }

    /**
     * اختصار: إنشاء إشعار "منتج جديد"
     */
    public function notifyNewProduct($product_id, $product_name, $product_image = null, $product_url = null)
    {
        return $this->create([
            'type' => 'new_product',
            'title' => '🎉 منتج جديد!',
            'body' => "تمت إضافة منتج جديد: {$product_name}",
            'url' => $product_url ?: (SITE_URL . 'pages/details_product.php?id=' . $product_id),
            'image' => $product_image,
            'icon' => 'fa-box',
            'target_audience' => 'all',
            'metadata' => ['product_id' => $product_id],
        ]);
    }

    /**
     * اختصار: إنشاء إشعار "خصم جديد"
     */
    public function notifyNewDiscount($product_id, $product_name, $discount_percentage, $old_price, $new_price, $product_image = null)
    {
        return $this->create([
            'type' => 'new_discount',
            'title' => "🏷️ خصم {$discount_percentage}%!",
            'body' => "خصم خاص على: {$product_name} - من {$old_price} إلى {$new_price}",
            'url' => SITE_URL . 'pages/details_product.php?id=' . $product_id,
            'image' => $product_image,
            'icon' => 'fa-tag',
            'target_audience' => 'all',
            'metadata' => [
                'product_id' => $product_id,
                'discount_percentage' => $discount_percentage,
                'old_price' => $old_price,
                'new_price' => $new_price,
            ],
        ]);
    }
}

/**
 * تهيئة مدير الإشعارات (singleton)
 */
function getNotificationsManager($conn = null)
{
    static $manager = null;
    if ($manager === null) {
        global $conn;
        if (!$conn) {
            require_once __DIR__ . '/db_connect.php';
        }
        $manager = new NotificationsManager($conn);
    }
    return $manager;
}

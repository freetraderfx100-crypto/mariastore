<?php
// التحقق من أن المستخدم مدير بعد بدء الجلسة
require_once __DIR__ . '/../includes/auth.php';
checkAdminRole();

// بدء buffer المخرجات
ob_start();
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($page_title) ? $page_title . ' | ' : ''; ?>لوحة التحكم - ماريا</title>
    <!-- ✅ PWA Manifest للإشعارات في الخلفية -->
    <link rel="manifest" href="<?php echo SITE_URL; ?>manifest.json">
    <meta name="theme-color" content="#667eea">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <link rel="apple-touch-icon" href="<?php echo SITE_URL; ?>assets/icons/icon-192.png">
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>assets/css/admin.css">
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>assets/css/dash.css">
    <!-- <link rel="stylesheet" href="<?php echo SITE_URL; ?>assets/css/customers.css"> -->

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>

<body>
    <!-- طبقة التعتيم للقائمة الجانبية -->
    <div class="sidebar-overlay"></div>

    <div class="admin-wrapper">
        <!-- القائمة الجانبية -->
        <aside class="admin-sidebar">
            <div class="sidebar-header">
                <h2><i class="fas fa-crown"></i> إدارة المتجر</h2>
                <button class="sidebar-close"><i class="fas fa-times"></i></button>
            </div>

            <nav class="sidebar-nav">
                <ul>
                    <li class="<?= basename($_SERVER['PHP_SELF']) == 'dashboard.php' ? 'active' : '' ?>">
                        <a href="<?php echo SITE_URL; ?>admin/dashboard.php">
                            <i class="fas fa-tachometer-alt"></i> لوحة التحكم
                        </a>
                    </li>
                    <li class="<?= basename($_SERVER['PHP_SELF']) == 'manage_products.php' ? 'active' : '' ?>">
                        <a href="<?php echo SITE_URL; ?>admin/manage_products.php">
                            <i class="fas fa-box-open"></i> المنتجات
                        </a>
                    </li>
                    <li class="<?= basename($_SERVER['PHP_SELF']) == 'manage_categories.php' ? 'active' : '' ?>">
                        <a href="<?php echo SITE_URL; ?>admin/manage_categories.php">
                            <i class="fas fa-tags"></i> التصنيفات
                        </a>
                    </li>
                    <li class="<?= basename($_SERVER['PHP_SELF']) == 'orders.php' ? 'active' : '' ?>">
                        <a href="<?php echo SITE_URL; ?>admin/orders.php">
                            <i class="fas fa-shopping-cart"></i> الطلبات
                        </a>
                    </li>
                    <li class="<?= basename($_SERVER['PHP_SELF']) == 'customers.php' ? 'active' : '' ?>">
                        <a href="<?php echo SITE_URL; ?>admin/customers.php">
                            <i class="fas fa-users"></i> العملاء
                        </a>
                    </li>
                    <li class="<?= basename($_SERVER['PHP_SELF']) == 'reports.php' ? 'active' : '' ?>">
                        <a href="<?php echo SITE_URL; ?>admin/reports.php">
                            <i class="fas fa-chart-bar"></i> التقارير
                        </a>
                    </li>

                    <li class="<?= basename($_SERVER['PHP_SELF']) == 'manage_sliders.php' ? 'active' : '' ?>">
                        <a href="<?php echo SITE_URL; ?>admin/manage_sliders.php">
                            <i class="fa-solid fa-sliders"></i> اداره السلايد
                        </a>
                    </li>

                    <li class="<?= basename($_SERVER['PHP_SELF']) == 'messages.php' ? 'active' : '' ?>">
                        <a href="<?php echo SITE_URL; ?>admin/messages.php">
                            <i class="fa-solid fa-message"></i> رسائل العملاء
                        </a>
                    </li>

                    <li class="<?= basename($_SERVER['PHP_SELF']) == 'blog_dashboard.php' ? 'active' : '' ?>">
                        <a href="<?php echo SITE_URL; ?>admin/blog_dashboard.php">
                            <i class="fa-solid">📋</i> ادارة المقالات
                        </a>
                    </li>

                    <li class="<?= basename($_SERVER['PHP_SELF']) == 'manage_discounts.php' ? 'active' : '' ?>">
                        <a href="<?php echo SITE_URL; ?>admin/manage_discounts.php">
                            <i class="fa-solid">🔖</i> ادارة الخصومات
                        </a>
                    </li>

                    <li class="<?= basename($_SERVER['PHP_SELF']) == 'notification_settings.php' ? 'active' : '' ?>">
                        <a href="<?php echo SITE_URL; ?>admin/notification_settings.php">
                            <i class="fas fa-bell me-2"></i> إعدادات الإشعارات
                        </a>
                    </li>

                    <li class="<?= basename($_SERVER['PHP_SELF']) == 'shipping_settings.php' ? 'active' : '' ?>">
                        <a href="<?php echo SITE_URL; ?>admin/shipping_settings.php" class="list-group-item list-group-item-action">
                            <i class="fas fa-truck me-2"></i> إعدادات الشحن
                        </a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo SITE_URL; ?>admin/admin_visitors.php">
                            <i class="fas fa-users"></i>
                            <span>إحصاءات الزوار</span>
                        </a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo SITE_URL; ?>admin/payment_methods.php">
                            <i class="fas fa-money-check"></i>
                            <span>طرق الدفع</span>
                        </a>
                    </li>


                    <li class="divider"></li>
                    <li>
                        <a href="<?php echo SITE_URL; ?>" target="_blank">
                            <i class="fas fa-external-link-alt"></i> زيارة المتجر
                        </a>
                    </li>
                    <li class="divider"></li>
                    <li>
                        <a href="<?php echo SITE_URL; ?>admin/upload_excel.php">
                            <i class="fa-regular fa-file-excel"></i> رفع ملف اكسل
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo SITE_URL; ?>includes/logout.php">
                            <i class="fas fa-sign-out-alt"></i> تسجيل الخروج
                        </a>
                    </li>
                </ul>
            </nav>
        </aside>

        <!-- المحتوى الرئيسي -->
        <div class="admin-content">
            <!-- شريط التنقل العلوي -->
            <header class="admin-topbar">
                <div class="topbar-left">
                    <button class="sidebar-toggle">
                        <i class="fas fa-bars"></i>
                    </button>
                    <h3><?php echo isset($page_title) ? $page_title : 'لوحة التحكم'; ?></h3>
                </div>
                <div class="topbar-right">
                    <div class="admin-user">
                        <?php
                        // التحقق من وجود الصورة وتعيين الصورة الافتراضية إذا لزم الأمر
                        $avatar = $_SESSION['user_avatar'] ?? 'default-avatar.png';
                        $avatarPath = SITE_URL . 'assets/images/users/avatars/' . $avatar;

                        // إذا كانت الصورة غير موجودة أو فارغة، استخدم الصورة الافتراضية
                        if (empty($avatar) || $avatar === 'default-avatar.png' || !file_exists($_SERVER['DOCUMENT_ROOT'] . parse_url($avatarPath, PHP_URL_PATH))) {
                            $avatarPath = SITE_URL . 'assets/images/users/avatars/default-avatar.png';
                        }
                        ?>

                        <img src="<?= htmlspecialchars($avatarPath) ?>"
                            alt="صورة المستخدم"
                            class="user-avatar clickable"
                            onerror="this.src='<?= SITE_URL ?>assets/images/users/avatars/default-avatar.png'">

                        <span class="user-name"><?= htmlspecialchars($_SESSION['username'] ?? 'مستخدم') ?></span>
                        <i class="fas fa-chevron-down clickable"></i>
                        <div class="user-dropdown">
                            <a href="<?php echo SITE_URL; ?>admin/profile.php"><i class="fas fa-user"></i> الملف الشخصي</a>
                            <a href="<?php echo SITE_URL; ?>includes/logout.php"><i class="fas fa-sign-out-alt"></i> تسجيل الخروج</a>
                        </div>
                    </div>
                </div>
            </header>
            <script>
                // إضافة تأثير عند التمرير (اختياري)
                window.addEventListener('scroll', function() {
                    const topbar = document.querySelector('.admin-topbar');
                    if (window.scrollY > 10) {
                        topbar.classList.add('sticky');
                    } else {
                        topbar.classList.remove('sticky');
                    }
                });
            </script>

            <script>
                // إدارة القائمة الجانبية للهاتف
                document.addEventListener('DOMContentLoaded', function() {
                    const sidebar = document.querySelector('.admin-sidebar');
                    const sidebarToggle = document.querySelector('.sidebar-toggle');
                    const sidebarClose = document.querySelector('.sidebar-close');
                    const overlay = document.querySelector('.sidebar-overlay');
                    const adminUser = document.querySelector('.admin-user');
                    const userAvatar = document.querySelector('.user-avatar');
                    const chevronIcon = document.querySelector('.fa-chevron-down');
                    const userDropdown = document.querySelector('.user-dropdown');

                    // فتح القائمة الجانبية
                    sidebarToggle.addEventListener('click', function() {
                        sidebar.classList.add('active');
                        overlay.classList.add('active');
                        document.body.style.overflow = 'hidden';
                    });

                    // إغلاق القائمة الجانبية
                    function closeSidebar() {
                        sidebar.classList.remove('active');
                        overlay.classList.remove('active');
                        document.body.style.overflow = '';
                    }

                    sidebarClose.addEventListener('click', closeSidebar);
                    overlay.addEventListener('click', closeSidebar);

                    // إدارة القائمة المنسدلة للمستخدم عند النقر على الصورة أو الأيقونة
                    function toggleUserDropdown() {
                        userDropdown.classList.toggle('show');
                    }

                    // إضافة مستمعي الأحداث للعناصر القابلة للنقر
                    userAvatar.addEventListener('click', function(e) {
                        e.stopPropagation();
                        toggleUserDropdown();
                    });

                    chevronIcon.addEventListener('click', function(e) {
                        e.stopPropagation();
                        toggleUserDropdown();
                    });

                    // إغلاق القائمة المنسدلة عند النقر خارجها
                    document.addEventListener('click', function() {
                        userDropdown.classList.remove('show');
                    });

                    // منع إغلاق القائمة المنسدلة عند النقر عليها
                    userDropdown.addEventListener('click', function(e) {
                        e.stopPropagation();
                    });

                    // إغلاق القوائم عند تغيير حجم الشاشة
                    window.addEventListener('resize', function() {
                        if (window.innerWidth > 992) {
                            closeSidebar();
                            userDropdown.classList.remove('show');
                        }
                    });
                });
            </script>

            <!-- المحتوى الفعلي للصفحة سيتم إدراجه هنا -->
            <main class="content-wrapper">

                <!-- روابط -->
                <script src="<?php echo SITE_URL; ?>assets/js/sweetalert2.min.js"></script>

                <!-- ✅ نظام الإشعارات (للإدارة) -->
                <?php
                try {
                    require_once __DIR__ . '/notifications.php';
                    $notifMgr = new NotificationsManager($conn);
                    $notify_sound = $notifMgr->getSetting('notify_sound', '1');
                    $notify_dismiss = $notifMgr->getSetting('notify_auto_dismiss_seconds', '8');
                } catch (Exception $e) {
                    $notify_sound = '1';
                    $notify_dismiss = '8';
                }
                ?>
                <meta name="notify-sound" content="<?php echo htmlspecialchars($notify_sound); ?>">
                <meta name="notify-auto-dismiss" content="<?php echo htmlspecialchars($notify_dismiss); ?>">
                <?php
                // ✅ توليد CSRF token للإشعارات (للتحقق من POST requests)
                if (session_status() === PHP_SESSION_NONE) { session_start(); }
                if (empty($_SESSION['csrf_token'])) {
                    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
                }
                ?>
                <meta name="csrf-token" content="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                <!-- ✅ نظام الإشعارات الأصلي (VAPID + Web Push) -->
                <script src="<?php echo SITE_URL; ?>assets/js/notifications.js?v=<?php echo filemtime(__DIR__ . '/../assets/js/notifications.js'); ?>"></script>

        <!-- ✅ PWA Install Prompt - لتثبيت الموقع كتطبيق (يحسن وصول الإشعارات على الهاتف) -->
        <script src="<?php echo SITE_URL; ?>assets/js/pwa-install.js?v=<?php echo filemtime(__DIR__ . '/../assets/js/pwa-install.js'); ?>"></script>
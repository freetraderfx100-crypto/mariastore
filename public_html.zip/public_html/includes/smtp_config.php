<?php
/**
 * includes/smtp_config.php
 * --------------------------------------------------------------------
 * إعدادات SMTP المركزية.
 * يُستخدم في: register.php, resend_activation.php, forget_password.php
 *
 * بدلاً من تكرار إعدادات SMTP في كل ملف، نُعرّفها هنا مرة واحدة
 * ونقرأ القيم من ملف .env أو متغيرات البيئة.
 * --------------------------------------------------------------------
 */

require_once __DIR__ . '/env.php';

// إعدادات SMTP الافتراضية (تُقرأ من .env)
if (!defined('SMTP_HOST')) {
    define('SMTP_HOST', env('SMTP_HOST', 'smtp.gmail.com'));
}
if (!defined('SMTP_PORT')) {
    define('SMTP_PORT', (int) env('SMTP_PORT', '587'));
}
if (!defined('SMTP_SECURE')) {
    // قيم مقبولة: tls | ssl | (فارغ)
    define('SMTP_SECURE', env('SMTP_SECURE', 'tls'));
}
if (!defined('SMTP_USERNAME')) {
    define('SMTP_USERNAME', env('SMTP_USERNAME', ''));
}
if (!defined('SMTP_PASSWORD')) {
    define('SMTP_PASSWORD', env('SMTP_PASSWORD', ''));
}
if (!defined('SMTP_FROM_EMAIL')) {
    define('SMTP_FROM_EMAIL', env('SMTP_FROM_EMAIL', SMTP_USERNAME));
}
if (!defined('SMTP_FROM_NAME')) {
    define('SMTP_FROM_NAME', env('SMTP_FROM_NAME', SITE_NAME ?? 'ماريا ستور'));
}

/**
 * تهيئة كائن PHPMailer بإعدادات SMTP المركزية.
 *
 * @param  PHPMailer\PHPMailer\PHPMailer $mail
 * @return PHPMailer\PHPMailer\PHPMailer
 */
function configure_smtp(PHPMailer\PHPMailer\PHPMailer $mail): PHPMailer\PHPMailer\PHPMailer
{
    $mail->isSMTP();
    $mail->Host       = SMTP_HOST;
    $mail->SMTPAuth   = true;
    $mail->Username   = SMTP_USERNAME;
    $mail->Password   = SMTP_PASSWORD;
    $mail->Port       = SMTP_PORT;
    $mail->CharSet    = 'UTF-8';

    // ضبط نوع التشفير
    if (strtolower(SMTP_SECURE) === 'tls') {
        $mail->SMTPSecure = PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
    } elseif (strtolower(SMTP_SECURE) === 'ssl') {
        $mail->SMTPSecure = PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_SMTPS;
    }

    // المرسل الافتراضي
    $mail->setFrom(SMTP_FROM_EMAIL, SMTP_FROM_NAME);

    return $mail;
}

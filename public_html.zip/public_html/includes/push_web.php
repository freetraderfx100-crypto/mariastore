<?php
/**
 * includes/push_web.php
 * --------------------------------------------------------------------
 * دوال إرسال Web Push Notifications باستخدام Web Push API
 * 
 * يعمل بدون مكتبات خارجية - يستخدم cURL مباشرة.
 * يدعم تشفير AES128GCM (RFC 8291) و VAPID (RFC 8292).
 * 
 * متطلبات:
 *   - PHP 7.4+
 *   - openssl, curl, mbstring extensions
 *   - HTTPS على الإنتاج
 *   - مفاتيح VAPID (تُولّد من install_notifications.php أو يدوياً)
 * --------------------------------------------------------------------
 */

require_once __DIR__ . '/db_connect.php';
require_once __DIR__ . '/notifications.php';

/**
 * إرسال إشعار Web Push لاشتراك معيّن
 * 
 * @param array $subscription بيانات الاشتراك من جدول push_subscriptions
 * @param int $notification_id معرف الإشعار
 * @param PDO $conn اتصال قاعدة البيانات
 * @return bool نجح الإرسال أم لا
 */
function sendWebPushNotification($subscription, $notification_id, $conn)
{
    try {
        // جلب بيانات الإشعار
        $stmt = $conn->prepare("SELECT * FROM notifications WHERE id = ?");
        $stmt->execute([$notification_id]);
        $notif = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$notif) {
            return false;
        }

        // جلب مفاتيح VAPID
        $manager = new NotificationsManager($conn);
        $vapid_public = $manager->getSetting('vapid_public_key', '');
        $vapid_private = $manager->getSetting('vapid_private_key', '');
        $vapid_subject = $manager->getSetting('vapid_subject', 'mailto:admin@mariastore1.com');

        if (empty($vapid_public) || empty($vapid_private)) {
            error_log("WebPush: VAPID keys not configured");
            return false;
        }

        // ✅ إصلاح: ترميز اسم الملف فقط (وليس المسار كاملاً)
        $image_url = null;
        if (!empty($notif['image'])) {
            $image_path = $notif['image'];
            $last_slash = strrpos($image_path, '/');
            if ($last_slash !== false) {
                $dir = substr($image_path, 0, $last_slash + 1);
                $filename = substr($image_path, $last_slash + 1);
                $image_url = SITE_URL . 'assets/images/' . $dir . rawurlencode($filename);
            } else {
                $image_url = SITE_URL . 'assets/images/' . rawurlencode($image_path);
            }
        }
        
        // بناء payload
        $payload = json_encode([
            'id' => (int)$notif['id'],
            'type' => $notif['type'],
            'title' => $notif['title'],
            'body' => $notif['body'],
            'url' => $notif['url'] ?: '/',
            // ✅ استخدم صورة المنتج كأيقونة لو وجدت
            'icon' => $image_url ?: (SITE_URL . 'assets/icons/icon-192.png'),
            'badge' => SITE_URL . 'assets/icons/badge-72.png',
            'tag' => 'notif-' . $notif['id'],
            'image' => $image_url,
        ], JSON_UNESCAPED_UNICODE);

        // تشفير الـ payload (AES128GCM)
        $encrypted = encryptPayload($payload, $subscription['p256dh'], $subscription['auth']);
        if (!$encrypted) {
            error_log("WebPush: Encryption failed for subscription " . $subscription['id']);
            return false;
        }

        // بناء VAPID JWT
        $jwt = createVapidJWT($vapid_private, $vapid_public, $subscription['endpoint'], $vapid_subject);

        // إرسال الطلب (مع تمرير المفتاح العمومي للـ Authorization header)
        $result = sendPushRequest($subscription['endpoint'], $encrypted, $jwt, $vapid_public);

        if ($result['success']) {
            // تحديث last_used_at
            $stmt = $conn->prepare("UPDATE push_subscriptions SET last_used_at = NOW() WHERE id = ?");
            $stmt->execute([$subscription['id']]);
            return true;
        } else {
            $http_code = $result['http_code'] ?? 'no_response';
            $curl_error = $result['error'] ?? '';
            $response_body = $result['response'] ?? '';

            // ✅ v2.3: لو الـ endpoint لم يعد صالحاً، عطّل الاشتراك
            if (in_array($http_code, [404, 410])) {
                $stmt = $conn->prepare("UPDATE push_subscriptions SET is_active = 0 WHERE id = ?");
                $stmt->execute([$subscription['id']]);
                error_log("WebPush: Subscription {$subscription['id']} deactivated ({$http_code})");
            }

            // ✅ v2.4: لو VAPID credentials لا تطابق (403) → الاشتراك من مفاتيح قديمة
            // عطّله لأنه لن يعمل أبداً مع المفاتيح الحالية
            if ($http_code === 403) {
                $stmt = $conn->prepare("UPDATE push_subscriptions SET is_active = 0 WHERE id = ?");
                $stmt->execute([$subscription['id']]);
                error_log("WebPush: Subscription {$subscription['id']} deactivated (403 - VAPID mismatch - user needs to resubscribe)");
            }

            // ✅ v2.3: إرجاع رسالة خطأ مفصّلة بدلاً من false فقط
            $error_msg = "HTTP {$http_code}";
            if (!empty($curl_error)) {
                $error_msg .= " | cURL: {$curl_error}";
            }
            if (!empty($response_body)) {
                $error_msg .= " | Response: " . substr($response_body, 0, 200);
            }
            return $error_msg;
        }

    } catch (Exception $e) {
        error_log("WebPush error: " . $e->getMessage());
        return false;
    }
}

/**
 * تشفير الـ payload باستخدام AES128GCM (RFC 8291)
 */
function encryptPayload($payload, $userPublicKey, $userAuthKey)
{
    try {
        // تحويل المفاتيح من Base64URL إلى binary
        $userPublicKeyBinary = base64UrlDecode($userPublicKey);
        $userAuthKeyBinary = base64UrlDecode($userAuthKey);

        // ✅ التحقق من الأطوال
        if (strlen($userPublicKeyBinary) !== 65) {
            error_log("encryptPayload: invalid user public key length: " . strlen($userPublicKeyBinary));
            return false;
        }
        if (strlen($userAuthKeyBinary) !== 16) {
            error_log("encryptPayload: invalid auth key length: " . strlen($userAuthKeyBinary));
            return false;
        }

        // إنشاء زوج مفاتيح ECDH محلي (P-256)
        $localKey = openssl_pkey_new([
            'curve_name' => 'prime256v1',
            'private_key_type' => OPENSSL_KEYTYPE_EC,
        ]);
        if (!$localKey) {
            error_log("encryptPayload: openssl_pkey_new failed");
            return false;
        }

        // استخراج المفتاح العمومي المحلي بصيغة raw (65 بايت)
        $localDetails = openssl_pkey_get_details($localKey);
        if (!isset($localDetails['ec']['x']) || !isset($localDetails['ec']['y'])) {
            error_log("encryptPayload: failed to extract local EC key components");
            return false;
        }
        // ✅ المفتاح العمومي الخام: 0x04 + X (32) + Y (32) = 65 بايت
        $localPublicKeyRaw = "\x04" . $localDetails['ec']['x'] . $localDetails['ec']['y'];

        // ✅ بناء PEM من المفتاح العمومي للمستخدم (raw 65 بايت)
        // تحويل raw public key (uncompressed) إلى PEM
        $userPublicKeyPem = rawEcPublicKeyToPem($userPublicKeyBinary);
        if (!$userPublicKeyPem) {
            error_log("encryptPayload: failed to convert user public key to PEM");
            return false;
        }

        $userPublicKeyResource = openssl_pkey_get_public($userPublicKeyPem);
        if (!$userPublicKeyResource) {
            error_log("encryptPayload: openssl_pkey_get_public failed: " . openssl_error_string());
            return false;
        }

        // ✅ حساب shared secret باستخدام ECDH
        // محاولة مع openssl_pkey_derive (PHP 7.3+)
        $sharedSecret = '';
        if (function_exists('openssl_pkey_derive')) {
            $derived = openssl_pkey_derive($userPublicKeyResource, $localKey, 32);
            if ($derived === false) {
                error_log("encryptPayload: openssl_pkey_derive failed: " . openssl_error_string());
                return false;
            }
            $sharedSecret = $derived;
        } else {
            // طريقة بديلة: استخدام تجميع النقاط يدوياً (احتياطي)
            error_log("encryptPayload: openssl_pkey_derive not available");
            return false;
        }

        if (strlen($sharedSecret) !== 32) {
            error_log("encryptPayload: invalid shared secret length: " . strlen($sharedSecret));
            return false;
        }

        // ✅ اشتقاق المفاتيح باستخدام HKDF (RFC 5869)
        $salt = random_bytes(16);
        
        // IKM = shared secret
        // info for Content Encryption Key: "WebPush: info\0" + user_pub + local_pub
        $cekInfo = "WebPush: info\x00" . $userPublicKeyBinary . $localPublicKeyRaw;
        $contentEncryptionKey = hkdfSha256($sharedSecret, $salt, $cekInfo, 16);
        
        // info for Nonce: "Content-Encoding: nonce\0"
        $nonceInfo = "Content-Encoding: nonce\x00";
        $nonce = hkdfSha256($userAuthKeyBinary, $salt, $nonceInfo, 12);

        if (!$contentEncryptionKey || !$nonce) {
            error_log("encryptPayload: HKDF failed");
            return false;
        }

        // ✅ تشفير AES-128-GCM
        $tag = '';
        $ciphertext = openssl_encrypt($payload, 'aes-128-gcm', $contentEncryptionKey, OPENSSL_RAW_DATA, $nonce, $tag);
        if ($ciphertext === false) {
            error_log("encryptPayload: AES-GCM encryption failed: " . openssl_error_string());
            return false;
        }

        // ✅ بناء الـ payload النهائي (RFC 8291)
        // Format: salt (16) || rs (4) || idlen (2) || key (65) || ciphertext || tag (16)
        $result = $salt                              // 16 بايت salt
            . pack('N', 4096)                        // record size (4096)
            . pack('n', strlen($localPublicKeyRaw))  // key length (65)
            . $localPublicKeyRaw                     // 65 بايت
            . $ciphertext                            // encrypted data
            . $tag;                                  // 16 بايت GCM tag

        return $result;

    } catch (Exception $e) {
        error_log("encryptPayload exception: " . $e->getMessage());
        return false;
    }
}

/**
 * تحويل raw EC public key (65 بايت uncompressed) إلى PEM
 */
function rawEcPublicKeyToPem($rawKey)
{
    // raw = 0x04 + X (32) + Y (32) = 65 بايت
    if (strlen($rawKey) !== 65 || $rawKey[0] !== "\x04") {
        return false;
    }
    
    // بناء DER structure for SubjectPublicKeyInfo
    // AlgorithmIdentifier for EC (P-256):
    //   SEQUENCE { OID 1.2.840.10045.2.1 (ecPublicKey), OID 1.2.840.10045.3.1.7 (prime256v1) }
    $algo = pack(
        'H*',
        '301306072a8648ce3d020106082a8648ce3d030107'
    );
    
    // SubjectPublicKey: BIT STRING (raw key with 0 unused bits prefix)
    $bitString = "\x00" . $rawKey;  // 0 unused bits
    $bitStringHeader = "\x03" . derLength(strlen($bitString));
    $subjectPublicKey = $bitStringHeader . $bitString;
    
    // Full SubjectPublicKeyInfo
    $spki = "\x30" . derLength(strlen($algo) + strlen($subjectPublicKey)) . $algo . $subjectPublicKey;
    
    // Convert to PEM
    $b64 = base64_encode($spki);
    $pem = "-----BEGIN PUBLIC KEY-----\n";
    $pem .= chunk_split($b64, 64, "\n");
    $pem .= "-----END PUBLIC KEY-----\n";
    
    return $pem;
}

/**
 * بناء DER length bytes
 */
function derLength($length)
{
    if ($length < 0x80) {
        return chr($length);
    } elseif ($length < 0x100) {
        return "\x81" . chr($length);
    } else {
        return "\x82" . pack('n', $length);
    }
}

/**
 * HKDF-SHA256 (RFC 5869)
 */
function hkdfSha256($ikm, $salt, $info, $length)
{
    if (empty($salt)) {
        $salt = str_repeat("\x00", 32);
    }
    
    // Extract: PRK = HMAC-SHA256(salt, IKM)
    $prk = hash_hmac('sha256', $ikm, $salt, true);
    
    // Expand: T(N) = T(N-1) | info | N
    $okm = '';
    $t = '';
    $i = 1;
    while (strlen($okm) < $length) {
        $t = hash_hmac('sha256', $t . $info . chr($i), $prk, true);
        $okm .= $t;
        $i++;
    }
    
    return substr($okm, 0, $length);
}

/**
 * إنشاء VAPID JWT
 */
function createVapidJWT($privateKey, $publicKey, $endpoint, $subject)
{
    // استخراج origin من الـ endpoint
    $parsed = parse_url($endpoint);
    $origin = $parsed['scheme'] . '://' . $parsed['host'];
    if (!empty($parsed['port'])) {
        $origin .= ':' . $parsed['port'];
    }

    // Header
    $header = json_encode([
        'typ' => 'JWT',
        'alg' => 'ES256',
    ]);

    // Payload
    $payload = json_encode([
        'aud' => $origin,
        'exp' => time() + (60 * 60 * 12), // 12 ساعة
        'sub' => $subject,
    ]);

    // Base64URL encode
    $headerEncoded = base64UrlEncode($header);
    $payloadEncoded = base64UrlEncode($payload);

    $signingInput = $headerEncoded . '.' . $payloadEncoded;

    // ✅ تحميل المفتاح الخاص
    // المفتاح الخاص بتنسيق raw 32 بايت، نحوّله إلى PEM
    $privateKeyRaw = base64UrlDecode($privateKey);
    if (strlen($privateKeyRaw) !== 32) {
        error_log("createVapidJWT: invalid private key length: " . strlen($privateKeyRaw));
        return false;
    }
    
    $privateKeyPem = rawEcPrivateKeyToPem($privateKeyRaw);
    if (!$privateKeyPem) {
        error_log("createVapidJWT: failed to convert private key to PEM");
        return false;
    }
    
    $keyResource = openssl_pkey_get_private($privateKeyPem);
    if (!$keyResource) {
        error_log("createVapidJWT: openssl_pkey_get_private failed: " . openssl_error_string());
        return false;
    }

    // توقيع
    $signature = '';
    if (!openssl_sign($signingInput, $signature, $keyResource, 'sha256')) {
        error_log("createVapidJWT: openssl_sign failed: " . openssl_error_string());
        return false;
    }

    // تحويل التوقيع من DER إلى raw r||s (64 بايت)
    $rawSig = derToRawSignature($signature);
    if (strlen($rawSig) !== 64) {
        error_log("createVapidJWT: invalid raw signature length: " . strlen($rawSig));
        return false;
    }

    $signatureEncoded = base64UrlEncode($rawSig);

    return $signingInput . '.' . $signatureEncoded;
}

/**
 * تحويل raw EC private key (32 بايت) إلى PEM (PKCS#8)
 */
function rawEcPrivateKeyToPem($rawPrivateKey)
{
    if (strlen($rawPrivateKey) !== 32) {
        return false;
    }
    
    // بناء ECPrivateKey DER (RFC 5915):
    // SEQUENCE {
    //   INTEGER 1 (version)
    //   OCTET STRING (32 bytes) - private key d
    //   [0] OBJECT IDENTIFIER 1.2.840.10045.3.1.7 (prime256v1)
    //   [1] BIT STRING - public key (optional, can be omitted)
    // }
    
    // version: INTEGER 1
    $version = "\x02\x01\x01";
    
    // private key: OCTET STRING (32 bytes)
    $privKeyOctetString = "\x04\x20" . $rawPrivateKey;  // 0x04 = OCTET STRING, 0x20 = 32 bytes
    
    // OID for prime256v1 (P-256)
    $curveOid = "\x06\x08\x2a\x86\x48\xce\x3d\x03\x01\x07";  // 1.2.840.10045.3.1.7
    $curveWrapper = "\xa0" . derLength(strlen($curveOid)) . $curveOid;  // [0] explicit
    
    // Full ECPrivateKey SEQUENCE
    $ecPrivKeyContent = $version . $privKeyOctetString . $curveWrapper;
    $ecPrivKeyDer = "\x30" . derLength(strlen($ecPrivKeyContent)) . $ecPrivKeyContent;
    
    // Wrap in PKCS#8 PrivateKeyInfo:
    // SEQUENCE {
    //   INTEGER 0 (version)
    //   AlgorithmIdentifier (EC + prime256v1)
    //   OCTET STRING (ECPrivateKey)
    // }
    $algo = pack('H*', '301306072a8648ce3d020106082a8648ce3d030107');
    $pkcs8Content = "\x02\x01\x00" . $algo . "\x04" . derLength(strlen($ecPrivKeyDer)) . $ecPrivKeyDer;
    $pkcs8Der = "\x30" . derLength(strlen($pkcs8Content)) . $pkcs8Content;
    
    // Convert to PEM
    $b64 = base64_encode($pkcs8Der);
    $pem = "-----BEGIN PRIVATE KEY-----\n";
    $pem .= chunk_split($b64, 64, "\n");
    $pem .= "-----END PRIVATE KEY-----\n";
    
    return $pem;
}

/**
 * إرسال طلب HTTP POST للـ push service
 */
function sendPushRequest($endpoint, $payload, $jwt, $vapid_public_key = null)
{
    // ✅ إصلاح: FCM يتطلب إضافة المفتاح العمومي في الـ Authorization header
    // التنسيق: vapid t=JWT; k=BASE64_PUBLIC_KEY
    $auth_header = 'Authorization: vapid t=' . $jwt;
    if ($vapid_public_key) {
        $auth_header .= '; k=' . $vapid_public_key;
    }
    
    $ch = curl_init($endpoint);
    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $payload,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER => [
            'Content-Type: application/octet-stream',
            'Content-Encoding: aes128gcm',
            'Content-Length: ' . strlen($payload),
            'TTL: 2419200', // 28 يوم - مدة بقاء الإشعار في خادم FCM
            $auth_header,
            // ✅ v2.4: FCM يقبل فقط: high, normal, low (لا يقبل very-high)
            'Urgency: high',
            // ✅ Topic: يسمح بتجميع الإشعارات من نفس النوع
            // 'Topic: update',
        ],
        CURLOPT_TIMEOUT => 30,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_SSL_VERIFYHOST => 2,
    ]);

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    curl_close($ch);

    return [
        'success' => $httpCode >= 200 && $httpCode < 300,
        'http_code' => $httpCode,
        'response' => $response,
        'error' => $error,
    ];
}

// ============================================================
// دوال مساعدة
// ============================================================

function base64UrlEncode($data)
{
    return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
}

function base64UrlDecode($data)
{
    $padded = str_pad($data, strlen($data) + (4 - strlen($data) % 4) % 4, '=', STR_PAD_RIGHT);
    return base64_decode(strtr($padded, '-_', '+/'));
}

function pemToDer($pem)
{
    $lines = explode("\n", trim($pem));
    $der = '';
    foreach ($lines as $line) {
        if (strpos($line, '-----') === 0) continue;
        $der .= trim($line);
    }
    return base64_decode($der);
}

function derToPem($der, $type = 'private')
{
    $b64 = base64_encode($der);
    $lines = str_split($b64, 64);
    if ($type === 'private') {
        return "-----BEGIN PRIVATE KEY-----\n" . implode("\n", $lines) . "\n-----END PRIVATE KEY-----\n";
    } else {
        return "-----BEGIN PUBLIC KEY-----\n" . implode("\n", $lines) . "\n-----END PUBLIC KEY-----\n";
    }
}

function pemFromDer($der, $type = 'public')
{
    return derToPem($der, $type);
}

function derToRawSignature($der)
{
    // ECDSA signature in DER: SEQUENCE { INTEGER r, INTEGER s }
    // نريد raw r||s (64 بايت لـ P-256)
    if (strlen($der) < 8) return $der;
    
    $offset = 0;
    // SEQUENCE tag (0x30)
    if (ord($der[$offset]) !== 0x30) return $der;
    $offset++;
    
    // SEQUENCE length
    $seqLen = ord($der[$offset]);
    $offset++;
    if ($seqLen & 0x80) {
        $numBytes = $seqLen & 0x7F;
        $seqLen = 0;
        for ($i = 0; $i < $numBytes; $i++) {
            $seqLen = ($seqLen << 8) | ord($der[$offset + 1 + $i]);
        }
        $offset += $numBytes + 1;
    }
    
    // r
    if (ord($der[$offset]) !== 0x02) return $der;
    $offset++;
    $rLen = ord($der[$offset]);
    $offset++;
    $r = substr($der, $offset, $rLen);
    $offset += $rLen;
    
    // s
    if (ord($der[$offset]) !== 0x02) return $der;
    $offset++;
    $sLen = ord($der[$offset]);
    $offset++;
    $s = substr($der, $offset, $sLen);
    
    // إزالة الأصفار البادئة
    while (strlen($r) > 0 && ord($r[0]) === 0) $r = substr($r, 1);
    while (strlen($s) > 0 && ord($s[0]) === 0) $s = substr($s, 1);
    
    // pad إلى 32 بايت
    $r = str_pad($r, 32, "\0", STR_PAD_LEFT);
    $s = str_pad($s, 32, "\0", STR_PAD_LEFT);
    
    return $r . $s;
}

function hkdf($ikm, $salt, $info, $length)
{
    $prk = hash_hmac('sha256', $ikm, $salt, true);
    $okm = '';
    $t = '';
    $i = 1;
    while (strlen($okm) < $length) {
        $t = hash_hmac('sha256', $t . $info . chr($i), $prk, true);
        $okm .= $t;
        $i++;
    }
    return substr($okm, 0, $length);
}

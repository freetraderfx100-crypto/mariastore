<?php
require_once __DIR__ . '/db_connect.php';
require_once __DIR__ . '/functions.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $product_name = $_POST['product_name'] ?? '';
    $category_id = $_POST['category_id'] ?? null;

    if (!empty($product_name)) {
        $sku = generate_sku($product_name, $category_id);
        echo $sku;
    } else {
        echo 'أدخل اسم المنتج أولاً';
    }
}

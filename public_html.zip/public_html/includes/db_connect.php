<?php
require_once __DIR__ . '/../config.php';
try {
    // إنشاء اتصال PDO مع UTF8
    $conn = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS
    );

    // ضبط خيارات PDO
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); // عرض الأخطاء كاستثناءات
    $conn->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC); // وضع FETCH الافتراضي

    // ضبط الترميز الكامل
    $conn->exec("SET NAMES utf8mb4");
    $conn->exec("SET CHARACTER SET utf8mb4");
    $conn->exec("SET COLLATION_CONNECTION = 'utf8mb4_unicode_ci'");

    // ضبط المنطقة الزمنية لخادم قاعدة البيانات
    $conn->exec("SET time_zone = '+03:00'"); // حسب منطقتك الزمنية (اليمن/السعودية)
} catch (PDOException $e) {
    die("فشل الاتصال بقاعدة البيانات: " . $e->getMessage());
}




// كود قبل اضافه ترميز الوقت
// require_once __DIR__ . '/../config.php';

// try {
//     $conn = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME, DB_USER, DB_PASS);
//     $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
//     $conn->exec("SET NAMES 'utf8mb4'");
//     $conn->exec("SET CHARACTER SET utf8mb4");
//     $conn->exec("SET COLLATION_CONNECTION = 'utf8mb4_unicode_ci'");
// } catch (PDOException $e) {
//     die("فشل الاتصال بقاعدة البيانات: " . $e->getMessage());
// }

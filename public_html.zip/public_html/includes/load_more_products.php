<?php
require_once __DIR__ . '/includes/db_connect.php';

$offset = isset($_GET['offset']) ? (int)$_GET['offset'] : 0;
$limit = 8;

$stmt = $conn->prepare("
    SELECT p.*, (
        SELECT image_url FROM product_variants 
        WHERE product_id = p.id AND is_main = 1
        LIMIT 1
    ) AS image_url
    FROM products p
    WHERE p.is_active = 1
    ORDER BY p.created_at DESC
    LIMIT :limit OFFSET :offset
");

$stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmt->execute();
$products = $stmt->fetchAll(PDO::FETCH_ASSOC);

// إخراج HTML مباشر
foreach ($products as $product) {
    $image = $product['image_url'] ?? 'default-product-image.jpg';
    echo '<div class="product-card">';
    echo '<a href="<?php echo SITE_URL; ?>pages/details_product.php?id=' . $product['id'] . '">';
    echo '<img src="<?php echo SITE_URL; ?>assets/images/' . htmlspecialchars($image) . '" alt="' . htmlspecialchars($product['name']) . '">';
    echo '</a>';
    echo '<h3>' . htmlspecialchars($product['name']) . '</h3>';
    echo '<p>' . number_format($product['price'], 2) . ' ر.ي</p>';
    echo '<a href="<?php echo SITE_URL; ?>pages/details_product.php?id=' . $product['id'] . '" class="btn">عرض المنتج</a>';
    echo '</div>';
}

<?php
// visitor_tracking.php
require_once __DIR__ . '/../includes/db_connect.php';

class VisitorTracker
{
    private $conn;
    private $session_id;
    private $visitor_id;

    public function __construct($conn)
    {
        $this->conn = $conn;
        $this->session_id = session_id();
        $this->initializeVisitor();
    }

    private function initializeVisitor()
    {
        // التحقق مما إذا كانت هذه الجلسة قد تم تتبعها مسبقًا
        $stmt = $this->conn->prepare("SELECT id FROM visitors WHERE session_id = ?");
        $stmt->execute([$this->session_id]);
        $visitor = $stmt->fetch();

        if (!$visitor) {
            // تسجيل زائر جديد
            $this->registerNewVisitor();
        } else {
            $this->visitor_id = $visitor['id'];
        }
    }

    private function registerNewVisitor()
    {
        $ip_address = $this->getClientIP();
        $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';
        $referrer = $_SERVER['HTTP_REFERER'] ?? '';
        $landing_page = $_SERVER['REQUEST_URI'] ?? '';

        // الحصول على معلومات الموقع والجهاز
        $location_info = $this->getLocationInfo($ip_address);
        $device_info = $this->getDeviceInfo($user_agent);

        $user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;

        $stmt = $this->conn->prepare("
            INSERT INTO visitors 
            (session_id, ip_address, user_agent, referrer, landing_page, 
             country, city, device_type, browser, operating_system, user_id) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");

        $stmt->execute([
            $this->session_id,
            $ip_address,
            $user_agent,
            $referrer,
            $landing_page,
            $location_info['country'],
            $location_info['city'],
            $device_info['device_type'],
            $device_info['browser'],
            $device_info['os'],
            $user_id
        ]);

        $this->visitor_id = $this->conn->lastInsertId();
    }

    public function updateExitPage($exit_page)
    {
        if ($this->visitor_id) {
            $stmt = $this->conn->prepare("UPDATE visitors SET exit_page = ? WHERE id = ?");
            $stmt->execute([$exit_page, $this->visitor_id]);
        }
    }

    public function recordPageView($page)
    {
        if ($this->visitor_id) {
            $stmt = $this->conn->prepare("
                INSERT INTO page_views (visitor_id, page_url, created_at) 
                VALUES (?, ?, NOW())
            ");
            $stmt->execute([$this->visitor_id, $page]);
        }
    }

    private function getClientIP()
    {
        // ✅ إصلاح أمني: تحقق صارم من عناوين IP الموثوقة فقط
        // نأخذ IP مباشرة من REMOTE_ADDR، وفي حال وجود proxy نتحقق من X-Forwarded-For
        // بشكل آمن (أول IP فقط، مع فلترة)
        $remote_addr = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';

        // لو كان خلف proxy موثوق، نأخذ أول IP صالح من X-Forwarded-For
        if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $ips = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
            $first_ip = trim($ips[0]);
            // التحقق من أن IP صالح
            if (filter_var($first_ip, FILTER_VALIDATE_IP)) {
                return $first_ip;
            }
        }

        // التحقق من REMOTE_ADDR أيضاً
        if (filter_var($remote_addr, FILTER_VALIDATE_IP)) {
            return $remote_addr;
        }

        return '0.0.0.0';
    }

    private function getLocationInfo($ip)
    {
        // ✅ إصلاح: استخدام HTTPS بدلاً من HTTP لخدمة الموقع الجغرافي
        $url = "https://ip-api.com/json/{$ip}";

        try {
            $response = @file_get_contents($url);
            if ($response) {
                $data = json_decode($response, true);
                if ($data && $data['status'] == 'success') {
                    return [
                        'country' => $data['country'] ?? 'Unknown',
                        'city' => $data['city'] ?? 'Unknown'
                    ];
                }
            }
        } catch (Exception $e) {
            // تجاهل الأخطاء في حالة فشل خدمة الموقع
        }

        return ['country' => 'Unknown', 'city' => 'Unknown'];
    }

    private function getDeviceInfo($user_agent)
    {
        $device_type = 'Desktop';
        $browser = 'Unknown';
        $os = 'Unknown';

        // كشف نوع الجهاز
        if (preg_match('/mobile|android|iphone|ipad|ipod/i', $user_agent)) {
            $device_type = 'Mobile';
        } elseif (preg_match('/tablet|ipad/i', $user_agent)) {
            $device_type = 'Tablet';
        }

        // كشف المتصفح
        if (preg_match('/MSIE|Trident/i', $user_agent)) {
            $browser = 'Internet Explorer';
        } elseif (preg_match('/Edge/i', $user_agent)) {
            $browser = 'Microsoft Edge';
        } elseif (preg_match('/Firefox/i', $user_agent)) {
            $browser = 'Mozilla Firefox';
        } elseif (preg_match('/Chrome/i', $user_agent)) {
            $browser = 'Google Chrome';
        } elseif (preg_match('/Safari/i', $user_agent)) {
            $browser = 'Safari';
        } elseif (preg_match('/Opera|OPR/i', $user_agent)) {
            $browser = 'Opera';
        }

        // كشف نظام التشغيل
        if (preg_match('/Windows NT 10.0/i', $user_agent)) {
            $os = 'Windows 10';
        } elseif (preg_match('/Windows NT 6.3/i', $user_agent)) {
            $os = 'Windows 8.1';
        } elseif (preg_match('/Windows NT 6.2/i', $user_agent)) {
            $os = 'Windows 8';
        } elseif (preg_match('/Windows NT 6.1/i', $user_agent)) {
            $os = 'Windows 7';
        } elseif (preg_match('/Macintosh|Mac OS X/i', $user_agent)) {
            $os = 'Mac OS X';
        } elseif (preg_match('/Linux/i', $user_agent)) {
            $os = 'Linux';
        } elseif (preg_match('/Android/i', $user_agent)) {
            $os = 'Android';
        } elseif (preg_match('/iOS|iPhone|iPad/i', $user_agent)) {
            $os = 'iOS';
        }

        return [
            'device_type' => $device_type,
            'browser' => $browser,
            'os' => $os
        ];
    }

    public function getVisitorId()
    {
        return $this->visitor_id;
    }
    // في ملف visitor_tracking.php داخل كلاس VisitorTracker
    public function updateGuestId($guest_id)
    {
        if ($this->visitor_id) {
            $stmt = $this->conn->prepare("UPDATE visitors SET guest_id = ? WHERE id = ?");
            $stmt->execute([$guest_id, $this->visitor_id]);
        }
    }
}

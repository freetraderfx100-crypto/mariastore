            </main> <!-- نهاية content-wrapper -->

            <!-- تذييل الصفحة -->
            <footer class="admin-footer">
                <div class="footer-left">
                    <p>جميع الحقوق محفوظة &copy; <?php echo date('Y'); ?> <a href="<?php echo SITE_URL; ?>">ماريا</a></p>
                </div>
                <div class="footer-right">
                    <p>الإصدار 1.0.0</p>
                </div>
            </footer>
            </div> <!-- نهاية admin-content -->
            </div> <!-- نهاية admin-wrapper -->

            <!-- الأكواد البرمجية الجافاسكريبت -->
            <script>
                document.addEventListener('DOMContentLoaded', function() {
                    // ✅ تفعيل/تعطيل القائمة الجانبية (بدون jQuery)
                    const sidebarToggle = document.querySelector('.sidebar-toggle');
                    const adminWrapper = document.querySelector('.admin-wrapper');
                    if (sidebarToggle && adminWrapper) {
                        sidebarToggle.addEventListener('click', function() {
                            adminWrapper.classList.toggle('sidebar-collapsed');
                        });
                    }

                    // ✅ القائمة المنسدلة للمستخدم (بدون jQuery)
                    const adminUser = document.querySelector('.admin-user');
                    if (adminUser) {
                        adminUser.addEventListener('click', function(e) {
                            if (e.target.closest('.user-dropdown')) return;
                            const dropdown = this.querySelector('.user-dropdown');
                            if (dropdown) dropdown.classList.toggle('show');
                        });

                        // ✅ إغلاق القوائم المنسدلة عند النقر خارجها
                        document.addEventListener('click', function(e) {
                            if (!e.target.closest('.admin-user')) {
                                const dropdown = adminUser.querySelector('.user-dropdown');
                                if (dropdown) dropdown.classList.remove('show');
                            }
                        });
                    }
                });
            </script>
            </body>

            </html>

<?php
// session_config.php

// // إعدادات الجلسة
// ini_set('session.gc_probability', 1);
// ini_set('session.gc_divisor', 100);
// ini_set('session.gc_maxlifetime', 3600);

// // بدء الجلسة إذا لم تكن بدأت
// if (session_status() === PHP_SESSION_NONE) {
//     session_start([
//         'cookie_lifetime' => 3600,
//         'cookie_secure' => false,
//         'cookie_httponly' => true,
//         'cookie_samesite' => 'Lax'
//     ]);
// }


// // تعريف ثوابت الموقع إذا لم تكن معرفة
// if (!defined('SITE_URL')) {
//     define('SITE_URL', 'http://localhost/online_store/');
// }

// if (!defined('SITE_NAME')) {
//     define('SITE_NAME', 'متجر ماريا');
// }

// // التحقق مما إذا كانت الجلسة لم تبدأ بعد
// if (session_status() === PHP_SESSION_NONE) {
//     // تغيير إعدادات الجلسة فقط إذا لم تبدأ بعد
//     ini_set('session.gc_probability', 1);
//     ini_set('session.gc_divisor', 100);
//     ini_set('session.gc_maxlifetime', 3600);

//     // بدء الجلسة مع الإعدادات المطلوبة
//     session_start([
//         'cookie_lifetime' => 3600,
//         'cookie_secure' => false,
//         'cookie_httponly' => true,
//         'cookie_samesite' => 'Lax'
//     ]);
// } else {
//     // إذا كانت الجلسة قد بدأت، نكتفي ببدءها إذا لم تكن قد بدأت
//     if (session_status() === PHP_SESSION_NONE) {
//         session_start();
//     }
// }

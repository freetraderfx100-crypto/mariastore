<?php
require_once __DIR__ . '/../includes/db_connect.php';

session_start();

// فقط مسح بيانات المستخدم وليس الجلسة كاملة
unset($_SESSION['user_id']);
unset($_SESSION['username']);
unset($_SESSION['user_avatar']);
unset($_SESSION['role']);
unset($_SESSION['loggedin']);

// إذا كان هناك guest_id، احتفظ به أو امسحه حسب الحاجة
if (isset($_SESSION['guest_id'])) {
    unset($_SESSION['guest_id']);
}

// إعادة التوجيه
header("Location: " . SITE_URL . "pages/login.php");
exit;

</main>

<!-- الفوتر -->
<footer class="main-footer">
    <div class="footer-top">
        <div class="container">
            <div class="footer-grid">
                <!-- معلومات المتجر -->
                <div class="footer-col footer-about">
                    <div class="footer-logo">
                        <img src="<?php echo SITE_URL; ?>assets/images/logo-white.png" alt="ماريا">
                        <span>ماريا</span>
                    </div>
                    <p class="footer-description">
                        متجر ماريا يقدم أجمل المنتجات النسائية بتصميمات أنيقة وعصرية تناسب كل امرأة تبحث عن الأناقة والجمال.
                    </p>
                    <div class="social-icons">
                        <a href="https://www.instagram.com/maria_stores1/" target="_blank" class="social-icon" aria-label="إنستجرام"><i class="fab fa-instagram"></i></a>
                        <a href="https://www.facebook.com/mariastores1?_rdr" target="_blank" class="social-icon" aria-label="فيس بوك"><i class="fab fa-facebook"></i></a>

                    </div>
                </div>


                <!-- خدمة العملاء -->
                <!-- <div class="footer-col">
                    <h4 class="footer-title">خدمة العملاء</h4>
                    <ul class="footer-links">
                        <li><a href="<?php echo SITE_URL; ?>pages/track-order.php">تتبع الطلبية</a></li>
                        <li><a href="<?php echo SITE_URL; ?>pages/contact.php">تواصل معنا</a></li>
                    </ul>
                </div> -->

                <!-- معلومات الاتصال -->
                <div class="footer-col footer-contact">
                    <h4 class="footer-title">تواصل معنا</h4>
                    <ul class="contact-info">
                        <li>
                            <i class="fas fa-map-marker-alt"></i>
                            <span>الاصبحي شارع الحربي</span>
                        </li>
                        <li>
                            <i class="fas fa-phone-alt"></i>
                            <span dir="ltr">+967 775 616 559</span>
                        </li>
                        <li>
                            <i class="fas fa-envelope"></i>
                            <span>mariastore.ye@gmail.com</span>
                        </li>
                    </ul>

                    <!-- نموذج الاشتراك في النشرة البريدية -->
                    <!-- <div class="newsletter">
                        <h5>اشترك في نشرتنا البريدية</h5>
                        <form class="newsletter-form">
                            <input type="email" placeholder="بريدك الإلكتروني" required>
                            <button type="submit">اشتراك</button>
                        </form>
                        <p>احصلي على آخر العروض والتخفيضات مباشرة إلى بريدك</p>
                    </div> -->
                </div>
            </div>
        </div>
    </div>

    <!-- حقوق النشر -->
    <div class="footer-bottom">
        <div class="container">
            <div class="copyright">
                <p>&copy; <?php echo date('Y'); ?> جميع الحقوق محفوظة لـ <a href="<?php echo SITE_URL; ?>">ماريا</a></p>
            </div>
            <!-- <div class="payment-methods">
                <img src="/online_store/assets/images/payments/visa.png" alt="فيزا">
                <img src="/online_store/assets/images/payments/mastercard.png" alt="ماستركارد">
                <img src="/online_store/assets/images/payments/mada.png" alt="مدى">
                <img src="/online_store/assets/images/payments/apple-pay.png" alt="آبل باي">
            </div> -->
        </div>
    </div>
</footer>

<!-- الأكواد الجافاسكريبت -->
<!-- <script src="/online_store/assets/js/main.js"></script> -->
<script>
    // ✅ فحص وجود العنصر قبل إضافة event listener - يحل خطأ "Cannot read properties of null"
    document.addEventListener('DOMContentLoaded', function() {
        const mobileNavIcon = document.querySelector('.mobile-nav-icon');
        if (mobileNavIcon) {
            mobileNavIcon.addEventListener('click', function() {
                const icon = this.querySelector('i');
                if (icon) {
                    icon.classList.toggle('fa-times');
                    icon.classList.toggle('fa-bars');
                }
                const content = document.querySelector('.mobile-nav-content');
                if (content) content.classList.toggle('active');
            });
        }

        // القوائم المنسدلة في الهاتف
        document.querySelectorAll('.mobile-dropdown > a').forEach(item => {
            item.addEventListener('click', function(e) {
                e.preventDefault();
                const icon = this.querySelector('i');
                if (icon) {
                    icon.classList.toggle('fa-chevron-up');
                    icon.classList.toggle('fa-chevron-down');
                }
                if (this.nextElementSibling) {
                    this.nextElementSibling.classList.toggle('active');
                }
            });
        });

        // زر الحساب: على الهاتف انتقال مباشر لصفحة الحساب، وعلى الكمبيوتر يفتح القائمة المنسدلة
        const userIconLink = document.querySelector('.user-dropdown .icon-link');
        if (userIconLink) {
            userIconLink.addEventListener('click', function(e) {
                // على شاشة الهاتف: الانتقال المباشر إلى pages/profile.php (بدون قائمة منسدلة)
                if (window.innerWidth <= 768) {
                    return; // السماح بالانتقال الطبيعي للرابط
                }
                e.preventDefault();
                if (this.nextElementSibling) {
                    this.nextElementSibling.classList.toggle('show');
                }
            });
        }

        // إغلاق القوائم المنسدلة عند النقر خارجها
        window.addEventListener('click', function(e) {
            if (!e.target.matches('.user-dropdown .icon-link')) {
                const dropdowns = document.querySelectorAll('.user-dropdown .dropdown-content');
                dropdowns.forEach(dropdown => {
                    if (dropdown.classList.contains('show')) {
                        dropdown.classList.remove('show');
                    }
                });
            }
        });
    });
</script>
</body>

</html>
<?php

/**
 * ✅ بناء URL آمن للصور (يرمّز اسم الملف فقط، وليس المسار)
 * يحل مشكلة 404 للصور ذات الأسماء التي تحتوي على مسافات أو أحرف خاصة
 */
function safeImageUrl($image_path, $base_dir = 'assets/images/')
{
    if (empty($image_path)) {
        return SITE_URL . $base_dir . 'default-product-image.png';
    }
    
    // إزالة الشرطة المائلة من البداية لو وجدت
    $image_path = ltrim($image_path, '/');
    
    // فصل المسار عن اسم الملف
    $last_slash = strrpos($image_path, '/');
    if ($last_slash !== false) {
        $dir = substr($image_path, 0, $last_slash + 1);
        $filename = substr($image_path, $last_slash + 1);
        return SITE_URL . $base_dir . $dir . rawurlencode($filename);
    } else {
        return SITE_URL . $base_dir . rawurlencode($image_path);
    }
}


function get_order_status($status)
{
    $statuses = [
        'pending' => 'قيد الانتظار',
        'processing' => 'قيد المعالجة',
        'in_the_way' => 'في الطريق',
        'completed' => 'مكتمل',
        'cancelled' => 'ملغي'
    ];
    return $statuses[$status] ?? $status;
}


function toSlug($string)
{
    $string = preg_replace('/[^\p{Arabic}\p{L}\p{N}\s]/u', '', $string);
    $string = preg_replace('/\s+/', '-', trim($string));
    $string = mb_strtolower($string, 'UTF-8');
    return $string;
}

// دالة للتحقق من الخصومات المنتهية الصلاحية
function checkExpiredDiscounts($conn)
{
    $current_datetime = date('Y-m-d H:i:s');

    $stmt = $conn->prepare("
        UPDATE products 
        SET discount_percentage = 0, 
            discount_end_date = NULL,
            discount_end_time = NULL
        WHERE discount_end_date IS NOT NULL 
        AND CONCAT(discount_end_date, ' ', COALESCE(discount_end_time, '23:59:59')) < ?
    ");
    $stmt->execute([$current_datetime]);
}


// دالة لجلب إعدادات التنبيهات
function getAlertSettings()
{
    global $conn;

    $default_settings = [
        'alert_text' => 'مرحبا بكم في متجر ماريا انتضرونا في عروض اقوى',
        'alert_bg_color' => '#f8d7da',
        'alert_text_color' => '#721c24',
        'alert_enabled' => true
    ];

    try {
        $stmt = $conn->query("SELECT alert_text, alert_bg_color, alert_text_color, alert_enabled FROM shipping_settings WHERE alert_enabled = 1 ORDER BY id DESC LIMIT 1");
        $settings = $stmt->fetch();

        if ($settings) {
            return $settings;
        }
    } catch (PDOException $e) {
        error_log("Error fetching alert settings: " . $e->getMessage());
    }

    return $default_settings;
}

// دالة لجلب إعدادات الشحن
// دالة لجلب إعدادات الشحن
function getShippingSettings()
{
    global $conn;

    $default_settings = [
        'free_shipping_threshold' => null,
        'shipping_discount_percentage' => 0,
        'is_active' => true,
        'base_cost' => 1000,
        'cost_per_km' => 100,
        'min_cost' => 1000,
        'max_cost' => 5000
    ];

    try {
        $stmt = $conn->query("SELECT free_shipping_threshold, shipping_discount_percentage, is_active, base_cost, cost_per_km, min_cost, max_cost FROM shipping_settings WHERE is_active = 1 ORDER BY id DESC LIMIT 1");
        $settings = $stmt->fetch();

        if ($settings) {
            return $settings;
        }
    } catch (PDOException $e) {
        error_log("Error fetching shipping settings: " . $e->getMessage());
    }

    return $default_settings;
}

/**
 * توليد SKU تلقائي للمنتج
 */
function generate_sku($product_name, $category_id = null)
{
    global $conn;

    // الحصول على بادئة التصنيف إذا كان موجوداً
    $category_prefix = '';
    if ($category_id) {
        $stmt = $conn->prepare("SELECT name FROM categories WHERE id = ?");
        $stmt->execute([$category_id]);
        $category = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($category) {
            // أخذ أول 3 أحرف من اسم التصنيف (لاتينية)
            $category_name = preg_replace('/[^A-Za-z]/', '', $category['name']);
            $category_prefix = strtoupper(substr($category_name, 0, 3)) . '-';
        }
    }

    // أخذ أول 4 أحرف من اسم المنتج (لاتينية)
    $name_part = preg_replace('/[^A-Za-z0-9]/', '', $product_name);
    $name_part = strtoupper(substr($name_part, 0, 4));

    // رقم عشوائي
    $random_part = rand(1000, 9999);

    $sku = $category_prefix . $name_part . '-' . $random_part;

    // التحقق من أن SKU فريد
    $stmt = $conn->prepare("SELECT id FROM products WHERE sku = ?");
    $stmt->execute([$sku]);

    // إذا كان SKU موجوداً، حاول مرة أخرى
    if ($stmt->fetch()) {
        return generate_sku($product_name, $category_id);
    }

    return $sku;
}


// في ملف functions.php
function trackVisitorExit()
{
    global $conn;
    if (isset($_SESSION['visitor_tracker'])) {
        $visitorTracker = unserialize($_SESSION['visitor_tracker']);
        $visitorTracker->updateExitPage($_SERVER['REQUEST_URI']);
    }
}

// تسجيل الدالة ليتم استدعاؤها عند انتهاء الجلسة
register_shutdown_function('trackVisitorExit');
?>

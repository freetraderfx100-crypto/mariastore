<?php
/**
 * includes/env.php
 * --------------------------------------------------------------------
 * Loader بسيط لملف .env بدون الحاجة لمكتبات خارجية (vlucas/phpdotenv).
 *
 * - يقرأ ملف .env من جذر المشروع.
 * - يحمّل القيم في getenv() / $_ENV / $_SERVER.
 * - إن لم يوجد ملف .env، يعتمد على متغيرات البيئة الحقيقية
 *   (مفيد في الاستضافات التي تدعم ENV vars مثل Hostinger).
 * - إن لم توجد أي قيمة، يُرجع القيمة الافتراضية الممررة.
 * --------------------------------------------------------------------
 */

if (defined('MARIA_ENV_LOADED')) {
    return;
}
define('MARIA_ENV_LOADED', true);

/**
 * تحميل ملف .env في الذاكرة (إن وُجد).
 *
 * @return void
 */
function maria_env_load(): void
{
    // لو تم تحميله مسبقاً عبر $_ENV، تجاهل
    if (getenv('MARIA_ENV_FILE_LOADED') === '1') {
        return;
    }

    $envPath = dirname(__DIR__) . DIRECTORY_SEPARATOR . '.env';

    if (!is_file($envPath)) {
        // لا يوجد ملف .env — نعتمد على متغيرات البيئة الحقيقية
        putenv('MARIA_ENV_FILE_LOADED=0');
        return;
    }

    $lines = file($envPath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    if ($lines === false) {
        putenv('MARIA_ENV_FILE_LOADED=0');
        return;
    }

    foreach ($lines as $line) {
        $line = trim($line);

        // تجاهل التعليقات والأسطر الفارغة
        if ($line === '' || $line[0] === '#') {
            continue;
        }

        // تجاهل الأسطر التي لا تحتوي على =
        if (strpos($line, '=') === false) {
            continue;
        }

        [$key, $value] = explode('=', $line, 2);
        $key   = trim($key);
        $value = trim($value);

        // إزالة علامات الاقتباس إن وُجدت
        if (strlen($value) >= 2) {
            $first = $value[0];
            $last  = $value[strlen($value) - 1];
            if (($first === '"' && $last === '"') || ($first === "'" && $last === "'")) {
                $value = substr($value, 1, -1);
            }
        }

        // تسجيل في كل من getenv / $_ENV / $_SERVER
        // (لا نُطبع أي قيمة موجودة مسبقاً من بيئة النظام الحقيقية)
        if (getenv($key) === false && !isset($_ENV[$key])) {
            putenv($key . '=' . $value);
            $_ENV[$key]    = $value;
            $_SERVER[$key] = $value;
        }
    }

    putenv('MARIA_ENV_FILE_LOADED=1');
}

/**
 * قراءة قيمة من البيئة مع قيمة افتراضية.
 *
 * @param  string $key
 * @param  mixed  $default
 * @return string
 */
function env(string $key, $default = null): string
{
    $val = getenv($key);
    if ($val === false || $val === '') {
        $val = $_ENV[$key] ?? $_SERVER[$key] ?? '';
    }
    return ($val === '') ? (string) $default : $val;
}

// التحميل التلقائي عند تضمين الملف
maria_env_load();

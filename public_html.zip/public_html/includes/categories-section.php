 <!-- categories-section -->

 <!-- قسم الفئات الجديد -->
 <section class="categories-section">
     <div class="categories-container">
         <!-- <h2 style="text-align: center; margin-bottom: 30px; font-size: 24px;">تصفح حسب التصنيف</h2> -->

         <!-- أزرار التمرير -->
         <button class="scroll-btn left" id="scrollLeft">
             <i class="fas fa-chevron-right"></i>
         </button>

         <button class="scroll-btn right" id="scrollRight">
             <i class="fas fa-chevron-left"></i>
         </button>

         <div class="subcategories-wrapper" id="categoriesWrapper">
             <div class="subcategories-container">
                 <?php foreach ($subcategories as $subcategory): ?>
                     <a href="<?php echo SITE_URL; ?>pages/products.php?category_id=<?= $subcategory['id'] ?>" class="category-link" title="<?= htmlspecialchars($subcategory['name']) ?>">
                         <div class="category-image">
                             <img src="<?php echo SITE_URL; ?>assets/images/uploads/categories/<?= !empty($subcategory['image']) ? htmlspecialchars($subcategory['image']) : 'default-product-image.jpg' ?>" alt="<?= htmlspecialchars($subcategory['name']) ?>">
                         </div>
                         <div class="category-name"><?= htmlspecialchars($subcategory['name']) ?></div>
                     </a>
                 <?php endforeach; ?>
             </div>
         </div>
     </div>
 </section>
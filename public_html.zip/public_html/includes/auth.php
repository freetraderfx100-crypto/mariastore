<?php
require_once __DIR__ . '/../includes/db_connect.php';

// دالة التحقق من المدير
function checkAdminRole()
{
    if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'admin') {
        header("Location: " . SITE_URL . "pages/login.php");
        exit;
    }
}

function checkLogin()
{
    if (!isset($_SESSION['user_id'])) {
        // حفظ الصفحة الحالية للعودة إليها بعد التسجيل
        $_SESSION['redirect_url'] = $_SERVER['REQUEST_URI'];

        // توجيه إلى صفحة التسجيل
        header("Location: " . SITE_URL . "pages/login.php");
        exit;
    }
}

// إضافة دالة للتحقق من حالة الزائر
function isGuest()
{
    return isset($_SESSION['guest_id']) && (!isset($_SESSION['user_id']));
}

// دالة للتحقق من الصلاحيات للصفحات الإدارية فقط
function checkAdminAccess()
{
    $current_page = basename($_SERVER['PHP_SELF']);
    $admin_pages = [
        'dashboard.php',
        'orders.php',
        'products_management.php',
        'users_management.php',
        'manage_products.php',
        'manage_categories.php',
        'customers.php',
        'reports.php',
        'manage_sliders.php',
        'messages.php',
        'blog_dashboard.php',
        'manage_discounts.php',
        'shipping_settings.php',
        'admin_visitors.php',
        'payment_methods.php',
        // ✅ إضافة الصفحات المحمية حديثاً
        'save_payment.php',
        'edit_payment.php',
        'profile.php',
        'change_password.php',
        'add_product.php',
        'edit_product.php',
        'add_category.php',
        'edit_category.php',
        'delete_category.php',
        'add_customer.php',
        'edit_customer.php',
        'delete_customer.php',
        'toggle_status.php',
        'search_customers.php',
        'add_slider.php',
        'edit_slider.php',
        'delete_image.php',
        'delete_message.php',
        'upload.php',
        'get_product_quantity.php',
        'add_order_item.php',
        'edit_order_items.php',
        'order_details.php',
        'import_products.php',
        'upload_excel.php',
        'categories.php',
        'logs.php',
        'notification_settings.php',
        'diagnose_push.php'
    ];

    if (in_array($current_page, $admin_pages, true)) {
        checkAdminRole(); // التحقق من صلاحية المدير فقط للصفحات الإدارية
    }
}

// بدء الجلسة إذا لم تبدأ
if (session_status() === PHP_SESSION_NONE) {
    session_start([
        'name' => 'AdminSession',
        'cookie_secure' => isset($_SERVER['HTTPS']),
        'cookie_httponly' => true
    ]);
}

// استدعاء التحقق من الصلاحيات للإدارة فقط
checkAdminAccess();

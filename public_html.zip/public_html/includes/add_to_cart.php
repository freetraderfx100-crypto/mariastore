<?php
require_once('../includes/db_connect.php');
require_once('../includes/auth.php');

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'طريقة الطلب غير صحيحة']);
    exit();
}

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'يجب تسجيل الدخول أولاً']);
    exit();
}

// استقبال البيانات
$productId = filter_var($_POST['product_id'] ?? 0, FILTER_SANITIZE_NUMBER_INT);
$quantity = max(1, intval($_POST['quantity'] ?? 1));
$color = $_POST['color'] ?? null;
$size = $_POST['size'] ?? null;

if (!$productId) {
    echo json_encode(['success' => false, 'message' => 'معرف المنتج غير صالح']);
    exit();
}

try {
    // 1. التحقق من وجود المنتج
    $stmt = $conn->prepare("SELECT id, image FROM products WHERE id = ? AND is_active = 1");
    $stmt->execute([$productId]);
    $product = $stmt->fetch();

    if (!$product) {
        echo json_encode(['success' => false, 'message' => 'المنتج غير موجود أو غير متاح']);
        exit();
    }

    // 2. الحصول على cart_id للمستخدم (أو إنشاء سلة جديدة)
    $cartId = getOrCreateCart($conn, $_SESSION['user_id']);

    // 3. التحقق من وجود المنتج في السلة
    $stmt = $conn->prepare("
        SELECT id, quantity 
        FROM cart_items 
        WHERE cart_id = ? AND product_id = ?
        AND (color = ? OR (? IS NULL AND color IS NULL))
        AND (size = ? OR (? IS NULL AND size IS NULL))
    ");
    
    $stmt->execute([
        $cartId, 
        $productId,
        $color, $color,
        $size, $size
    ]);
    
    $existingItem = $stmt->fetch();

    if ($existingItem) {
        // تحديث الكمية إذا كان المنتج موجوداً
        $newQuantity = $existingItem['quantity'] + $quantity;
        $stmt = $conn->prepare("UPDATE cart_items SET quantity = ? WHERE id = ?");
        $stmt->execute([$newQuantity, $existingItem['id']]);
    } else {
        // إضافة منتج جديد إلى السلة
        // ✅ إصلاح: كان الكود السابق يخزّن النص الحرفي '<?php echo SITE_URL; ?>' في قاعدة البيانات
        // الآن نبني المسار بشكل صحيح باستخدام ثابت SITE_URL
        $imageUrl = SITE_URL . 'assets/images/products/' . $product['image'];

        $stmt = $conn->prepare("
            INSERT INTO cart_items 
            (cart_id, product_id, quantity, color, size, image_url, added_at)
            VALUES (?, ?, ?, ?, ?, ?, NOW())
        ");
        
        $stmt->execute([
            $cartId,
            $productId,
            $quantity,
            $color,
            $size,
            $imageUrl
        ]);
    }

    // حساب العدد الإجمالي للعناصر في السلة
    $stmt = $conn->prepare("SELECT SUM(quantity) AS total FROM cart_items WHERE cart_id = ?");
    $stmt->execute([$cartId]);
    $cartCount = $stmt->fetchColumn();

    echo json_encode([
        'success' => true,
        'cart_count' => (int)$cartCount,
        'message' => 'تمت إضافة المنتج إلى السلة بنجاح'
    ]);

} catch (PDOException $e) {
    error_log("Cart Error: " . $e->getMessage());
    // ✅ إصلاح: لا نكشف رسالة الخطأ للمستخدم
    echo json_encode([
        'success' => false,
        'message' => 'حدث خطأ تقني، يرجى المحاولة لاحقاً'
    ]);
}

// دالة مساعدة للحصول على سلة موجودة أو إنشاء جديدة
function getOrCreateCart($conn, $userId) {
    // تحقق من وجود سلة نشطة للمستخدم
    $stmt = $conn->prepare("SELECT id FROM carts WHERE user_id = ? AND status = 'active'");
    $stmt->execute([$userId]);
    $cart = $stmt->fetch();

    if ($cart) {
        return $cart['id'];
    } else {
        // إنشاء سلة جديدة
        $stmt = $conn->prepare("INSERT INTO carts (user_id, created_at, status) VALUES (?, NOW(), 'active')");
        $stmt->execute([$userId]);
        return $conn->lastInsertId();
    }
}
?>
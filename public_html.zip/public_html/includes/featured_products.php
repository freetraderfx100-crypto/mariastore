<?php
require_once __DIR__ . '/db_connect.php';

header('Content-Type: application/json');

try {
    // استعلام لاسترجاع المنتجات المميزة مع معالجة الصور
    $stmt = $conn->prepare("
        SELECT 
            p.id, 
            p.name, 
            p.price,
            COALESCE(
                (SELECT image_urls 
                 FROM product_variants 
                 WHERE product_id = p.id 
                 AND image_urls IS NOT NULL 
                 AND image_urls != '[]' 
                 LIMIT 1),
                'default-product-image.jpg'
            ) as image_data
        FROM products p
        WHERE p.is_active = 1
        AND p.is_featured = 1
        GROUP BY p.id
        ORDER BY p.created_at DESC
        LIMIT 5
    ");

    $stmt->execute();
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // معالجة بيانات الصور
    foreach ($results as &$product) {
        if ($product['image_data'] && $product['image_data'] !== 'default-product-image.jpg') {
            $images = json_decode($product['image_data'], true);
            if (is_array($images) && !empty($images)) {
                $product['image'] = $images[0]; // أخذ أول صورة
            } else {
                $product['image'] = 'default-product-image.jpg';
            }
        } else {
            $product['image'] = 'default-product-image.jpg';
        }
        unset($product['image_data']); // إزالة الحقل المؤقت
    }

    echo json_encode($results);
} catch (PDOException $e) {
    error_log("Featured products error: " . $e->getMessage());
    echo json_encode([]);
}

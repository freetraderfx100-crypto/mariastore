<!-- includes/products-loop.php -->
<div class="products-grid">
    <?php if (!empty($products)): ?>
        <?php foreach ($products as $product): ?>
            <?php
            // استرجاع الألوان من الجدول product_variants
            $stmt_colors = $conn->prepare("SELECT DISTINCT color FROM product_variants WHERE product_id = ?");
            $stmt_colors->execute([$product['id']]);
            $colors = $stmt_colors->fetchAll(PDO::FETCH_COLUMN);
            ?>
            <div class="product-card">
                <a href="<?php echo SITE_URL; ?>pages/details_product.php?id=<?= $product['id'] ?>">
                    <img src="<?php echo SITE_URL; ?>assets/images/<?= htmlspecialchars($product['image_url'] ?? 'default-product-image.png') ?>" alt="<?= htmlspecialchars($product['name']) ?>">
                </a>
                <h3><?= htmlspecialchars($product['name']) ?></h3>
                <p><?= number_format($product['price'], 2) ?> ر.ي</p>

                <?php if (!empty($colors)): ?>
                    <div class="product-colors">
                        <?php foreach ($colors as $color): ?>
                            <span class="color-dot" style="background-color: <?= htmlspecialchars($color) ?>;" title="<?= htmlspecialchars($color) ?>">
                                <?= mb_substr(htmlspecialchars($color), 0, 1) ?>
                            </span>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
    <?php else: ?>
        <div class="no-products-message">
            <i class="fas fa-box-open"></i>
            <p><?= $error_message ?? 'لا توجد منتجات متاحة حالياً' ?></p>
            <a href="<?php echo SITE_URL; ?>index.php" class="btn">تصفح جميع المنتجات</a>
        </div>
    <?php endif; ?>
</div>

<?php if ($total_pages > 1): ?>
    <div class="pagination">
        <?php for ($i = 1; $i <= $total_pages; $i++): ?>
            <a href="?<?= $category_id ? "category_id=$category_id&" : "" ?>page=<?= $i ?>" class="<?= $i == $page ? 'active' : '' ?>">
                <?= $i ?>
            </a>
        <?php endfor; ?>
    </div>
<?php endif; ?>
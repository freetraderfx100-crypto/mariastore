<?php
require_once __DIR__ . '/../includes/db_connect.php';
require_once __DIR__ . '/../includes/auth.php';

session_start();
header("Content-Type: application/json; charset=UTF-8");

$response = ['count' => 0];

if (isset($_SESSION['user_id']) && isset($conn)) {
    try {
        // البحث عن سلة التسوق النشطة للمستخدم
        $stmt = $conn->prepare("SELECT id FROM carts WHERE user_id = ? AND status = 'active' LIMIT 1");
        $stmt->execute([$_SESSION['user_id']]);
        $cart = $stmt->fetch();

        if ($cart) {
            $stmt = $conn->prepare("SELECT COALESCE(SUM(quantity), 0) FROM cart_items WHERE cart_id = ?");
            $stmt->execute([$cart['id']]);
            $response['count'] = (int)$stmt->fetchColumn();
        }
    } catch (PDOException $e) {
        error_log("Cart count error: " . $e->getMessage());
    }
} elseif (isset($_SESSION['guest_cart'])) {
    $response['count'] = is_array($_SESSION['guest_cart']) ? array_sum($_SESSION['guest_cart']) : 0;
}

echo json_encode($response);

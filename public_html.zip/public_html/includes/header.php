<?php
require_once __DIR__ . '/../includes/db_connect.php';
require_once __DIR__ . '/../includes/functions.php';

// بداية الجلسة إذا لم تبدأ
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// جلب إعدادات التنبيهات
$alert_settings = getAlertSettings();

// عرض شريط التنبيهات إذا كان مفعلاً
if ($alert_settings['alert_enabled'] && !empty($alert_settings['alert_text'])):

?>
    <!DOCTYPE html>
    <html lang="ar" dir="rtl">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title><?php echo isset($pageTitle) ? $pageTitle : SITE_NAME; ?></title>
        <!-- ✅ PWA Manifest - مهم للإشعارات في الخلفية -->
        <link rel="manifest" href="<?php echo SITE_URL; ?>manifest.json">
        <!-- ✅ Theme color للهاتف -->
        <meta name="theme-color" content="#667eea">
        <!-- ✅ iOS - لدعم الإشعارات على iPhone -->
        <meta name="mobile-web-app-capable" content="yes">
        <meta name="apple-mobile-web-app-status-bar-style" content="default">
        <meta name="apple-mobile-web-app-title" content="ماريا">
        <link rel="apple-touch-icon" href="<?php echo SITE_URL; ?>assets/icons/icon-192.png">
        <!-- Font Awesome - نسخة محلية (لا يعتمد على CDN) -->
        <link rel="stylesheet" href="<?php echo SITE_URL; ?>assets/css/font-awesome.min.css">
        <!-- نسخة احتياطية من CDN لو فشل التحميل المحلي -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" media="all" onerror="this.onerror=null;this.href='https://use.fontawesome.com/releases/v6.4.0/css/all.css';">
        <!-- ✅ إضافة ?v=3 لكسر الكاش وإجبار المتصفح على تحميل النسخة الجديدة -->
        <link rel="stylesheet" href="<?php echo SITE_URL; ?>assets/css/style.css?v=5">
        <link rel="stylesheet" href="<?php echo SITE_URL; ?>assets/css/responsive.css">
        <link rel="stylesheet" href="<?php echo SITE_URL; ?>assets/css/search.css">
        <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;700&display=swap" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;500;600&display=swap" rel="stylesheet">

        <!-- Favicon -->
        <link rel="icon" type="image/x-icon" href="<?php echo SITE_URL; ?>assets/images/favicon.ico">
        <link rel="shortcut icon" type="image/x-icon" href="<?php echo SITE_URL; ?>assets/images/favicon.ico">
        <link rel="apple-touch-icon" sizes="180x180" href="<?php echo SITE_URL; ?>assets/images/apple-touch-icon.png">
        <link rel="icon" type="image/png" sizes="32x32" href="<?php echo SITE_URL; ?>assets/images/favicon-32x32.png">
        <link rel="icon" type="image/png" sizes="16x16" href="<?php echo SITE_URL; ?>assets/images/favicon-16x16.png">

        <!-- تصميم الدائره الى في الشاشه الي تعرض القوائم في الهاتف -->
        <style>
            /* تنسيقات قائمة الهاتف المتحركة - معدلة */
            .mobile-nav {
                position: fixed;
                bottom: 20px;
                right: 20px;
                z-index: 9999;
                display: none;
            }

            .mobile-nav-icon {
                width: 60px;
                height: 60px;
                background: linear-gradient(135deg, #ff6b6b, #ee5a52);
                border-radius: 50%;
                display: flex;
                flex-direction: column;
                justify-content: center;
                align-items: center;
                cursor: pointer;
                box-shadow: 0 4px 20px rgba(255, 107, 107, 0.3);
                transition: all 0.3s ease;
                position: relative;
                z-index: 10002;
            }

            .mobile-nav-icon:hover {
                transform: scale(1.1);
                box-shadow: 0 6px 25px rgba(255, 107, 107, 0.4);
            }

            .nav-icon-line {
                width: 25px;
                height: 3px;
                background: white;
                margin: 3px 0;
                border-radius: 2px;
                transition: all 0.3s ease;
            }

            .mobile-nav-overlay {
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background: rgba(0, 0, 0, 0.7);
                z-index: 999;
                opacity: 0;
                visibility: hidden;
                transition: all 0.3s ease;
            }

            .mobile-nav-content {
                position: fixed;
                top: 0;
                right: -100%;
                width: 85%;
                max-width: 350px;
                height: 100%;
                background: white;
                z-index: 1000;
                overflow-y: auto;
                transition: right 0.4s ease;
                box-shadow: -5px 0 25px rgba(0, 0, 0, 0.15);
            }

            .mobile-nav-content.active {
                right: 0;
            }

            .mobile-nav-overlay.active {
                opacity: 1;
                visibility: visible;
            }

            .mobile-nav-header {
                display: flex;
                justify-content: space-between;
                align-items: center;
                padding: 20px;
                background: linear-gradient(135deg, #ff6b6b, #ee5a52);
                color: white;
            }

            .mobile-nav-logo img {
                height: 40px;
            }

            .mobile-nav-close {
                font-size: 24px;
                cursor: pointer;
                transition: transform 0.3s ease;
            }

            .mobile-nav-close:hover {
                transform: rotate(90deg);
            }

            .mobile-nav-body {
                padding: 20px 0;
            }

            .mobile-main-menu {
                list-style: none;
                padding: 0;
                margin: 0;
            }

            .mobile-main-menu>li {
                border-bottom: 1px solid #f1f1f1;
            }

            .mobile-main-menu a {
                display: flex;
                align-items: center;
                padding: 15px 20px;
                color: #333;
                text-decoration: none;
                font-weight: 500;
                transition: all 0.3s ease;
                flex: 1;
            }

            .mobile-main-menu a:hover {
                background: #f8f9fa;
                color: #ff6b6b;
            }

            .mobile-main-menu i:first-child {
                margin-left: 10px;
                width: 20px;
                text-align: center;
            }

            /* تنسيقات جديدة للعناصر المنفصلة */
            .menu-item-container {
                display: flex;
                align-items: center;
                padding: 0 20px;
                min-height: 50px;
            }

            .menu-link,
            .submenu-link {
                flex: 1;
                display: flex;
                align-items: center;
                padding: 15px 0;
                color: #333;
                text-decoration: none;
            }

            .menu-toggle-arrow,
            .submenu-toggle-arrow {
                padding: 15px 10px;
                cursor: pointer;
                display: flex;
                align-items: center;
                justify-content: center;
                color: #888;
                transition: all 0.3s ease;
            }

            .menu-toggle-arrow:hover,
            .submenu-toggle-arrow:hover {
                color: #ff6b6b;
            }

            .toggle-icon {
                transition: transform 0.3s ease;
            }

            .toggle-icon.rotate {
                transform: rotate(180deg);
            }

            .mobile-sub-menu,
            .mobile-submenu-level2 {
                list-style: none;
                padding: 0;
                margin: 0;
                background: #f8f9fa;
                max-height: 0;
                overflow: hidden;
                transition: max-height 0.4s ease;
            }

            .mobile-sub-menu.active,
            .mobile-submenu-level2.active {
                max-height: 1000px;
            }

            .mobile-sub-menu li {
                border-bottom: 1px solid #e9ecef;
            }

            .mobile-sub-menu .menu-item-container {
                padding: 0 20px 0 40px;
            }

            .mobile-submenu-level2 a {
                padding: 12px 20px 12px 60px;
                font-size: 13px;
                display: flex;
                align-items: center;
            }

            .mobile-submenu-level2 i {
                font-size: 12px;
                margin-left: 8px;
            }

            .mobile-nav-footer {
                padding: 20px;
                margin-top: 20px;
                border-top: 1px solid #f1f1f1;
            }

            .mobile-social-links {
                display: flex;
                justify-content: center;
                gap: 15px;
                margin-bottom: 20px;
            }

            .social-link {
                width: 40px;
                height: 40px;
                border-radius: 50%;
                background: #f8f9fa;
                display: flex;
                align-items: center;
                justify-content: center;
                color: #ff6b6b;
                text-decoration: none;
                transition: all 0.3s ease;
            }

            .social-link:hover {
                background: #ff6b6b;
                color: white;
                transform: translateY(-3px);
            }

            .mobile-contact-info p {
                margin: 8px 0;
                color: #666;
                font-size: 14px;
            }

            .mobile-contact-info i {
                margin-left: 8px;
                color: #ff6b6b;
            }

            /* للشاشات الصغيرة فقط */
            @media (max-width: 768px) {
                .mobile-nav {
                    display: block;
                }
            }

            /* تحسينات للهواتف الأصغر */
            @media (max-width: 480px) {
                .mobile-nav-content {
                    width: 90%;
                }

                .mobile-nav-icon {
                    width: 50px;
                    height: 50px;
                    bottom: 15px;
                    right: 15px;
                }

                .nav-icon-line {
                    width: 20px;
                    height: 2px;
                }

                .menu-item-container {
                    padding: 0 15px;
                }

                .mobile-sub-menu .menu-item-container {
                    padding: 0 15px 0 30px;
                }

                .mobile-submenu-level2 a {
                    padding: 10px 15px 10px 45px;
                }
            }

            /* تحسين مظهر شريط التمرير */
            .mobile-nav-content::-webkit-scrollbar {
                width: 4px;
            }

            .mobile-nav-content::-webkit-scrollbar-track {
                background: #f1f1f1;
            }

            .mobile-nav-content::-webkit-scrollbar-thumb {
                background: #ff6b6b;
                border-radius: 2px;
            }

            .mobile-nav-content::-webkit-scrollbar-thumb:hover {
                background: #ee5a52;
            }

            /* ===== تحسين أيقونات الهيدر للهاتف ===== */
            @media (max-width: 768px) {
                /* تحسين Header Icons - تظهر أيقونات بوضوح */
                .header-icons {
                    display: flex !important;
                    align-items: center !important;
                    gap: 10px !important;
                    margin: 0 !important;
                }

                .header-icons .icon-link {
                    font-size: 20px !important;
                    color: #2c3e50 !important;
                    position: relative;
                    display: inline-flex !important;
                    align-items: center !important;
                    justify-content: center !important;
                    width: 40px !important;
                    height: 40px !important;
                    border-radius: 50% !important;
                    background: #f8f9fa !important;
                    transition: all 0.3s ease !important;
                    text-decoration: none !important;
                }

                .header-icons .icon-link:hover {
                    background: #ff6b8b !important;
                    color: #fff !important;
                    transform: translateY(-2px) !important;
                }

                .header-icons .icon-link i {
                    font-size: 18px !important;
                    line-height: 1 !important;
                }

                /* ضمان ظهور أيقونة السلة بشكل واضح */
                .header-icons .cart-icon i.fa-shopping-bag,
                .header-icons .cart-icon i.fa-shopping-cart,
                .header-icons .cart-icon i.fas,
                .header-icons .cart-icon i.far {
                    display: inline-block !important;
                    visibility: visible !important;
                    opacity: 1 !important;
                }

                /* شارة عدد المنتجات في السلة */
                .header-icons .cart-count {
                    position: absolute !important;
                    top: -4px !important;
                    inset-inline-end: -4px !important;
                    background: #ff6b8b !important;
                    color: #fff !important;
                    font-size: 11px !important;
                    min-width: 18px !important;
                    height: 18px !important;
                    border-radius: 50% !important;
                    display: inline-flex !important;
                    align-items: center !important;
                    justify-content: center !important;
                    padding: 0 5px !important;
                    font-weight: 700 !important;
                    line-height: 1 !important;
                    border: 2px solid #fff !important;
                    box-shadow: 0 2px 4px rgba(0,0,0,0.15) !important;
                }

                /* تحسين user-dropdown */
                .header-icons .user-dropdown {
                    position: relative !important;
                }

                .header-icons .user-dropdown .dropdown-content {
                    position: absolute !important;
                    top: 100% !important;
                    inset-inline-end: 0 !important;
                    min-width: 180px !important;
                    background: #fff !important;
                    box-shadow: 0 4px 14px rgba(0,0,0,0.15) !important;
                    border-radius: 8px !important;
                    padding: 8px 0 !important;
                    z-index: 1100 !important;
                    display: none !important;
                }

                /* على الهاتف: لا تظهر القائمة المنسدلة أبداً — زر الحساب ينقل مباشرة لصفحة الحساب */
                .header-icons .user-dropdown:hover .dropdown-content,
                .header-icons .user-dropdown:focus-within .dropdown-content,
                .header-icons .user-dropdown .dropdown-content.show {
                    display: none !important;
                }

                .header-icons .user-dropdown .dropdown-content a {
                    display: flex !important;
                    align-items: center !important;
                    gap: 8px !important;
                    padding: 10px 16px !important;
                    color: #2c3e50 !important;
                    text-decoration: none !important;
                    font-size: 14px !important;
                    transition: background 0.2s !important;
                }

                .header-icons .user-dropdown .dropdown-content a:hover {
                    background: #f8f9fa !important;
                    color: #ff6b8b !important;
                }

                .header-icons .user-dropdown .dropdown-content a i {
                    font-size: 14px !important;
                    width: 18px !important;
                    text-align: center !important;
                }

                .header-icons .guest-welcome {
                    display: block !important;
                    padding: 10px 16px !important;
                    color: #6c757d !important;
                    font-size: 13px !important;
                    border-bottom: 1px solid #e9ecef !important;
                    margin-bottom: 4px !important;
                }
            }

            /* تحسين إضافي للشاشات الأصغر */
            @media (max-width: 480px) {
                .header-icons {
                    gap: 6px !important;
                }
                .header-icons .icon-link {
                    width: 36px !important;
                    height: 36px !important;
                    font-size: 18px !important;
                }
                .header-icons .icon-link i {
                    font-size: 16px !important;
                }
            }

            /* ضمان ظهور الأيقونات دائماً (حتى لو CSS الموجود يعارض) */
            .header-icons .icon-link i,
            .header-icons .icon-link i.far,
            .header-icons .icon-link i.fas,
            .header-icons .icon-link i.fab,
            .header-icons .icon-link i.fa-heart,
            .header-icons .icon-link i.fa-user,
            .header-icons .icon-link i.fa-shopping-bag,
            .header-icons .icon-link i.fa-shopping-cart,
            .header-icons .cart-icon i,
            .header-icons .user-dropdown .icon-link i {
                display: inline-block !important;
                visibility: visible !important;
                opacity: 1 !important;
                color: inherit !important;
                font-size: 18px !important;
                width: auto !important;
                height: auto !important;
                line-height: 1 !important;
                text-indent: 0 !important;
                overflow: visible !important;
                position: static !important;
                background: none !important;
                text-align: center !important;
            }

            /* ضمان ظهور الأيقونات على الهاتف فقط - متجاوب */
            @media (max-width: 768px) {
                /* إظهار الحاوية الأم للأيقونات */
                .header-icons,
                .main-header .header-icons,
                header.main-header .header-icons,
                .container .header-icons {
                    display: flex !important;
                    flex-direction: row !important;
                    align-items: center !important;
                    justify-content: flex-end !important;
                    gap: 8px !important;
                    visibility: visible !important;
                    opacity: 1 !important;
                    width: auto !important;
                    height: auto !important;
                    overflow: visible !important;
                    position: static !important;
                    margin: 0 !important;
                    padding: 0 !important;
                }

                /* كل رابط أيقونة يظهر كدائرة واضحة */
                .header-icons .icon-link,
                .main-header .header-icons .icon-link,
                .header-icons .cart-icon,
                .header-icons a.icon-link {
                    display: inline-flex !important;
                    visibility: visible !important;
                    opacity: 1 !important;
                    width: 38px !important;
                    height: 38px !important;
                    border-radius: 50% !important;
                    background: rgba(255, 255, 255, 0.95) !important;
                    color: #2c3e50 !important;
                    align-items: center !important;
                    justify-content: center !important;
                    text-decoration: none !important;
                    position: relative !important;
                    overflow: visible !important;
                    margin: 0 !important;
                    padding: 0 !important;
                    box-shadow: 0 2px 6px rgba(0, 0, 0, 0.08) !important;
                    flex-shrink: 0 !important;
                }

                /* الأيقونات داخل الروابط */
                .header-icons .icon-link i,
                .header-icons .icon-link i::before,
                .header-icons .cart-icon i,
                .header-icons .cart-icon i::before {
                    display: inline-block !important;
                    visibility: visible !important;
                    opacity: 1 !important;
                    font-size: 17px !important;
                    color: #2c3e50 !important;
                    width: auto !important;
                    height: auto !important;
                    line-height: 1 !important;
                    text-indent: 0 !important;
                    overflow: visible !important;
                    position: static !important;
                    background: none !important;
                    text-align: center !important;
                    -webkit-text-fill-color: #2c3e50 !important;
                    flex-shrink: 0 !important;
                }

                /* تنسيق الأيقونات عند المرور عليها */
                .header-icons .icon-link:hover,
                .header-icons .cart-icon:hover {
                    background: #ff6b8b !important;
                    color: #fff !important;
                    transform: translateY(-2px) !important;
                }

                .header-icons .icon-link:hover i,
                .header-icons .cart-icon:hover i {
                    color: #fff !important;
                    -webkit-text-fill-color: #fff !important;
                }

                /* شارة عدد منتجات السلة */
                .header-icons .cart-count,
                .header-icons .cart-icon .cart-count {
                    position: absolute !important;
                    top: -5px !important;
                    inset-inline-end: -5px !important;
                    background: #ff6b8b !important;
                    color: #fff !important;
                    font-size: 11px !important;
                    min-width: 18px !important;
                    height: 18px !important;
                    border-radius: 50% !important;
                    display: inline-flex !important;
                    align-items: center !important;
                    justify-content: center !important;
                    padding: 0 5px !important;
                    font-weight: 700 !important;
                    line-height: 1 !important;
                    border: 2px solid #fff !important;
                    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2) !important;
                    z-index: 10 !important;
                    inset-inline-start: auto !important;
                    inset-inline-end: -5px !important;
                    left: auto !important;
                    right: -5px !important;
                    visibility: visible !important;
                    opacity: 1 !important;
                }

                /* user-dropdown على الهاتف */
                .header-icons .user-dropdown,
                .header-icons .user-dropdown .icon-link {
                    display: inline-flex !important;
                    visibility: visible !important;
                    opacity: 1 !important;
                    position: relative !important;
                }

                /* محتوى القائمة المنسدلة */
                .header-icons .user-dropdown .dropdown-content {
                    position: absolute !important;
                    top: 100% !important;
                    inset-inline-end: 0 !important;
                    min-width: 180px !important;
                    background: #fff !important;
                    box-shadow: 0 4px 14px rgba(0, 0, 0, 0.15) !important;
                    border-radius: 8px !important;
                    padding: 8px 0 !important;
                    z-index: 1100 !important;
                    display: none !important;
                }

                /* على الهاتف: لا تظهر القائمة المنسدلة أبداً — زر الحساب ينقل مباشرة لصفحة الحساب */
                .header-icons .user-dropdown:hover .dropdown-content,
                .header-icons .user-dropdown:focus-within .dropdown-content,
                .header-icons .user-dropdown .dropdown-content.show {
                    display: none !important;
                }

                .header-icons .user-dropdown .dropdown-content a {
                    display: flex !important;
                    align-items: center !important;
                    gap: 8px !important;
                    padding: 10px 16px !important;
                    color: #2c3e50 !important;
                    text-decoration: none !important;
                    font-size: 14px !important;
                    background: #fff !important;
                    width: auto !important;
                    border-radius: 0 !important;
                    box-shadow: none !important;
                }

                .header-icons .user-dropdown .dropdown-content a:hover {
                    background: #f8f9fa !important;
                    color: #ff6b8b !important;
                }

                .header-icons .user-dropdown .dropdown-content a i {
                    font-size: 14px !important;
                    width: 18px !important;
                    text-align: center !important;
                    color: inherit !important;
                    -webkit-text-fill-color: currentColor !important;
                }

                .header-icons .guest-welcome {
                    display: block !important;
                    padding: 10px 16px !important;
                    color: #6c757d !important;
                    font-size: 13px !important;
                    border-bottom: 1px solid #e9ecef !important;
                    margin-bottom: 4px !important;
                }
            }

            /* شاشات أصغر (480px وأقل) */
            @media (max-width: 480px) {
                .header-icons {
                    gap: 6px !important;
                }
                .header-icons .icon-link {
                    width: 34px !important;
                    height: 34px !important;
                }
                .header-icons .icon-link i,
                .header-icons .cart-icon i {
                    font-size: 15px !important;
                }
            }

            /* على الهاتف، يجب أن يكون هناك زر هامبرغر واضح أيضاً */
            @media (max-width: 768px) {
                .mobile-nav {
                    display: block !important;
                }
                .mobile-nav-icon {
                    width: 50px !important;
                    height: 50px !important;
                    background: linear-gradient(135deg, #ff6b6b, #ee5a52) !important;
                    border-radius: 50% !important;
                    display: flex !important;
                    flex-direction: column !important;
                    justify-content: center !important;
                    align-items: center !important;
                    cursor: pointer !important;
                    box-shadow: 0 4px 14px rgba(255, 107, 107, 0.4) !important;
                }
                .mobile-nav-icon .nav-icon-line {
                    background: #fff !important;
                    display: block !important;
                    visibility: visible !important;
                    opacity: 1 !important;
                }
            }
        </style>
    </head>

    <body>
        <!-- شريط التنبيهات العلوي -->
        <div class="top-bar" style="background-color: <?= $alert_settings['alert_bg_color'] ?>; color: <?= $alert_settings['alert_text_color'] ?>;">
            <div class="container">
                <div class="offer-text">
                    <i class="fas fa-gift"></i> <span class="offer-text-content"><?= $alert_settings['alert_text'] ?></span>
                </div>
                <div class="top-links">
                    <a href="<?php echo SITE_URL; ?>pages/track-order.php" title="تتبع طلبك"><i class="fas fa-truck"></i> <span>تتبع طلبك</span></a>
                    <a href="<?php echo SITE_URL; ?>pages/contact.php" title="المساعدة"><i class="fas fa-headset"></i> <span>المساعدة</span></a>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <!-- الهيدر الرئيسي -->
    <header class="main-header">
        <div class="container">
            <!-- شعار المتجر -->
            <div class="logo">
                <a href="<?php echo SITE_URL; ?>">
                    <img src="<?php echo SITE_URL; ?>assets/images/logo.png" alt="ماريا">
                </a>
            </div>

            <!-- شريط البحث -->
            <div class="search-bar">
                <form action="<?php echo SITE_URL; ?>pages/search.php" method="get" class="search-form">
                    <input type="text" name="q" id="search-input"
                        placeholder="ابحثي عن منتجاتك المفضلة..."
                        class="search-input"
                        autocomplete="off">
                    <button type="submit" class="search-btn" aria-label="بحث">
                        <i class="fas fa-search"></i>
                    </button>
                    <div class="search-suggestions" id="search-suggestions"></div>
                </form>
            </div>

            <!-- أيقونات المستخدم والسلة -->
            <div class="header-icons">
                <a href="<?php echo SITE_URL; ?>pages/wishlist.php" class="icon-link" title="المفضلة">
                    <i class="far fa-heart"></i>
                </a>

                <div class="user-dropdown">
                    <a href="<?php echo SITE_URL; ?>pages/profile.php" class="icon-link" title="حسابي">
                        <i class="far fa-user"></i>
                    </a>
                    <div class="dropdown-content">
                        <?php if (isset($_SESSION['user_id'])): ?>
                            <a href="<?php echo SITE_URL; ?>pages/profile.php"><i class="fas fa-user-circle"></i> حسابي</a>
                            <a href="<?php echo SITE_URL; ?>pages/orders_user.php"><i class="fas fa-box-open"></i> طلباتي</a>
                            <a href="<?php echo SITE_URL; ?>includes/logout.php"><i class="fas fa-sign-out-alt"></i> تسجيل خروج</a>
                        <?php elseif (isset($_SESSION['guest_id'])): ?>
                            <span class="guest-welcome">مرحباً، زائر</span>
                            <a href="<?php echo SITE_URL; ?>pages/register.php"><i class="fas fa-user-plus"></i> إنشاء حساب</a>
                            <a href="<?php echo SITE_URL; ?>pages/login.php"><i class="fas fa-sign-in-alt"></i> تسجيل دخول</a>
                        <?php else: ?>
                            <a href="<?php echo SITE_URL; ?>pages/login.php"><i class="fas fa-sign-in-alt"></i> تسجيل دخول</a>
                            <a href="<?php echo SITE_URL; ?>pages/register.php"><i class="fas fa-user-plus"></i> إنشاء حساب</a>
                        <?php endif; ?>
                    </div>
                </div>

                <a href="<?php echo SITE_URL; ?>pages/cart.php" class="icon-link cart-icon" title="سلة التسوق">
                    <i class="fas fa-shopping-bag"></i>
                    <span class="cart-count">
                        <?php
                        $count = 0;
                        if (isset($_SESSION['user_id'])) {
                            try {
                                if ($conn) {
                                    // 1. احصل على cart_id من جدول carts باستخدام user_id
                                    $stmt = $conn->prepare("SELECT id FROM carts WHERE user_id = ?");
                                    $stmt->execute([$_SESSION['user_id']]);
                                    $cart = $stmt->fetch(PDO::FETCH_ASSOC);

                                    if ($cart && isset($cart['id'])) {
                                        // 2. احسب عدد المنتجات في cart_items باستخدام cart_id
                                        $stmt = $conn->prepare("SELECT COALESCE(SUM(quantity), 0) AS total_items FROM cart_items WHERE cart_id = ?");
                                        $stmt->execute([$cart['id']]);
                                        $result = $stmt->fetch(PDO::FETCH_ASSOC);
                                        $count = (int)$result['total_items'];
                                    }
                                }
                            } catch (PDOException $e) {
                                echo "0"; // خطأ في الاستعلام
                            }
                        }
                        // حساب عناصر سلة الزائر
                        elseif (isset($_SESSION['guest_id']) && isset($_SESSION['guest_cart'])) {
                            foreach ($_SESSION['guest_cart'] as $item) {
                                $count += $item['quantity'];
                            }
                        }
                        echo $count;
                        ?>
                    </span>
                </a>
            </div>
        </div>
    </header>

    <!-- القائمة الرئيسية -->
    <nav class="main-nav">
        <div class="container">
            <ul class="nav-list">
                <li><a href="<?php echo SITE_URL; ?>">الرئيسية</a></li>
                <!-- <li><a href="<?php echo SITE_URL; ?>admin/add_product.php">اضافه منتج</a></li> -->
                <!-- <li><a href="<?php echo SITE_URL; ?>admin/manage_products.php">تعديل منتج</a></li> -->
                <li class="dropdown">
                    <a href="<?php echo SITE_URL; ?>pages/products.php">المنتجات</a>
                    <div class="mega-menu">
                        <div class="mega-menu-content">
                            <?php
                            // جلب جميع التصنيفات
                            $stmt = $conn->query("SELECT * FROM categories ORDER BY name");
                            $categories = $stmt->fetchAll(PDO::FETCH_ASSOC);

                            // تقسيم التصنيفات إلى مجموعات لعرضها في أعمدة
                            $chunked_categories = array_chunk($categories, ceil(count($categories) / 2));
                            ?>

                            <div class="row">
                                <?php
                                // جلب الأقسام الرئيسية مع تصنيفاتها الفرعية
                                $stmt = $conn->query("
                                    SELECT c1.id as main_id, c1.name as main_name, 
                                        c2.id as sub_id, c2.name as sub_name
                                    FROM categories c1
                                    LEFT JOIN categories c2 ON c2.parent_id = c1.id
                                    WHERE c1.parent_id IS NULL
                                    ORDER BY c1.name, c2.name
                                ");
                                $categories = $stmt->fetchAll();

                                // تجميع البيانات حسب الأقسام الرئيسية
                                $grouped = [];
                                foreach ($categories as $cat) {
                                    if (!isset($grouped[$cat['main_id']])) {
                                        $grouped[$cat['main_id']] = [
                                            'name' => $cat['main_name'],
                                            'subs' => []
                                        ];
                                    }
                                    if ($cat['sub_id']) {
                                        $grouped[$cat['main_id']]['subs'][] = [
                                            'id' => $cat['sub_id'],
                                            'name' => $cat['sub_name']
                                        ];
                                    }
                                }

                                // عرض الأقسام في أعمدة
                                $chunked = array_chunk($grouped, ceil(count($grouped) / 2), true);

                                foreach ($chunked as $column): ?>
                                    <div class="mega-menu-section">
                                        <?php foreach ($column as $main_id => $main): ?>
                                            <h4 class="section-title"><?= $main['name'] ?></h4>
                                            <ul class="section-links">
                                                <?php foreach ($main['subs'] as $sub): ?>
                                                    <li><a href="<?php echo SITE_URL; ?>pages/products.php?category_id=<?= $sub['id'] ?>"><?= $sub['name'] ?></a></li>
                                                <?php endforeach; ?>
                                            </ul>
                                        <?php endforeach; ?>
                                    </div>
                                <?php endforeach; ?>
                            </div>

                            <!-- قسم العروض الثابت -->
                            <div class="mega-menu-section">
                                <h4 class="section-title"><i class="fas fa-tag"></i> العروض</h4>
                                <ul class="section-links">
                                    <li><a href="<?php echo SITE_URL; ?>pages/products.php?discount=1">خصومات</a></li>
                                    <!-- <li><a href="<?php echo SITE_URL; ?>pages/new-arrivals.php">وصل حديثاً</a></li> -->
                                    <!-- <li><a href="<?php echo SITE_URL; ?>pages/best-sellers.php">الأكثر مبيعاً</a></li> -->
                                </ul>
                            </div>

                            <!-- بانر العرض -->
                            <div class="mega-menu-banner">
                                <img src="<?php echo SITE_URL; ?>assets/images/banners/686a1e45d4421.png" alt="عرض خاص">
                                <div class="banner-overlay">
                                    <h3>خصم 30%</h3>
                                    <p>على تشكيلة الصيف الجديدة</p>
                                    <a href="<?php echo SITE_URL; ?>pages/summer-sale.php" class="btn">تسوق الآن</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </li>
                <li><a href="<?php echo SITE_URL; ?>pages/about.php">عن ماريا</a></li>
                <li><a href="<?php echo SITE_URL; ?>pages/blog.php">المدونة</a></li>
                <li><a href="<?php echo SITE_URL; ?>pages/contact.php">اتصل بنا</a></li>
            </ul>
        </div>
    </nav>

    <!-- قائمة الهاتف المتحركة -->
    <div class="mobile-nav">
        <div class="mobile-nav-icon">
            <span class="nav-icon-line"></span>
            <span class="nav-icon-line"></span>
            <span class="nav-icon-line"></span>
        </div>

        <div class="mobile-nav-overlay"></div>

        <div class="mobile-nav-content">
            <div class="mobile-nav-header">
                <div class="mobile-nav-logo">
                    <a href="<?php echo SITE_URL; ?>">
                        <img src="<?php echo SITE_URL; ?>assets/images/logo.png" alt="ماريا">
                    </a>
                </div>
                <div class="mobile-nav-close">
                    <i class="fas fa-times"></i>
                </div>
            </div>

            <div class="mobile-nav-body">
                <ul class="mobile-main-menu">
                    <li>
                        <a href="<?php echo SITE_URL; ?>">
                            <i class="fas fa-home"></i>
                            الرئيسية
                        </a>
                    </li>

                    <li class="mobile-menu-dropdown">
                        <div class="menu-item-container">
                            <a href="<?php echo SITE_URL; ?>pages/products.php" class="menu-link">
                                <i class="fas fa-box"></i>
                                المنتجات
                            </a>
                            <span class="menu-toggle-arrow">
                                <i class="fas fa-chevron-down toggle-icon"></i>
                            </span>
                        </div>
                        <ul class="mobile-sub-menu">
                            <?php
                            // نفس الاستعلام من نسخة الكمبيوتر
                            $stmt = $conn->query("
                            SELECT c1.id as main_id, c1.name as main_name, 
                                   c2.id as sub_id, c2.name as sub_name
                            FROM categories c1
                            LEFT JOIN categories c2 ON c2.parent_id = c1.id
                            WHERE c1.parent_id IS NULL
                            ORDER BY c1.name, c2.name
                        ");
                            $categories = $stmt->fetchAll();

                            $grouped = [];
                            foreach ($categories as $cat) {
                                if (!isset($grouped[$cat['main_id']])) {
                                    $grouped[$cat['main_id']] = [
                                        'name' => $cat['main_name'],
                                        'subs' => []
                                    ];
                                }
                                if ($cat['sub_id']) {
                                    $grouped[$cat['main_id']]['subs'][] = [
                                        'id' => $cat['sub_id'],
                                        'name' => $cat['sub_name']
                                    ];
                                }
                            }

                            // عرض القائمة (رئيسي + فرعي)
                            foreach ($grouped as $main_id => $main) {
                                echo '<li class="mobile-sub-dropdown">';
                                echo '<div class="menu-item-container">';
                                echo '<a href="' . SITE_URL . 'pages/products.php?category_id=' . $main_id . '" class="submenu-link">';
                                echo '<i class="fas fa-folder"></i>';
                                echo $main['name'];
                                echo '</a>';
                                if (!empty($main['subs'])) {
                                    echo '<span class="submenu-toggle-arrow">';
                                    echo '<i class="fas fa-chevron-down toggle-icon"></i>';
                                    echo '</span>';
                                }
                                echo '</div>';

                                if (!empty($main['subs'])) {
                                    echo '<ul class="mobile-submenu-level2">';
                                    foreach ($main['subs'] as $sub) {
                                        echo '<li>';
                                        echo '<a href="' . SITE_URL . 'pages/products.php?category_id=' . $sub['id'] . '">';
                                        echo '<i class="fas fa-arrow-left"></i>';
                                        echo $sub['name'];
                                        echo '</a>';
                                        echo '</li>';
                                    }
                                    echo '</ul>';
                                }
                                echo '</li>';
                            }
                            ?>

                            <!-- قسم العروض -->
                            <li class="mobile-sub-dropdown">
                                <div class="menu-item-container">
                                    <a href="<?php echo SITE_URL; ?>pages/products.php?discount=1" class="submenu-link">
                                        <i class="fas fa-tag"></i>
                                        العروض
                                    </a>
                                    <span class="submenu-toggle-arrow">
                                        <i class="fas fa-chevron-down toggle-icon"></i>
                                    </span>
                                </div>
                                <ul class="mobile-submenu-level2">
                                    <li>
                                        <a href="<?php echo SITE_URL; ?>pages/products.php?discount=1">
                                            <i class="fas fa-percentage"></i>
                                            منتجات مخفضة
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo SITE_URL; ?>pages/new-arrivals.php">
                                            <i class="fas fa-star"></i>
                                            وصل حديثاً
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo SITE_URL; ?>pages/best-sellers.php">
                                            <i class="fas fa-fire"></i>
                                            الأكثر مبيعاً
                                        </a>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                    </li>

                    <li>
                        <a href="<?php echo SITE_URL; ?>pages/about.php">
                            <i class="fas fa-info-circle"></i>
                            عن ماريا
                        </a>
                    </li>

                    <li>
                        <a href="<?php echo SITE_URL; ?>pages/blog.php">
                            <i class="fas fa-blog"></i>
                            المدونة
                        </a>
                    </li>

                    <li>
                        <a href="<?php echo SITE_URL; ?>pages/contact.php">
                            <i class="fas fa-phone"></i>
                            اتصل بنا
                        </a>
                    </li>
                </ul>

                <div class="mobile-nav-footer">
                    <div class="mobile-social-links">
                        <a href="https://www.instagram.com/maria_stores1/" target="_blank" class="social-link"><i class="fab fa-instagram"></i></a>
                        <a href="https://www.facebook.com/mariastores1?_rdr" target="_blank" class="social-link"><i class="fab fa-facebook"></i></a>
                    </div>

                    <div class="mobile-contact-info">
                        <p><i class="fas fa-phone"></i> <span dir="ltr">+967 775 616 559</span></p>
                        <p><i class="fas fa-envelope"></i> mariastore.ye@gmail.com‏</p>
                    </div>
                </div>
            </div>
        </div>
    </div>



    <script>
        // ✅ v2.7: تحسين فتح القائمة - يعمل حتى لو DOMContentLoaded أُطلق قبل تسجيل السكريبت
        function initMobileNav() {
            const mobileNavIcon = document.querySelector('.mobile-nav-icon');
            const mobileNavClose = document.querySelector('.mobile-nav-close');
            const mobileNavContent = document.querySelector('.mobile-nav-content');
            const mobileNavOverlay = document.querySelector('.mobile-nav-overlay');
            const toggleArrows = document.querySelectorAll('.menu-toggle-arrow, .submenu-toggle-arrow');

            if (!mobileNavIcon) {
                console.warn('[MobileNav] .mobile-nav-icon not found');
                return;
            }
            if (!mobileNavContent) {
                console.warn('[MobileNav] .mobile-nav-content not found');
                return;
            }

            console.log('[MobileNav] Initializing...');

            // ✅ منع التسجيل المزدوج
            if (mobileNavIcon.dataset.initialized === '1') {
                console.log('[MobileNav] Already initialized, skipping');
                return;
            }
            mobileNavIcon.dataset.initialized = '1';

            // ✅ فتح القائمة - نستخدم click + touchstart للموبايل
            function openMobileNav(e) {
                if (e) {
                    e.preventDefault();
                    e.stopPropagation();
                }
                console.log('[MobileNav] Opening menu');
                mobileNavContent.classList.add('active');
                mobileNavOverlay.classList.add('active');
                document.body.style.overflow = 'hidden';
            }

            mobileNavIcon.addEventListener('click', openMobileNav);
            // ✅ touchstart للاستجابة الفورية على الهاتف (بدون 300ms delay)
            mobileNavIcon.addEventListener('touchstart', function(e) {
                e.preventDefault();
                openMobileNav(e);
            }, { passive: false });

            // إغلاق القائمة
            function closeMobileNav() {
                mobileNavContent.classList.remove('active');
                mobileNavOverlay.classList.remove('active');
                document.body.style.overflow = '';

                // إغلاق جميع القوائم الفرعية
                document.querySelectorAll('.mobile-sub-menu, .mobile-submenu-level2').forEach(menu => {
                    menu.classList.remove('active');
                });

                // إعادة ضبط الأسهم
                document.querySelectorAll('.toggle-icon').forEach(icon => {
                    icon.classList.remove('rotate');
                });
            }

            mobileNavClose.addEventListener('click', closeMobileNav);
            mobileNavOverlay.addEventListener('click', closeMobileNav);

            // التعامل مع أسهم التوسيع/الطي
            toggleArrows.forEach(arrow => {
                arrow.addEventListener('click', function(e) {
                    e.stopPropagation();

                    const toggleIcon = this.querySelector('.toggle-icon');
                    let targetMenu;

                    if (this.classList.contains('menu-toggle-arrow')) {
                        targetMenu = this.closest('.mobile-menu-dropdown').querySelector('.mobile-sub-menu');
                    } else if (this.classList.contains('submenu-toggle-arrow')) {
                        targetMenu = this.closest('.mobile-sub-dropdown').querySelector('.mobile-submenu-level2');
                    }

                    if (targetMenu) {
                        const isActive = targetMenu.classList.contains('active');

                        // إغلاق القوائم الأخرى في نفس المستوى
                        if (targetMenu.classList.contains('mobile-sub-menu')) {
                            document.querySelectorAll('.mobile-sub-menu').forEach(menu => {
                                if (menu !== targetMenu) {
                                    menu.classList.remove('active');
                                    menu.previousElementSibling.querySelector('.toggle-icon')?.classList.remove('rotate');
                                }
                            });
                        } else if (targetMenu.classList.contains('mobile-submenu-level2')) {
                            const parent = targetMenu.closest('.mobile-sub-menu');
                            parent.querySelectorAll('.mobile-submenu-level2').forEach(menu => {
                                if (menu !== targetMenu) {
                                    menu.classList.remove('active');
                                    menu.previousElementSibling.querySelector('.toggle-icon')?.classList.remove('rotate');
                                }
                            });
                        }

                        // تبديل الحالة الحالية
                        targetMenu.classList.toggle('active', !isActive);

                        if (toggleIcon) {
                            toggleIcon.classList.toggle('rotate', !isActive);
                        }
                    }
                });
            });

            // إغلاق القائمة عند النقر على رابط عادي
            document.querySelectorAll('.menu-link, .submenu-link, .mobile-main-menu > li > a').forEach(link => {
                link.addEventListener('click', closeMobileNav);
            });

            // منع إغلاق القائمة عند النقر داخل القائمة
            mobileNavContent.addEventListener('click', function(e) {
                e.stopPropagation();
            });

            console.log('[MobileNav] Initialized successfully');
        }

        // ✅ استدعاء initMobileNav عند تحميل DOM
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', initMobileNav);
        } else {
            // DOM جاهز بالفعل
            initMobileNav();
        }
    </script>


    <!-- المحتوى الرئيسي -->
    <main>


        <!-- <script>
            // الاقتراحات التلقائية للبحث
            document.addEventListener('DOMContentLoaded', function() {
                const searchInput = document.getElementById('search-input');
                const searchSuggestions = document.getElementById('search-suggestions');
                let debounceTimer;

                searchInput.addEventListener('input', function() {
                    clearTimeout(debounceTimer);
                    const query = this.value.trim();

                    if (query.length < 2) {
                        searchSuggestions.style.display = 'none';
                        return;
                    }

                    debounceTimer = setTimeout(() => {
                        fetch(`<?php echo SITE_URL; ?>includes/autocomplete.php?q=${encodeURIComponent(query)}`)
                            .then(response => response.json())
                            .then(data => {
                                if (data.length > 0) {
                                    searchSuggestions.innerHTML = '';
                                    data.forEach(item => {
                                        const suggestion = document.createElement('div');
                                        suggestion.className = 'search-suggestion';
                                        suggestion.innerHTML = `
                                <img src="<?php echo SITE_URL; ?>assets/images/${item.image || 'default-product-image.jpg'}" alt="${item.name}">
                                <div class="product-info">
                                    <div class="product-name">${item.name}</div>
                                    <div class="product-price">${item.price} ر.ي</div>
                                </div>
                            `;
                                        suggestion.addEventListener('click', () => {
                                            searchInput.value = item.name;
                                            searchSuggestions.style.display = 'none';
                                            document.querySelector('.search-form').submit();
                                        });
                                        searchSuggestions.appendChild(suggestion);
                                    });
                                    searchSuggestions.style.display = 'block';
                                } else {
                                    searchSuggestions.style.display = 'none';
                                }
                            })
                            .catch(error => {
                                console.error('Error:', error);
                                searchSuggestions.style.display = 'none';
                            });
                    }, 300);
                });

                // إغلاق الاقتراحات عند النقر خارجها
                document.addEventListener('click', function(e) {
                    if (!searchInput.contains(e.target) && !searchSuggestions.contains(e.target)) {
                        searchSuggestions.style.display = 'none';
                    }
                });

                // إظهار الاقتراحات عند التركيز على حقل البحث
                searchInput.addEventListener('focus', function() {
                    if (this.value.trim().length >= 2 && searchSuggestions.innerHTML !== '') {
                        searchSuggestions.style.display = 'block';
                    }
                });

                // إرسال النموذج عند الضغط على Enter
                searchInput.addEventListener('keydown', function(e) {
                    if (e.key === 'Enter') {
                        searchSuggestions.style.display = 'none';
                    }
                });
            });
        </script> -->

        <!-- كود اداره الضغط لاظهار القائمه في الهواتف -->

        <script>
            // عند تحميل الصفحة
            document.addEventListener("DOMContentLoaded", function() {
                const dropdowns = document.querySelectorAll(".mobile-sub-dropdown > a");

                dropdowns.forEach(link => {
                    link.addEventListener("click", function(e) {
                        e.preventDefault(); // منع الانتقال المباشر

                        const parentLi = this.parentElement;

                        // إغلاق القوائم الأخرى (اختياري)
                        document.querySelectorAll(".mobile-sub-dropdown").forEach(li => {
                            if (li !== parentLi) {
                                li.classList.remove("active");
                            }
                        });

                        // تبديل الحالة للقائمة الحالية
                        parentLi.classList.toggle("active");
                    });
                });
            });
        </script>



        <!--حقل البحث-->

        <script>
            document.addEventListener('DOMContentLoaded', function() {
                const searchInput = document.getElementById('search-input');
                const searchSuggestions = document.getElementById('search-suggestions');
                let debounceTimer;

                // ✅ فحص وجود حقل البحث قبل إضافة الأحداث
                if (!searchInput) return;

                // عرض المنتجات المميزة عند التركيز على حقل البحث
                searchInput.addEventListener('focus', function() {
                    if (this.value.trim() === '') {
                        fetchFeaturedProducts();
                    }
                });

                function fetchFeaturedProducts() {
                    fetch('<?php echo SITE_URL; ?>includes/featured_products.php')
                        .then(response => response.json())
                        .then(data => {
                            if (data.length > 0) {
                                renderSuggestions(data, 'منتجات مميزة');
                            }
                        });
                }

                // دالة لعرض الاقتراحات
                function renderSuggestions(items, title) {
                    searchSuggestions.innerHTML = `
                        <div class="suggestions-header">
                            <span>${title}</span>
                        </div>
                    `;

                    items.forEach(item => {
                        const suggestion = document.createElement('div');
                        suggestion.className = 'search-suggestion';

                        // إصلاح مسار الصورة
                        const imagePath = item.image ?
                            `<?php echo SITE_URL; ?>assets/images/${item.image}` :
                            `<?php echo SITE_URL; ?>assets/images/default-product-image.jpg`;

                        suggestion.innerHTML = `
                            <img src="${imagePath}" alt="${item.name}" 
                                onerror="this.src='<?php echo SITE_URL; ?>assets/images/default-product-image.jpg'">
                            <div class="product-info">
                                <div class="product-name">${item.name}</div>
                                <div class="product-price">${item.price} ر.ي</div>
                            </div>
                        `;

                        suggestion.addEventListener('click', () => {
                            if (title === 'منتجات مميزة') {
                                window.location.href = `<?php echo SITE_URL; ?>pages/details_product.php?id=${item.id}`;
                            } else {
                                searchInput.value = item.name;
                                searchSuggestions.style.display = 'none';
                                document.querySelector('.search-form').submit();
                            }
                        });

                        searchSuggestions.appendChild(suggestion);
                    });

                    searchSuggestions.style.display = 'block';
                }

                // باقي كود الاقتراحات التلقائية...
                searchInput.addEventListener('input', function() {
                    clearTimeout(debounceTimer);
                    const query = this.value.trim();

                    if (query.length < 2) {
                        searchSuggestions.style.display = 'none';
                        return;
                    }

                    debounceTimer = setTimeout(() => {
                        fetch(`<?php echo SITE_URL; ?>includes/autocomplete.php?q=${encodeURIComponent(query)}`)
                            .then(response => response.json())
                            .then(data => {
                                if (data.length > 0) {
                                    renderSuggestions(data, 'نتائج البحث');
                                }
                            });
                    }, 300);
                });

                // إغلاق الاقتراحات عند النقر خارجها
                document.addEventListener('click', function(e) {
                    if (!searchInput.contains(e.target) && !searchSuggestions.contains(e.target)) {
                        searchSuggestions.style.display = 'none';
                    }
                });

                // إرسال النموذج عند الضغط على Enter
                searchInput.addEventListener('keydown', function(e) {
                    if (e.key === 'Enter') {
                        searchSuggestions.style.display = 'none';
                    }
                });
            });
        </script>

        <!-- زر الحساب على الهاتف: انتقال مباشر لصفحة الحساب بدون قائمة منسدلة -->
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                /*
                 * تم تعطيل القائمة المنسدلة لحساب المستخدم على شاشات الهاتف.
                 * الضغط على زر الحساب ينقل الآن مباشرة إلى pages/profile.php
                 * (الرابط موجود في href الخاص بالزر ولا يتم اعتراضه بـ preventDefault).
                 * على شاشات الكمبيوتر: القائمة المنسدلة تظهر عند مرور المؤشر (hover) كالمعتاد.
                 */
            });
        </script>
        <!-- هاذا لاستخدام SITE_URL في صفحات JS -->
        <script>
            // ✅ استخدام window.SITE_URL بدلاً من const لتجنب التعارض
            if (typeof window.SITE_URL === 'undefined') {
                window.SITE_URL = "<?php echo SITE_URL; ?>";
            }
        </script>

        <!-- ✅ إعدادات نظام الإشعارات -->
        <?php
        try {
            require_once __DIR__ . '/notifications.php';
            $notifMgr = new NotificationsManager($conn);
            $notify_sound = $notifMgr->getSetting('notify_sound', '1');
            $notify_dismiss = $notifMgr->getSetting('notify_auto_dismiss_seconds', '8');
        } catch (Exception $e) {
            $notify_sound = '1';
            $notify_dismiss = '8';
        }
        ?>
        <meta name="notify-sound" content="<?php echo htmlspecialchars($notify_sound); ?>">
        <meta name="notify-auto-dismiss" content="<?php echo htmlspecialchars($notify_dismiss); ?>">
        <?php
        // ✅ توليد CSRF token للإشعارات (للتحقق من POST requests)
        if (session_status() === PHP_SESSION_NONE) { session_start(); }
        if (empty($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }
        ?>
        <meta name="csrf-token" content="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
        
        <!-- بدلاً من كود الاقتراحات الطويل، استبدله بـ: -->
        <script src="<?php echo SITE_URL; ?>assets/js/search_suggestions.js"></script>
        
        <!-- ✅ نظام الإشعارات الأصلي (VAPID + Web Push) -->
        <script src="<?php echo SITE_URL; ?>assets/js/notifications.js?v=<?php echo filemtime(__DIR__ . '/../assets/js/notifications.js'); ?>"></script>

        <!-- ✅ PWA Install Prompt - لتثبيت الموقع كتطبيق (يحسن وصول الإشعارات على الهاتف) -->
        <script src="<?php echo SITE_URL; ?>assets/js/pwa-install.js?v=<?php echo filemtime(__DIR__ . '/../assets/js/pwa-install.js'); ?>"></script>
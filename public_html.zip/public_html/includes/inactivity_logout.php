 <!-- هاذا الكود لتسجيل خروج المستخدم الغير نشط -->

 <?php
    require_once __DIR__ . '/../includes/db_connect.php';

    // مدة انتهاء الجلسة بعد عدم النشاط بالثواني
    $timeout = 86400; // يوم بالثواني

    if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > $timeout)) {
        session_unset();
        session_destroy();
    }

    $_SESSION['last_activity'] = time();
    ?>

 <style>
     .logout-warning {
         display: none;
         position: fixed;
         top: 50%;
         left: 50%;
         transform: translate(-50%, -50%);
         background: white;
         padding: 30px;
         border-radius: 15px;
         box-shadow: 0 5px 25px rgba(0, 0, 0, 0.3);
         z-index: 1000;
         text-align: center;
         width: 90%;
         max-width: 400px;
         border: 2px solid #e74c3c;
     }

     .overlay {
         display: none;
         position: fixed;
         top: 0;
         left: 0;
         width: 100%;
         height: 100%;
         background: rgba(0, 0, 0, 0.6);
         z-index: 999;
     }

     .inactivity-timer {
         position: fixed;
         bottom: 20px;
         left: 20px;
         background: rgba(231, 76, 60, 0.9);
         color: white;
         padding: 10px 15px;
         border-radius: 50px;
         font-size: 14px;
         display: none;
         z-index: 100;
         box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
     }

     @media (max-width:768px) {
         .inactivity-timer {
             bottom: 10px;
             left: 10px;
             right: 10px;
             text-align: center;
         }
     }
 </style>

 <!-- مؤشر عدم النشاط -->
 <div class="inactivity-timer" id="inactivityTimer">
     <i class="fas fa-clock me-2"></i> سيتم تسجيل الخروج خلال: <span id="countdown">05:00</span>
 </div>

 <div class="overlay" id="overlay"></div>
 <div class="logout-warning" id="logoutWarning">
     <div class="warning-icon mb-3">
         <i class="fas fa-exclamation-triangle fa-3x text-danger"></i>
     </div>
     <h2 class="text-danger">تحذير!</h2>
     <p class="my-3">سيتم تسجيل خروجك تلقائياً بسبب عدم النشاط</p>
     <div class="timer mb-3">
         المتبقي: <span id="warningCountdown" class="fw-bold">00:30</span>
     </div>
     <button class="btn btn-primary w-100" onclick="stayLoggedIn()">
         <i class="fas fa-check me-2"></i> البقاء مسجلاً
     </button>
 </div>
 
 <script>
     const SITE_URL = "<?php echo SITE_URL; ?>";
 </script>
 <script src="<?php echo SITE_URL; ?>assets/js/inactivity_logout.js"></script>